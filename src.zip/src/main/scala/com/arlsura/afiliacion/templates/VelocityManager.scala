package com.arlsura.afiliacion.templates

import java.io.StringWriter
import java.util.Properties

import org.apache.velocity.{ Template, VelocityContext }
import org.apache.velocity.app.VelocityEngine

/**
 * Contiene datos acerca de velocity, plantillas y expone operaciones para trabajar con el VelocityEngine o para llenar un template diretamente
 * Created by root on 18/12/14.
 */
object VelocityManager {

  val templatesPath = "templates/"

  val preaffiliationCompletedNotificationTemplate = "PreaffiliationCompletedNotification.vm"
  val segmentationValidationTemplate = "SegmentationValidationNotification.vm"

  def setupVelocityEngine(): VelocityEngine = {
    val props = new Properties()
    props.setProperty( "resource.loader", "class" )
    props.setProperty( "class.resource.loader.class", "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader" )
    val velocityEngine = new VelocityEngine( props )
    velocityEngine.init()
    velocityEngine
  }

  def fillTemplate( templateToUse: String, context: VelocityContext ): String = {
    val velocityEngine = setupVelocityEngine()
    val template: Template = velocityEngine.getTemplate( templatesPath + templateToUse )
    val writer = new StringWriter()
    template.merge( context, writer )
    writer.toString
  }

}
