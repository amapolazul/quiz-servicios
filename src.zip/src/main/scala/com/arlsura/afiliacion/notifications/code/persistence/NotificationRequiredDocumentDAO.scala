package com.arlsura.afiliacion.notifications.code.persistence

import reactivemongo.bson.{ BSONDocument, BSONObjectID }
import reactivemongo.bson.DefaultBSONHandlers._
import reactivemongo.extensions.dao.BsonDao
import scala.concurrent.ExecutionContext.Implicits.global
import com.arlsura.afiliacion.persistence.config.MongoDBContext._

/**
 * Created by John on 14/05/15.
 */
object NotificationRequiredDocumentDAO extends BsonDao[ NotificationRequiredDocument, BSONObjectID ]( database, "notification_required_documents" )
