package com.arlsura.afiliacion.notifications

import com.arlsura.afiliacion.persistence.entities.PreAffiliation
import com.arlsura.afiliacion.templates.VelocityManager
import org.apache.velocity.VelocityContext

/**
 * Created by juanmartinez on 30/12/14.
 */
object SegmentationValidationNotification {

  private val descriptionMaxLength: Int = 285
  private val descriptionTerminationSymbol: String = "..."
  private val defaultDescription: String = "Sin descripción"
  private val subject: String = "Afiliación ARL SURA - Segmentación no superada"

  def send( email: String, affiliation: PreAffiliation ): Unit = {
    val content = buildMessageContent( affiliation )
    NotificationUtils.send( email, subject, content )
  }

  private def buildMessageContent( preAffiliation: PreAffiliation ): String = {
    val context = new VelocityContext()
    val provinceAddress: ( String, String ) = getProvinceAddressInformation( preAffiliation.address )
    context.put( "docType", preAffiliation.contactInfo.identificationType )
    context.put( "document", preAffiliation.contactInfo.identification )
    context.put( "economicActivityDescription", getCommercialActivityDescription( preAffiliation.fullEconomicActivity.description ) )
    context.put( "economicActivityCode", preAffiliation.fullEconomicActivity.economicActivityId )
    context.put( "name", getName( preAffiliation ) )
    context.put( "phone", preAffiliation.contactInfo.phone.getOrElse( "" ) )
    context.put( "cellPhone", preAffiliation.cellphone.getOrElse( "" ) )
    context.put( "city", provinceAddress._2 )
    context.put( "province", provinceAddress._1 )
    VelocityManager.fillTemplate( VelocityManager.segmentationValidationTemplate, context )
  }

  private def getCommercialActivityDescription( eaDescription: Option[ String ] ): String = {
    var description = eaDescription.getOrElse( defaultDescription )
    if ( description.length > descriptionMaxLength ) {
      description = description.substring( 0, descriptionMaxLength ) + descriptionTerminationSymbol
    }
    description
  }

  private def getProvinceAddressInformation( address: String ) = {
    val addressArray = address.split( "," )
    ( addressArray( 0 ), addressArray( 1 ) )
  }

  private def getName( preAffiliation: PreAffiliation ): String = {
    preAffiliation.contactInfo.name.getOrElse( s"${preAffiliation.contactInfo.name1} " +
      s"${preAffiliation.contactInfo.name2.getOrElse( "" )}" +
      s"${preAffiliation.contactInfo.lastname1}" +
      s"${preAffiliation.contactInfo.lastname2.getOrElse( "" )}" )
  }

}
