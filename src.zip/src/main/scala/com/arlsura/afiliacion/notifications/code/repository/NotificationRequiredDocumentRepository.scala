package com.arlsura.afiliacion.notifications.code.repository

import com.arlsura.afiliacion.notifications.code.persistence.{ NotificationRequiredDocument, NotificationRequiredDocumentDAO }
import reactivemongo.bson.{ BSONBoolean, BSONDocument }
import scala.concurrent.ExecutionContext.Implicits.global

import scala.concurrent.Future

/**
 * Created by John on 14/05/15.
 */
class NotificationRequiredDocumentRepository {

  val dao: NotificationRequiredDocumentDAO.type = NotificationRequiredDocumentDAO

  def findNewCompanyDocuments(): Future[ List[ NotificationRequiredDocument ] ] = dao.findAll(
    BSONDocument(
      "companyAffiliation" -> BSONBoolean( true ),
      "newCompany" -> BSONBoolean( true )
    )
  )

  def findNewDomesticDocuments(): Future[ List[ NotificationRequiredDocument ] ] = dao.findAll(
    BSONDocument(
      "domesticAffiliation" -> BSONBoolean( true ),
      "newCompany" -> BSONBoolean( true )
    )
  )

  def findTransferCompanyDocuments(): Future[ List[ NotificationRequiredDocument ] ] = dao.findAll(
    BSONDocument(
      "companyAffiliation" -> BSONBoolean( true ),
      "arlTransfer" -> BSONBoolean( true )
    )
  )

  def findTransferDomesticDocuments(): Future[ List[ NotificationRequiredDocument ] ] = dao.findAll(
    BSONDocument(
      "domesticAffiliation" -> BSONBoolean( true ),
      "arlTransfer" -> BSONBoolean( true )
    )
  )

}
