package com.arlsura.afiliacion.notifications.code

import com.arlsura.afiliacion.notifications.NotificationUtils
import com.arlsura.afiliacion.notifications.code.persistence.NotificationRequiredDocument
import com.arlsura.afiliacion.notifications.code.repository.NotificationRequiredDocumentRepository
import com.arlsura.afiliacion.templates.VelocityManager
import com.arlsura.afiliacion.utils.Utils
import org.apache.velocity.VelocityContext

import scala.collection.mutable.ListBuffer

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future
import scala.util.{ Failure, Success }

/**
 * Utilidad que se encarga de enviar una notificación cuando el código de un usuario es generado
 * Created by John on 17/12/14.
 */
object CodeWasGeneratedNotification {

  val domesticAffiliationType: String = "DE"

  val imgEncabezadoURL: String = "https://arlafilinea-notificaciones.herokuapp.com/images/encabezado.jpg"
  val imgBannerURL: String = "https://arlafilinea-notificaciones.herokuapp.com/images/bannerPrincipal.jpg"
  val icoXURL: String = "https://arlafilinea-notificaciones.herokuapp.com/images/ico-x.png"
  val icoDescargarURL: String = "https://arlafilinea-notificaciones.herokuapp.com/images/ico-descargar.png"
  val icoChromeURL: String = "https://arlafilinea-notificaciones.herokuapp.com/images/ico-googleChrome.png"
  val icoCandadoURL: String = "https://arlafilinea-notificaciones.herokuapp.com/images/ico-codigoEmpresa-1.png"
  val icoTipsURL: String = "https://arlafilinea-notificaciones.herokuapp.com/images/ico-tips.png"
  val icoVinetaURL: String = "https://arlafilinea-notificaciones.herokuapp.com/images/ico-vineta.png"

  val notificationSubject: String = "Afiliación ARL SURA - Código de Seguridad"

  val repository: NotificationRequiredDocumentRepository = new NotificationRequiredDocumentRepository()

  /**
   * Envia la notificacion luego de consultar los documentos requeridos
   * @param dni
   * @param email
   * @param code
   * @param affiliationType
   * @param newCompany
   */
  def send( dni: String, email: String, code: String, affiliationType: String, newCompany: Boolean ): Unit = {
    executeQuery( affiliationType, newCompany ) onComplete {
      case Success( list ) =>
        sendEmail( dni, code, email, list )
      case Failure( error ) =>
        //        error.printStackTrace()
        sendEmail( dni, code, email, List.empty[ NotificationRequiredDocument ] )
    }
  }

  /**
   * Consulta los documentos requeridos
   * @param affiliationType
   * @param newCompany
   * @return
   */
  private def executeQuery( affiliationType: String, newCompany: Boolean ): Future[ List[ NotificationRequiredDocument ] ] = {
    val isDomestic: Boolean = affiliationType.equals( domesticAffiliationType )
    ( newCompany, isDomestic ) match {
      case ( true, true )   => repository.findNewDomesticDocuments()
      case ( true, false )  => repository.findNewCompanyDocuments()
      case ( false, true )  => repository.findTransferDomesticDocuments()
      case ( false, false ) => repository.findTransferCompanyDocuments()
    }
  }

  /**
   * Construye el cuerpo de la notificacion y envia el mensaje
   * @param dni
   * @param code
   * @param to
   * @param documents
   */
  private def sendEmail( dni: String, code: String, to: String, documents: List[ NotificationRequiredDocument ] ): Unit = {
    val content = buildNewMessageContent( dni, code, documents )
    NotificationUtils.send( to, notificationSubject, content )
  }

  /**
   * Construye el cuerpo del mensaje
   * @param dni
   * @param code
   * @param documents
   * @return
   */
  private def buildNewMessageContent( dni: String, code: String, documents: List[ NotificationRequiredDocument ] ): String = {
    val context = new VelocityContext()
    addImagesURLsToContext( context )
    addCodeRelatedData( context, dni, code )
    addDocuments( context, documents )
    VelocityManager.fillTemplate( VelocityManager.preaffiliationCompletedNotificationTemplate, context )
  }

  /**
   * Construye la URL para continuar con la afiliacion
   * @param dni
   * @return
   */
  private def buildUrl( dni: String ): String = {
    val host = Utils.getProperty( "front.", "host" ).asInstanceOf[ String ]
    val port = Utils.getProperty( "front.", "port" ).asInstanceOf[ Int ]
    val urlBase = s"$host:$port"
    s"http://${urlBase}/#/preaffiliation/continue/$dni"
  }

  /**
   * Agrega las URLs de las imagenes/iconos al contexto de velocity
   * @param context
   */
  private def addImagesURLsToContext( context: VelocityContext ): Unit = {
    context.put( "imgEncabezadoURL", imgEncabezadoURL )
    context.put( "imgBannerURL", imgBannerURL )
    context.put( "icoXURL", icoXURL )
    context.put( "icoDescargarURL", icoDescargarURL )
    context.put( "icoChromeURL", icoChromeURL )
    context.put( "icoCandadoURL", icoCandadoURL )
    context.put( "icoTipsURL", icoTipsURL )
    context.put( "icoVinetaURL", icoVinetaURL )
  }

  /**
   * Agrega el DNI y el codigo de seguridad al contexto de velocity
   * @param context
   * @param dni
   * @param code
   */
  private def addCodeRelatedData( context: VelocityContext, dni: String, code: String ): Unit = {
    val url = buildUrl( dni )
    context.put( "url", url )
    context.put( "code", code )
  }

  /**
   * Agrega arrays con los documentos y las obsevaciones al contexto de velocity
   * @param context
   * @param documents
   */
  private def addDocuments( context: VelocityContext, documents: List[ NotificationRequiredDocument ] ): Unit = {
    val documentsList: List[ String ] = documents.map( _.document )
    val commentsList: List[ String ] = documents.map( _.comments ).map( _.getOrElse( "" ) )
    context.put( "documentsList", documentsList.toArray )
    context.put( "commentsList", commentsList.toArray )
    context.put( "indexes", ( 0 until commentsList.length ).toArray )
  }

}
