package com.arlsura.afiliacion.notifications.code.persistence

import reactivemongo.bson.{ Macros, BSONObjectID }

/**
 * Created by John on 14/05/15.
 */
case class NotificationRequiredDocument(
  _id:                 BSONObjectID     = BSONObjectID.generate,
  document:            String,
  companyAffiliation:  Boolean,
  domesticAffiliation: Boolean,
  newCompany:          Boolean,
  arlTransfer:         Boolean,
  comments:            Option[ String ] = None
)

object NotificationRequiredDocument {

  implicit val notificationRequiredDocumentHandler = Macros.handler[ NotificationRequiredDocument ]

}
