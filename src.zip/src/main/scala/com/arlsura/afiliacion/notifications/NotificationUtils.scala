package com.arlsura.afiliacion.notifications

import co.com.suramericana.notificaciones.servicios.ws.ObjetoCorreo
import co.com.suramericana.notificaciones.servicios.ws.customer.ServicioNotificacionesConsumer
import com.arlsura.afiliacion.bussiness.SoapConsumerSupport
import com.arlsura.afiliacion.utils.Utils
import org.joda.time.DateTime
import org.joda.time.format.DateTimeFormat

/**
 * Permite enviar una notificaion desde Afiliacion en Linea con algunas parametrizaciones por defecto
 * Created by root on 18/12/14.
 */
object NotificationUtils extends SoapConsumerSupport {

  private val url = Utils.getProperty( "soap.services.", "notificaciones" ).asInstanceOf[ String ]
  private val user = Utils.getProperty( "soap.credentials.", "username" ).asInstanceOf[ String ]
  private val pass = Utils.getProperty( "soap.credentials.", "password" ).asInstanceOf[ String ]
  private val token = Utils.getProperty( "notificaciones.", "token" ).asInstanceOf[ String ]
  private val from = Utils.getProperty( "notificaciones.", "from" ).asInstanceOf[ String ]
  private val codigoAplicacionAfiliacionEnLinea = Utils.getProperty( "notificaciones.", "codigoAplicacionAfiliacionEnLinea" ).asInstanceOf[ String ]
  private val codigoUsuarioAfiliacionEnLinea = Utils.getProperty( "notificaciones.", "codigoUsuarioAfiliacionEnLinea" ).asInstanceOf[ String ]
  private val errorEmail = Utils.getProperty( "notificaciones.", "errorEmail" ).asInstanceOf[ String ]

  def send( to: String, subject: String, content: String ): Unit = {
    val consumer = new ServicioNotificacionesConsumer( user, pass, token, url )
    consumer.authenticateToProxy( this.cloudProxyHost, this.cloudProxyPort, this.cloudProxyUser, this.cloudProxyPassword )
    val emailData = buildEmailData( to, subject, content )
    consumer.enviarCorreo( emailData )
  }

  private def buildEmailData( to: String, subject: String, content: String ): ObjetoCorreo = {
    val emailData = new ObjetoCorreo()
    emailData.setDe( from )
    emailData.setPara( to )
    emailData.setAsunto( subject )
    emailData.setContenido( content )
    emailData.setCodAplicacion( codigoAplicacionAfiliacionEnLinea )
    emailData.setCodUsuario( codigoUsuarioAfiliacionEnLinea )
    emailData.setConfEnvio( "N" )
    emailData.setConfHtml( "S" )
    emailData.setCorreoError( errorEmail )
    emailData.setPrioridad( "I" )
    emailData.setAuxiliar1( "A" )
    emailData.setFecEnvio( getTimeAsString )
    emailData
  }

  private def getTimeAsString: String = {
    val formatter = DateTimeFormat.forPattern( "dd/MM/yyyy" )
    val datetime = new DateTime()
    formatter.print( datetime )
  }

}
