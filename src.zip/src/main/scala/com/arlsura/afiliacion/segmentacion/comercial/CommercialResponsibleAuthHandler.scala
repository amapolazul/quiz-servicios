package com.arlsura.afiliacion.segmentacion.comercial

import com.arlsura.afiliacion.bussiness.HandlerSupport._
import com.arlsura.afiliacion.bussiness.affiliation.BasicDataRepository
import com.arlsura.afiliacion.bussiness.commercial.responsible.CommercialResponsibleManager
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.{ GeneralJsonResponseData, GetCommercialResponsibleRequest }
import com.arlsura.afiliacion.segmentacion.comercial.CommercialResponsibleMarshaller.CommercialResponsibleAuth
import com.google.inject.Inject
import com.typesafe.scalalogging.LazyLogging

import scala.concurrent.{ ExecutionContext, Future }

/**
 * Created by John on 24/07/15.
 */
class CommercialResponsibleAuthHandler @Inject() ( commercialResponsibleManager: CommercialResponsibleManager, basicDataManager: BasicDataRepository ) extends LazyLogging {

  def auth( clientDni: String, authData: CommercialResponsibleAuth )( implicit ec: ExecutionContext ): Future[ ServiceHandlerResponse ] = {
    basicDataManager.getByDni( clientDni ) flatMap {
      case None => Future.successful( Left( s"No se encontro al usuario asociado al dni $clientDni" ) )
      case Some( basicData ) =>
        val city = basicData.mainAddress.get.city
        val query = GetCommercialResponsibleRequest(
          city = Some( city ),
          email = Some( authData.email ),
          networkUser = Some( authData.user ),
          dni = Some( authData.commercialConsultantDni )
        )
        commercialResponsibleManager.getBy( query ) flatMap {
          list =>
            if ( list.length == 0 ) {
              Future.successful( Left( s"No se encontro ningun asesor comercial en la ciudad $city" ) )
            }
            else {
              Future.successful( Right( GeneralJsonResponseData( "Autorizado" ) ) )
            }
        }
    } recover {
      case e: Throwable =>
        //        e.printStackTrace()
        Left( s"Ocurrio un error. DNI cliente: $clientDni. Error: ${e.getMessage}" )
    }
  }

}
