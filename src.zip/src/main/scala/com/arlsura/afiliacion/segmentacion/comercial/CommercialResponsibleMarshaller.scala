package com.arlsura.afiliacion.segmentacion.comercial

import com.arlsura.afiliacion.utils.FormatValidator
import org.json4s.{ DefaultFormats, Formats }
import spray.httpx.Json4sSupport

/**
 * Created by John on 24/07/15.
 */
object CommercialResponsibleMarshaller extends Json4sSupport {

  override implicit def json4sFormats: Formats = DefaultFormats

  case class CommercialResponsibleAuth(
      commercialConsultantDni: String,
      email:                   String,
      user:                    String
  ) {
    require( FormatValidator.alphanumeric( commercialConsultantDni ), "DNI inválido." )
    require( FormatValidator.validEmail( email ), "Correo electrónico inválido." )
    require( FormatValidator.alphabetic( user ), "Usuario inválido." )
  }

}
