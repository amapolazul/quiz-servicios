package com.arlsura.afiliacion.persistence.scripts

import java.io.FileWriter

import com.arlsura.afiliacion.bussiness.cache._

import scala.io.Source
import scala.util.control.NonFatal

//import com.arlsura.afiliacion.persistence.cache.daos._
import com.arlsura.afiliacion.persistence.cache.entities._
import com.typesafe.scalalogging.LazyLogging
import spray.json.DefaultJsonProtocol
import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

/**
 * Created by Jesús Martínez on 5/08/15.
 */
object BackupPopulator extends LazyLogging with App {

  import com.arlsura.afiliacion.utils.cache.CacheBackupManager._
  import spray.json._

  private val salary: SalaryCache = SalaryRefresher.refresh( SalaryCache( amount = 0.0 ) )
  private val econActs: Seq[ EconomicActivityCache ] = EconomicActivitiesRefresher.refresh( List.empty )
  private val addresses: Seq[ AddressCache ] = AddressesRefresher.refresh( List.empty )
  private val arps: Seq[ ARPCache ] = ARPRefresher.refresh( List.empty )
  private val afps: Seq[ AFPCache ] = AFPRefresher.refresh( List.empty )
  private val eps: Seq[ EPSCache ] = EPSRefresher.refresh( List.empty )
  private val contributors: Seq[ ContributorTypeCache ] = ContributorsTypesRefresher.refresh( List.empty )
  //  //val legalNatures :  [ Seq[ LegalNaturesCache ] ] = LegalNaturesRefresher.refresh( legalNaturesCatalog
  private val legalNatures: Seq[ LegalNaturesCache ] = LegalNatureSoapRefresher.refresh( List.empty )
  private val charges: Seq[ ChargeCache ] = ChargesRefresher.refresh

  def writeBackup[ T ]( collectionName: String, collection: Seq[ T ] )( implicit jsonWriter: JsonWriter[ T ] ) = {
    //
    //    logger.debug( s"Writing backup for collection: $collectionName" )
    //    logger.debug( s"These are the objects before serialization: $collection" )
    //    logger.debug( s"${collection.length} elements to save in collection $collectionName" )

    val filename = s"/opt/app/backups/${collectionName}_backup.txt"
    val fileWriter = new FileWriter( filename, false )

    val data = collection.map( _.toJson ).mkString( "%%%" )
    //    logger.debug( s"About to write $data in file named $filename..." )

    try {
      fileWriter.write( data )
    }
    catch {
      case NonFatal( t ) =>
      //        logger.debug( s"There was an error writing into file $filename." )
      //        logger.debug( s"Description: ${t.toString}" )
      //        t.printStackTrace()
    }
    finally {
      //      logger.debug( s"Closing file $filename..." )
      fileWriter.close()
    }
  }

  def loadBackup[ T ]( collectionName: String )( implicit jsonReader: JsonReader[ T ] ): Seq[ T ] = {
    //logger.debug(s"Loading backup for collection: $collectionName")

    val filename = s"/opt/app/backups/${collectionName}_backup.txt"
    val data = Source.fromFile( filename ).getLines().next().filterNot( _.isControl )

    val result = data.split( "%%%" ).toSeq.map( _.parseJson.convertTo[ T ] )

    //logger.debug(s"Successfully read file. Here's the data:\n $result")
    result
  }

  writeBackup( "charges", charges )
}