package com.arlsura.afiliacion.persistence.entities.affiliation.basic_data

import com.arlsura.afiliacion.persistence.entities.affiliation.contacts_data.ContactInformation
import com.arlsura.afiliacion.persistence.entities.preaffiliation.{ FullEconomicActivity, ProvinceSelected }
import org.joda.time.DateTime
import reactivemongo.bson.{ BSONObjectID, Macros }
import reactivemongo.extensions.dao.Handlers._

/**
 * Representa la coleccion de afiliacion datos basicos, primera pantalla en el proceso de afiliacion a la ARL SURA
 * Created by John on 30/03/15.
 */
case class AffiliationBasicData(
  _id:                  BSONObjectID              = BSONObjectID.generate,
  dni:                  String,
  contactInformation:   ContactInformation,
  commercialName:       Option[ String ]          = None,
  newCompany:           Option[ Boolean ]         = None,
  personType:           String,
  juridicalNature:      Option[ Int ]             = None,
  contributorType:      Int,
  previousARL:          Option[ String ]          = None,
  letterDeliveryDate:   Option[ DateTime ]        = None,
  coverageStartDate:    Option[ DateTime ]        = None,
  foundationDate:       Option[ DateTime ]        = None,
  commercialActivity:   String,
  fullEconomicActivity: FullEconomicActivity,
  mainAddress:          Option[ Address ]         = None,
  mailAddress:          Option[ Address ]         = None,
  bankInformation:      Option[ BankInformation ] = None,
  provincesSelected:    List[ ProvinceSelected ]
)

object AffiliationBasicData {

  implicit val addressHandler = Macros.handler[ Address ]
  implicit val bankInfoHandler = Macros.handler[ BankInformation ]
  implicit val affiliationBasicDataHandler = Macros.handler[ AffiliationBasicData ]

}

