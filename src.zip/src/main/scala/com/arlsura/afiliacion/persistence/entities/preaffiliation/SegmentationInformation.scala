package com.arlsura.afiliacion.persistence.entities.preaffiliation

import org.joda.time.DateTime
import reactivemongo.bson.Macros
import reactivemongo.extensions.dao.Handlers._

/**
 * Created by John 23/07/15.
 */
case class SegmentationInformation(
  commercialConsultantDni: String,
  affiliationApproved:     Boolean,
  rejectionCause:          Option[ String ] = None,
  date:                    DateTime         = DateTime.now()
)

object SegmentationInformation {
  implicit val segmentationInformationHandler = Macros.handler[ SegmentationInformation ]
}
