package com.arlsura.afiliacion.persistence.daos.wrappers

import com.arlsura.afiliacion.persistence.daos.CommercialResponsibleDAO
import com.arlsura.afiliacion.persistence.entities.CommercialResponsible
import reactivemongo.bson.{ BSONObjectID, BSONDocument }
import reactivemongo.core.commands.LastError
import scala.concurrent.{ Future, ExecutionContext }

/**
 * Created by jesus on 18/06/15.
 */
class CommercialResponsibleWrapper {
  private val dao = CommercialResponsibleDAO
  /**
   * Encuentra un documento basado en el selector.
   * @param query Consulta que se llevará a cabo.
   * @return Futuro con a lo sumo un resultado proveniente de la consulta.
   */
  def findOne( query: BSONDocument )( implicit ec: ExecutionContext ): Future[ Option[ CommercialResponsible ] ] = {
    dao.findOne( query )
  }

  /**
   * Elimina documentos basados en el selector.
   * @param selector Consulta para determinar qué elementos se eliminarán.
   * @param firstMatchOnly Flag para indicar si sólo se elimina la primera coincidencia o todas.
   * @return Futuro con el estado de la transacción.
   */
  def remove( selector: BSONDocument, firstMatchOnly: Boolean = false )( implicit ec: ExecutionContext ): Future[ LastError ] = {
    dao.remove( selector, firstMatchOnly = firstMatchOnly )
  }

  /**
   * Actualiza el documento que coincida con el criterio de búsqueda.
   * @param selector Criterio de búsqueda para determinar cuál elemento se va a actualizar.
   * @param document Documento con el que se sobreescribirá el documento seleccionado.
   * @param upsert Flag para indicar si se inserta el documento en caso de no haber ninguna coincidencia.
   * @return Futuro con el estado de la transacción.
   */
  def update( selector: BSONDocument, document: CommercialResponsible, upsert: Boolean = false )( implicit ec: ExecutionContext ): Future[ LastError ] = {
    dao.update( selector = selector, update = document, upsert = upsert )
  }

  /**
   * Inserta un nuevo documento en la colección.
   * @param document Documento a insertar.
   * @return Futuro con el estado de la transacción.
   */
  def insert( document: CommercialResponsible )( implicit ec: ExecutionContext ): Future[ LastError ] = {
    dao.insert( document )
  }

  /**
   * Trae todos los documentos que coincidan con el criterio de búsqueda.
   * @param selector Criterio de búsqueda.
   * @return Futuro con el resultado de la consulta.
   */
  def findAll( selector: BSONDocument = BSONDocument() )( implicit ec: ExecutionContext ): Future[ List[ CommercialResponsible ] ] = {
    dao.findAll( selector )
  }

  /**
   * Elimina todos los documentos en la colección
   * @return Futuro con el estado de la transacción.
   */
  def removeAll()( implicit ec: ExecutionContext ): Future[ LastError ] = {
    dao.removeAll()
  }

  /**
   * @param id Identificador del documento que se quiere modificar.
   * @param changes Modificaciones hechas al documento
   * @return Futuro con el estado de la transacción.
   */
  def updateById( id: BSONObjectID, changes: BSONDocument )( implicit ec: ExecutionContext ): Future[ LastError ] = {
    dao.updateById( id, changes )
  }

}
