package com.arlsura.afiliacion.persistence.cache.entities

import reactivemongo.bson.Macros

/**
 * Created by Jesús Martínez on 31/03/15.
 */
case class SalaryCache( amount: Double )

//object SalaryCache {
//  implicit val salaryCacheHandler = Macros.handler[ SalaryCache ]
//}