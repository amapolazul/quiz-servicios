package com.arlsura.afiliacion.persistence.entities.affiliation.basic_data

import com.arlsura.afiliacion.ValidationLogger
import com.arlsura.afiliacion.utils.{ FormatValidator, CipherFacility }
import reactivemongo.bson.Macros

/**
 * Representa la coleccion embebida direccion
 * Created by John on 30/03/15.
 */
case class Address(
    province:         String,
    provinceCode:     String,
    delegationCode:   String,
    municipalityCode: String,
    city:             String,
    nomenclaturaVial: String,
    number1:          String,
    letter1:          Option[ String ],
    orientation1:     Option[ String ],
    number2:          Option[ String ],
    letter2:          Option[ String ],
    number3:          Option[ String ],
    orientation2:     Option[ String ],
    details:          Option[ String ]
) {
  override def toString: String = {
    val buildingNumber = if ( number3.isDefined ) " - " + number3.get else ""
    //val areaInformation = province + ", " + city + ", "
    val line1 = nomenclaturaVial + " " + number1 + " " + letter1.getOrElse( "" ) + " " + orientation1.getOrElse( "" )
    val line2 = if ( number2.isDefined ) " # " + number2.get + letter2.getOrElse( "" ) + " " + orientation2.getOrElse( "" ) + buildingNumber else ""
    line1 + line2 + " " + details.getOrElse( "" )
  }
}

object Address extends CipherFacility with ValidationLogger {

  def encrypt( a: Address ) = Address(
    encode( a.province ),
    encode( a.provinceCode ),
    encode( a.delegationCode ),
    encode( a.municipalityCode ),
    encode( a.city ),
    encode( a.nomenclaturaVial ),
    encode( a.number1 ),
    a.letter1.map( encode ),
    a.orientation1.map( encode ),
    a.number2.map( encode ),
    a.letter2.map( encode ),
    a.number3.map( encode ),
    a.orientation2.map( encode ),
    a.details.map( encode )
  )

  def decrypt( a: Address ) = Address(
    decode( a.province ),
    decode( a.provinceCode ),
    decode( a.delegationCode ),
    decode( a.municipalityCode ),
    decode( a.city ),
    decode( a.nomenclaturaVial ),
    decode( a.number1 ),
    a.letter1.map( decode ),
    a.orientation1.map( decode ),
    a.number2.map( decode ),
    a.letter2.map( decode ),
    a.number3.map( decode ),
    a.orientation2.map( decode ),
    a.details.map( decode )
  )

  def validFormat( a: Address ): Boolean = {
    //    logValidationsBlock( "address", Some( a ) )

    val provinceCode: Boolean = FormatValidator.numeric( a.provinceCode )
    //    logValidationFailed( provinceCode, "Province Code (numeric)" )

    val municipalityCode: Boolean = FormatValidator.numeric( a.municipalityCode )
    //    logValidationFailed( municipalityCode, "Municipality Code (numeric)" )

    val delegationCode: Boolean = FormatValidator.numeric( a.delegationCode )
    //    logValidationFailed( delegationCode, "Delegation Code (numeric)" )

    val province: Boolean = a.province.forall( c => c.isWhitespace || c.isLetter || c == '.' )
    //    logValidationFailed( province, "Province (alphabetic)" )

    val city: Boolean = FormatValidator.alphabetic( a.city )
    //    logValidationFailed( city, "City (alphabetic)" )

    val number1: Boolean = FormatValidator.numeric( a.number1 )
    //    logValidationFailed( number1, "Number1 (numeric)" )

    val letter1: Boolean = a.letter1.forall( l => l.length <= 2 && FormatValidator.alphabetic( l, false ) )
    //    logValidationFailed( letter1, "Letter1 (alphabetic not required)" )

    val letter2: Boolean = a.letter2.forall( l => l.length <= 2 && FormatValidator.alphabetic( l, false ) )
    //    logValidationFailed( letter2, "Letter2 (alphabetic not required)" )

    val number2: Boolean = a.number2.forall( FormatValidator.numeric )
    //    logValidationFailed( number2, "Number2 (numeric not required)" )

    val number3: Boolean = a.number3.forall( FormatValidator.numeric )
    //    logValidationFailed( number3, "Number3 (numeric not required)" )

    val valid: Boolean = province && city && number1 && letter1 && letter2 && number2 && number3 && provinceCode && delegationCode && municipalityCode
    //    logValidationResult( valid )
    valid
  }

  implicit val addressHandler = Macros.handler[ Address ]
}
