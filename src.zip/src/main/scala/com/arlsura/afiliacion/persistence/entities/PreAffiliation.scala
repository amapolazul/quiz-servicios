package com.arlsura.afiliacion.persistence.entities

import com.arlsura.afiliacion.persistence.entities.affiliation.contacts_data.ContactInformation
import com.arlsura.afiliacion.persistence.entities.preaffiliation.{ SegmentationInformation, FullEconomicActivity, ProvinceSelected }
import org.joda.time.DateTime
import reactivemongo.bson.{ BSONObjectID, Macros }
import reactivemongo.extensions.dao.Handlers._

/**
 * Entidad engargada de guardar la información de la preafiliacion para un cliente
 * Created by juanmartinez on 27/11/14.
 */
case class PreAffiliation(
  _id:                  BSONObjectID                      = BSONObjectID.generate,
  dni:                  String,
  contactInfo:          ContactInformation,
  fullName:             String,
  address:              String,
  cellphone:            Option[ String ],
  econoact:             String,
  fullEconomicActivity: FullEconomicActivity,
  workers:              Long,
  prevarp:              String,
  racea:                String,
  fileName:             Option[ String ]                  = None,
  file:                 Option[ String ]                  = None,
  affiliationType:      String,
  isNewCompany:         Option[ Boolean ],
  selectedProvinces:    List[ ProvinceSelected ],
  gender:               Option[ String ]                  = None,
  birthDate:            Option[ DateTime ]                = None,
  segmentation:         Option[ SegmentationInformation ] = None
)

object PreAffiliation {

  implicit val preaffiliationHandler = Macros.handler[ PreAffiliation ]
}
