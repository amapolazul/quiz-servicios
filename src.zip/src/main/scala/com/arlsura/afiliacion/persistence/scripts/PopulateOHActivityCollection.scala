//package com.arlsura.afiliacion.persistence.scripts
//
//import java.io.FileInputStream
//
//import com.arlsura.afiliacion.persistence.daos.OccupationalHealthRUTSummaryDAO
//import com.arlsura.afiliacion.persistence.entities.OccupationalHealthRUTSummary
//import com.arlsura.afiliacion.utils.Utils
//import scala.concurrent.ExecutionContext.Implicits.global
//import org.apache.poi.hssf.usermodel.HSSFWorkbook
//import org.joda.time.DateTime
//
//import scala.io.{ BufferedSource, Source }
//import scala.util.{Success, Failure}
//
///**
// * Created by root on 21/01/15.
// */
//object PopulateOHActivityCollection extends App {
//  //Borra todos los documentos de la colección.
//  OccupationalHealthRUTSummaryDAO.removeAll() onSuccess {
//    //Para evitar problemas, se espera a que la operación termine.
//    case _ =>
//      val fileName = "/home/jesus/Desktop/Sura/Documentación/Act_3.csv"
//      val src = Source.fromFile( fileName )
//
//      val elementsByLine = src.getLines().drop( 1 ).map( _.split( "_" ) )
//
//      var numElems = 1
//      elementsByLine foreach {
//        elems =>
//          val rutStartDate = Utils.stringToDate( parseDate( elems( 0 ) ) )
//          val rutExpirationDate = Utils.stringToDate( parseDate( elems( 1 ) ) )
//          val ciiuActivityCode = elems( 2 )
//          val ohActivityCode = elems( 3 )
//          val quotationRate = elems( 4 ).toDouble
//          val description = elems( 5 )
//
//          val document = OccupationalHealthRUTSummary(
//            rutStartDate = rutStartDate,
//            rutExpirationDate = rutExpirationDate,
//            CIIUActivityCode = ciiuActivityCode,
//            OHActivityCode = ohActivityCode,
//            quotationRate = quotationRate,
//            description = description
//          )
//          println(s"Inserting element $numElems")
//          OccupationalHealthRUTSummaryDAO.insert( document ) onComplete {
//            case Success(lastError) => if (lastError.ok) println("\tInserted element") else println("\tOccurred error during insertion.")
//            case Failure(f) => f.printStackTrace()
//          }
//          numElems += 1
//      }
//  }
//
//  private def parseDate( date: String ) = {
//    val year = date.take( 4 )
//    val month = date.drop( year.length ).take( 2 )
//    val day = date.drop( year.length + month.length ).take( 2 )
//    s"$day/$month/$year"
//  }
//}
