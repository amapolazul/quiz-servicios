package com.arlsura.afiliacion.persistence.entities.affiliation.contacts_data

import reactivemongo.bson.{ Macros, BSONObjectID }

/**
 * Objeto contenedor de datos de contactos en el proceso de afiliación a la ARL|Sura.
 * Created by Jesús Martínez on 15/04/15.
 */

/**
 * @param _id Identificador unívoco del documento.
 * @param dni Identificador del titular del proceso de afiliación.
 * @param securityCode Código de seguridad asociado al proceso de afiliación.
 * @param legalRepresentative Datos del representante legal.
 * @param manager Datos del administrador.
 * @param humanResourcesRepresentative Datos del responsable de RRHH.
 * @param rosterRepresentative Datos del representante de nómina.
 * @param workSafetyRepresentative Datos del representante de seguridad laboral.
 * @param insideTrainingRepresentative Datos del representante de capacitación interna.
 */
case class AffiliationContactsData(
  _id:                          BSONObjectID       = BSONObjectID.generate,
  dni:                          String,
  securityCode:                 String             = "",
  legalRepresentative:          ContactInformation,
  manager:                      ContactInformation = new ContactInformation( contactId = Some( "GE" ) ),
  humanResourcesRepresentative: ContactInformation = new ContactInformation( contactId = Some( "RS" ) ),
  rosterRepresentative:         ContactInformation = new ContactInformation( contactId = Some( "NO" ) ),
  workSafetyRepresentative:     ContactInformation = new ContactInformation( contactId = Some( "SO" ) ),
  insideTrainingRepresentative: ContactInformation = new ContactInformation( contactId = Some( "RI" ) )
)

object AffiliationContactsData {
  implicit val affiliationContactsData = Macros.handler[ AffiliationContactsData ]
}
