package com.arlsura.afiliacion.persistence.cache.entities

import reactivemongo.bson.Macros

/**
 * Created by Jesús Martínez on 13/04/15.
 */

/**
 * Representación de los datos de Naturalezas Jurídicas en la colección "legal_natures_cache" de MongoDB.
 * @param code Código de la naturaleza jurídica.
 * @param description Descripción textual de la naturaleza jurídica.
 * @param officialEntityCode Código de la entidad oficinal de la naturaleza jurídica.
 * //@param startDate Fecha de alta.
 * //@param endDate Fecha de baja.
 * @param dni DNI de ingreso.
 */
case class LegalNaturesCache(
  code:               String,
  description:        String,
  officialEntityCode: String,
  // startDate:          Option[ DateTime ],
  // endDate:            Option[ DateTime ],
  dni: String
)

//object LegalNaturesCache {
//  implicit val legalNaturesCacheHandler = Macros.handler[ LegalNaturesCache ]
//}