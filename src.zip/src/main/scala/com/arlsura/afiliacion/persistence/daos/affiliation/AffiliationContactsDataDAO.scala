package com.arlsura.afiliacion.persistence.daos.affiliation

import com.arlsura.afiliacion.persistence.entities.affiliation.contacts_data.AffiliationContactsData
import reactivemongo.bson.BSONObjectID
import reactivemongo.extensions.dao.BsonDao
import scala.concurrent.ExecutionContext.Implicits.global
import com.arlsura.afiliacion.persistence.config.MongoDBContext._

/**
 * Created by Jesús Martínez on 15/04/15.
 */
object AffiliationContactsDataDAO extends BsonDao[ AffiliationContactsData, BSONObjectID ]( database, "affiliation_contacts_data" )
