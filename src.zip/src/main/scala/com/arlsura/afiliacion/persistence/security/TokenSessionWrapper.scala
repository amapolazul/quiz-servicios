package com.arlsura.afiliacion.persistence.security

import reactivemongo.bson.{ BSONString, BSONDocument }
import reactivemongo.core.commands.LastError

import scala.concurrent.{ ExecutionContext, Future }

/**
 * Created by juanmartinez on 23/06/15.
 */
class TokenSessionWrapper {

  private val tokenDao = TokenSessionDAO

  /**
   * Realiza la busqueda de un token
   * @param token
   * @return
   */
  def findByToken( token: String )( implicit ec: ExecutionContext ): Future[ Option[ TokenSession ] ] = tokenDao.findOne( BSONDocument( "token" -> BSONString( token ) ) )

  /**
   * Busca el token por un dni asociado
   * @param dni
   * @return
   */
  def findByDni( dni: String )( implicit ec: ExecutionContext ): Future[ Option[ TokenSession ] ] = tokenDao.findOne( BSONDocument( "dni" -> BSONString( dni ) ) )

  /**
   * inserta el token en la base de datos
   * @param tokenEntity
   * @return
   */
  def insert( tokenEntity: TokenSession )( implicit ec: ExecutionContext ): Future[ LastError ] = tokenDao.insert( tokenEntity )

  /**
   * Remueve un token por su DNI
   * @param dni
   * @return
   */
  def removeByDni( dni: String )( implicit ec: ExecutionContext ): Future[ LastError ] = tokenDao.remove( BSONDocument( "dni" -> BSONString( dni ) ) )
}
