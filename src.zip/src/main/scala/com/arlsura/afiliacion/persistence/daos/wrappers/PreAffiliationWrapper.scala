package com.arlsura.afiliacion.persistence.daos.wrappers

import com.arlsura.afiliacion.persistence.daos.PreAffiliationDAO
import com.arlsura.afiliacion.persistence.entities.PreAffiliation
import reactivemongo.bson.BSONDocument
import reactivemongo.core.commands.LastError

import scala.concurrent.{ Future, ExecutionContext }

/**
 * Created by Jesús Martínez on 2/06/15.
 */
class PreAffiliationWrapper {
  private val dao = PreAffiliationDAO
  /**
   * Encuentra un documento basado en el selector.
   * @param query Consulta que se llevará a cabo.
   * @return Futuro con a lo sumo un resultado proveniente de la consulta.
   */
  def findOne( query: BSONDocument )( implicit ec: ExecutionContext ): Future[ Option[ PreAffiliation ] ] = {
    dao.findOne( query )
  }

  /**
   * Elimina documentos basados en el selector.
   * @param selector Consulta para determinar qué elementos se eliminarán.
   * @param firstMatchOnly Flag para indicar si sólo se elimina la primera coincidencia o todas.
   * @return Futuro con el estado de la transacción.
   */
  def remove( selector: BSONDocument, firstMatchOnly: Boolean = false )( implicit ec: ExecutionContext ): Future[ LastError ] = {
    dao.remove( selector, firstMatchOnly = firstMatchOnly )
  }

  /**
   * Actualiza el documento que coincida con el criterio de búsqueda.
   * @param selector Criterio de búsqueda para determinar cuál elemento se va a actualizar.
   * @param document Documento con el que se sobreescribirá el documento seleccionado.
   * @param upsert Flag para indicar si se inserta el documento en caso de no haber ninguna coincidencia.
   * @return Futuro con el estado de la transacción.
   */
  def update( selector: BSONDocument, document: PreAffiliation, upsert: Boolean = false )( implicit ec: ExecutionContext ): Future[ LastError ] = {
    dao.update( selector = selector, update = document, upsert = upsert )
  }

  /**
   * Inserta un nuevo documento en la colección.
   * @param document Documento a insertar.
   * @return Futuro con el estado de la transacción.
   */
  def insert( document: PreAffiliation )( implicit ec: ExecutionContext ): Future[ LastError ] = {
    dao.insert( document )
  }

  /**
   * Trae todos los documentos que coincidan con el criterio de búsqueda.
   * @param selector Criterio de búsqueda.
   * @return Futuro con el resultado de la consulta.
   */
  def findAll( selector: BSONDocument = BSONDocument() )( implicit ec: ExecutionContext ): Future[ List[ PreAffiliation ] ] = {
    dao.findAll( selector )
  }
}
