package com.arlsura.afiliacion.persistence.entities.affiliation.work_center_data

import com.arlsura.afiliacion.ValidationLogger
import com.arlsura.afiliacion.persistence.entities.affiliation.basic_data.Address
import com.arlsura.afiliacion.persistence.entities.affiliation.contacts_data.ContactInformation
import com.arlsura.afiliacion.persistence.entities.preaffiliation.FullEconomicActivity
import com.arlsura.afiliacion.utils.{ FormatValidator, CipherFacility }
import reactivemongo.bson.{ Macros, BSONObjectID }

/**
 * Created by Jesús Martínez on 16/04/15.
 */
case class AffiliationWorkCentersData(
  _id:          BSONObjectID                  = BSONObjectID.generate,
  dni:          String,
  securityCode: String,
  workCenters:  List[ WorkCenterInformation ]
)

case class WorkCenterInformation(
  workcenterCode:        String,
  workcenterName:        String,
  branch:                String,
  workcenterAddressData: Address,
  phone:                 Option[ String ]                     = None,
  fax:                   Option[ String ]                     = None,
  commercialActivity:    FullEconomicActivity                 = FullEconomicActivity( "" ),
  contacts:              Option[ List[ ContactInformation ] ]
)

object WorkCenterInformation extends CipherFacility with ValidationLogger {
  def encrypt( w: WorkCenterInformation ): WorkCenterInformation =
    WorkCenterInformation(
      workcenterCode = w.workcenterCode,
      workcenterName = w.workcenterName,
      branch = w.branch,
      workcenterAddressData = Address.encrypt( w.workcenterAddressData ),
      phone = w.phone.map( encode ),
      fax = w.fax.map( encode ),
      commercialActivity = w.commercialActivity,
      contacts = w.contacts.map( _.map( ContactInformation.encrypt ) )
    )

  def decrypt( w: WorkCenterInformation ): WorkCenterInformation = WorkCenterInformation(
    workcenterCode = w.workcenterCode,
    workcenterName = w.workcenterName,
    branch = w.branch,
    workcenterAddressData = Address.decrypt( w.workcenterAddressData ),
    phone = w.phone.map( decode ),
    fax = w.fax.map( decode ),
    commercialActivity = w.commercialActivity,
    contacts = w.contacts.map( _.map( ContactInformation.decrypt ) )
  )

  def validFormat( w: WorkCenterInformation ): Boolean = {
    //    logValidationsBlock( "workcenters", Some( w ) )

    val workcenterName: Boolean = FormatValidator.alphanumeric( w.workcenterName )
    //    logValidationFailed( workcenterName, "Workcenter Name (alphanumeric)" )

    val workcenterAddressData: Boolean = Address.validFormat( w.workcenterAddressData )
    //    logValidationFailed( workcenterAddressData, "Workcenter Address (Address.validFormat)" )

    val phone: Boolean = w.phone.forall( p => FormatValidator.validPhone( p ) )
    //    logValidationFailed( phone, "Phone (not required phone)" )

    val fax: Boolean = w.fax.forall( p => FormatValidator.validPhone( p ) || FormatValidator.validCellphone( p ) )
    //    logValidationFailed( fax, "Fax (not required phone or cellphone)" )

    val contacts: Boolean = w.contacts.forall( _.forall( ContactInformation.validFormat ) )
    //    logValidationFailed( contacts, "Contacts (not required ContactInformation.validForma)" )

    val valid: Boolean = workcenterName && workcenterAddressData && phone && fax && contacts
    //    logValidationResult( valid )
    valid
  }

}

object AffiliationWorkCentersData {
  implicit val workCenterInformation = Macros.handler[ WorkCenterInformation ]
  implicit val affiliationWorkCentersData = Macros.handler[ AffiliationWorkCentersData ]
}
