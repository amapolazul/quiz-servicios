package com.arlsura.afiliacion.persistence.cache.entities

import reactivemongo.bson.Macros

/**
 * Created by Jesús Martínez on 31/03/15.
 */
case class ContributorTypeCache(
  affiliateTypeCode:       String,
  contributorSubtypeCode:  String,
  contributorTypeCode:     String,
  relationshipDescription: String,
  orderNumber:             Int
)

//object ContributorTypeCache {
//  implicit val contributorTypeCacheHandler = Macros.handler[ ContributorTypeCache ]
//}
