package com.arlsura.afiliacion.persistence.blacklist

import com.arlsura.afiliacion.persistence.config.MongoDBContext._
import reactivemongo.bson.BSONObjectID
import reactivemongo.extensions.dao.BsonDao
import scala.concurrent.ExecutionContext.Implicits.global

/**
 * Created by Jesús Martínez on 9/06/15.
 */
object BlacklistDAO extends BsonDao[ Blacklist, BSONObjectID ]( database, "blacklist" )
