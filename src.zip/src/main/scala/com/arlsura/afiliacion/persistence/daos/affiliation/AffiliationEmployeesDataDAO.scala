package com.arlsura.afiliacion.persistence.daos.affiliation

import com.arlsura.afiliacion.persistence.entities.affiliation.employee_data.AffiliationEmployeesData
import reactivemongo.bson.BSONObjectID
import reactivemongo.extensions.dao.BsonDao
import com.arlsura.afiliacion.persistence.config.MongoDBContext._
import scala.concurrent.ExecutionContext.Implicits.global

/**
 * Created by Jesús Martínez on 16/04/15.
 */
object AffiliationEmployeesDataDAO extends BsonDao[ AffiliationEmployeesData, BSONObjectID ]( database, "affiliation_employees_data" )
