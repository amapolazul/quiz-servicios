package com.arlsura.afiliacion.persistence.entities

import reactivemongo.bson.{ BSONObjectID, Macros }

/**
 * Representa la coleccion contributor
 * @param _id
 * @param id
 * @param name
 */
case class Contributor(
  _id:  BSONObjectID = BSONObjectID.generate,
  id:   Int,
  name: String
)

object Contributor {
  implicit val securityCodeHandler = Macros.handler[ Contributor ]
}