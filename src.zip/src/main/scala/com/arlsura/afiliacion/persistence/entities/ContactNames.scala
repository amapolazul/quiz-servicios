package com.arlsura.afiliacion.persistence.entities

import reactivemongo.bson.{ BSONObjectID, Macros }

/**
 * Created by John on 31/07/15.
 */
case class ContactNames(
  _id:                  BSONObjectID = BSONObjectID.generate,
  contactId:            String,
  contactDescription:   String,
  isMainContact:        Boolean,
  neededForWorkcenters: Boolean
)
object ContactNames {
  implicit val contactNamesHandler = Macros.handler[ ContactNames ]
}