package com.arlsura.afiliacion.persistence.daos.affiliation.wrappers

import com.arlsura.afiliacion.persistence.daos.affiliation.AffiliationEmployeesDataDAO
import com.arlsura.afiliacion.persistence.entities.affiliation.employee_data.AffiliationEmployeesData
import reactivemongo.bson.BSONDocument
import reactivemongo.core.commands.LastError
import scala.concurrent.{ ExecutionContext, Future }

/**
 * Created by Jesús Martínez on 4/05/15.
 */
class AffiliationEmployeesDataWrapper {
  val dao = AffiliationEmployeesDataDAO
  /**
   * Encuentra un documento basado en el selector.
   * @param query Consulta que se llevará a cabo.
   * @return Futuro con a lo sumo un resultado proveniente de la consulta.
   */
  def findOne( query: BSONDocument )( implicit ec: ExecutionContext ): Future[ Option[ AffiliationEmployeesData ] ] = {
    dao.findOne( query )
  }

  /**
   * Elimina documentos basados en el selector.
   * @param selector Consulta para determinar qué elementos se eliminarán.
   * @param firstMatchOnly Flag para indicar si sólo se elimina la primera coincidencia o todas.
   * @return Futuro con el estado de la transacción.
   */
  def remove( selector: BSONDocument, firstMatchOnly: Boolean = false )( implicit ec: ExecutionContext ): Future[ LastError ] = {
    dao.remove( selector, firstMatchOnly = firstMatchOnly )
  }

  /**
   * Actualiza el documento que coincida con el criterio de búsqueda.
   * @param selector Criterio de búsqueda para determinar cuál elemento se va a actualizar.
   * @param document Documento con el que se sobreescribirá el documento seleccionado.
   * @param upsert Flag para indicar si se inserta el documento en caso de no haber ninguna coincidencia.
   * @return Futuro con el estado de la transacción.
   */
  def update( selector: BSONDocument, document: AffiliationEmployeesData, upsert: Boolean = false )( implicit ec: ExecutionContext ): Future[ LastError ] = {
    dao.update( selector = selector, update = document, upsert = upsert )
  }

  /**
   * Inserta un nuevo documento en la colección.
   * @param document Documento a insertar.
   * @return Futuro con el estado de la transacción.
   */
  def insert( document: AffiliationEmployeesData )( implicit ec: ExecutionContext ): Future[ LastError ] = {
    dao.insert( document )
  }

  /**
   * Trae todos los documentos que coincidan con el criterio de búsqueda.
   * @param selector Criterio de búsqueda.
   * @return Futuro con el resultado de la consulta.
   */
  def findAll( selector: BSONDocument = BSONDocument() )( implicit ec: ExecutionContext ): Future[ List[ AffiliationEmployeesData ] ] = {
    dao.findAll( selector )
  }
}
