package com.arlsura.afiliacion.persistence.entities

import reactivemongo.bson.{ Macros, BSONObjectID }

/**
 * Clase que modela la entidad para las opciones de menu para los tipos de documento
 * @param _id
 * @param docType
 * @param options
 */
case class CustomerOptionsMenu(
  _id:     BSONObjectID   = BSONObjectID.generate,
  docType: String,
  options: List[ String ]
)

object CustomerOptionsMenu {
  implicit val customerOptionsHandler = Macros.handler[ CustomerOptionsMenu ]
}