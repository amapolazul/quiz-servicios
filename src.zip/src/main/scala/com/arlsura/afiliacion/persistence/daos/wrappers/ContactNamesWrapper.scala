package com.arlsura.afiliacion.persistence.daos.wrappers

import com.arlsura.afiliacion.persistence.daos.ContactNamesDAO
import com.arlsura.afiliacion.persistence.entities.ContactNames
import reactivemongo.bson.BSONDocument
import reactivemongo.core.commands.LastError

import scala.concurrent.{ Future, ExecutionContext }

/**
 * Created by John on 31/07/15.
 */
class ContactNamesWrapper {

  private val dao = ContactNamesDAO

  def findAll( selector: BSONDocument = BSONDocument() )( implicit ec: ExecutionContext ): Future[ List[ ContactNames ] ] = {
    dao.findAll( selector )
  }

}
