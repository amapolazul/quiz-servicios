//package com.arlsura.afiliacion.persistence.scripts
//
//import com.arlsura.afiliacion.persistence.daos.CommercialResponsibleDAO
//import com.arlsura.afiliacion.persistence.entities.CommercialResponsible
//import scala.concurrent.ExecutionContext.Implicits.global
//import scala.io.Source
//import scala.util.{Success, Failure}
//
///**
// * Created by Jesús Martínez on 24/08/15.
// */
//object CommercialResponsiblePopulator extends App {
//  private val FILE_NAME = "/home/jesus/Desktop/rs.csv"
//
//  //Borra todos los documentos de la colección.
//  CommercialResponsibleDAO.removeAll() onComplete {
//    case Success(_) =>
//      println("All documents were deleted successfully.")
//      val src = Source.fromFile(FILE_NAME)
//
//      val lines = src.getLines().drop(1).map(_.split("_"))
//
//      for (tokens <- lines) {
//        val office: Int = Integer.parseInt(tokens(0))
//        val city: String = tokens(1)
//        val fullName: String = tokens(2)
//        val email: String = tokens(3)
//        val charge: String = tokens(4)
//        val networkUser: String = tokens(5)
//        val dni: String = tokens(6)
//
//        val doc = CommercialResponsible(office = office, city = city, fullName = fullName, email = email, charge = charge, networkUser = networkUser, dni = dni)
//        CommercialResponsibleDAO.insert(doc)
//      }
//    case Failure(f) => println(s"An error has occurred while deleting documents from collection $f")
//  }
//}
