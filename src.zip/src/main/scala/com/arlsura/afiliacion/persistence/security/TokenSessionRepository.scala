package com.arlsura.afiliacion.persistence.security

import com.google.inject.Inject
import reactivemongo.core.commands.LastError

import scala.concurrent.{ ExecutionContext, Future }

/**
 * Created by juanmartinez on 23/06/15.
 */
class TokenSessionRepository @Inject() ( private val wrapper: TokenSessionWrapper ) {

  /**
   * Crea el token desde la clase wrapper
   * @param token
   * @return
   */
  def createSessionToken( token: TokenSession )( implicit ec: ExecutionContext ): Future[ LastError ] = wrapper.insert( token )

}
