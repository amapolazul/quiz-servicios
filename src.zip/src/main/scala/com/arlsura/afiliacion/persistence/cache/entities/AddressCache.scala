package com.arlsura.afiliacion.persistence.cache.entities

import reactivemongo.bson.Macros

/**
 * Created by root on 20/03/15.
 */
case class AddressCache(
  countryName: String,
  countryCode: Int,
  provinces:   List[ ProvinceElement ]
)
case class ProvinceElement( delegationCode: String, provinceCode: String, zoneCode: String, provinceName: String, municipalities: List[ MunicipalityElement ] )
case class MunicipalityElement( municipalityName: String, delegationCode: String, departmentCode: String, municipalityCode: String )

//object AddressCache {
//  implicit val municipalityElementHandler = Macros.handler[ MunicipalityElement ]
//  implicit val provinceElementHandler = Macros.handler[ ProvinceElement ]
//  implicit val addressCacheHandler = Macros.handler[ AddressCache ]
//}

