package com.arlsura.afiliacion.persistence.entities

import org.joda.time.DateTime
import reactivemongo.bson.{ BSONObjectID, Macros }
import reactivemongo.extensions.dao.Handlers._

/**
 * Created by Jesús Martínez on 30/12/14.
 */
/**
 * Entidad representativa de la tabla de equivalencias entre el RUT y las actividades de salud ocupacional.
 * @param _id Identificador del documento en base de datos.
 * @param rutStartDate Fecha de inicio de la vigencia del RUT.
 * @param CIIUActivityCode Código de la actividad principal relacionada con el RUT.
 * @param OHActivityCode Código de la actividad de salud ocupacional.
 * @param quotationRate Tasa de cotización.
 * @param description Descipción textual de la actividad.
 */
case class OccupationalHealthRUTSummary(
  _id:               BSONObjectID = BSONObjectID.generate,
  rutStartDate:      DateTime,
  rutExpirationDate: DateTime,
  CIIUActivityCode:  String,
  OHActivityCode:    String,
  quotationRate:     Double,
  description:       String
)

object OccupationalHealthRUTSummary {
  implicit val securityCodeHandler = Macros.handler[ OccupationalHealthRUTSummary ]
}