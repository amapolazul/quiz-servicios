package com.arlsura.afiliacion.persistence.security

import com.arlsura.afiliacion.persistence.config.MongoDBContext._
import reactivemongo.bson.BSONObjectID
import reactivemongo.extensions.dao.BsonDao

import scala.concurrent.ExecutionContext.Implicits.global

/**
 * Created by juanmartinez on 23/06/15.
 */
object TokenSessionDAO extends BsonDao[ TokenSession, BSONObjectID ]( database, "token_session" )
