package com.arlsura.afiliacion.persistence.cache.entities

/**
 * Created by Jesús Martínez on 26/08/15.
 */
case class ChargeCache( code: Int, description: String, chargeType: String )
