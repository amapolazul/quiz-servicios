package com.arlsura.afiliacion.persistence.daos.affiliation

import com.arlsura.afiliacion.persistence.config.MongoDBContext._
import com.arlsura.afiliacion.persistence.entities.affiliation.basic_data.AffiliationBasicData
import reactivemongo.bson.BSONObjectID
import reactivemongo.extensions.dao.BsonDao
import scala.concurrent.ExecutionContext.Implicits.global

/**
 * DAO de la entidad AffiliationBasicData, colleccion affiliation_basic_data
 * Created by John on 31/03/15.
 */
object AffiliationBasicDataDAO extends BsonDao[ AffiliationBasicData, BSONObjectID ]( database, "affiliation_basic_data" )
