package com.arlsura.afiliacion.persistence.cache.entities

import reactivemongo.bson.Macros

/**
 * Created by Jesús Martínez on 24/03/15.
 */
case class ARPCache( code: Int, dni: String, groupCode: Int, commercialDescription: String )

//object ARPCache {
//  implicit val arpCache = Macros.handler[ ARPCache ]
//}