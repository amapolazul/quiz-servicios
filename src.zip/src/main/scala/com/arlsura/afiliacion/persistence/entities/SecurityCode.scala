package com.arlsura.afiliacion.persistence.entities

import org.joda.time.DateTime
import reactivemongo.bson.{ Macros, BSONObjectID }
import reactivemongo.extensions.dao.Handlers._

/**
 * Entidad para manejar el codigo de seguridad
 * Created by root on 26/11/14.
 */
case class SecurityCode(
  _id:            BSONObjectID = BSONObjectID.generate,
  dni:            String,
  code:           String,
  generationDate: DateTime     = DateTime.now(),
  expirationDate: DateTime     = DateTime.now(),
  source:         String,
  email:          String
)

object SecurityCode {
  implicit val securityCodeHandler = Macros.handler[ SecurityCode ]
}