package com.arlsura.afiliacion.persistence.daos

import com.arlsura.afiliacion.persistence.entities.Contributor
import reactivemongo.bson.BSONObjectID
import reactivemongo.extensions.dao.BsonDao
import scala.concurrent.ExecutionContext.Implicits.global
import com.arlsura.afiliacion.persistence.config.MongoDBContext._

/**
 * DAO para acceder a la coleccion contributor
 */
object ContributorDAO extends BsonDao[ Contributor, BSONObjectID ]( database, "contributors" )
