package com.arlsura.afiliacion.persistence.entities.affiliation.branch_data

import com.arlsura.afiliacion.persistence.entities.affiliation.basic_data.Address
import reactivemongo.bson.{ Macros, BSONObjectID }

/**
 * Created by Jesús Martínez on 15/04/15.
 *
 */
/**
 * @param _id Identificador unívoco del documento.
 * @param branchID ID para la sincronizacion de sucursales con el cliente
 * @param dni Identificador del titular del proceso de afiliación.
 * @param securityCode Código de seguridad asociado al proceso de afiliación.
 * @param branchCode Código de la sucursal.
 * @param branchName Nombre de la sucursal.
 * @param branchAddressData Dirección de la sucursal.
 * @param email Dirección de correo electrónico de la sucursal.
 * @param phone Teléfono de la sucursal.
 * @param contact Contacto principal en la sucursal.
 */
case class AffiliationBranchesData(
  _id:               BSONObjectID     = BSONObjectID.generate,
  branchID:          String,
  securityCode:      Option[ String ] = None,
  dni:               String,
  branchCode:        String,
  branchName:        String,
  branchAddressData: Address,
  email:             String,
  phone:             Option[ String ] = None,
  contact:           Option[ String ] = None
)

object AffiliationBranchesData {
  implicit val affiliationBranchesData = Macros.handler[ AffiliationBranchesData ]
}
