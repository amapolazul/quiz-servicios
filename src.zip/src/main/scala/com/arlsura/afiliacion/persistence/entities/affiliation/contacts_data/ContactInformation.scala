package com.arlsura.afiliacion.persistence.entities.affiliation.contacts_data

import com.arlsura.afiliacion.ValidationLogger
import com.arlsura.afiliacion.persistence.entities.affiliation.work_center_data.WorkCenterInformation._
import com.arlsura.afiliacion.utils.{ FormatValidator, CipherFacility }
import reactivemongo.bson.Macros

/**
 * Created by Jesús Martínez on 16/04/15.
 */
//TODO Identificar cuáles campos son obligatorios [también basados en el orden de llenado de la información].
/**
 * @param identificationType Tipo de identificación (Pasaporte, Cédula, etc.)
 * @param identification Número de identificación.
 * @param name1 Primer nombre.
 * @param name2 Segundo nombre.
 * @param lastname1 Primer apellido.
 * @param lastname2 Segundo apellido.
 * @param position Cargo.
 * @param phone Número de teléfono.
 * @param email Dirección de correo electrónico.
 */
case class ContactInformation(
  identificationType: String           = "",
  identification:     String           = "",
  name:               Option[ String ] = None,
  name1:              String           = "",
  name2:              Option[ String ] = None,
  lastname1:          String           = "",
  lastname2:          Option[ String ] = None,
  position:           Option[ String ] = None,
  phone:              Option[ String ] = None,
  email:              String           = "",
  title:              Option[ String ] = None,
  contactId:          Option[ String ],
  chargeCode:         Option[ String ] = None
)

object ContactInformation extends CipherFacility with ValidationLogger {

  def encrypt( c: ContactInformation ) = ContactInformation(
    encode( c.identificationType ),
    encode( c.identification ),
    c.name.map( encode ),
    encode( c.name1 ),
    c.name2.map( encode ),
    encode( c.lastname1 ),
    c.lastname2.map( encode ),
    c.position.map( encode ),
    c.phone.map( encode ),
    encode( c.email ),
    c.title.map( encode ),
    c.contactId,
    c.chargeCode
  )

  def decrypt( c: ContactInformation ) = ContactInformation(
    decode( c.identificationType ),
    decode( c.identification ),
    c.name.map( decode ),
    decode( c.name1 ),
    c.name2.map( decode ),
    decode( c.lastname1 ),
    c.lastname2.map( decode ),
    c.position.map( decode ),
    c.phone.map( decode ),
    decode( c.email ),
    c.title.map( decode ),
    c.contactId,
    c.chargeCode
  )

  def validFormat( c: ContactInformation ): Boolean = {
    //    logValidationsBlock( "contact information", Some( c ) )

    val name1: Boolean = FormatValidator.validName( c.name1 )
    //    logValidationFailed( name1, "Name1 (validName)" )

    val lastname1: Boolean = FormatValidator.validName( c.lastname1 )
    //    logValidationFailed( lastname1, "Lastname1 (validName)" )

    val email: Boolean = FormatValidator.validEmail( c.email ) || c.email.isEmpty
    //    logValidationFailed( email, "Email (validEmail)" )

    val name2: Boolean = c.name2.forall( FormatValidator.validName )
    //    logValidationFailed( name2, "Name2 (validName not required)" )

    val lastname2: Boolean = c.lastname2.forall( FormatValidator.validName )
    //    logValidationFailed( lastname2, "Lastname2 (validName not required)" )

    val phone: Boolean = c.phone.forall( FormatValidator.validPhone )
    //    logValidationFailed( phone, "Phone (phone not required)" )

    val title: Boolean = c.title.forall( FormatValidator.alphabetic( _ ) )
    //    logValidationFailed( title, "Title (alphabetic not required)" )

    val position: Boolean = c.position.forall( FormatValidator.alphabetic( _ ) )
    //    logValidationFailed( position, "Position (alphabetic not required)" )

    val valid: Boolean = name1 && lastname1 && email && name2 && lastname2 && phone && title && position
    //    logValidationResult( valid )
    valid
  }

  implicit val contactInformation = Macros.handler[ ContactInformation ]
}