package com.arlsura.afiliacion.persistence.entities

import reactivemongo.bson.{ Macros, BSONObjectID }

/**
 * Created by juanmartinez on 16/01/15.
 */
case class DomesticEmployerActivity(
  _id:         BSONObjectID = BSONObjectID.generate,
  code:        String,
  name:        String,
  description: String
)

object DomesticEmployerActivity {
  implicit val domesticEmployerActivity = Macros.handler[ DomesticEmployerActivity ]
}
