package com.arlsura.afiliacion.persistence.daos

import com.arlsura.afiliacion.persistence.entities.CustomerOptionsMenu
import reactivemongo.api.{ MongoDriver, DB }
import reactivemongo.bson.BSONObjectID
import reactivemongo.bson.DefaultBSONHandlers._
import reactivemongo.extensions.dao.BsonDao
import scala.concurrent.ExecutionContext.Implicits.global
import com.arlsura.afiliacion.persistence.config.MongoDBContext._

/**
 * Created by juanmartinez on 12/11/14.
 */
object CustomerOptionsMenuDAO extends BsonDao[ CustomerOptionsMenu, BSONObjectID ]( database, "customeroptionmenus" )
