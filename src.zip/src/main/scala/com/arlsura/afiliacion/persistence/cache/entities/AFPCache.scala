package com.arlsura.afiliacion.persistence.cache.entities

import reactivemongo.bson.Macros

/**
 * Created by root on 30/03/15.
 */
case class AFPCache( code: String, dni: String, ministryCode: String, name: String )

//object AFPCache {
//  implicit val afpCacheHandler = Macros.handler[ AFPCache ]
//}
