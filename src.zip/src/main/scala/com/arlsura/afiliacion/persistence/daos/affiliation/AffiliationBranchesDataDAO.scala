package com.arlsura.afiliacion.persistence.daos.affiliation

import com.arlsura.afiliacion.persistence.entities.affiliation.branch_data.AffiliationBranchesData
import reactivemongo.bson.BSONObjectID
import reactivemongo.extensions.dao.BsonDao
import scala.concurrent.ExecutionContext.Implicits.global
import com.arlsura.afiliacion.persistence.config.MongoDBContext._

/**
 * Created by Jesús Martínez on 15/04/15.
 */
object AffiliationBranchesDataDAO extends BsonDao[ AffiliationBranchesData, BSONObjectID ]( database, "affiliation_branches_data" )
