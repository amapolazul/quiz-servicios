package com.arlsura.afiliacion.persistence.security

import org.joda.time.DateTime
import reactivemongo.bson.{ BSONObjectID, Macros }
import reactivemongo.extensions.dao.Handlers._

/**
 *
 * @param _id
 * @param dni
 * @param token
 * @param creationDate
 * @param expirationDate
 */
case class TokenSession(
  _id:            BSONObjectID = BSONObjectID.generate,
  dni:            String,
  token:          String,
  creationDate:   DateTime     = DateTime.now(),
  expirationDate: DateTime     = DateTime.now()
)

object TokenSession {
  implicit val tokenSessionHandler = Macros.handler[ TokenSession ]
}