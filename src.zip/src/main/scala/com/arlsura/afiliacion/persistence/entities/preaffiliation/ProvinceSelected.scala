package com.arlsura.afiliacion.persistence.entities.preaffiliation

import reactivemongo.bson.Macros

/**
 * Created by juanmartinez on 6/05/15.
 */
case class ProvinceSelected(
  provinceCode: String,
  provinceName: String
)

object ProvinceSelected {
  implicit val provincesSelectedHandler = Macros.handler[ ProvinceSelected ]
}