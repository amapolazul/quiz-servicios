package com.arlsura.afiliacion.persistence.daos

import com.arlsura.afiliacion.persistence.entities.OccupationalHealthRUTSummary
import reactivemongo.bson.BSONObjectID
import reactivemongo.extensions.dao.BsonDao
import scala.concurrent.ExecutionContext.Implicits.global
import com.arlsura.afiliacion.persistence.config.MongoDBContext._

/**
 * Created by Jesús Martínez on 30/12/14.
 * DAO para manejar las operaciones sobre la tabla de equivalencias entre el RUT y la Actividad de Salud Ocupacional.
 */
object OccupationalHealthRUTSummaryDAO extends BsonDao[ OccupationalHealthRUTSummary, BSONObjectID ]( database, "occupational_health_rut_summary" )
