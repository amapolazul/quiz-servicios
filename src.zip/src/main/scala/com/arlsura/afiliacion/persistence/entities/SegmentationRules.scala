package com.arlsura.afiliacion.persistence.entities

import reactivemongo.bson.{ Macros, BSONObjectID }

/**
 * Created by juanmartinez on 22/12/14.
 */
case class SegmentationRules(
  _id:         BSONObjectID = BSONObjectID.generate,
  ciiu:        String,
  city:        String,
  operator:    String,
  num_workers: Long
)

object SegmentationRules {

  implicit val segmentationRulesHandler = Macros.handler[ SegmentationRules ]

}
