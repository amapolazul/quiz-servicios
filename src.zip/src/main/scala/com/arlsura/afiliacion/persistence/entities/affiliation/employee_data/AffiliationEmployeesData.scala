package com.arlsura.afiliacion.persistence.entities.affiliation.employee_data

import com.arlsura.afiliacion.ValidationLogger
import com.arlsura.afiliacion.persistence.entities.affiliation.basic_data.Address
import com.arlsura.afiliacion.persistence.entities.affiliation.contacts_data.ContactInformation
import com.arlsura.afiliacion.utils.FormatValidator
import org.joda.time.DateTime
import reactivemongo.bson.{ Macros, BSONObjectID }
import reactivemongo.extensions.dao.Handlers._

/**
 * Created by Jesús Martínez on 16/04/15.
 */
case class AffiliationEmployeesData(
  _id:          BSONObjectID                          = BSONObjectID.generate,
  dni:          String,
  securityCode: String,
  employees:    Option[ List[ EmployeeInformation ] ]
)

//TODO Ver cuáles son opcionales.
case class EmployeeInformation(
  contactInfo:          ContactInformation,
  cellphone:            Option[ String ],
  birthdate:            Option[ String ]   = None,
  gender:               String,
  salary:               String,
  workcenter:           String,
  jobModality:          Option[ String ]   = None,
  remoteWorkType:       Option[ String ]   = None,
  remoteWorkPlace:      Option[ String ]   = None,
  commercialActivity:   Option[ String ]   = None,
  eps:                  Option[ String ]   = None,
  afp:                  Option[ String ]   = None,
  contractType:         Option[ String ]   = None,
  contractStartDate:    Option[ DateTime ] = None,
  contractEndDate:      Option[ DateTime ] = None,
  contractTotalValue:   Option[ Double ]   = None,
  contractMonthlyValue: Option[ Double ]   = None,
  ibc:                  Option[ Double ]   = None,
  employeeAddressData:  Address
)

object EmployeeInformation extends ValidationLogger {

  def validFormat( e: EmployeeInformation ): Boolean = {
    //    logValidationsBlock( "employees", Some( e ) )

    val contact: Boolean = ContactInformation.validFormat( e.contactInfo )
    //    logValidationFailed( contact, "Contact (ContactInformation.validFormat)" )

    val cellphone: Boolean = e.cellphone.forall( FormatValidator.validCellphone )
    //    logValidationFailed( cellphone, "Cellphone (cellphone not required)" )

    val contractTotalValue: Boolean = e.contractTotalValue.forall( _ > 0.0 )
    //    logValidationFailed( contractTotalValue, "Contract Total Value (not required, greater than 0)" )

    val contractMonthlyValue: Boolean = e.contractMonthlyValue.forall( _ > 0f )
    //    logValidationFailed( contractMonthlyValue, "Contract Monthly Value (not required, greater than 0)" )

    val ibc: Boolean = e.ibc.forall( _ > 0f )
    //    logValidationFailed( ibc, "IBC (not required, greater than 0)" )

    val address: Boolean = Address.validFormat( e.employeeAddressData )
    //    logValidationFailed( address, "Address (Address.validFormat)" )

    val valid: Boolean = contact && cellphone && contractTotalValue && contractMonthlyValue && ibc && address
    //    logValidationResult( valid )
    valid
  }

}

object AffiliationEmployeesData {
  implicit val employeeInformation = Macros.handler[ EmployeeInformation ]
  implicit val affiliationEmployeesData = Macros.handler[ AffiliationEmployeesData ]
}