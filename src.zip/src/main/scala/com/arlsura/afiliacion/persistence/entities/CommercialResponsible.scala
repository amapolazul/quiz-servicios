package com.arlsura.afiliacion.persistence.entities

import reactivemongo.bson.{ BSONObjectID, Macros }

/**
 * Esta entidad representa la matriz de responsables comerciales por oficina ARL Sura.
 * Created by Jesús Martínez on 22/12/14.
 */
case class CommercialResponsible(
  _id:         BSONObjectID = BSONObjectID.generate,
  office:      Int,
  city:        String,
  fullName:    String,
  email:       String,
  charge:      String,
  networkUser: String,
  dni:         String
)

object CommercialResponsible {
  implicit val commercialResponsibleHandler = Macros.handler[ CommercialResponsible ]
}