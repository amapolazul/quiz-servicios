package com.arlsura.afiliacion.persistence.daos

import com.arlsura.afiliacion.persistence.config.MongoDBContext._
import com.arlsura.afiliacion.persistence.entities.DomesticEmployerActivity
import reactivemongo.bson.BSONObjectID
import reactivemongo.extensions.dao.BsonDao

import scala.concurrent.ExecutionContext.Implicits.global

/**
 * Created by juanmartinez on 16/01/15.
 */
object DomesticEmployerActivityDAO extends BsonDao[ DomesticEmployerActivity, BSONObjectID ]( database, "domestic_employer_activity" )
