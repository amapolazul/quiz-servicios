package com.arlsura.afiliacion.persistence.entities.affiliation.basic_data

import reactivemongo.bson.Macros

/**
 * Representa la coleccion embebida de informacion bancaria/financiera
 * Created by John on 30/03/15.
 */
case class BankInformation(
  //_id: BSONObjectID = BSONObjectID.generate,
  company:       String,
  accountType:   String,
  accountNumber: Int,
  entity:        String,
  entityBranch:  String
)

object BankInformation {
  implicit val bankInformationHandler = Macros.handler[ BankInformation ]
}
