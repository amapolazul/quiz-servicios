package com.arlsura.afiliacion.persistence.cache.entities

import reactivemongo.bson.Macros

/**
 * Created by root on 20/03/15.
 */
case class EconomicActivityCache( name: String, code: String, classCode: String, rate: Double )

//object EconomicActivityCache {
//  implicit val economicActivityCacheHandler = Macros.handler[ EconomicActivityCache ]
//}
