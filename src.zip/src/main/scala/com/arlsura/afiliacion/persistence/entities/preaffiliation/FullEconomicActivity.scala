package com.arlsura.afiliacion.persistence.entities.preaffiliation

import reactivemongo.bson.Macros

/**
 * Created by juanmartinez on 3/06/15.
 */
case class FullEconomicActivity(
  economicActivityId: String,
  description:        Option[ String ] = None,
  rate:               Option[ String ] = None,
  cdClass:            Option[ String ] = None
)

object FullEconomicActivity {
  implicit val preaffiliationHandler = Macros.handler[ FullEconomicActivity ]
}