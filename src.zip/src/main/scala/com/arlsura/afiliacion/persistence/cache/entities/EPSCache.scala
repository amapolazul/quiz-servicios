package com.arlsura.afiliacion.persistence.cache.entities

import reactivemongo.bson.Macros

/**
 * Created by root on 30/03/15.
 */
case class EPSCache( code: String, dni: String, ministryCode: String, name: String ) {
  require( code != null, "Code is null!" )
  require( dni != null, "DNI is null!" )
  require( ministryCode != null, "ministryCode is null!" )
  require( name != null, "name is null!" )
}

//object EPSCache {
//  //implicit val epsCacheHandler = Macros.handler[ EPSCache ]
//}
