package com.arlsura.afiliacion.persistence.config

import com.arlsura.afiliacion.utils.Utils
import reactivemongo.api.MongoDriver
import reactivemongo.core.nodeset.Authenticate
import scala.concurrent.ExecutionContext.Implicits.global
import scala.collection.JavaConverters._

/**
 * Created by juanmartinez on 12/11/14.
 */
object MongoDBContext {

  val replicaSetHosts = Utils.getPropertyAsList( "persistence.", "replica_set_host" ).asScala.toList
  val databaseName = Utils.getProperty( "persistence.", "databaseTransactional" ).asInstanceOf[ String ]
  val user = Utils.getProperty( "persistence.", "user" ).asInstanceOf[ String ]
  val pass = Utils.getProperty( "persistence.", "password" ).asInstanceOf[ String ]

  val credentials = Seq( Authenticate( databaseName, user, pass ) )

  val driver = new MongoDriver()
  val connection = driver.connection( replicaSetHosts, nbChannelsPerNode = 5, authentications = credentials )

  def database = connection( databaseName )
}
