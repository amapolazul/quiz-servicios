package com.arlsura.afiliacion.persistence.cache.daos

import com.arlsura.afiliacion.persistence.cache.entities._
import com.arlsura.afiliacion.persistence.config.MongoDBContext._
import reactivemongo.bson.BSONObjectID
import reactivemongo.extensions.dao.BsonDao
import scala.concurrent.ExecutionContext.Implicits.global

/**
 * Created by Jesús Martínez on 5/08/15.
 */
//object AddressCacheDAO extends BsonDao[ AddressCache, BSONObjectID ]( database, "addresses_cache" )
//object AFPCacheDAO extends BsonDao[ AFPCache, BSONObjectID ]( database, "afps_cache" )
//object ARPCacheDAO extends BsonDao[ ARPCache, BSONObjectID ]( database, "arps_cache" )
//object ContributorTypeCacheDAO extends BsonDao[ ContributorTypeCache, BSONObjectID ]( database, "contributor_types_cache" )
//object EconomicActivityCacheDAO extends BsonDao[ EconomicActivityCache, BSONObjectID ]( database, "economic_activities_cache" )
//object EPSCacheDAO extends BsonDao[ EPSCache, BSONObjectID ]( database, "eps_cache" )
//object LegalNaturesCacheDAO extends BsonDao[ LegalNaturesCache, BSONObjectID ]( database, "legal_natures_cache" )
//object SalaryCacheDAO extends BsonDao[ SalaryCache, BSONObjectID ]( database, "salary_cache" )
