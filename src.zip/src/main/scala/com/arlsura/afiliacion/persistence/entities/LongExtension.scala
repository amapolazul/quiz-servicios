package com.arlsura.afiliacion.persistence.entities

/**
 * Created by juanmartinez on 22/12/14.
 */
class LongExtension( num: Long ) {

  /**
   * Redefine la operacion menorque o igual para dos numeros long
   * @param other
   * @return
   */
  def ltoe( other: Long ) = num <= other

  /**
   * Redefine la operacion mayorque o igual para dos numeros long
   * @param other
   * @return
   */
  def gtoe( other: Long ) = num >= other

  /**
   * Redefine la operacion menor estricto para dos long
   * @param other
   * @return
   */
  def lt( other: Long ) = num < other

  /**
   * Redefine la operacion mayor estricto para dos longs
   * @param other
   * @return
   */
  def gt( other: Long ) = num > other

  /**
   * Redefine la operacion igual
   * @param other
   * @return
   */
  def eq( other: Long ) = num == other

}

case object LongExtension {
  def apply( long: Long ) = new LongExtension( long )
}
