package com.arlsura.afiliacion.persistence.entities

import org.joda.time.DateTime
import reactivemongo.bson.{ BSONObjectID, Macros }
import reactivemongo.extensions.dao.Handlers._

/**
 * Entidad para manejar informacion sobre el empleado independiente
 * Created by john on 14/11/14.
 */
case class SelfEmployee(
  _id:          BSONObjectID = BSONObjectID.generate,
  dni:          String,
  lastEntrance: DateTime     = DateTime.now()
)

object SelfEmployee {

  implicit val selfEmployeeHandler = Macros.handler[ SelfEmployee ]

}