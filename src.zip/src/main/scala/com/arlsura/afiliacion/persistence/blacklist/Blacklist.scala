package com.arlsura.afiliacion.persistence.blacklist

import org.joda.time.DateTime
import reactivemongo.bson.{ Macros, BSONObjectID }
import reactivemongo.extensions.dao.Handlers._

/**
 * Created by Jesús Martínez on 9/06/15.
 */
case class Blacklist( _id: BSONObjectID = BSONObjectID.generate, dni: String, factor: Double, since: DateTime ) {
  def calculateBlockEnd: DateTime = since.plusMinutes( ( 60 * factor ).asInstanceOf[ Int ] )
}

object Blacklist {
  implicit val blacklistHandler = Macros.handler[ Blacklist ]
}