package com.arlsura.afiliacion.persistence.daos.affiliation

import com.arlsura.afiliacion.persistence.entities.affiliation.work_center_data.AffiliationWorkCentersData
import reactivemongo.bson.BSONObjectID
import reactivemongo.extensions.dao.BsonDao
import com.arlsura.afiliacion.persistence.config.MongoDBContext._
import scala.concurrent.ExecutionContext.Implicits.global

/**
 * Created by Jesús Martínez on 6/05/15.
 */
object AffiliationWorkCentersDataDAO extends BsonDao[ AffiliationWorkCentersData, BSONObjectID ]( database, "affiliation_work_centers_data" )
