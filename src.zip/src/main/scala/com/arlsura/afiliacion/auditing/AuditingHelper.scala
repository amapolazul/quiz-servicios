package com.arlsura.afiliacion.auditing

import com.arlsura.afiliacion.ARLContext._
import com.arlsura.afiliacion.utils.CipherFacility
import com.sura.sessionmanager.{ GenericData, Found, NotFound }
import com.typesafe.scalalogging.LazyLogging

import org.joda.time.DateTime

import spray.http.{ HttpHeader, HttpResponse }
import spray.routing.RequestContext

/**
 * Object that represents auditing helper
 */
object AuditingHelper extends LazyLogging with CipherFacility {

  /**
   * Method that audit an action in log
   * @param ctx Request context
   * @param date Request date
   * @return Modified request context
   */
  def auditAction( ctx: RequestContext, date: DateTime = new DateTime() ): RequestContext = ctx.withRouteResponseMapped {
    case response: HttpResponse =>

      val audRequest: String = s"Request: \n" +
        s"\t HttpMethod: ${ctx.request.method.value} \n" +
        s"\t Url: ${ctx.request.uri.path.toString()} \n" +
        s"\t Body: ${ctx.request.entity.asString} \n" +
        s"\t Time: ${date.toString( "dd/MM/yyyy HH:mm:ss" )}"

      val audResponse: String = s"Response: \n" +
        s"\t StatusCode: ${response.status.value} \n" +
        s"\t Body: ${response.entity.asString} \n" +
        s"\t Time: ${new DateTime().toString( "dd/MM/yyyy HH:mm:ss" )}"

      val sessionHeader: Option[ HttpHeader ] = ctx.request.headers.find( _.name == "Session-Tag" )
      sessionHeader match {
        case None => logger.info( s"A new request has arrived. \n $audRequest \n $audResponse" )
        case Some( header ) =>
          val sessionValue: String = header.value
          val ( _, cookieDni, _ ) = decode( sessionValue, timestamp = true, sep = "%%%" ).right.get
          sessionManager.findSession( cookieDni, update = true ).map {
            case NotFound( _ ) =>
            case Found( sessionDni, updated, data: GenericData ) =>
              val audSession: String = s"Session: \n" +
                s"\t DNI: $sessionDni"
              logger.info( s"A new request has arrived. \n $audRequest \n $audSession \n $audResponse" )
          }
      }

      response
    case x => x
  }

}
