package com.arlsura.afiliacion.utils
import scala.concurrent.duration._
import akka.util.Timeout
/**
 * Created by root on 4/02/15.
 */
trait GlobalParamsProvider {
  private def parseDuration( config: String ): FiniteDuration = {
    val time: Int = if ( config.equalsIgnoreCase( "timeout" ) )
      Utils.getProperty( "timeout.", "time" ).asInstanceOf[ Int ]
    else
      Utils.getProperty( "retries.", "time-window" ).asInstanceOf[ Int ]

    Utils.getProperty( "timeout.", "units" ).asInstanceOf[ String ] match {
      case "seconds" => time.seconds
      case "nano"    => time.nanoseconds
      case "millis"  => time.milliseconds
      case "minutes" => time.minutes
    }
  }
  final val MX_NR_OF_RETRIES: Int = Utils.getProperty( "retries.", "number-of-retries" ).asInstanceOf[ Int ]
  final val TIMEOUT: FiniteDuration = parseDuration( "timeout" )
  final implicit val AKKA_TIMEOUT = Timeout( TIMEOUT )
  final val TIME_WINDOW: Duration = parseDuration( "retries" )
}
