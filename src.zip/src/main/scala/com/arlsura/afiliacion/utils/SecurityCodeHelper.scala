package com.arlsura.afiliacion.utils

import com.arlsura.afiliacion.bussiness.code.{ CodeSourceIdentifiers, SecurityCodeManager }
import com.arlsura.afiliacion.notifications.code.CodeWasGeneratedNotification
import com.arlsura.afiliacion.persistence.entities.{ SecurityCode, PreAffiliation }
import com.arlsura.afiliacion.security.CodeGenerator

/**
 * Created by John on 24/07/15.
 */
object SecurityCodeHelper {

  private val SECURITY_CODE_LENGTH: Int = 8
  private val SECURITY_CODE_ALPHANUMERIC: Boolean = true

  def buildSecurityCode( preaffiliation: PreAffiliation, source: String ): SecurityCode = {
    val generatedCode = CodeGenerator.generate( SECURITY_CODE_LENGTH, SECURITY_CODE_ALPHANUMERIC ).right.get
    SecurityCodeManager.buildSecurityCodeEntity(
      code = generatedCode,
      dni = preaffiliation.dni,
      email = preaffiliation.contactInfo.email,
      source = source,
      expirationDate = SecurityCodeManager.generateExpirationDate()
    )
  }

  def sendCodeNotification( preaffiliation: PreAffiliation, securityCodeEntity: SecurityCode ): Unit = {
    CodeWasGeneratedNotification.send(
      dni = securityCodeEntity.dni,
      code = securityCodeEntity.code,
      email = securityCodeEntity.email,
      affiliationType = preaffiliation.affiliationType,
      newCompany = preaffiliation.isNewCompany.get
    )
  }

}
