package com.arlsura.afiliacion.utils

import scala.collection.immutable.HashMap

/**
 * Clase para obtener un DNI a partir de un tipo de documento y un numero de documento
 * Created by john on 10/11/14.
 */
object DNIBuilder {

  def identificationTypes = HashMap[ String, Option[ String ] ](
    "CC" -> Some( "C" ),
    "NI" -> Some( "N" ),
    "CE" -> Some( "E" ),
    "TI" -> Some( "T" ),
    "RC" -> Some( "I" ),
    "M" -> Some( "M" ),
    "PA" -> Some( "P" ),
    "CD" -> Some( "D" )
  )

  def build( identificationType: String, identification: String ): String = {
    if ( identification.trim.isEmpty ) {
      throw new IllegalArgumentException( "El numero de identificacion no puede estar vacio" )
    }
    identificationTypes get identificationType match {
      case Some( id ) => id.get + identification
      case None       => throw new IllegalArgumentException( s"No existe el tipo de identificacion '$identificationType'" )
    }
  }

}
