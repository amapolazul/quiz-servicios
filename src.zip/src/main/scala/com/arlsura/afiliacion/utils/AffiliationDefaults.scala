package com.arlsura.afiliacion.utils

/**
 * Created by John on 31/03/15.
 */
object AffiliationDefaults {

  val contributorType = 1
  val juridcalNature = 5

}
