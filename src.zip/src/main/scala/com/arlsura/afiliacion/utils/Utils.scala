package com.arlsura.afiliacion.utils

import java.io.FileInputStream
import java.net.InetAddress
import java.util.{ Properties, Calendar }
import com.typesafe.config.{ Config, ConfigFactory }
import com.typesafe.scalalogging.LazyLogging
import org.apache.commons.codec.binary.Base64
import org.joda.time.DateTime
import org.joda.time.format.DateTimeFormat
import scala.util.{ Failure, Success, Try }

object Utils extends LazyLogging {

  val monthsMap = Map(
    1 -> "Enero",
    2 -> "Febrero",
    3 -> "Marzo",
    4 -> "Abril",
    5 -> "Mayo",
    6 -> "Junio",
    7 -> "Julio",
    8 -> "Agosto",
    9 -> "Semptiembre",
    10 -> "Octubre",
    11 -> "Noviembre",
    12 -> "Diciembre"
  )

  /**
   * Ambiente por defecto: heroku_lab
   */
  val defaultEnvironment = "heroku_lab"

  /**
   * ip por defecto en caso de haber problemas con las interfaces de red
   */
  val defaultHostAddress = "127.0.0.1"

  /**
   * Carga la configuracion del archivo application.conf
   */
  val conf = loadConfigFactory()

  /**
   * formato que define el patron de las fechas
   */
  private val format = DateTimeFormat.forPattern( "dd/MM/YYYY" )

  /**
   * prefijo para las propiedades de configuracion
   * @return
   */
  def prefix = "com.arlsura.afiliacion."

  /**
   * Devuelve la propiedad que coincida con la ruta de la propiedad y el valor de la propiedad
   * @param pack Este valor se concatena con el prefijo y debe ir seguido de un punt e.g. persistence.
   * @param propName El nombre de la propiedad a traer del archivo de configuracion
   * @return El valor de la propiedad. Se devuelve un Any para ser manipulado por quien haga uso del metodo
   */
  def getProperty( pack: String, propName: String ) = conf.getAnyRef( prefix concat pack concat propName )

  /**
   * Devuelve una lista de propiedades definidas en los archivos de configuracion
   * @param pack
   * @param propName
   * @return
   */
  def getPropertyAsList( pack: String, propName: String ) = conf.getStringList( prefix concat pack concat propName )

  /**
   * retorna la url de para comunicarse con venta informacion REST
   * @return
   */
  def getVentaInformacionUrl: String = {
    val host = getProperty( "ventainformacion.", "host" ).asInstanceOf[ String ]
    val port = getProperty( "ventainformacion.", "port" ).asInstanceOf[ Int ].toString
    val context = getProperty( "ventainformacion.", "context" ).asInstanceOf[ String ]
    s"${host}:${port concat context}"
  }

  /**
   * Obtiene la estampa de tiempo correspondiente a la fecha actual.
   * @return Fecha actual, expresada en un valor entero.
   */
  def getTimestamp = Calendar.getInstance().getTime.getTime

  /**
   * codifica el array de datos en string
   *
   * @param imageByteArray
   * @return
   */
  def encodeFile( imageByteArray: Array[ Byte ] ): String = Base64.encodeBase64URLSafeString( imageByteArray )

  /**
   * Decodifica un string que representa un bussiness y lo
   * convierte en arreglo de bytes
   *
   * @param fileString - String que representa el bussiness
   * @return
   */
  def decodeFile( fileString: String ): Array[ Byte ] = Base64.decodeBase64( fileString )

  /**
   * Retorna el formato de la fecha especifiado en el patron del formatter
   * @param date
   * @return
   */
  def dateFormatToString( date: DateTime ) = format.print( date )

  /**
   * Toma un string con formato dd/mm/yyyy y lo transforma en una fecha.
   * @param date Representación de la fecha.
   * @return Objeto DateTime equivalente a la fecha ingresada como string.
   */
  def stringToDate( date: String ) = format.parseDateTime( date )

  /**
   * Carga el archivo de configuracion en base al ambiente en el que el servidor se encuentre
   * @return
   */
  private def loadConfigFactory(): Config = {
    val environment = getEnvironment()
    environment match {
      case Success( env ) =>
        ConfigFactory.load( s"conf/$env/application.conf" )
      case Failure( ex ) =>
        ConfigFactory.load( s"conf/$defaultEnvironment/application.conf" )
    }
  }

  /**
   * Busca la variable AMBIENTE en el archivo /opt/app/shared/afilinea_api/configuration.conf
   * @return
   */
  def getEnvironment(): Try[ String ] = {
    Try {
      val prop: Properties = new Properties()
      prop.load( new FileInputStream( "/opt/app/shared/afilinea_api/configuration.conf" ) )
      val environment: String = prop.getProperty( "AMBIENTE" )
      if ( environment == null || environment.trim().length == 0 ) {
        defaultEnvironment
      }
      environment
    }
  }

  /**
   * Retorna la direccion IP del host local
   * Encuentra la ip basado en la interfaz de red eth0 por lo tanto solo va a trabajar en ambientes linux
   * @return
   */
  def getLocalIpAddress: String = {
    val localhost = InetAddress.getLocalHost
    localhost.getHostAddress
  }

  def getMonth( index: Int ): Option[ String ] = {
    monthsMap.get( index )
  }

  def replaceNullIfAny( s: String ) = s match {
    case null => ""
    case x    => x
  }

}
