package com.arlsura.afiliacion.utils

import scala.util.matching.Regex

/**
 * Created by Jesús Martínez on 6/07/15.
 *
 * Singleton que provee validaciones generales para distintos tipos de entrada, tales como
 * correo electrónico, teléfono, celular, entre otros.
 */
object FormatValidator {

  private final val PHONE_PATTERN: Regex = "^[1-9][0-9]{6}$".r
  private final val CELLPHONE_PATTERN: Regex = "^[1-9][0-9]{9}$".r
  private final val EMAIL_REGEX: Regex = "^([\\w-]+(?:\\.[\\w-]+)*)@((?:[\\w-]+\\.)*\\w[\\w-]{0,66})\\.([a-z]{2,20}(?:\\.[a-z]{2})?)$".r
  private final val NAME_MINIMUM_LENGTH: Int = 2
  private final val NAME_MAXIMUM_LENGTH: Int = 80
  private final val IP_V4_PATTERN: Regex = "^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$".r
  /**
   * Valida que un texto cumpla con una expresión regular.
   * @param input Texto a ser comparado.
   * @param pattern Expresión regular utilizada para la comparación.
   * @return True si hay cumplimiento, false si no.
   */
  private def matchesPattern( input: String, pattern: Regex ): Boolean = pattern.findFirstIn( input ).nonEmpty

  /**
   * Valida que un texto corresponda a un email válido.
   * @param email Texto a ser verificado.
   * @return True si es correcto, false si no.
   */
  def validEmail( email: String ): Boolean = matchesPattern( email, EMAIL_REGEX )

  /**
   * Verifica que los caracteres de una cadena de texto sean sólo letras o números.
   * @param input Texto a ser verificado.
   * @return True si es correcto, false si no.
   */
  def alphanumeric( input: String, allowWhitespaces: Boolean = true ): Boolean =
    if ( allowWhitespaces ) {
      input.forall( c => c.isLetterOrDigit || c.isSpaceChar )
    }
    else {
      input.forall( _.isLetterOrDigit )
    }

  /**
   * Verifica que los caracteres de una cadena de texto sean sólo números.
   * @param input Texto a ser verificado.
   * @return True si es correcto, false si no.
   */
  def numeric( input: String ): Boolean = input.forall( _.isDigit )

  /**
   * Verifica que los catacteres de una cadena de texto sean solo letras.
   * @param input Texto a ser verificado.
   * @return True si es correcto, false si no.
   */
  def alphabetic( input: String, allowWhitespaces: Boolean = true ): Boolean =
    if ( allowWhitespaces ) {
      input.forall( c => c.isLetter || c.isSpaceChar )
    }
    else {
      input.forall( _.isLetter )
    }

  /**
   * Verifica que el texto de entrada corresponda a un nombre válido.
   * @param input Texto a ser verificado.
   * @return True si es correcto, false si no.
   */
  def validName( input: String ): Boolean = {
    val length = input.length
    val validLength = NAME_MINIMUM_LENGTH <= length && length <= NAME_MAXIMUM_LENGTH
    validLength && alphabetic( input )
  }

  /**
   * Verifica que el texto de entrada corresponda a un número de celular válido.
   * @param input Texto a ser verificado.
   * @return True si es correcto, false si no.
   */
  def validCellphone( input: String ): Boolean = matchesPattern( input, CELLPHONE_PATTERN )

  /**
   * Verifica que el texto de entrada corresponda a un número telefónico válido.
   * @param input Texto a ser verificado.
   * @return True si es correcto, false si no.
   */
  def validPhone( input: String ): Boolean = matchesPattern( input, PHONE_PATTERN )

  /**
   * Verifica que el texto de entrada corresponda a una dirección IPv4 válida.
   * @param input Texto a ser verificado.
   * @return True si es correcto, false si no.
   */
  def validIPv4( input: String ): Boolean = matchesPattern( input, IP_V4_PATTERN )
}
