package com.arlsura.afiliacion.utils.messages

import com.arlsura.afiliacion.utils.Utils

/**
 * Created by juanmartinez on 15/05/15.
 */
object MessagesFormRetriever {

  /**
   * retorna los mensajes necesarios para los mensajes en los reportes
   * @param entity
   * @param kind
   * @param messageName
   * @return
   */
  def getMessage( entity: String, kind: String, messageName: String ) =
    Utils.getProperty( s"$entity.$kind.", messageName ).asInstanceOf[ String ]

}
