package com.arlsura.afiliacion.utils

/**
 * Created by John on 21/05/15.
 */
class ProxyParameters {

  private val proxyPropertyName: String = "proxy."

  val environmentHasProxy: Boolean = Utils.getProperty( proxyPropertyName, "proxy" ).asInstanceOf[ Boolean ]

  val protocol: Option[ String ] = if ( environmentHasProxy ) Some( Utils.getProperty( proxyPropertyName, "protocol" ).asInstanceOf[ String ] ) else None

  val URL: Option[ String ] = if ( environmentHasProxy ) Some( Utils.getProperty( proxyPropertyName, "url" ).asInstanceOf[ String ] ) else None

  val port: Option[ Int ] = if ( environmentHasProxy ) Some( Utils.getProperty( proxyPropertyName, "port" ).asInstanceOf[ Int ] ) else None

}
