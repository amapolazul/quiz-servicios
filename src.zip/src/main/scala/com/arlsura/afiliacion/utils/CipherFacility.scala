package com.arlsura.afiliacion.utils

import java.security.MessageDigest
import java.util
import javax.crypto.{ Cipher, SecretKeyFactory }
import javax.crypto.spec.{ IvParameterSpec, SecretKeySpec, PBEKeySpec }
import org.apache.commons.codec.binary.Base64

/**
 * Created by Jesús Martínez on 23/06/15.
 */
trait CipherFacility {
  //Instancia de algoritmo de hasheo SHA-1
  private val sha1 = MessageDigest.getInstance( "SHA-1" )
  //Palabra secreta utilizada para el algoritmo de cifrado.
  private val passphrase = Utils.getProperty( "persistence.", "passphrase" ).asInstanceOf[ String ]
  private val keyDigest = initKeyDigest
  private val secretKey = initSecretKey
  private val vector = initVector
  private val cipher = Cipher.getInstance( "AES/CBC/PKCS5Padding" )

  private def initKeyDigest: Array[ Byte ] = {
    val sha1 = MessageDigest.getInstance( "SHA-1" )
    sha1.digest( this.passphrase.getBytes( "UTF-8" ) )
  }
  private def initVector: IvParameterSpec = {
    val keyRehashed = sha1.digest( keyDigest )
    new IvParameterSpec( util.Arrays.copyOf( keyRehashed, 16 ) )
  }

  private def initSecretKey: SecretKeySpec = new SecretKeySpec( util.Arrays.copyOf( keyDigest, 16 ), "AES" )

  private def setCipherToEncryptMode(): Unit = cipher.init( Cipher.ENCRYPT_MODE, secretKey, vector )

  private def setCipherToDecryptMode(): Unit = cipher.init( Cipher.DECRYPT_MODE, secretKey, vector )

  /**
   * Obtiene data en forma de string y la cifra usando AES.
   * @param data String a ser cifrado.
   * @return Versión cifrada del String
   */
  def encode( data: String ): String = {
    this.synchronized {
      setCipherToEncryptMode()
      val dataBytes = data.getBytes
      val encrypted = cipher.doFinal( dataBytes )
      Base64.encodeBase64URLSafeString( encrypted )
    }
  }

  /**
   * Obtiene un string representando información cifrada y lo descifra usando AES.
   * @param encoded String a ser descifrado.
   * @return Versión original del string previamente cifrado.
   */
  def decode( encoded: String ): String = {
    this.synchronized {
      setCipherToDecryptMode()
      val bytes = Base64.decodeBase64( encoded )
      val decrypted = cipher.doFinal( bytes )
      new String( decrypted )
    }
  }

  /**
   * Codifica un string, haciendo uso de un salt y un timestamp (opcional). Para separar cada elemento, se utiliza una
   * secuencia de caracteres (por defecto '-').
   * @param salt Valor para generar entropía en el cifrado.
   * @param data Data que se quiere codificar.
   * @param timestamp True si se desea añadir estampa de tiempo
   * @param sep Separador de elementos.
   * @return String codificado.
   */
  def encode( salt: String, data: String, timestamp: Boolean = true, sep: String = "-" ): String =
    this.encode( salt + sep + data + sep + ( if ( timestamp ) Utils.getTimestamp else "" ) )

  /**
   * Decodifica un string, devolviendo tres resultados: El salt usado para codificarlo, la información en sí y el timestamp, de haberlo. Para que funcione
   * hay que cersiorarse de que el dato codificado fue o no generado con timestamp (usar el flag apropiado), y que el separador para decodificar sea el mismo
   * usado para codificar.
   * @param encoded Data cifrada.
   * @param timestamp True si se cifró con estampa de tiempo, false en caso contrario.
   * @param sep Separador de elementos utilizado en el cifrado.
   * @return Terna con la siguiente estructura (salt, data, timestamp [en un Some, en caso de haberlo; si no, None]) si el descifrado fue exitoso; mensaje de error si no.
   */
  def decode( encoded: String, timestamp: Boolean, sep: String = "-" ): Either[ String, ( String, String, Option[ String ] ) ] = {
    val errMsg = "Ocurrió un error decodificando. Verifique que la información fue codificada con estampa de tiempo y que el separador provisto sea el mismo de la codificación."

    val decoded: String = this.decode( encoded )

    val tokens: Array[ String ] = decoded.split( sep )

    if ( timestamp ) {
      if ( tokens.length != 3 ) {
        Left( errMsg )
      }
      else {
        Right( ( tokens( 0 ), tokens( 1 ), Some( tokens( 2 ) ) ) )
      }
    }
    else {
      if ( tokens.length != 2 ) {
        Left( errMsg )
      }
      else {
        Right( ( tokens( 0 ), tokens( 1 ), None ) )
      }
    }

  }

}
