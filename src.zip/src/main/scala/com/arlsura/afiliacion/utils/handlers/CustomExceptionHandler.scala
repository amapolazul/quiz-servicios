package com.arlsura.afiliacion.utils.handlers

import spray.http.StatusCodes._
import spray.http.{ StatusCodes, IllegalRequestException, RequestProcessingException }
import spray.routing.{ ExceptionHandler, Route, RoutingSettings }
import spray.util.LoggingContext

import scala.util.control.NonFatal

trait CustomExceptionHandler extends ExceptionHandler.PF

object CustomExceptionHandler {
  type PF = PartialFunction[ Throwable, Route ]

  implicit def apply( pf: PF ): ExceptionHandler =
    new ExceptionHandler {
      def isDefinedAt( error: Throwable ) = pf.isDefinedAt( error )
      def apply( error: Throwable ) = pf( error )
    }

  implicit def default( implicit settings: RoutingSettings, log: LoggingContext ): ExceptionHandler =
    apply {
      case e: IllegalRequestException => ctx =>
        //        log.warning(
        //          "Illegal request {}\n\t{}\n\tCompleting with '{}' response",
        //          ctx.request, e.getMessage, e.status
        //        )
        ctx.complete( ( e.status, e.info.format( settings.verboseErrorMessages ) ) )

        case e: RequestProcessingException => ctx =>
        //        log.warning(
        //          "Request {} could not be handled normally\n\t{}\n\tCompleting with '{}' response",
        //          ctx.request, e.getMessage, e.status
        //        )
        ctx.complete( ( e.status, e.info.format( settings.verboseErrorMessages ) ) )

        case e: IllegalArgumentException => ctx =>
        //        log.warning( "Un error inesperado ha ocurrido" )
        ctx.complete( ( StatusCodes.InternalServerError, e.getMessage ) )

        case NonFatal( e ) => ctx =>
          log.error( e, "Error during processing of request {}", ctx.request )
          ctx.complete( InternalServerError )
    }
}
