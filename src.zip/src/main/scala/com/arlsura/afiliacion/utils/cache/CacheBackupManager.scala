package com.arlsura.afiliacion.utils.cache

import com.arlsura.afiliacion.persistence.cache.entities._
import com.arlsura.afiliacion.utils.Utils
import com.typesafe.scalalogging
import spray.json._
import scala.io.Source

/**
 * Created by Jesús Martínez on 10/08/15.
 */
class CacheBackupManager extends scalalogging.LazyLogging {
  private val validCollections = Set( "addresses", "eps", "afps", "arps", "legal_natures", "contributor_types", "economic_activities", "salary", "charges" )

  def loadBackup[ T ]( collectionName: String, fromDisk: Boolean = false )( implicit jsonReader: JsonReader[ T ] ): Seq[ T ] = {
    require( validCollections contains collectionName.toLowerCase, s"No existe colección $collectionName" )

    //    logger.debug( s"Loading backup for collection: $collectionName" )

    val data: String = fromDisk match {
      case true =>
        val filename = s"/opt/app/backups/${collectionName}_backup.txt"
        Source.fromFile( filename ).getLines().next()
      case false =>
        Utils.getProperty( "backups.", collectionName ).asInstanceOf[ String ]
    }

    val cleanedData = data.filterNot( _.isControl )
    val dataTokens = cleanedData.split( "%%%" )
    val result = dataTokens.map( _.parseJson.convertTo[ T ] )

    //    logger.debug( s"Successfully read file. Here's the data:\n $result" )
    result
  }

}

object CacheBackupManager extends DefaultJsonProtocol with scalalogging.LazyLogging {

  implicit val municipalityElementJsonFormat: RootJsonFormat[ MunicipalityElement ] = jsonFormat4( MunicipalityElement )
  implicit val provinceElementJsonFormat = jsonFormat5( ProvinceElement )
  implicit val addressesCacheJsonFormat = jsonFormat3( AddressCache )
  implicit val epsCacheJsonFormat = jsonFormat4( EPSCache )
  implicit val afpsCacheJsonFormat = jsonFormat4( AFPCache )
  implicit val arpsCacheJsonFormat = jsonFormat4( ARPCache )
  implicit val salaryCacheJsonFormat = jsonFormat1( SalaryCache )
  implicit val legalNaturesCacheJsonFormat = jsonFormat4( LegalNaturesCache )
  implicit val economicActivitiesCacheJsonFormat = jsonFormat4( EconomicActivityCache )
  implicit val contributorTypesCacheJsonFormat = jsonFormat5( ContributorTypeCache )
  implicit val chargesCacheJsonFormat = jsonFormat3( ChargeCache )
}

