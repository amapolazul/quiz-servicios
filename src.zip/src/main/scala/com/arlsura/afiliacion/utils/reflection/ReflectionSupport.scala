package com.arlsura.afiliacion.utils.reflection

import com.arlsura.afiliacion.persistence.entities.LongExtension

/**
 * Created by juanmartinez on 22/12/14.
 */
trait ReflectionSupport {

  /**
   * Define el universo para la refleccion
   */
  val runtimeUniverse = scala.reflect.runtime.universe

  /**
   * Devuelve el metodo reflejado
   * @param signature
   * @param typeRef
   * @return
   */
  def getReflectedMethod( signature: String, typeRef: Any ): ReflectionSupport.this.runtimeUniverse.MethodSymbol = {
    if ( typeRef.isInstanceOf[ LongExtension ] )
      runtimeUniverse.typeOf[ LongExtension ].decl( runtimeUniverse.TermName( signature ) ).asMethod
    else
      null
  }

}
