package com.arlsura.afiliacion.utils.resources

import com.arlsura.afiliacion.utils.Utils

/**
 * Created by juanmartinez on 3/02/15.
 */
object ResourcesNameRetriever {

  /**
   * Retorna un mensaje definido en alguno de los archivos de configuración "success_messages.conf" o "error_messages.conf"
   * @param entity Entidad específica del mensaje que se desea obtener.
   * @param messageName Nombre del mensaje que se desea obtener.
   * @return String con el contenido del mensaje.
   */
  def getResource( entity: String, messageName: String ) =
    Utils.getProperty( s"resources.$entity.", messageName ).asInstanceOf[ String ]

}
