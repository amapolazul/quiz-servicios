package com.arlsura.afiliacion.utils.directives

import com.arlsura.afiliacion.headers.CORSHeaders
import com.arlsura.afiliacion.utils.handlers.{ CustomRejectionHandler, CustomExceptionHandler }
import spray.routing._

/**
 * Created by juanmartinez on 19/01/15.
 */
trait CustomDirectives extends HttpService with CORSHeaders {

  def CORSRejectionAndExceptionSupport: Directive0 = {
    respondWithHeaders( crossHeadersList ) &
      handleExceptions( CustomExceptionHandler.default orElse ExceptionHandler.default ) &
      handleRejections( CustomRejectionHandler.Default )
  }

}
