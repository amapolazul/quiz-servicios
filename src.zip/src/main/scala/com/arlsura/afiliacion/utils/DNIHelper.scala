package com.arlsura.afiliacion.utils

/**
 * Created by John on 31/03/15.
 */
object DNIHelper {

  val NIT = "NI"

  def isNIT( identificationType: String ): Boolean = identificationType equals NIT

}
