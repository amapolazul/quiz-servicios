package com.arlsura.afiliacion.utils.messages

import com.arlsura.afiliacion.utils.Utils

/**
 * Created by Jesús Martínez on 25/11/14.
 */
object MessagesRetriever {
  /**
   * Retorna un mensaje definido en alguno de los archivos de configuración "success_messages.conf" o "error_messages.conf"
   * @param entity Entidad específica del mensaje que se desea obtener.
   * @param kind Tipo de mensaje: "error" o "success"
   * @param messageName Nombre del mensaje que se desea obtener.
   * @return String con el contenido del mensaje.
   */
  private def getMessage( entity: String, kind: String, messageName: String ) =
    Utils.getProperty( s"messages.$kind.$entity.", messageName ).asInstanceOf[ String ]

  /**
   * Retorna un mensaje de éxito, presente en el archivo "success_messages.conf"
   * @param entity Entidad específica del mensaje que se desea obtener.
   * @param messageName Nombre del mensaje que se desea obtener.
   * @return String con el contenido del mensaje.
   */
  def getSuccessMessage( entity: String, messageName: String ) = getMessage( entity, "success", messageName )

  /**
   * Retorna un mensaje de error, presente en el archivo "error.conf"
   * @param entity Entidad específica del mensaje que se desea obtener.
   * @param messageName Nombre del mensaje que se desea obtener.
   * @return String con el contenido del mensaje.
   */
  def getErrorMessage( entity: String, messageName: String ) = getMessage( entity, "error", messageName )
}
