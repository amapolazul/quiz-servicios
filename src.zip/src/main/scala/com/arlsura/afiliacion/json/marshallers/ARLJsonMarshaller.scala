package com.arlsura.afiliacion.json.marshallers

import com.arlsura.afiliacion.bussiness.segmentation.SegmentationManager
import com.arlsura.afiliacion.persistence.entities.affiliation.basic_data.{ BankInformation, Address }
import com.arlsura.afiliacion.persistence.cache.entities.{ EPSCache, AFPCache, AddressCache }
import com.arlsura.afiliacion.persistence.entities.affiliation.employee_data.EmployeeInformation
import com.arlsura.afiliacion.persistence.entities.affiliation.work_center_data.WorkCenterInformation
import com.arlsura.afiliacion.persistence.entities.preaffiliation.FullEconomicActivity
import org.joda.time.DateTime
import org.json4s.{ DefaultFormats, Formats }
import spray.httpx.Json4sSupport
import java.util.Date
import com.arlsura.afiliacion.utils.FormatValidator

/**
 * Aqui se definen todas las clases que son transformadas a respuestas y peticiones JSON
 * Todas deben heredar la clase GeneralJsonResponseData para agregar los dos campos
 *
 * Created by juanmartinez on 4/11/14.
 */
object ARLJsonMarshaller extends Json4sSupport {
  override implicit def json4sFormats: Formats = DefaultFormats

  case class GeneralJsonResponseData( message: String, data: Option[ Any ] = None, suraSessionManager: Option[ String ] = None )

  case class FormatValidationWebResponse( isValid: Boolean )

  case class CustomerOptionMenuResponse( customerOptions: List[ String ] )

  case class ClientWithSelfEmployeeServiceResponse( hasSelfEmployees: Boolean )

  case class KeyExistenceCheckWebResponse( hasKey: Boolean )

  case class PreValidateARLWebResponse( canProceed: Boolean )

  case class LastEntranceDateServiceResponse( firstEntrance: Boolean, lastEntrance: Option[ Date ] )

  case class AffiliationCheckWebResponse( affiliated: Boolean )

  case class AffiliationValidationResponse( status: Int, message: String, data: AffiliationCheckWebResponse )

  case class SaveLastEntranceServiceResponse( lastEntrance: Date )

  case class ClientHasCodeFromCommercialOfficeServiceResponse( hasCommercialCode: Boolean, expirationDate: Option[ Date ] )

  case class CodeValidationData( dni: String, code: String )

  case class CodeRecallData( by: String, key: String )

  case class ClientMatchesCodeServiceResponse( codeMatches: Boolean, hasExpired: Boolean, source: String, suraSessionManager: String )

  case class Person( docType: String = "", document: String = "", name: String = "", secondName: String = "", lastName: String = "", secondLastName: String = "", fullName: String = "", dni: String = "", exist: Boolean )

  case class ExceptionOccurred( cause: String, message: String )

  case class ARP( groupCode: Int, arpCode: Int, dni: String, dsCommercial: String )

  case class PreAffiliationResponse( affiliated: Boolean, codeExpirationDate: String, segmentationValidationPassed: Boolean )

  case class MunicipalityConsultWebResponse( delegationCode: String, branchCode: String )

  case class AddressFullInformationConsultWebResponse( results: List[ AddressCache ] )

  case class AddressSingleParamProjectionConsultWebResponse( results: List[ String ] )

  case class ARLList( arls: List[ ARP ] )

  case class CodeWasGeneratedNotificationServiceResponse( emailWasSend: Boolean )

  case class PreAffiliationExistResponse( exist: Boolean )

  case class SegmentationEntityResponse( id: Option[ String ], ciiu: String, city: String, operator: String, num_workers: Long )

  case class SegmentationEntityRequest( id: Option[ String ], ciiu: String, city: String, operator: String, num_workers: Long ) {
    require( !ciiu.isEmpty, "El ciiu no puede estar vacío" )
    require( !city.isEmpty, "La ciudad no puede estar vacía" )
    require( !operator.isEmpty && SegmentationManager.getAvailableOperators.contains( operator ), "El operador no coincide con los permitidos por la aplicación" )
    require( num_workers < 99999L, "El número de trabajadores no puede ser mayor a 100000" )
  }

  case class SegmentationRulesResponse( segmentationRules: List[ SegmentationEntityResponse ] )

  case class SegmentationOperator( id: String, description: String )

  case class SegmentationOperators( list: List[ SegmentationOperator ] )

  case class ValidateSegmentationRuleResponse( segmentationValidationPassed: Boolean )

  case class CreateCommercialResponsibleRequest( office: Int, city: String, fullName: String, email: String, charge: String, networkUser: String, dni: String ) {
    require( office > 0, "El número de la oficina debe ser superior a 0." )
    require( FormatValidator.alphabetic( city ), "El nombre de la ciudad de contener sólo letras." )
    require( FormatValidator.validName( fullName ), "El nombre es inválido." )
    require( FormatValidator.validEmail( email ), "El email es inválido." )
    require( FormatValidator.alphabetic( charge ), "El cargo es inválido." )
    require( FormatValidator.alphanumeric( networkUser ), "El usuario de red es inválido." )
    require( FormatValidator.alphanumeric( dni ), "El DNI es inválido." )
  }

  case class GetCommercialResponsibleRequest( office: Option[ Int ] = None, city: Option[ String ] = None, fullName: Option[ String ] = None, email: Option[ String ] = None, charge: Option[ String ] = None, networkUser: Option[ String ] = None, dni: Option[ String ] = None )

  case class UpdateCommercialResponsibleRequest( id: String, office: Option[ Int ] = None, city: Option[ String ] = None, fullName: Option[ String ] = None, email: Option[ String ] = None, charge: Option[ String ] = None, networkUser: Option[ String ] = None, dni: Option[ String ] = None ) {
    require( office.forall( _ > 0 ), "El número de la oficina debe ser superior a 0." )
    require( city.forall( FormatValidator.alphabetic( _ ) ), "El nombre de la ciudad de contener sólo letras." )
    require( fullName.forall( FormatValidator.validName ), "El nombre es inválido." )
    require( email.forall( FormatValidator.validEmail ), "El email es inválido." )
    require( charge.forall( FormatValidator.alphabetic( _ ) ), "El cargo es inválido." )
    require( networkUser.forall( FormatValidator.alphanumeric( _ ) ), "El usuario de red es inválido." )
    require( dni.forall( FormatValidator.alphanumeric( _ ) ), "El DNI es inválido." )
  }

  case class CreateOHvsRUTRecordRequest( rutStartDate: String, rutExpirationDate: String, CIIUActivityCode: String, OHActivityCode: String, quotationRate: Double, description: String ) {
    require( rutStartDate.nonEmpty, "Debe proveer una fecha de inicio de vigencia del RUT." )
    require( rutExpirationDate.nonEmpty, "Debe proveer una fecha de expiración de vigencia del RUT." )
    require( quotationRate >= 0.0, "La tasa de cotización no puede ser negativa." )
    require( quotationRate <= 100.0, "La tasa de cotización debe ser a lo sumo 100%" )
    require( description.nonEmpty, "La descripción no puedes estar vacía." )

    override def toString = {
      s"$rutStartDate ; $rutExpirationDate ; $CIIUActivityCode ; $OHActivityCode ; $quotationRate ; $description"
    }
  }

  case class UpdateOHvsRUTRecordRequest( id: String, rutStartDate: Option[ String ] = None, rutExpirationDate: Option[ String ] = None, CIIUActivityCode: Option[ String ] = None, OHActivityCode: Option[ String ] = None, quotationRate: Option[ Double ], description: Option[ String ] = None ) {
    require( rutStartDate.forall( _.nonEmpty ), "Debe proveer una fecha de inicio de vigencia del RUT." )
    require( rutExpirationDate.forall( _.nonEmpty ), "Debe proveer una fecha de expiración de vigencia del RUT." )
    require( quotationRate.forall( _ >= 0.0 ), "La tasa de cotización no puede ser negativa." )
    require( quotationRate.forall( _ <= 100.0 ), "La tasa de cotización debe ser a lo sumo 100%" )
    require( description.forall( _.nonEmpty ), "La descripción no puedes estar vacía." )
  }

  case class Activity( cdActivity: String, cdClass: String, acName: String, rate: Double )

  case class ActivityListResponse( activities: List[ Activity ] )

  case class DomesticEmployerActivity( id: Option[ String ], code: String, description: String, name: String ) {
    require( !code.isEmpty, "El código de la actividad no debe ser vacío" )
    require( !description.isEmpty, "La descripción de la actividad no debe estar vacía" )
    require( !name.isEmpty, "El nombre no puede ser vacio" )
  }

  case class SaveAffiliationBasicData(
      identification:       String,
      identificationType:   String,
      dni:                  String,
      name:                 Option[ String ]          = None,
      name1:                Option[ String ]          = None,
      name2:                Option[ String ]          = None,
      lastname1:            Option[ String ]          = None,
      lastname2:            Option[ String ]          = None,
      commercialName:       Option[ String ]          = None,
      newCompany:           Option[ Boolean ]         = None,
      personType:           String,
      juridicalNature:      Option[ Int ]             = None,
      contributorType:      Int,
      previousARL:          Option[ String ]          = None,
      letterDeliveryDate:   Option[ Long ]            = None,
      coverageStartDate:    Option[ Long ]            = None,
      foundationDate:       Option[ Long ]            = None,
      fullEconomicActivity: FullEconomicActivity,
      mainAddress:          Option[ Address ]         = None,
      mailAddress:          Option[ Address ]         = None,
      bankInformation:      Option[ BankInformation ] = None,
      provincesSelected:    List[ ProvinceSelected ]
  ) {
    private def checkValidCoverageDate = {
      newCompany match {
        case Some( true ) =>
          true
        case Some( false ) =>
          ( letterDeliveryDate, coverageStartDate ) match {
            case ( Some( letterDate ), Some( coverageDate ) ) =>
              val datePlus30Days = new DateTime( letterDate ).plusDays( 30 )
              val datePlusFraction = datePlus30Days.plusMonths( 1 ).withDayOfMonth( 1 )

              datePlusFraction.toDate.getTime == coverageDate
            case ( _, _ ) =>
              false
          }
        case None => true
      }
    }

    require( name.forall( FormatValidator.alphabetic( _ ) ), "El nombre sólo puede contener letras y espacios." )
    require( name1.forall( FormatValidator.alphabetic( _ ) ), "El nombre sólo puede contener letras y espacios." )
    require( name2.forall( FormatValidator.alphabetic( _ ) ), "El nombre sólo puede contener letras y espacios." )
    require( lastname1.forall( FormatValidator.alphabetic( _ ) ), "El apellido sólo puede contener letras y espacios." )
    require( lastname2.forall( FormatValidator.alphabetic( _ ) ), "El apellido sólo puede contener letras y espacios." )
    require( mailAddress.forall( Address.validFormat ), "La dirección no es válida." )
    require( mainAddress.forall( Address.validFormat ), "La dirección no es válida." )
    require( checkValidCoverageDate, "La fecha de inicio de cobertura no es correcta." )
  }

  case class ProvinceSelected( provinceName: String, provinceCode: String )

  case class DomesticActivityList( domesticEmployerActivities: List[ DomesticEmployerActivity ] )

  case class SingleDomesticActivityResponse( activity: DomesticEmployerActivity )

  case class SeusAuthenticationResponse( tokenMus: String, tokenPubs: String, nombre: String )

  case class SeusAuthenticationRequest( login: String, password: String, ip: String )

  case class CheckAffiliationResponse( affiliations: Int )

  case class CheckAffiliationServiceResponse( message: String, data: CheckAffiliationResponse )

  case class LegalNature( cdnaturaleza_juridica: String, dsnaturaleza: String, cdentidad_oficial: String, fealta: Option[ Date ], febaja: Option[ Date ], dni_ingresa: String )

  case class LegalNaturesResponse( message: String, data: List[ LegalNature ] )

  case class GetAllAFPsResponse( data: List[ AFPCache ] )

  case class GetAllEPSsResponse( data: List[ EPSCache ] )

  case class SaveContactInformation(
    dni:                          String,
    securityCode:                 String,
    legalRepresentative:          ContactInformationData,
    manager:                      ContactInformationData,
    humanResourcesRepresentative: ContactInformationData,
    rosterRepresentative:         ContactInformationData,
    workSafetyRepresentative:     ContactInformationData,
    insideTrainingRepresentative: ContactInformationData
  )

  case class ContactInformationData(
      identificationType: String,
      identification:     String,
      name1:              String,
      name2:              Option[ String ] = None,
      lastname1:          String,
      lastname2:          Option[ String ] = None,
      position:           Option[ String ] = None,
      phone:              Option[ String ] = None,
      email:              String,
      title:              Option[ String ] = None,
      contactId:          Option[ String ]
  ) {
    require( FormatValidator.validName( name1 ), "Nombre inválido." )
    require( FormatValidator.validName( lastname1 ), "Nombre inválido." )
    require( lastname2.forall( FormatValidator.validName ), "Apellido inválido." )
    require( name2.forall( FormatValidator.validName ), "Apellido inválido." )
    require( phone.forall( FormatValidator.validPhone ), "Teléfono inválido." )
    require( FormatValidator.validEmail( email ) || email.isEmpty, "Correo electrónico inválido." )
    require( title.forall( FormatValidator.alphabetic( _ ) ), "Cargo inválido." )
    require( position.forall( FormatValidator.numeric ), "Puesto inválido." )
  }

  case class SaveEmployeesData( dni: String, securityCode: String, employees: List[ EmployeeInformation ] ) {
    require( employees.forall( EmployeeInformation.validFormat ), "Información de empleados inválida." )
  }

  case class SaveWorkCentersData( dni: String, securityCode: String, workCenters: List[ WorkCenterInformation ] ) {
    require( workCenters.forall( WorkCenterInformation.validFormat ), "Información de centros de trabajo inválida." )
  }

  case class BlacklistEntry( dni: String, factor: Double, since: Long ) {
    require( factor > 0.5 && factor % 0.5 == 0, "El factor debe ser múltiplo de 0,5 y mayor a 0,5." )
  }

  case class BlacklistEntryResponse( dni: String, factor: Double, since: Long, until: Long ) {
    require( factor > 0.5 && factor % 0.5 == 0, "El factor debe ser múltiplo de 0,5 y mayor a 0,5." )
  }

}

