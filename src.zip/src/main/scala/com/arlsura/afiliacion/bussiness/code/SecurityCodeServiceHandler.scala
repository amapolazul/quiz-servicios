package com.arlsura.afiliacion.bussiness.code

import com.arlsura.afiliacion.bussiness.HandlerSupport.ServiceHandlerResponse
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.GeneralJsonResponseData
import com.google.inject.Inject

/**
 * Created by root on 6/02/15.
 */
class SecurityCodeServiceHandler @Inject() ( securityCodeManager: SecurityCodeManager ) {

  /**
   * Genera un código de seguridad basado en unos parámetros.
   * @param length Longitud que debe tener el código.
   * @param alphanumeric Indica si el código debe contener solo números o también puede incluir letras.
   */
  def generateSecurityCode( length: Int, alphanumeric: Boolean ): ServiceHandlerResponse =
    securityCodeManager.generateCode( length, alphanumeric ) match {
      case Right( c ) =>
        val response = GeneralJsonResponseData( "Código generado con éxito.", Some( Map( "code" -> c ) ) )
        Right( response )
      case Left( e ) =>
        Left( e.message )
    }
}
