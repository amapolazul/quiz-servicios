package com.arlsura.afiliacion.bussiness.legal_natures

import akka.actor.ActorSelection
import akka.pattern._
import com.arlsura.afiliacion.actors.cache.CacheRefresherActor
import com.arlsura.afiliacion.bussiness.RequestContextSupport
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.GeneralJsonResponseData
import com.arlsura.afiliacion.persistence.cache.entities.LegalNaturesCache
import com.arlsura.afiliacion.utils.GlobalParamsProvider
import com.arlsura.afiliacion.utils.messages.MessagesRetriever
import spray.http.StatusCodes
import spray.routing.RequestContext
import scala.concurrent.{ ExecutionContext, Future }
import scala.util.{ Failure, Success }

/**
 * Created by Jesús Martínez on 27/04/15.
 */
class LegalNaturesServiceHandler( context: RequestContext, cacheActor: ActorSelection )( implicit ec: ExecutionContext ) extends RequestContextSupport with GlobalParamsProvider {

  /**
   * Obtiene el catálogo de naturalezas jurídicas y completa la petición.
   */
  def retrieveLegalNaturesCatalog(): Unit = {
    getCatalog onComplete {
      case Success( list ) =>
        complete( context, StatusCodes.OK, GeneralJsonResponseData( LegalNaturesServiceHandler.getAllSuccessMessage, Some( list ) ) )
      case Failure( e ) =>
        completeWithFailure( context, e.toString )
    }
  }

  /**
   * Obtiene el catálogo de naturalezas jurídicas directamente del cache.
   * @return Futuro con una secuencia de tipos de naturalezas jurídicas.
   */
  private def getCatalog: Future[ Seq[ LegalNaturesCache ] ] = {
    val askableActor = new AskableActorSelection( cacheActor )
    val ask = ( askableActor ? CacheRefresherActor.GetLegalNaturesCatalog ).mapTo[ CacheRefresherActor.LegalNaturesCatalogReturned ]
    ask.map( _.catalog )
  }
}

/**
 * Companion
 */
object LegalNaturesServiceHandler {

  def getAllSuccessMessage = MessagesRetriever.getSuccessMessage( "juridical_natures", "GET_ALL" )

}
