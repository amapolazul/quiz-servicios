package com.arlsura.afiliacion.bussiness.charge

import akka.actor.ActorSelection

import akka.pattern.AskableActorSelection
import com.arlsura.afiliacion.actors.cache.CacheRefresherActor
import com.arlsura.afiliacion.bussiness.RequestContextSupport
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.GeneralJsonResponseData
import com.arlsura.afiliacion.persistence.cache.entities.ChargeCache
import com.arlsura.afiliacion.utils.GlobalParamsProvider
import spray.http.StatusCodes
import spray.routing.RequestContext
import scala.concurrent.{ Future, ExecutionContext }
import scala.util.{ Failure, Success }

/**
 * Created by Jesús Martínez on 26/08/15.
 */
class ChargeServiceHandler( requestContext: RequestContext, cacheActor: ActorSelection )( implicit ec: ExecutionContext ) extends RequestContextSupport with GlobalParamsProvider {

  /**
   * Obtiene todos los cargos almacenados en cache.
   */
  def retrieveCharges(): Unit = {
    getAllCharges onComplete {
      case Success( list ) =>
        val response = GeneralJsonResponseData( "Respuesta exitosa", Some( list ) )
        complete( requestContext, StatusCodes.OK, response )
      case Failure( f ) =>
        completeWithFailure( requestContext, f.toString )
    }
  }

  /**
   * Obtiene el catálogo de cargos.
   * @return Un futuro de una secuencia de objetos ChargeCache.
   */
  private def getAllCharges: Future[ Seq[ ChargeCache ] ] = {
    val askableActor = new AskableActorSelection( cacheActor )
    val ask = ( askableActor ? CacheRefresherActor.GetChargesCatalog ).mapTo[ CacheRefresherActor.ChargesCatalogReturned ]
    ask.map( _.catalog )
  }
}
