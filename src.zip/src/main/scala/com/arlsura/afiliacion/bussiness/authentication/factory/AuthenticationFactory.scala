package com.arlsura.afiliacion.bussiness.authentication.factory

import com.arlsura.afiliacion.bussiness.authentication.AuthenticationService
import com.arlsura.afiliacion.bussiness.authentication.implementations.SeusAuthenticationImplementation
import com.arlsura.afiliacion.utils.Utils

import scala.concurrent.Future

/**
 * Created by juanmartinez on 16/02/15.
 */
object AuthenticationFactory {

  def apply( authenticationMethod: String ) = {
    authenticationMethod match {
      case "seus" => new SeusAuthenticationImplementation
      case _ =>
        null
    }
  }

  /**
   * Obtiene las credenciales
   * @return
   */
  def getCredentials(): Credentials = {
    val username = Utils.getProperty( "soap.credentials.", "username" ).asInstanceOf[ String ]
    val password = Utils.getProperty( "soap.credentials.", "password" ).asInstanceOf[ String ]
    Credentials(
      username = username,
      password = password
    )
  }

}

/**
 * Clase que modela las credenciales del usuario nombrado para la autenticación
 * @param username
 * @param password
 */
case class Credentials( username: String, password: String )
