package com.arlsura.afiliacion.bussiness.affiliation.workcenters

import com.arlsura.afiliacion.persistence.daos.affiliation.wrappers.AffiliationWorkCentersDataWrapper
import com.arlsura.afiliacion.persistence.entities.affiliation.basic_data.Address
import com.arlsura.afiliacion.persistence.entities.affiliation.work_center_data.{ WorkCenterInformation, AffiliationWorkCentersData }
import com.arlsura.afiliacion.utils.CipherFacility
import com.google.inject.Inject
import reactivemongo.bson.{ BSONObjectID, BSONDocument }
import reactivemongo.core.commands.LastError
import scala.concurrent.{ Future, ExecutionContext }

/**
 * Created by Jesús Martínez on 6/05/2015.
 * @param dao [Dependencia] Objeto para interactuar con la base de datos.
 */
class WorkCentersDataRepository @Inject() ( private val dao: AffiliationWorkCentersDataWrapper ) extends CipherFacility {

  private def decryptDocument( d: AffiliationWorkCentersData ): AffiliationWorkCentersData =
    AffiliationWorkCentersData( _id = d._id, securityCode = d.securityCode, dni = decode( d.dni ), workCenters = d.workCenters.map( WorkCenterInformation.decrypt ) )

  private def encryptDocument( d: AffiliationWorkCentersData ): AffiliationWorkCentersData =
    AffiliationWorkCentersData( _id = d._id, securityCode = d.securityCode, dni = encode( d.dni ), workCenters = d.workCenters.map( WorkCenterInformation.encrypt ) )

  /**
   * Crea o actualiza un documento, dependiendo del caso. Primero, se realiza la busqueda de algun documento
   * que coincida con el DNI provisto; si se obtiene un resultado, se actualiza dicho documento. Si no, se crea uno nuevo.
   * @param dni DNI asociado al proceso de afiliación, el cual se usará como clave para la búsqueda.
   * @param securityCode Código de seguridad asociado al proceso de afiliación.
   * @param workCenters Lista actualizada de centros de trabajos
   * @return Futuro con el estado de la transacción.
   */
  def createOrUpdate( dni: String, securityCode: String, workCenters: List[ WorkCenterInformation ] )( implicit ec: ExecutionContext ): Future[ LastError ] = {
    val wcs: List[ WorkCenterInformation ] = workCenters.map( w => w.copy( workcenterName = w.workcenterName.replaceAll( "\\.", "" ) ) )
    findByDni( dni ) flatMap {
      maybeResult =>
        val id = maybeResult.map( _._id ).getOrElse( BSONObjectID.generate )
        val document = AffiliationWorkCentersData( id, dni, securityCode, wcs )
        //Si el documento ya existe, solo lo actualiza, si no, lo crea.
        dao.update( BSONDocument( "dni" -> encode( dni ) ), encryptDocument( document ), upsert = true )
    }
  }

  /**
   * Encuentra un documento en base de datos.
   * @param dni DNI asociado al proceso de afiliación, el cual se usará como clave para la búsqueda.
   * @return Futuro con a lo sumo un resultado (de existir alguno)
   */
  def findByDni( dni: String )( implicit ec: ExecutionContext ): Future[ Option[ AffiliationWorkCentersData ] ] = {
    dao.findOne( BSONDocument( "dni" -> encode( dni ) ) ) map ( _.map( decryptDocument ) )
  }

  /**
   * Elimina un documento en base de datos.
   * @param dni DNI asociado al proceso de afiliación, el cual se usará como clave para la búsqueda.
   * @return Futuro con el estado de la transaccion.
   */
  def removeByDni( dni: String )( implicit ec: ExecutionContext ): Future[ LastError ] = {
    dao.remove( BSONDocument( "dni" -> encode( dni ) ) )
  }

  /**
   * Crea un documento en la base de datos.
   * @param a Documento a ser insertado.
   * @return Futuro con el estado de la transacción.
   */
  def create( a: AffiliationWorkCentersData )( implicit ec: ExecutionContext ): Future[ LastError ] = {
    val wcs: List[ WorkCenterInformation ] = a.workCenters.map( w => w.copy( workcenterName = w.workcenterName.replaceAll( "\\.", "" ) ) )
    val na: AffiliationWorkCentersData = a.copy( workCenters = wcs )
    dao.insert( encryptDocument( na ) )
  }

  /**
   * Actualiza un documento, buscándolo por DNI.
   * @param dni Número de identificación utilizado como clave de búsqueda.
   * @param d Documento actualizado.
   * @return Futuro con el estado de la transacción.
   */
  def updateByDni( dni: String, d: AffiliationWorkCentersData )( implicit ec: ExecutionContext ): Future[ LastError ] = {
    val wcs: List[ WorkCenterInformation ] = d.workCenters.map( w => w.copy( workcenterName = w.workcenterName.replaceAll( "\\.", "" ) ) )
    val na: AffiliationWorkCentersData = d.copy( workCenters = wcs )
    dao.update( BSONDocument( "dni" -> encode( dni ) ), encryptDocument( na ) )
  }

}
