package com.arlsura.afiliacion.bussiness.cache

import co.com.sura.ventainformacion.service.MonedaCambioDTO
import com.arlsura.afiliacion.bussiness.SoapConsumerSupport
import com.arlsura.afiliacion.persistence.cache.entities.SalaryCache
import com.arlsura.afiliacion.utils.Utils
import com.suramericana.serviciosalarios.SalaryServiceConsumer
import com.typesafe.scalalogging.LazyLogging

/**
 * Created by Jesús Martínez on 24/04/15.
 */
object SalaryRefresher extends SoapConsumerSupport with LazyLogging {
  private lazy val salaryServiceUrl = Utils.getProperty( "soap.services.", "salary" ).asInstanceOf[ String ]
  private lazy val salaryServiceConsumer = new SalaryServiceConsumer( this.username, this.password, "1", salaryServiceUrl )

  /**
   * @return Colección de datos provenientes del servicio exterior.
   */
  private def consumeService(): Option[ Seq[ MonedaCambioDTO ] ] = {
    //    logger.debug( s"SALARY SERVICE URL: $salaryServiceUrl" )
    salaryServiceConsumer.authenticateToProxy( this.cloudProxyHost, this.cloudProxyPort, this.cloudProxyUser, this.cloudProxyPassword )
    val results = salaryServiceConsumer.consultarSalarioMinimo()

    if ( results != null && results.length > 0 ) Some( results.toSeq ) else None
  }

  /**
   * @param data Colección de datos "crudos" provenientes del servicio de terceros.
   * @return Colección de documentos que serán almacenados en Mongo.
   */
  private def prepareData( data: Seq[ MonedaCambioDTO ] ): Seq[ SalaryCache ] = data.map( m => SalaryCache( amount = m.getTipoCambio ) )

  def refresh( default: SalaryCache ): SalaryCache = {
    consumeService().map( prepareData ).map( _.head ).getOrElse( default )
  }
}
