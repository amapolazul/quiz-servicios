package com.arlsura.afiliacion.bussiness.blacklist

import java.util.Date

import com.arlsura.afiliacion.bussiness.HandlerSupport.ServiceHandlerResponse
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.{ BlacklistEntry, GeneralJsonResponseData, BlacklistEntryResponse }
import com.arlsura.afiliacion.utils.Utils
import com.arlsura.afiliacion.utils.messages.MessagesRetriever
import com.google.inject.Inject
import scala.concurrent.{ ExecutionContext, Future }

/**
 * Created by Jesús Martínez on 9/06/15.
 */
class BlacklistServiceHandler @Inject() ( repository: BlacklistRepository ) {
  import BlacklistServiceHandler._

  /**
   * Verifica si un determinado DNI está en la lista negra (bloqueado).
   * @param dni DNI que será consultado.
   * @return Un futuro con un Either, donde: Right contiene la respuesta exitosa de la consulta y Left un mensaje de error.
   */
  def get( dni: String )( implicit ec: ExecutionContext ): Future[ ServiceHandlerResponse ] = {
    repository.findByDni( dni ) map {
      option =>
        val response = option map {
          entry =>
            val payload = BlacklistEntryResponse( dni = entry.dni, factor = entry.factor, since = entry.since.toDate.getTime, until = entry.calculateBlockEnd.toDate.getTime )
            GeneralJsonResponseData( message = getEntrySuccessMessage, suraSessionManager = getSessionString( dni ), data = Some( payload ) )
        } getOrElse {
          GeneralJsonResponseData( message = noEntrySuccessMessage, suraSessionManager = getSessionString( dni ) )
        }

        Right( response )
    } recover {
      case e: Throwable =>
        Left( "" )
    }
  }

  /**
   * Guarda en la lista negra la información de bloqueo de un determiando usuario.
   * @param entry Objeto con la información de una entrada en la lista negra.
   * @return Un futuro con un Either, donde: Right contiene la respuesta exitosa de la consulta y Left un mensaje de error.
   */
  def save( entry: BlacklistEntry )( implicit ec: ExecutionContext ): Future[ ServiceHandlerResponse ] = {
    repository.save( entry.dni, entry.since, entry.factor ) map {
      status =>
        if ( status.ok ) {
          val response = GeneralJsonResponseData( message = saveEntrySuccessMessage, suraSessionManager = getSessionString( entry.dni ) )
          Right( response )
        }
        else {
          Left( errorOccurredMessage( status.err.getOrElse( "ERROR." ) ) )
        }
    } recover {
      case e: Throwable =>
        Left( "" )
    }
  }

  //TODO Sacar esto a un trait.
  private def getSessionString( dni: String ): Option[ String ] = {
    val d = s"$dni-${new Date().getTime}"
    Some( Utils.encodeFile( d.getBytes ) )
  }
}

object BlacklistServiceHandler {
  //mensajes de error y de exito para las respuestas
  val getEntrySuccessMessage: String = MessagesRetriever.getSuccessMessage( "blacklist", "GET" )
  val noEntrySuccessMessage: String = MessagesRetriever.getSuccessMessage( "blacklist", "NO_ENTRY" )
  val saveEntrySuccessMessage: String = MessagesRetriever.getSuccessMessage( "blacklist", "SAVE" )
  def errorOccurredMessage( error: String ): String = s"Ocurrió un error: $error"
}
