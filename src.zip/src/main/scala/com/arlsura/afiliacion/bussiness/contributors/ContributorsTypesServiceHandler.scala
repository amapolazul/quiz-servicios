package com.arlsura.afiliacion.bussiness.contributors

import com.arlsura.afiliacion.actors.cache.CacheRefresherActor
import com.arlsura.afiliacion.bussiness.RequestContextSupport
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.GeneralJsonResponseData
import com.arlsura.afiliacion.persistence.cache.entities.ContributorTypeCache
import spray.http.StatusCodes
import spray.routing.RequestContext
import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future
import scala.util.{ Success, Failure }
import akka.pattern._
import akka.actor.{ ActorSelection, ActorRef }
import com.arlsura.afiliacion.utils.GlobalParamsProvider

/**
 * Created by Jesús Martínez on 1/04/15.
 */
class ContributorsTypesServiceHandler( requestContext: RequestContext, cacheActor: ActorSelection ) extends RequestContextSupport with GlobalParamsProvider {
  /**
   * Obtiene el catálogo de tipos de contribuyentes, y completa la petición.
   */
  def retrieveAllContributorsTypes(): Unit = process( getContributorsTypesCatalog )

  /**
   * Obtiene todos los tipos de contribuyentes que coincidan con el código, y completa la petición.
   * @param code Código utilizado para filtrar el tipo de contribuyentes deseado.
   */
  def retrieveContributorsTypesByAffiliateCode( code: String = "" ): Unit =
    if ( code.nonEmpty )
      process( getContributorsTypesCatalog.map( c => c.filter( _.affiliateTypeCode == code ) ) )
    else
      retrieveAllContributorsTypes()

  /**
   * Procesa un futuro con el resultado de una petición, y procede a completarla.
   * @param f Futuro a ser procesado.
   */
  private def process( f: Future[ Seq[ ContributorTypeCache ] ] ): Unit = {
    f onComplete {
      case Success( list ) =>
        val response = GeneralJsonResponseData( "Respuesta exitosa", Some( list ) )
        complete( requestContext, StatusCodes.OK, response )
      case Failure( e ) =>
        completeWithFailure( requestContext, e.toString )
    }
  }

  /**
   * Obtiene el catálogo de tipos de contribuyentes desde el cache.
   * @return Futuro de una secuencia de elementos con información de tipo de contribuyentes
   */
  private def getContributorsTypesCatalog: Future[ Seq[ ContributorTypeCache ] ] = {
    val askableActor = new AskableActorSelection( cacheActor )
    val ask = ( askableActor ask CacheRefresherActor.GetContributorsTypes ).mapTo[ CacheRefresherActor.ContributorsTypesCatalogReturned ]
    ask.map( _.catalog )
  }
}

