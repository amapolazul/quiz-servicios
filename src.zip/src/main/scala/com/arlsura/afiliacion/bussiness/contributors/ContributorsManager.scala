package com.arlsura.afiliacion.bussiness.contributors

import com.arlsura.afiliacion.persistence.daos.ContributorDAO
import com.arlsura.afiliacion.persistence.entities.{ Contributor }
import reactivemongo.bson.{ BSONDocument, BSONObjectID }

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future
import scala.util.{ Failure, Success }

/**
 * Created by root on 9/02/15.
 */
class ContributorsManager {

  /**
   * Obtiene todos los documentos de la coleccion Contributor
   * @return
   */
  def getAll(): Future[ List[ Contributor ] ] = {
    ContributorDAO.findAll()
  }

  /**
   * Obtiene el documento de Contributor que tenga el id indicado
   * @param id
   * @return
   */
  def getById( id: String ): Future[ Option[ Contributor ] ] = {
    BSONObjectID.parse( id ) match {
      case Success( bsonId ) =>
        ContributorDAO.findById( bsonId )
      case Failure( e ) =>
        throw new IllegalArgumentException( e )
    }
  }

}
