package com.arlsura.afiliacion.bussiness.affiliation.key

import com.arlsura.afiliacion.bussiness.HandlerSupport._
import com.arlsura.afiliacion.bussiness.affiliation.BasicDataRepository
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.GeneralJsonResponseData
import com.arlsura.afiliacion.utils.DNIBuilder
import com.google.inject.Inject

import scala.concurrent.{ ExecutionContext, Future }

class OnlineServicesKeyServiceHandler @Inject() ( private val basicDataRepository: BasicDataRepository ) {

  /**
   * Method that retrieves summary to obtain online services key
   * @param dni Session dni
   * @return A future with ServiceHandlerResponse inside
   *         Left (error message) if anything goes wrong
   *         Right (GeneralJsonResponseData) with summary if all was executed successfully
   */
  def getSummaryData( dni: String )( implicit ec: ExecutionContext ): Future[ ServiceHandlerResponse ] = {
    for {
      basicDataOption <- basicDataRepository.getByDni( dni )
    } yield {
      basicDataOption match {
        case Some( basicData ) =>
          val summaryData: Map[ String, Option[ String ] ] = Map(
            "cdAdm" -> Some( "ArpSura" ),
            "cdApli" -> Some( "AD" ),
            "tipoDocumento" -> DNIBuilder.identificationTypes( basicData.contactInformation.identificationType ),
            "documento" -> Some( basicData.contactInformation.identification ),
            "nomEmpre" -> basicData.commercialName,
            "codDep" -> basicData.mainAddress.map( _.provinceCode ),
            "codCiu" -> basicData.mainAddress.map( _.municipalityCode ),
            "telPrin" -> basicData.contactInformation.phone,
            "dirEmpre" -> basicData.mainAddress.map( _.toString )
          )
          Right( GeneralJsonResponseData( "Summary retrieved successfully", Some( summaryData ) ) )
        case _ => Left( "No se encontraron datos para la solicitud" )
      }
    }
  }

}
