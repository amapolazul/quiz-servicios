package com.arlsura.afiliacion.bussiness.security

import com.arlsura.afiliacion.persistence.security.{ TokenSessionWrapper, TokenSessionRepository }
import com.google.inject.AbstractModule
import net.codingwell.scalaguice.ScalaModule

/**
 * Created by juanmartinez on 23/06/15.
 */
/**
 * Created by Jesús Martínez on 9/06/15.
 */
class TokenServiceModule extends AbstractModule with ScalaModule {
  override def configure(): Unit = {
    bind[ TokenSessionRepository ]
    bind[ TokenSessionWrapper ]
  }
}
