package com.arlsura.afiliacion.bussiness

import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.GeneralJsonResponseData

/**
 * Created by Jesús Martínez on 20/05/15.
 *
 * Objeto que contiene utilidades y herramientas de soporte para los manejadores de los diferentes servicios REST.
 */
object HandlerSupport {
  type ServiceHandlerResponse = Either[ String, GeneralJsonResponseData ]
  type ServiceFileHandlerResponse = Either[ String, Array[ Byte ] ]
}
