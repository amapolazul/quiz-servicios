package com.arlsura.afiliacion.bussiness

import com.arlsura.afiliacion.bussiness.HandlerSupport.ServiceHandlerResponse
import com.arlsura.afiliacion.bussiness.PreAffiliationServiceHandler.{ SavePreAffiliationDataResponse, _ }
import com.arlsura.afiliacion.bussiness.affiliation.{ PreaffiliationBasicDataHelper, PreaffiliationManager }
import com.arlsura.afiliacion.bussiness.code.{ CodeSourceIdentifiers, SecurityCodeManager }
import com.arlsura.afiliacion.bussiness.segmentation.SegmentationManager
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller._
import com.arlsura.afiliacion.notifications.SegmentationValidationNotification
import com.arlsura.afiliacion.notifications.code.CodeWasGeneratedNotification
import com.arlsura.afiliacion.persistence.daos.{ CommercialResponsibleDAO, SegmentationRulesDAO }
import com.arlsura.afiliacion.persistence.entities.{ SecurityCode, SegmentationRules, CommercialResponsible, PreAffiliation }
import com.arlsura.afiliacion.security.CodeGenerator
import com.arlsura.afiliacion.services.preaffiliation.PreaffiliationMarshaller.PreAffiliationSaveRequest
import com.arlsura.afiliacion.utils.{ SecurityCodeHelper, Utils }
import com.google.inject.Inject
import com.typesafe.scalalogging.LazyLogging
import reactivemongo.bson.{ BSONDocument, BSONString }
import reactivemongo.core.commands.LastError
import spray.http.HttpData

import scala.concurrent.{ ExecutionContext, Future }

/**
 * Actor encargado de manejar los procesos de afiliaciones para un cliente
 * Created by juanmartinez(who is dead for us now!) on 26/11/14.
 */
class PreAffiliationServiceHandler @Inject() ( securityCodeManager: SecurityCodeManager, segmentationManager: SegmentationManager, affiliationManager: PreaffiliationManager ) extends LazyLogging {

  val CENTRAL_OFFICE = 11
  /**
   * Carga desde BD la preafiliacion asociada al DNI de entrada y completa la solicitud
   * @param dni
   */
  def getPreAffiliation( dni: String )( implicit ec: ExecutionContext ): Future[ ServiceHandlerResponse ] = {
    affiliationManager.getPreAffiliationByDni( dni ) map {
      case None =>
        Right( GeneralJsonResponseData( s"No existe una preafiliacion asociada al dni $dni" ) )
      case Some( preaffiliation ) =>
        Right( GeneralJsonResponseData( "La preafiliacion fue cargada correctamente", Some( transformPreaffiliation( preaffiliation ) ) ) )
    } recover {
      case e: Throwable =>
        //e.printStackTrace()
        Left( s"Ocurrio un error al intentar cargar la preafiliacion. Mensaje: ${e.getMessage}. Causa: ${e.getCause}" )
    }
  }

  /**
   * Guarda al preafiliacion de un cliente. Si se determina que pasa el proceso de segmentacion
   * se guarda la preafiliacion y se le genera clave de seguridad. En caso contrario se guarda la preafiliacion
   * y no se genera clave
   * @param requestData
   */
  def savePreAffiliationData( requestData: PreAffiliationSaveRequest )( implicit ec: ExecutionContext ): Future[ ServiceHandlerResponse ] = {
    val entity: PreAffiliation = affiliationManager.buildPreAffiliationEntity( requestData )
    val segmentationRuleFuture: Future[ Option[ SegmentationRules ] ] = findSegmentationRule( ec, requestData.address.city.toLowerCase, entity.econoact )

    affiliationManager.saveClientAffiliation( entity ) flatMap {
      _ =>
        PreaffiliationBasicDataHelper.saveBasicData( entity, requestData )
        segmentationRuleFuture flatMap {
          case Some( sr ) =>
            val segmentationValidationPassed: Boolean = segmentationManager.validateSegmentation( sr, entity.workers )
            if ( segmentationValidationPassed ) {
              completePreAffiliationWithSecurityCode( entity )
            }
            else {
              completePreAffiliationWithoutSecurityCode( entity, requestData )
            }
          case None =>
            completePreAffiliationWithSecurityCode( entity )
        } recover {
          case e: Throwable =>
            //e.printStackTrace()
            Left( s"${RequestContextSupport.internalServerErrorMessage} -No fue posible guardar la preafiliacion- ${e.getMessage}" )
        }
    } recover {
      case e: Throwable =>
        //e.printStackTrace()
        Left( s"${RequestContextSupport.internalServerErrorMessage} -No fue posible guardar la preafiliacion- ${e.getMessage}" )
    }
  }

  /**
   * Completa el proceso de afiliacion en caso de que el proceso de segmentacion haya sido existoso
   * @param preaffiliation
   */
  private def completePreAffiliationWithSecurityCode( preaffiliation: PreAffiliation )( implicit ec: ExecutionContext ): Future[ ServiceHandlerResponse ] = {
    val securityCodeEntity: SecurityCode = SecurityCodeHelper.buildSecurityCode( preaffiliation, CodeSourceIdentifiers.STANDARD )
    val futureSaveCodeRequest: Future[ LastError ] = securityCodeManager.saveSecurityCodeManager( securityCodeEntity )

    futureSaveCodeRequest map {
      _ =>
        //logger.debug( s"El codigo de seguridad asociado con el documento ${preaffiliation.contactInfo.identification} fue creado satisfactoriamente" )
        SecurityCodeHelper.sendCodeNotification( preaffiliation, securityCodeEntity )
        //logger.debug( s"La notificacion es enviada a ${preaffiliation.contactInfo.email}" )
        val response = SavePreAffiliationDataResponse( PreAffiliationResponse( true, Utils.dateFormatToString( securityCodeEntity.expirationDate ), true ) )
        Right( GeneralJsonResponseData( "Preafiliacion completada", Some( response ) ) )
    } recover {
      case e: Throwable =>
        //        e.printStackTrace()
        //        logger.debug( s"No fue posible guardar el codigo de seguridad. ${e.getMessage}" )
        Left( s"No fue posible guardar el codigo de seguridad. ${e.getMessage}" )
    }
  }

  //TODO Trabajar aquí.
  /**
   * Completa el proceso de afiliacion en caso de que el proceso de segmentacion haya sido existoso
   * @param preaffiliation
   * @param requestData
   */
  private def completePreAffiliationWithoutSecurityCode( preaffiliation: PreAffiliation, requestData: PreAffiliationSaveRequest )( implicit ec: ExecutionContext ): Future[ ServiceHandlerResponse ] = {
    val query = BSONDocument( "office" -> BSONDocument( "$in" -> List( CENTRAL_OFFICE, Integer.parseInt( requestData.address.delegationCode ) ) ) )
    val operation: Future[ List[ CommercialResponsible ] ] = CommercialResponsibleDAO.findAll( query )

    //    logger.debug( s"Envia el correo a los usuarios en la matriz de responsables" )

    operation map {
      cr =>
        cr foreach ( r => SegmentationValidationNotification.send( r.email, preaffiliation ) )
        val response = SavePreAffiliationDataResponse( PreAffiliationResponse( true, "", false ) )
        Right( GeneralJsonResponseData( "Preafiliacion completada", Some( response ) ) )
    } recover {
      case e: Throwable =>
        //        e.printStackTrace()
        //        logger.debug( s"No fue posible notificar  a los responsable comerciales. ${e.getMessage}" )
        Left( s"No fue posible notificar  a los responsable comerciales. ${e.getMessage}" )
    }
  }

  /**
   * Toma los parámetros (opcionales) y arma un query de mongo.
   * @param office ID de la oficina del responsable comercial.
   * @param city Ciudad donde está la oficina del responsable comercial.
   * @param fullName Nombres y apellidos del responsable comercial.
   * @param email Correo electrónico del responsable comercial.
   * @param charge Cargo del responsable comercial.
   * @return Representación del query como BSONDocument.
   */
  private def obtainDocument( office: Option[ Int ], city: Option[ String ], fullName: Option[ String ], email: Option[ String ], charge: Option[ String ] ) = {
    var query = BSONDocument()

    office match {
      case Some( o ) => query = query ++ BSONDocument( "office" -> o )
      case _         =>
    }

    city match {
      case Some( c ) => query = query ++ BSONDocument( "city" -> c.toLowerCase )
      case _         =>
    }

    fullName match {
      case Some( fn ) => query = query ++ BSONDocument( "fullName" -> BSONDocument( "$regex" -> fn.toLowerCase ) )
      case _          =>
    }
    PreAffiliation
    email match {
      case Some( e ) => query = query ++ BSONDocument( "email" -> e.toLowerCase )
      case _         =>
    }

    charge match {
      case Some( ch ) => query = query ++ BSONDocument( "charge" -> ch.toLowerCase )
      case _          =>
    }

    query
  }

  private def findSegmentationRule( implicit ec: ExecutionContext, city: String, economicActivity: String ): Future[ Option[ SegmentationRules ] ] = {
    SegmentationRulesDAO.findOne( BSONDocument( "ciiu" -> economicActivity, "city" -> city ) )
  }

}

object PreAffiliationServiceHandler {

  case class PreAffiliationWithSegmentationFailureResponse( segmentationSucceed: Boolean )

  case class SavePreAffiliationData( data: Map[ String, HttpData ] )

  case class SavePreAffiliationDataResponse( affiliated: PreAffiliationResponse )

  case class VerifyPreviousAffiliation( dni: String )

  case class ExistPreviousAffiliationResponse( existPreAff: PreAffiliationExistResponse )

  case class ValidateSegmentationRules( city: String, ciiu: String, numWorkers: Long )

  case class SavePreAffiliationSegmentationWarning( prea: PreAffiliationWithSegmentationFailureResponse )

  case class VerifySegmentationClientResponse( prea: PreAffiliationWithSegmentationFailureResponse )

  case class PreaffiliationResponse(
    id:              String,
    dni:             String,
    docType:         String,
    document:        String,
    fullName:        String,
    name:            String,
    secondName:      Option[ String ],
    lastName:        String,
    secondLastName:  String,
    address:         String,
    email:           String,
    phone:           Option[ String ],
    cellphone:       Option[ String ],
    econoact:        String,
    workers:         Long,
    prevarp:         String,
    racea:           String,
    fileName:        Option[ String ],
    file:            Option[ String ],
    affiliationType: String
  )

  def transformPreaffiliation( entity: PreAffiliation ): PreaffiliationResponse = {
    PreaffiliationResponse(
      id = entity._id.stringify,
      dni = entity.dni,
      docType = entity.contactInfo.identificationType,
      document = entity.contactInfo.identification,
      fullName = entity.fullName,
      name = entity.contactInfo.name1,
      secondName = entity.contactInfo.name2,
      lastName = entity.contactInfo.lastname1,
      secondLastName = entity.contactInfo.lastname2.getOrElse( "" ),
      address = entity.address,
      email = entity.contactInfo.email,
      phone = entity.contactInfo.phone,
      cellphone = entity.cellphone,
      econoact = entity.econoact,
      workers = entity.workers,
      prevarp = entity.prevarp,
      racea = entity.racea,
      fileName = entity.fileName,
      file = entity.file,
      affiliationType = entity.affiliationType
    )
  }

}
