package com.arlsura.afiliacion.bussiness.client

import com.arlsura.afiliacion.bussiness.RequestContextSupport
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.GeneralJsonResponseData
import com.arlsura.afiliacion.preaffiliation.validations.IndependentsChecker
import com.arlsura.afiliacion.services.document.validation.Validator
import spray.http.StatusCodes
import spray.routing.RequestContext
import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

/**
 * Created by root on 9/02/15.
 */
class ClientServiceHandler( requestContext: RequestContext ) extends RequestContextSupport {
  /**
   * Verifica si un determinado cliente tiene independientes asociados.
   * @param dni Identificador del cliente.
   */
  def checkIndependents( dni: String ): Unit = {
    val consultFut: Future[ Boolean ] = IndependentsChecker.hasIndependents( dni )

    try {
      consultFut onSuccess {
        case result: Boolean =>
          val payload = Map( "hasIndependents" -> result )
          val response = GeneralJsonResponseData( "Respuesta exitosa", Some( payload ) )
          complete( requestContext, StatusCodes.OK, response )
      }

      consultFut onFailure {
        case e: Throwable => throw e
      }
    }
    catch {
      case e: Throwable => completeWithFailure( requestContext, e.toString )
    }
  }

  /**
   * Valida que el formato del número de documento del cliente es el adecuado.
   * @param dni Número de documento.
   * @param digit Dígitio de verificación. Solo aplica cuando el DNI es un NIT.
   */
  def validateDocumentFormat( dni: String, digit: Option[ String ] = None ): Unit = {
    val result: Boolean = new Validator().validate( dni, digit )

    val ( status, response ) = if ( result )
      ( StatusCodes.OK, GeneralJsonResponseData( "La combinación de documento es correcta" ) )
    else
      ( StatusCodes.Unauthorized, GeneralJsonResponseData( "La combinación de documento no es correcta" ) )

    complete( requestContext, status, response )
  }
}
