package com.arlsura.afiliacion.bussiness.independents

import com.arlsura.afiliacion.bussiness.RequestContextSupport
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.{ LastEntranceDateServiceResponse, SaveLastEntranceServiceResponse, GeneralJsonResponseData }
import com.arlsura.afiliacion.persistence.daos.SelfEmployeeDAO
import com.arlsura.afiliacion.persistence.entities.SelfEmployee
import org.joda.time.DateTime
import reactivemongo.bson.BSONDocument
import reactivemongo.core.commands.LastError
import spray.http.StatusCodes
import spray.routing.RequestContext

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

/**
 * Created by Jesús Martínez on 6/02/15.
 */
class IndependentsServiceHandler( requestContext: RequestContext ) extends RequestContextSupport {

  val manager: IndependentsManager = new IndependentsManager()

  /**
   * Registra la última fecha de entrada al sistema de un determinado usuario.
   * @param dni Identificador del usuario.
   */
  def recordLastEntranceDate( dni: String ): Unit = {
    val entrance = new DateTime()
    val operation: Future[ LastError ] = manager.create( dni, entrance )

    operation onSuccess {
      case result: LastError =>
        if ( result.ok ) {
          val payload = Some( SaveLastEntranceServiceResponse( entrance.toDate ) )
          val response: GeneralJsonResponseData = GeneralJsonResponseData( "OK", payload )
          complete( requestContext, StatusCodes.OK, response )
        }
        else {
          val response = GeneralJsonResponseData( "Ocurrió un problema intentando guardar la última fecha de ingreso." )
          complete( requestContext, StatusCodes.InternalServerError, response )
        }
    }

    operation onFailure {
      case e: Throwable => completeWithFailure( requestContext, e.toString )
    }
  }

  /**
   * Obtiene la última fecha de entrada de un usuario.
   * @param dni Identificador del usuario.
   */
  def retrieveLastEntranceDate( dni: String ): Unit = {
    val operation: Future[ Option[ SelfEmployee ] ] = manager.get( dni )

    operation onSuccess {
      case result: Option[ SelfEmployee ] =>
        val payload = LastEntranceDateServiceResponse( result.isEmpty, result map ( _.lastEntrance.toDate ) )
        val response = GeneralJsonResponseData( "OK", Some( payload ) )
        complete( requestContext, StatusCodes.OK, response )
    }

    operation onFailure {
      case e: Throwable => completeWithFailure( requestContext, e.toString )
    }
  }
}
