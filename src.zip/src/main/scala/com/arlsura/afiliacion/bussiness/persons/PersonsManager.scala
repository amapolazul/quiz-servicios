package com.arlsura.afiliacion.bussiness.persons

import co.com.sura.ventainformacion.personas.consumer.PersonasConsumerService
import co.com.sura.ventainformacion.service.PersonaDTO
import com.arlsura.afiliacion.bussiness.SoapConsumerSupport
import com.arlsura.afiliacion.utils.Utils
import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

/**
 * Created by juanmartinez on 15/11/14.
 */
object PersonsManager extends SoapConsumerSupport {

  /**
   * url del servicio que va a utilizar
   */
  val serviceUrl = Utils.getProperty( "soap.services.", "personas" ).asInstanceOf[ String ]

  /**
   * instancia la clase consumer que tiene todos los metodos para interactuar con el sistema
   */
  val consumer = new PersonasConsumerService( this.username, this.password, "123", serviceUrl )

  /**
   *
   * @param dni
   * @return
   */
  def getPersonExistByDni( dni: String ): PersonaDTO = consumer.consularPersona( dni )
}
