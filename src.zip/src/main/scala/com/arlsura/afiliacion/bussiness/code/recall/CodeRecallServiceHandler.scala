package com.arlsura.afiliacion.bussiness.code.recall

import java.util.Date

import com.arlsura.afiliacion.bussiness.HandlerSupport.ServiceHandlerResponse
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.GeneralJsonResponseData
import com.arlsura.afiliacion.notifications.code.CodeWasGeneratedNotification
import com.arlsura.afiliacion.persistence.entities.PreAffiliation
import com.arlsura.afiliacion.utils.Utils
import com.arlsura.afiliacion.utils.messages.MessagesRetriever
import com.google.inject.Inject

import scala.concurrent.{ Future, ExecutionContext }

/**
 * Created by Jesús Martínez on 2/06/15.
 */
class CodeRecallServiceHandler @Inject() ( repo: CodeRecallRepository ) {
  import CodeRecallServiceHandler._

  /**
   * Lleva a cabo el proceso de recordatorio de código. Para ello, verifica que la información provista coincida con la
   * persistida. Sí y solo sí dicha información coincide se envía la notificación con el código de seguridad.
   * @param dni DNI asociado al proceso de afiliación.
   * @param by Indica por cuál campo se hará la validación: "email" o "phone"
   * @param key Valor utilizado para la validación.
   * @param ec Contexto de ejecución para las operaciones concurrentes.
   * @return Futuro con el estado de la transacción.
   */
  def recallCode( dni: String, by: String, key: String )( implicit ec: ExecutionContext ): Future[ ServiceHandlerResponse ] = {
    def obtainPreAffiliation: Future[ Option[ PreAffiliation ] ] =
      if ( by.equalsIgnoreCase( "email" ) ) repo.findByEmail( dni, key ) else repo.findByPhone( dni, key )

    obtainPreAffiliation flatMap {
      _ map {
        p =>
          repo.findCode( dni ) map {
            case Some( c ) =>
              notify( dni, p.contactInfo.email, c.code, p.affiliationType, p.isNewCompany.getOrElse( true ) )
              Right( challengePassedResponse( dni ) )
            case None =>
              Left( codeNotFound )
          }
      } getOrElse {
        Future.successful( Right( challengeFailedResponse( dni ) ) )
      } recover {
        case e: Throwable =>
          Left( errorOccurred( e.toString ) )
      }
    }
  }

  private def notify( dni: String, email: String, code: String, aType: String, newCompany: Boolean ): Unit =
    CodeWasGeneratedNotification.send( dni, email, code, aType, newCompany )
  private def challengePassedResponse( dni: String ) = GeneralJsonResponseData( challengePassed, Some( Map( "challengePassed" -> true ) ), getSessionString( dni ) )
  private def challengeFailedResponse( dni: String ) = GeneralJsonResponseData( challengeFailed, Some( Map( "challengePassed" -> false ) ), getSessionString( dni ) )

  /**
   * Genera una cadena de caracteres de sesión con base en el DNI.
   * @param dni DNI usado para generar la cadena.
   * @return
   */
  private def getSessionString( dni: String ): Option[ String ] = {
    val d = s"$dni-${new Date().getTime.toString}"
    Some( Utils.encodeFile( d.getBytes ) )
  }
}

private object CodeRecallServiceHandler {
  lazy val challengePassed = MessagesRetriever.getSuccessMessage( "code", "CHALLENGE_PASSED" )
  lazy val challengeFailed = MessagesRetriever.getSuccessMessage( "code", "CHALLENGE_FAILED" )
  lazy val codeNotFound = MessagesRetriever.getErrorMessage( "code", "NOT_FOUND" )
  def errorOccurred( e: String ) = s"Ha ocurrido un error: $e"
}
