package com.arlsura.afiliacion.bussiness.affiliation

import com.arlsura.afiliacion.persistence.daos.affiliation.wrappers.AffiliationBasicDataWrapper
import com.arlsura.afiliacion.persistence.entities.affiliation.basic_data.{ BankInformation, AffiliationBasicData, Address }
import com.arlsura.afiliacion.persistence.entities.affiliation.contacts_data.ContactInformation
import com.arlsura.afiliacion.persistence.entities.preaffiliation.{ FullEconomicActivity, ProvinceSelected }
import com.arlsura.afiliacion.utils.CipherFacility
import com.google.inject.Inject
import org.joda.time.DateTime
import reactivemongo.bson.{ BSONString, BSONDocument }
import reactivemongo.core.commands.LastError
import scala.concurrent.{ ExecutionContext, Future }

/**
 * Manager de AffiliationBasicData
 * Created by John on 31/03/15.
 */
class BasicDataRepository @Inject() ( val dao: AffiliationBasicDataWrapper ) extends CipherFacility {

  private def encryptDocument( a: AffiliationBasicData ) = {
    AffiliationBasicData(
      _id = a._id,
      dni = encode( a.dni ),
      contactInformation = ContactInformation.encrypt( a.contactInformation ),
      commercialName = a.commercialName,
      newCompany = a.newCompany,
      personType = a.personType,
      juridicalNature = a.juridicalNature,
      contributorType = a.contributorType,
      previousARL = a.previousARL,
      letterDeliveryDate = a.letterDeliveryDate,
      coverageStartDate = a.coverageStartDate,
      foundationDate = a.foundationDate,
      commercialActivity = a.commercialActivity,
      fullEconomicActivity = a.fullEconomicActivity,
      mainAddress = a.mainAddress.map( Address.encrypt ),
      mailAddress = a.mailAddress.map( Address.encrypt ),
      bankInformation = a.bankInformation,
      provincesSelected = a.provincesSelected
    )
  }

  private def decryptDocument( a: AffiliationBasicData ) = {
    AffiliationBasicData(
      _id = a._id,
      dni = decode( a.dni ),
      contactInformation = ContactInformation.decrypt( a.contactInformation ),
      commercialName = a.commercialName,
      newCompany = a.newCompany,
      personType = a.personType,
      juridicalNature = a.juridicalNature,
      contributorType = a.contributorType,
      previousARL = a.previousARL,
      letterDeliveryDate = a.letterDeliveryDate,
      coverageStartDate = a.coverageStartDate,
      foundationDate = a.foundationDate,
      commercialActivity = a.commercialActivity,
      fullEconomicActivity = a.fullEconomicActivity,
      mainAddress = a.mainAddress.map( Address.decrypt ),
      mailAddress = a.mailAddress.map( Address.decrypt ),
      bankInformation = a.bankInformation,
      provincesSelected = a.provincesSelected
    )
  }

  def getAll()( implicit ec: ExecutionContext ): Future[ List[ AffiliationBasicData ] ] = dao.findAll().map( _.map( decryptDocument ) )

  def getByDni( dni: String )( implicit ec: ExecutionContext ): Future[ Option[ AffiliationBasicData ] ] = dao.findOne( BSONDocument(
    "dni" -> encode( dni )
  ) ) map ( _.map( decryptDocument ) )

  def getByIdentification( identification: String )( implicit ec: ExecutionContext ): Future[ Option[ AffiliationBasicData ] ] = dao.findOne( BSONDocument(
    "contactInformation.identification" -> encode( identification )
  ) ) map ( _.map( decryptDocument ) )

  def deleteByDni( dni: String )( implicit ec: ExecutionContext ): Future[ LastError ] = dao.remove( BSONDocument(
    "dni" -> encode( dni )
  ) )

  def deleteByIdentification( identification: String )( implicit ec: ExecutionContext ): Future[ LastError ] = dao.remove( BSONDocument(
    "contactInformation.identification" -> encode( identification )
  ) )

  def updateByDni( dni: String, basicData: AffiliationBasicData )( implicit ec: ExecutionContext ): Future[ LastError ] = dao.update( BSONDocument(
    "dni" -> encode( dni )
  ), encryptDocument( basicData ) )

  def create( basicData: AffiliationBasicData )( implicit ec: ExecutionContext ): Future[ LastError ] = dao.insert( encryptDocument( basicData ) )

  def create(
    identification:       String,
    identificationType:   String,
    dni:                  String,
    name:                 Option[ String ]          = None,
    name1:                Option[ String ]          = None,
    name2:                Option[ String ]          = None,
    lastname1:            Option[ String ]          = None,
    lastname2:            Option[ String ]          = None,
    commercialName:       Option[ String ],
    newCompany:           Option[ Boolean ]         = None,
    personType:           String,
    juridicalNature:      Option[ Int ]             = None,
    contributorType:      Int,
    previousARL:          Option[ String ]          = None,
    letterDeliveryDate:   Option[ DateTime ]        = None,
    coverageStartDate:    Option[ DateTime ]        = None,
    foundationDate:       Option[ DateTime ]        = None,
    commercialActivity:   String,
    mainAddress:          Option[ Address ]         = None,
    mailAddress:          Option[ Address ]         = None,
    bankInformation:      Option[ BankInformation ] = None,
    selectedProvinces:    List[ ProvinceSelected ],
    fullEconomicActivity: FullEconomicActivity
  )( implicit ec: ExecutionContext ): Future[ LastError ] = {
    dao.insert( encryptDocument( AffiliationBasicData(
      dni = dni,
      contactInformation = ContactInformation(
        identification = identification,
        identificationType = identificationType,
        name1 = name1.get,
        name2 = name2,
        lastname1 = lastname1.get,
        lastname2 = lastname2,
        contactId = Some( "RL" )
      ),
      commercialName = commercialName,
      newCompany = newCompany,
      personType = personType,
      juridicalNature = juridicalNature,
      contributorType = contributorType,
      previousARL = previousARL,
      letterDeliveryDate = letterDeliveryDate,
      coverageStartDate = coverageStartDate,
      foundationDate = foundationDate,
      commercialActivity = commercialActivity,
      mainAddress = mainAddress,
      mailAddress = mailAddress,
      bankInformation = bankInformation,
      provincesSelected = selectedProvinces,
      fullEconomicActivity = fullEconomicActivity
    ) ) )
  }

}
