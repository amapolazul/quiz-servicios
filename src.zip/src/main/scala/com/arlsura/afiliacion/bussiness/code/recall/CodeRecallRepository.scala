package com.arlsura.afiliacion.bussiness.code.recall

import com.arlsura.afiliacion.bussiness.affiliation.PreaffiliationManager
import com.arlsura.afiliacion.bussiness.code.SecurityCodeManager
import com.arlsura.afiliacion.persistence.daos.wrappers.{ PreAffiliationWrapper, SecurityCodeWrapper }
import com.arlsura.afiliacion.persistence.entities.{ SecurityCode, PreAffiliation }
import com.google.inject.Inject
import scala.concurrent.{ ExecutionContext, Future }

/**
 * Created by Jesús Martínez on 2/06/15.
 */
class CodeRecallRepository @Inject() ( codeDao: SecurityCodeManager, preAffiliationDao: PreaffiliationManager ) {

  /**
   * Encuentra una preafiliación por dni y correo electrónico.
   * @param dni DNI utilizado como clave de búsqueda.
   * @param email Dirección de correo electrónico utilizado como clave de búsqueda.
   * @param ec Contexto de ejecución para las operaciones concurrentes.
   * @return Futuro de una preafiliación.
   */
  def findByEmail( dni: String, email: String )( implicit ec: ExecutionContext ): Future[ Option[ PreAffiliation ] ] = {
    preAffiliationDao.getPreAffiliationByEmail( dni, email )
  }

  /**
   * Encuentra una preafiliación por dni y número de teléfono fijo.
   * @param dni DNI utilizado como clave de búsqueda.
   * @param phone Número de teléfono fijo utilizado como clave de búsqueda.
   * @param ec Contexto de ejecución para las operaciones concurrentes.
   * @return Futuro de una preafiliación.
   */
  def findByPhone( dni: String, phone: String )( implicit ec: ExecutionContext ): Future[ Option[ PreAffiliation ] ] = {
    preAffiliationDao.getPreAffiliationByPhone( dni, phone )
  }

  /**
   * Encuentra un código de seguridad por dni.
   * @param dni DNI utilizado como clave de búsqueda.
   * @param ec Contexto de ejecución para las operaciones concurrentes.
   * @return Futuro de un código de seguridad.
   */
  def findCode( dni: String )( implicit ec: ExecutionContext ): Future[ Option[ SecurityCode ] ] = {
    codeDao.existSecurityCode( dni )
    //    codeDao.findOne( BSONDocument( "dni" -> dni ) )
  }
}
