package com.arlsura.afiliacion.bussiness.independents

import com.arlsura.afiliacion.persistence.daos.SelfEmployeeDAO
import com.arlsura.afiliacion.persistence.entities.SelfEmployee
import org.joda.time.DateTime
import reactivemongo.bson.BSONDocument
import reactivemongo.core.commands.LastError

import scala.concurrent.Future

import scala.concurrent.ExecutionContext.Implicits.global

/**
 * Clase para manejar las operaciondes relacionadas a la coleccion self_employee (eventualmente, independents)
 * Created by on 13/02/15.
 * @author John Cely
 *
 */
class IndependentsManager {

  /**
   * Permite obtener un documento de la coleccion self_employee cuyo dni sea el indicado
   * @param dni
   * @return
   */
  def get( dni: String ): Future[ Option[ SelfEmployee ] ] = {
    SelfEmployeeDAO.findOne( BSONDocument( "dni" -> dni ) )
  }

  /**
   * Permite insertar un nuevo documento dentro de la coleccion self_employee
   * @param dni
   * @param lastEntrance
   * @return
   */
  def create( dni: String, lastEntrance: DateTime ): Future[ LastError ] = {
    SelfEmployeeDAO.insert( SelfEmployee( dni = dni, lastEntrance = lastEntrance ) )
  }

}
