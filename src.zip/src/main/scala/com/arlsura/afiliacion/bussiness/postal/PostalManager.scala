package com.arlsura.afiliacion.bussiness.postal

import co.com.sura.ventainformacion.service.PostalDTO
import com.arlsura.afiliacion.bussiness.SoapConsumerSupport
import com.arlsura.afiliacion.utils.Utils
import com.sura.arl.serviciocentrotrabajo.consumer.PostalServiceConsumer

/**
 * Proxy para consumir los servicios SOAP relacionados con los centros de trabajo.
 * Created by Jesús Martínez on 11/12/14.
 */
object PostalManager extends SoapConsumerSupport {

  //Url del servicio en venta información.
  private val url = Utils.getProperty( "soap.services.", "postal" ).asInstanceOf[ String ]
  private val consumer = new PostalServiceConsumer( this.username, this.password, "123", url )

  /**
   * Dado un código de municipio, retorna una tupla, cuyo primer elemento es
   * el código de la delegación y el segundo el código de la sucursal.
   * @param code
   * @return Terna (String, String) con la información ya descrita.
   */
  def consultMunicipality( code: String ): ( String, String ) = {
    consumer.authenticateToProxy( this.cloudProxyHost, this.cloudProxyPort, this.cloudProxyUser, this.cloudProxyPassword )
    val dto = consumer.consultarMunicipio( code )
    ( dto.getDelegacion.getCodigoDelegacion, dto.getDelegacion.getSucursal.getCodigoSucursal )
  }

  /**
   * Dado un código de departamento y un código de delegación, se retorna una lista con los municipios/ciudades
   * correspondientes.
   * @param departmentCode
   * @param delegationCode
   * @return Lista de Strings, donde cada elemento es un municipio o ciudad válido.
   */
  def getSettlements( departmentCode: String, delegationCode: String ): List[ PostalDTO ] = {
    consumer.authenticateToProxy( this.cloudProxyHost, this.cloudProxyPort, this.cloudProxyUser, this.cloudProxyPassword )
    consumer.consultarMunicipiosPorDelegacionYDpto( departmentCode, delegationCode ).getListaPostales.toList
  }

}
