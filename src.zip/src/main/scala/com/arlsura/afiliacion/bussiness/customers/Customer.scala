package com.arlsura.afiliacion.bussiness

import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.AffiliationValidationResponse
import com.arlsura.afiliacion.persistence.daos.CustomerOptionsMenuDAO
import com.arlsura.afiliacion.persistence.entities.CustomerOptionsMenu
import com.arlsura.afiliacion.utils.Utils
import reactivemongo.bson.{ BSONString, BSONDocument }

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future
import spray.client.pipelining._

/**
 * Clase encargada de toda la lógica del cliente
 * Created by juanmartinez on 12/11/14.
 */
class Customer {

  /**
   * Consulta el menu dependiendo del tipo de documento
   * @param docType
   * @return
   */
  def buildCustomerOptionsMenu( docType: String ): Future[ Option[ CustomerOptionsMenu ] ] = {
    val query = BSONDocument( "docType" -> BSONString( docType ) )
    CustomerOptionsMenuDAO.findOne( query )
  }
}
