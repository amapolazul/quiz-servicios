package com.arlsura.afiliacion.bussiness.cache

import com.arlsura.afiliacion.bussiness.SoapConsumerSupport
import com.typesafe.scalalogging.LazyLogging

/**
 * Created by Jesús Martínez on 24/04/15.
 */
/**
 * Patrón Template Method utilizado. Se define un algoritmo general para mantener al día los datos de una cache almacenada en memoria.
 * Los subtipos tienen que implementar los pasos del template method.
 * @tparam ServiceResultType Tipo de dato del servicio externo de donde se obtiene la información.
 * @tparam CacheType Modelo de datos de la cache.
 */
trait CacheLoader[ ServiceResultType, CacheType ] extends SoapConsumerSupport with LazyLogging {
  /**
   * Consume el servicio externo de donde se obtienen los datos a ser almacenados en la cache.
   * @return Colección de datos provenientes del servicio exterior.
   */
  def consumeService(): Option[ Seq[ ServiceResultType ] ]

  /**
   * Toma los datos obtenidos de un servicio externo y los transforma en objetos especiales.
   * @param data Colección de datos "crudos" provenientes del servicio de terceros.
   * @return Colección de elementos que serán mantenidos en memoria.
   */
  def prepareData( data: Seq[ ServiceResultType ] ): Seq[ CacheType ]

  /**
   * Consulta la información en servicios externos y, en caso de obtenerla,
   * la almacena; si no, utiliza el valor por defecto.
   * @param default Valor por defecto que será evaluado sí y solo sí no se puede obtener la información al consumir
   *                los servicios de terceros.
   * @return Colección de elementos que serán mantenidos en memoria.
   */
  final def refresh( default: => Seq[ CacheType ] ): Seq[ CacheType ] = {
    consumeService().map( prepareData ).getOrElse( default )
  }
}