package com.arlsura.afiliacion.bussiness.afp
import akka.actor.{ ActorSelection, ActorRef }
import com.arlsura.afiliacion.actors.cache.CacheRefresherActor
import com.arlsura.afiliacion.bussiness.RequestContextSupport
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.GeneralJsonResponseData
import com.arlsura.afiliacion.persistence.cache.entities.AFPCache
import spray.http.StatusCodes
import spray.routing.RequestContext
import scala.concurrent.ExecutionContext
import akka.pattern._
import scala.concurrent.Future
import scala.util.{ Failure, Success }
import com.arlsura.afiliacion.utils.GlobalParamsProvider

/**
 * Created by Jesús Martínez on 30/03/15.
 */
class AFPServiceHandler( requestContext: RequestContext, cacheActor: ActorSelection )( implicit ec: ExecutionContext ) extends RequestContextSupport with GlobalParamsProvider {
  /**
   * Obtiene todas las AFPs almacenadas en cache.
   */
  def retrieveAFPs(): Unit = {
    getAllAFP onComplete {
      case Success( list ) =>
        val response = GeneralJsonResponseData( "Respuesta exitosa", Some( list ) )
        complete( requestContext, StatusCodes.OK, response )
      case Failure( e ) =>
        completeWithFailure( requestContext, e.toString )
    }
  }

  /**
   * Obtiene el catálogo de AFPS.
   * @return Un futuro de una secuencia de objetos AFPCache.
   */
  private def getAllAFP: Future[ Seq[ AFPCache ] ] = {
    val askableActor = new AskableActorSelection( cacheActor )
    val ask = ( askableActor ? CacheRefresherActor.GetAFPsCatalog ).mapTo[ CacheRefresherActor.AFPsCatalogReturned ]
    ask.map( _.catalog )
  }
}
