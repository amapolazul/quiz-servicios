package com.arlsura.afiliacion.bussiness.affiliation

import com.arlsura.afiliacion.persistence.daos.affiliation.wrappers.AffiliationBasicDataWrapper
import com.arlsura.afiliacion.persistence.entities.PreAffiliation
import com.arlsura.afiliacion.persistence.entities.affiliation.basic_data.{ AffiliationBasicData, Address }
import com.arlsura.afiliacion.persistence.entities.affiliation.contacts_data.ContactInformation
import com.arlsura.afiliacion.persistence.entities.preaffiliation.{ FullEconomicActivity, ProvinceSelected }
import com.arlsura.afiliacion.services.preaffiliation.PreaffiliationMarshaller.PreAffiliationSaveRequest
import com.arlsura.afiliacion.utils.{ AffiliationDefaults, DNIHelper }
import spray.http.HttpData
import scala.concurrent.ExecutionContext.Implicits.global
import scala.collection.mutable

/**
 * Created by John on 1/04/15.
 */
object PreaffiliationBasicDataHelper {

  val wrapper: AffiliationBasicDataWrapper = new AffiliationBasicDataWrapper()
  val manager: BasicDataRepository = new BasicDataRepository( wrapper )

  /**
   * Guarda los datos basicos del cliente
   * @param data
   */
  def saveBasicData( data: PreAffiliation, request: PreAffiliationSaveRequest ): Unit = {
    val personType: String = if ( DNIHelper.isNIT( data.contactInfo.identificationType ) ) "J" else "N"
    val juridicalNature: Some[ Int ] = Some( AffiliationDefaults.juridcalNature )
    val contributorType: Int = AffiliationDefaults.contributorType
    val mainAddress: Address = buildAddress( data, request )
    val contactInformation: ContactInformation = buildContactInformation( data )
    val affiliationBasicData: AffiliationBasicData = buildAffiliationBasicData(
      data = data,
      contactInformation = contactInformation,
      mainAddress = mainAddress,
      personType = personType,
      juridicalNature = juridicalNature,
      contributorType = contributorType
    )
    manager.create( affiliationBasicData )
  }

  private def buildAddress( data: PreAffiliation, request: PreAffiliationSaveRequest ): Address = {
    Address(
      provinceCode = request.address.provinceCode,
      municipalityCode = request.address.municipalityCode,
      delegationCode = request.address.delegationCode,
      province = request.address.province,
      city = request.address.city,
      nomenclaturaVial = request.address.nomenclaturaVial,
      number1 = request.address.number1,
      letter1 = request.address.letter1,
      orientation1 = request.address.orientation1,
      number2 = request.address.number2,
      letter2 = request.address.letter2,
      number3 = request.address.number3,
      orientation2 = request.address.orientation2,
      details = request.address.details
    )
  }

  private def buildContactInformation( data: PreAffiliation ): ContactInformation = {
    ContactInformation(
      identification = data.contactInfo.identification,
      identificationType = data.contactInfo.identificationType,
      name = Some( data.fullName ),
      name1 = data.contactInfo.name1,
      name2 = data.contactInfo.name2,
      lastname1 = data.contactInfo.lastname1,
      lastname2 = data.contactInfo.lastname2,
      email = data.contactInfo.email,
      contactId = Some( "RL" )
    )
  }

  private def buildAffiliationBasicData( data: PreAffiliation, contactInformation: ContactInformation, mainAddress: Address, personType: String, juridicalNature: Some[ Int ], contributorType: Int ): AffiliationBasicData = {
    AffiliationBasicData(
      dni = data.dni,
      contactInformation = contactInformation,
      personType = personType,
      juridicalNature = juridicalNature,
      previousARL = Some( data.prevarp ),
      commercialActivity = data.fullEconomicActivity.economicActivityId,
      mainAddress = Some( mainAddress ),
      mailAddress = Some( mainAddress ),
      commercialName = Some( data.fullName ),
      contributorType = contributorType,
      newCompany = data.isNewCompany,
      provincesSelected = data.selectedProvinces,
      fullEconomicActivity = data.fullEconomicActivity
    )
  }

}
