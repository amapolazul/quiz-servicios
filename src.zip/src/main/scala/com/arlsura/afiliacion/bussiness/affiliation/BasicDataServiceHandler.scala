package com.arlsura.afiliacion.bussiness.affiliation

import java.util.Date

import com.arlsura.afiliacion.bussiness.HandlerSupport.ServiceHandlerResponse
import com.arlsura.afiliacion.bussiness.affiliation.BasicDataServiceHandler.AffiliationBasicDataResponse
import com.arlsura.afiliacion.bussiness.affiliation.contacts.ContactDataRepository
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.{ SaveContactInformation, ContactInformationData, SaveAffiliationBasicData, GeneralJsonResponseData }
import com.arlsura.afiliacion.persistence.entities.affiliation.basic_data.{ BankInformation, AffiliationBasicData, Address }
import com.arlsura.afiliacion.persistence.entities.affiliation.contacts_data.{ ContactInformation, AffiliationContactsData }
import com.arlsura.afiliacion.persistence.entities.preaffiliation.{ FullEconomicActivity, ProvinceSelected }
import com.arlsura.afiliacion.proceso.pasos.centros_trabajo.WorkCenterPreSaving
import com.arlsura.afiliacion.proceso.pasos.sucursales.BranchDataMarshaller.{ ContactName, PreSavingData }
import com.arlsura.afiliacion.proceso.pasos.sucursales.BranchDataPreSaving
import com.arlsura.afiliacion.utils.{ DNIHelper, Utils }
import com.google.inject.Inject
import org.joda.time.DateTime
import reactivemongo.bson.BSONObjectID
import reactivemongo.core.commands.LastError
import scala.concurrent.{ Future, ExecutionContext }
import scala.util.{ Failure, Success }

/**
 * Service handler para el servicio de afiliacion datos básicos
 * Created by John on 31/03/15.
 */
class BasicDataServiceHandler @Inject() ( private val repository: BasicDataRepository, private val contactsRepository: ContactDataRepository, private val paRepository: PreaffiliationManager ) {

  def getBasicData( dni: String )( implicit ec: ExecutionContext ): Future[ ServiceHandlerResponse ] = {
    repository.getByDni( dni ) map {
      basicData =>
        val payload = basicData map {
          data => GeneralJsonResponseData( s"Los datos básicos asociados al dni $dni fueron cargados correctamente", Some( mapResponse( data ) ) )
        } getOrElse {
          GeneralJsonResponseData( s"No existen datos básicos asociados al dni $dni" )
        }

        Right( payload )
    } recover {
      case throwable: Throwable =>
        Left( s"Ocurrió un error al consultar los datos básicos asociados al dni $dni: ${throwable.getMessage}" )
    }
  }

  def saveBasicData( dni: String, data: SaveAffiliationBasicData )( implicit ec: ExecutionContext ): Future[ ServiceHandlerResponse ] = {
    def repoInit: Future[ LastError ] = repository.getByDni( dni ) flatMap {
      oldDataOption =>
        oldDataOption map {
          oldData => repository.updateByDni( dni, mapSaveRequest( data, Some( oldData ), oldData._id ) )
        } getOrElse {
          repository.create( mapSaveRequest( data, id = BSONObjectID.generate ) )
        }
    }

    def data1: Future[ Any ] = saveContactData( dni, data )
    def data2: Future[ Any ] = saveBranchData( dni, data )
    def data3: Future[ Any ] = saveWorkCentersData( dni, data )

    val processInformation: Future[ Either[ String, GeneralJsonResponseData ] with Product with Serializable ] = for {
      update <- repoInit
      saveContacts <- data1
      saveBranch <- data2
      workCenters <- data3
    } yield {
      if ( update.ok ) {
        val d = s"$dni-${new Date().getTime.toString}"
        val t = Utils.encodeFile( d.getBytes )
        val session = Some( t )
        Right( GeneralJsonResponseData( s"Los datos básicos asociados al dni $dni fueron guardados correctamente", suraSessionManager = session ) )
      }
      else {
        Left( s"No fue posible actualizar los datos básicos asociados al dni $dni" )
      }
    }

    processInformation.recover {
      case throwable: Throwable =>
        Left( s"Ocurrió un error al consultar los datos básicos asociados al dni $dni: ${throwable.getMessage}" )
    }

  }

  def mapSaveRequest( data: SaveAffiliationBasicData, oldData: Option[ AffiliationBasicData ] = None, id: BSONObjectID ): AffiliationBasicData = {

    val foundationDate = data.foundationDate match {
      case Some( date ) => Some( new DateTime( date ) )
      case None         => None
    }
    val letterDeliveryDate = data.letterDeliveryDate match {
      case Some( date ) => Some( new DateTime( date ) )
      case None         => None
    }
    val coverageStartDate = data.coverageStartDate match {
      case Some( date ) => Some( new DateTime( date ) )
      case None         => None
    }

    val economicActivity = FullEconomicActivity(
      economicActivityId = data.fullEconomicActivity.economicActivityId,
      description = data.fullEconomicActivity.description match {
      case Some( e ) => Some( e )
      case None      => oldData.get.fullEconomicActivity.description
    },
      rate = data.fullEconomicActivity.rate match {
      case Some( e ) => Some( e )
      case None      => oldData.get.fullEconomicActivity.rate
    },
      cdClass = data.fullEconomicActivity.cdClass match {
      case Some( e ) => Some( e )
      case None      => oldData.get.fullEconomicActivity.cdClass
    }
    )

    AffiliationBasicData(
      _id = id,
      contactInformation = ContactInformation(
        identification = data.identification,
        identificationType = data.identificationType,
        name1 = data.name1.getOrElse( "" ),
        name2 = data.name2,
        lastname1 = data.lastname1.getOrElse( "" ),
        lastname2 = data.lastname2,
        email = "",
        name = data.name,
        contactId = Some( "RL" )
      ),
      dni = data.dni,
      commercialName = data.commercialName,
      commercialActivity = data.fullEconomicActivity.economicActivityId,
      personType = data.personType,
      contributorType = data.contributorType,
      mainAddress = data.mainAddress,
      mailAddress = data.mailAddress,
      bankInformation = data.bankInformation,
      foundationDate = foundationDate,
      letterDeliveryDate = letterDeliveryDate,
      coverageStartDate = coverageStartDate,
      newCompany = data.newCompany,
      juridicalNature = data.juridicalNature,
      previousARL = data.previousARL,
      provincesSelected = for ( province <- data.provincesSelected )
        yield ProvinceSelected(
        provinceName = province.provinceName,
        provinceCode = province.provinceCode
      ),
      fullEconomicActivity = economicActivity
    )
  }

  private def mapResponse( basicData: AffiliationBasicData ): AffiliationBasicDataResponse = {
    val letterDeliveryDate: Option[ Date ] = basicData.letterDeliveryDate match {
      case Some( date ) => Some( date.toDate )
      case None         => None
    }
    val coverageStartDate: Option[ Date ] = basicData.coverageStartDate match {
      case Some( date ) => Some( date.toDate )
      case None         => None
    }
    val foundationDate: Option[ Date ] = basicData.foundationDate match {
      case Some( date ) => Some( date.toDate )
      case None         => None
    }
    AffiliationBasicDataResponse(
      identificationType = basicData.contactInformation.identificationType,
      identification = basicData.contactInformation.identification,
      dni = basicData.dni,
      fullName = basicData.contactInformation.name match {
      case Some( e ) =>
        Some( e )
      case None =>
        buildFullName(
          name1 = basicData.contactInformation.name1,
          name2 = basicData.contactInformation.name2,
          lastname1 = basicData.contactInformation.lastname1,
          lastname2 = basicData.contactInformation.lastname2
        )
    },
      name1 = Some( basicData.contactInformation.name1 ),
      name2 = basicData.contactInformation.name2,
      lastname1 = Some( basicData.contactInformation.lastname1 ),
      lastname2 = basicData.contactInformation.lastname2,
      commercialName = basicData.commercialName,
      isNewCompany = basicData.newCompany,
      personType = basicData.personType,
      juridicalNature = basicData.juridicalNature,
      previousARL = basicData.previousARL,
      commercialActivity = basicData.commercialActivity,
      letterDeliveryDate = letterDeliveryDate,
      coverageStartDate = coverageStartDate,
      foundationDate = foundationDate,
      mainAddressData = basicData.mainAddress,
      mailAddressData = basicData.mailAddress,
      bankInfoData = basicData.bankInformation,
      contributor = basicData.contributorType,
      provincesSelected = basicData.provincesSelected
    )
  }

  private def buildFullName( name1: String, name2: Option[ String ], lastname1: String, lastname2: Option[ String ] ) = {
    Some( s"$name1 ${name2.getOrElse( "" )} $lastname1 ${lastname2.getOrElse( "" )}" )
  }

  private def saveContactData( dni: String, data: SaveAffiliationBasicData )( implicit ec: ExecutionContext ): Future[ Any ] = {
    if ( !DNIHelper.isNIT( data.identificationType ) )
      contactsRepository.findByDni( dni ) map {
        case Some( e ) =>
          Future.successful( "Ya existen contactos" )
        case None =>
          callCreateContact( dni, data )
      }
    else {
      Future.successful( "Es un nit y no se crean por defecto" )
    }
  }

  private def callCreateContact( dni: String, data: SaveAffiliationBasicData )( implicit ec: ExecutionContext ): Future[ LastError ] = {
    val legalRepresentative = ContactInformation(
      identificationType = data.identificationType,
      identification = data.identification,
      name1 = data.name1.get,
      name2 = data.name2,
      lastname1 = data.lastname1.get,
      lastname2 = data.lastname2,
      contactId = Some( "RL" )
    )

    paRepository.getPreAffiliationByDni( dni ) flatMap {
      case Some( pa ) if pa.affiliationType.toUpperCase == "DE" =>
        //Si se trata de una afiliaciÓn de domÉsticos, hay que agregar el email de la
        //preafiliaciÓn.
        val lr = legalRepresentative.copy( email = pa.contactInfo.email )

        contactsRepository.create( AffiliationContactsData(
          dni = dni,
          legalRepresentative = lr,
          manager = lr.copy( contactId = Some( "GE" ) ),
          humanResourcesRepresentative = lr.copy( contactId = Some( "RS" ) ),
          rosterRepresentative = lr.copy( contactId = Some( "NO" ) ),
          workSafetyRepresentative = lr.copy( contactId = Some( "SO" ) ),
          insideTrainingRepresentative = lr.copy( contactId = Some( "RI" ) )
        ) )
      case _ =>
        contactsRepository.create( AffiliationContactsData(
          dni = dni,
          legalRepresentative = legalRepresentative
        ) )
    }
  }

  private def saveBranchData( dni: String, data: SaveAffiliationBasicData )( implicit ec: ExecutionContext ): Future[ Any ] = {
    if ( !DNIHelper.isNIT( data.identificationType ) ) {
      val branchDataPreSaving: BranchDataPreSaving = new BranchDataPreSaving()
      val contact = ContactName(
        name1 = data.name1.get,
        name2 = data.name2,
        lastName1 = data.lastname1.get,
        lastName2 = data.lastname2
      )
      branchDataPreSaving.save( PreSavingData( dni, contact ) )
    }
    else {
      Future.successful( "Es un nit y no se crean por defecto" )
    }
  }

  private def saveWorkCentersData( dni: String, data: SaveAffiliationBasicData )( implicit ec: ExecutionContext ): Future[ Any ] = {
    if ( !DNIHelper.isNIT( data.identificationType ) ) {
      val workCenter: WorkCenterPreSaving = new WorkCenterPreSaving()

      contactsRepository.findByDni( dni ) map {
        contacts =>
          val contactRequestInformation: SaveContactInformation = getSaveContactInformation( dni, data )

          contacts match {
            case _ =>
              workCenter.saveOrUpdate( contactRequestInformation )
          }
      }
    }
    else {
      Future.successful( "Es un nit y no se crean por defecto" )
    }
  }

  /**
   * Retorna el objeto transformado para centros de trabajo
   * @param dni
   * @param data
   * @return
   */
  private def getSaveContactInformation( dni: String, data: SaveAffiliationBasicData ): SaveContactInformation = {

    def getContactInformationData( contactId: String ): ContactInformationData = {
      ContactInformationData(
        email = "",
        identification = data.identification,
        identificationType = data.identificationType,
        name1 = data.name1.getOrElse( "" ),
        name2 = data.name2,
        lastname1 = data.lastname1.getOrElse( "" ),
        lastname2 = data.lastname2,
        phone = None,
        position = None,
        title = None,
        contactId = Some( contactId )
      )
    }

    SaveContactInformation(
      dni = dni,
      securityCode = "",
      humanResourcesRepresentative = getContactInformationData( "RS" ),
      insideTrainingRepresentative = getContactInformationData( "RI" ),
      legalRepresentative = getContactInformationData( "RL" ),
      manager = getContactInformationData( "GE" ),
      rosterRepresentative = getContactInformationData( "NO" ),
      workSafetyRepresentative = getContactInformationData( "SO" )
    )
  }

}

object BasicDataServiceHandler {

  case class AffiliationBasicDataResponse(
    identificationType: String,
    identification:     String,
    dni:                String,
    fullName:           Option[ String ]          = None,
    name1:              Option[ String ]          = None,
    name2:              Option[ String ]          = None,
    lastname1:          Option[ String ]          = None,
    lastname2:          Option[ String ]          = None,
    commercialName:     Option[ String ]          = None,
    isNewCompany:       Option[ Boolean ]         = None,
    personType:         String,
    juridicalNature:    Option[ Int ]             = None,
    previousARL:        Option[ String ]          = None,
    commercialActivity: String,
    letterDeliveryDate: Option[ Date ]            = None,
    coverageStartDate:  Option[ Date ]            = None,
    foundationDate:     Option[ Date ]            = None,
    mainAddressData:    Option[ Address ]         = None,
    mailAddressData:    Option[ Address ]         = None,
    bankInfoData:       Option[ BankInformation ] = None,
    contributor:        Int,
    provincesSelected:  List[ ProvinceSelected ]

  )

}
