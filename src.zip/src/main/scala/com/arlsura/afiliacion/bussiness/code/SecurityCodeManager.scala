package com.arlsura.afiliacion.bussiness.code

import com.arlsura.afiliacion.bussiness.code.SecurityCodeManager.SecurityCodeDigest
import com.arlsura.afiliacion.persistence.daos.SecurityCodeDAO
import com.arlsura.afiliacion.persistence.daos.wrappers.SecurityCodeWrapper
import com.arlsura.afiliacion.persistence.entities.SecurityCode
import com.arlsura.afiliacion.security.CodeGenerator
import com.arlsura.afiliacion.security.SecurityErrors.LengthOutOfBounds
import com.arlsura.afiliacion.utils.{ CipherFacility, Utils }
import com.google.inject.Inject
import org.joda.time
import org.joda.time.DateTime
import reactivemongo.bson.{ BSONDateTime, BSONString, BSONDocument }
import reactivemongo.core.commands.LastError

import scala.concurrent.Future
import scala.concurrent.ExecutionContext.Implicits.global

/**
 * Created by juanmartinez on 15/12/14.
 */
class SecurityCodeManager @Inject() ( wrapper: SecurityCodeWrapper ) extends CipherFacility {
  private def encryptDocument( d: SecurityCode ) =
    SecurityCode(
      _id = d._id,
      dni = encode( d.dni ),
      source = d.source,
      email = encode( d.email ),
      generationDate = d.generationDate,
      expirationDate = d.expirationDate,
      code = encode( d.code )
    )

  private def decryptDocument( d: SecurityCode ) =
    SecurityCode(
      _id = d._id,
      dni = decode( d.dni ),
      source = d.source,
      email = decode( d.email ),
      generationDate = d.generationDate,
      expirationDate = d.expirationDate,
      code = decode( d.code )
    )

  def hasCode( dni: String ): Future[ Option[ SecurityCodeDigest ] ] = wrapper.findOne( BSONDocument( "dni" -> encode( dni ) ) ) map {
    _ map { c => SecurityCodeDigest( Utils.dateFormatToString( c.expirationDate ), c.source ) }
  }

  def codeMatches( dni: String, code: String ): Future[ Option[ SecurityCode ] ] =
    wrapper.findOne( BSONDocument( "dni" -> encode( dni ), "code" -> encode( code ) ) ) map ( _.map( decryptDocument ) )

  /**
   * Genera un código de seguridad basado en ciertos parámetros.
   * @param length Longitud del código.
   * @param alphanumeric True si será alfanumérico, false si solo contendrá números.
   * @return
   */
  def generateCode( length: Int = 4, alphanumeric: Boolean = true ): Either[ LengthOutOfBounds, String ] = CodeGenerator.generate( length, alphanumeric )

  /**
   * Verifica si existe o no un codigo de seguridad basado en el dni
   * y si la fecha de expiración es mayor a la fecha actual
   * @param dni
   * @return
   */
  def existSecurityCode( dni: String ): Future[ Option[ SecurityCode ] ] =
    wrapper.findOne( BSONDocument( "dni" -> encode( dni ), "expirationDate" -> BSONDocument( "$gte" -> BSONDateTime( DateTime.now.getMillis ) ) ) ) map ( _.map( decryptDocument ) )

  /**
   *
   * @param secCode
   * @return
   */
  def saveSecurityCodeManager( secCode: SecurityCode ): Future[ LastError ] =
    wrapper.insert( encryptDocument( secCode ) )

  /**
   * Valida si la fecha de expiracion esta antes de la fecha actual
   * @param secCode
   * @return
   */
  def validateSecurityCode( secCode: SecurityCode ) = secCode.expirationDate.isBeforeNow

}

object SecurityCodeManager {

  case class SecurityCodeDigest( expirationDate: String, source: String )

  /**
   * Construye la entidad que guarda el código de seguridad para un cliente
   * @param code
   * @param dni
   * @param email
   * @param expirationDate
   * @param source
   * @return
   */
  def buildSecurityCodeEntity( code: String, dni: String, email: String, expirationDate: time.DateTime = DateTime.now(), source: String ): SecurityCode = {
    SecurityCode(
      code = code,
      dni = dni,
      email = email,
      expirationDate = expirationDate,
      source = source
    )
  }

  /**
   *
   * @return La fecha de expiración para un registro. TODO modificar con los parametros de la aplicación
   */
  def generateExpirationDate() = DateTime.now.plusMonths( 2 )

}