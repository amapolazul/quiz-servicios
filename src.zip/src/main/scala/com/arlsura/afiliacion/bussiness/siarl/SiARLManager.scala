package com.arlsura.afiliacion.bussiness.siarl

import java.io.IOException

import com.arlsura.afiliacion.bussiness.SoapConsumerSupport
import com.arlsura.afiliacion.utils.Utils
import com.sura.arl.serviciosiarl.consumer.SiARLServiceConsumer

/**
 * Proxy para consumir los servicios SOAP de SiARL.
 * Created by Jesús Martínez on 27/11/14.
 */
object SiARLManager extends SoapConsumerSupport {
  private val LOG_IN_DNI = "C98621950"

  //Url del servicio en venta información.
  private val url = Utils.getProperty( "soap.services.", "siarl" ).asInstanceOf[ String ]

  private val consumer = new SiARLServiceConsumer( this.username, this.password, "123", this.url )

  def prevalidateByDni( dni: String, isCompany: Boolean ): Boolean = {
    consumer.authenticateToProxy( this.cloudProxyHost, this.cloudProxyPort, this.cloudProxyUser, this.cloudProxyPassword )
    val response = consumer.prevalidarARL( dni, LOG_IN_DNI, "NA", "NA", "NA", "NA", "NA", if ( isCompany ) "AEM" else "AIN" ).getRespuesta

    //Si el valor de "radicado" empieza por "NR", significa que
    //ha sucedido un error técnico.
    if ( response.getRadicado.take( 2 ).equalsIgnoreCase( "nr" ) ) {
      val exception = new IOException( "A technical error has occurred.", new Throwable() )
      throw exception
    }

    response.getCorrecto.equalsIgnoreCase( "s" )
  }

}
