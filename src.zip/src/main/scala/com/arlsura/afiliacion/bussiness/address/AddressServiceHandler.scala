package com.arlsura.afiliacion.bussiness.address

import akka.actor.{ ActorSelection, ActorRef }
import com.arlsura.afiliacion.actors.cache.CacheRefresherActor
import com.arlsura.afiliacion.bussiness.RequestContextSupport
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.{ AddressFullInformationConsultWebResponse, GeneralJsonResponseData }
import com.arlsura.afiliacion.persistence.cache.entities.AddressCache
import spray.http.StatusCodes
import spray.routing.RequestContext
import akka.pattern._
import scala.concurrent.Future
import scala.util.{ Success, Failure }
import com.arlsura.afiliacion.utils.GlobalParamsProvider
import scala.concurrent.ExecutionContext

/**
 * Created by Jesús Martínez on 27/04/15.
 */
class AddressServiceHandler( context: RequestContext, cacheActor: ActorSelection )( implicit ec: ExecutionContext ) extends RequestContextSupport with GlobalParamsProvider {

  /**
   * Obtiene toda la información y completa la petición.
   */
  def retrieveAll(): Unit = process( getAddressCatalog )

  /**
   * Obtiene la información filtrada por código de país, y completa la petición.
   * @param code Código del país utilizado para el filtrado.
   */
  def retrieveByCountryCode( code: Int = 57 ): Unit = process( getAddressCatalog.map( e => e.filter( _.countryCode == code ) ) )

  /**
   * Obtiene la información filtrada por nombre de país, y completa la petición.
   * @param name Nombre del país utilizado para el filtrado.
   */
  def retrieveByCountryName( name: String = "COLOMBIA" ): Unit = process( getAddressCatalog.map( e => e.filter( _.countryName == name ) ) )

  /**
   * @param f
   */
  private def process( f: Future[ Seq[ AddressCache ] ] ): Unit = {
    f onComplete {
      case Success( seq ) =>
        val response = GeneralJsonResponseData( "Respuesta exitosa", Some( AddressFullInformationConsultWebResponse( seq.toList ) ) )
        complete( context, StatusCodes.OK, response )
      case Failure( e ) =>
        completeWithFailure( context, e.toString )
    }
  }
  /**
   * Obtiene el catálogo de direcciones directamente del cache.
   * @return Futuro que contiene una secuencia de elementos del catálogo de direcciones.
   */
  private def getAddressCatalog: Future[ Seq[ AddressCache ] ] = {
    val askableAktor = new AskableActorSelection( cacheActor )
    val ask = ( askableAktor ? CacheRefresherActor.GetAddressesInfoCatalog ).mapTo[ CacheRefresherActor.AddressInfoCatalogReturned ]
    ask.map( _.catalog )
  }
}
