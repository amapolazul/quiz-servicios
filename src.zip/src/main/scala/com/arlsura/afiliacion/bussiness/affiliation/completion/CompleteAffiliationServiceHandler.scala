package com.arlsura.afiliacion.bussiness.affiliation.completion

import java.text.SimpleDateFormat
import java.util.{ Date, Calendar }

import co.com.sura.ventainformacion.preafiliacion.service._
import co.com.sura.ventainformacion.preafiliacion.service.consumer.PreafiliacionConsumerService
import com.arlsura.afiliacion.bussiness.HandlerSupport._
import com.arlsura.afiliacion.bussiness.SoapConsumerSupport
import com.arlsura.afiliacion.bussiness.affiliation.{ PreaffiliationManager, BasicDataRepository }
import com.arlsura.afiliacion.bussiness.affiliation.contacts.ContactDataRepository
import com.arlsura.afiliacion.bussiness.affiliation.employees.EmployeeDataRepository
import com.arlsura.afiliacion.bussiness.affiliation.workcenters.WorkCentersDataRepository
import com.arlsura.afiliacion.services.document.validation.Validator

import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.GeneralJsonResponseData

import com.arlsura.afiliacion.persistence.entities.PreAffiliation
import com.arlsura.afiliacion.persistence.entities.affiliation.basic_data.AffiliationBasicData
import com.arlsura.afiliacion.persistence.entities.affiliation.contacts_data.{ ContactInformation, AffiliationContactsData }
import com.arlsura.afiliacion.persistence.entities.affiliation.employee_data.{ EmployeeInformation, AffiliationEmployeesData }
import com.arlsura.afiliacion.persistence.entities.affiliation.work_center_data.{ WorkCenterInformation, AffiliationWorkCentersData }
import com.arlsura.afiliacion.utils.{ DNIBuilder, Utils }

import com.google.inject.Inject
import com.typesafe.scalalogging.LazyLogging

import scala.concurrent.{ ExecutionContext, Future }
import scala.util.control.NonFatal

class CompleteAffiliationServiceHandler @Inject() (
    private val preAffiliationManager:     PreaffiliationManager,
    private val basicDataRepository:       BasicDataRepository,
    private val contactsDataRepository:    ContactDataRepository,
    private val employeesDataRepository:   EmployeeDataRepository,
    private val workCentersDataRepository: WorkCentersDataRepository
) extends SoapConsumerSupport with LazyLogging {

  /**
   * Method that completes and save affiliation data
   * @param dni Affiliation dni
   * @param ec Execution context for future manipulation
   * @return An Either.
   *         Left if service was not executed successfully
   *         Right with built array otherwise
   */
  def completeAffiliation( dni: String )( implicit ec: ExecutionContext ): Future[ ServiceHandlerResponse ] = {

    val preAffiliationDataF: Future[ Option[ PreAffiliation ] ] = preAffiliationManager.getPreAffiliationByDni( dni )
    val workCentersDataF: Future[ Option[ AffiliationWorkCentersData ] ] = workCentersDataRepository.findByDni( dni )
    val employeesDataF: Future[ Option[ AffiliationEmployeesData ] ] = employeesDataRepository.findByDni( dni )
    val contactsDataF: Future[ Option[ AffiliationContactsData ] ] = contactsDataRepository.findByDni( dni )
    val basicDataF: Future[ Option[ AffiliationBasicData ] ] = basicDataRepository.getByDni( dni )

    val preAffiliationDTOF: Future[ Either[ String, PreAfiliacionDTO ] ] = for {
      preAffiliationData <- preAffiliationDataF
      workCentersData <- workCentersDataF
      employeesData <- employeesDataF
      contactsData <- contactsDataF
      basicData <- basicDataF
    } yield {
      for {
        centrosTrabajo <- buildCentrosTrabajo( workCentersData, employeesData, contactsData ).right
        controlEmpresaAfiliacion <- buildControlEmpresaAfiliacionDTO( contactsData, basicData, employeesData, workCentersData ).right
        empresaAfiliacion <- buildEmpresaAfiliacionDTO( preAffiliationData, contactsData, basicData ).right
        personas <- buildPersonas( basicData, contactsData ).right
        trabajadores <- buildTrabajadores( workCentersData, employeesData ).right
      } yield new PreAfiliacionDTO( centrosTrabajo, controlEmpresaAfiliacion, empresaAfiliacion, personas, trabajadores )
    }

    preAffiliationDTOF.flatMap {
      case Right( dto ) => saveAffiliation( dto ).map { result =>
        if ( result ) Right( GeneralJsonResponseData( "Affiliation was saved successfully." ) )
        else Left( "Affiliation was NOT saved. The service was executed correctly but it returned an unsuccessful response." )
      }
      case Left( error ) => Future.successful( Left( error ) )
    }.recover {
      case NonFatal( exception ) =>
        exception.printStackTrace()
        Left( "There was an exception saving the affiliation." )
    }

  }

  /**
   * Method that build an array of "ControlCentroTrabajoDTO"
   * @param wcDataOp WorkCentersData loaded from affiliation_work_centers_data collection
   * @param empDataOp EmployeesData loaded from affiliation_employees_data collection
   * @return An Either.
   *         Left if not data was found.
   *         Right with built array otherwise
   */
  private def buildCentrosTrabajo(
    wcDataOp:  Option[ AffiliationWorkCentersData ],
    empDataOp: Option[ AffiliationEmployeesData ],
    cDataOp:   Option[ AffiliationContactsData ]
  ): Either[ String, Array[ ControlCentroTrabajoDTO ] ] = {
    ( wcDataOp, empDataOp, cDataOp ) match {
      case ( Some( workCenterData ), Some( employeesData ), Some( contactsData ) ) =>

        val responseArray: Array[ ControlCentroTrabajoDTO ] = workCenterData.workCenters.toArray.zipWithIndex.map {
          case ( wc, index ) =>

            val ct: ControlCentroTrabajoDTO = new ControlCentroTrabajoDTO()

            // DATOS NOMINA
            ct.setCdCargoNomina( "5" ) // TODO QUEMADO
            ct.setDniNomina( DNIBuilder.build( contactsData.rosterRepresentative.identificationType, contactsData.rosterRepresentative.identification ) )
            ct.setDsNomina( buildName( contactsData.rosterRepresentative ).toUpperCase )
            ct.setEmailNomina( contactsData.rosterRepresentative.email.toUpperCase )

            // DATOS SALUDOCU
            ct.setCdCargoSaludOcu( "526" ) // TODO QUEMADO
            ct.setDniSaludOcu( DNIBuilder.build( contactsData.workSafetyRepresentative.identificationType, contactsData.workSafetyRepresentative.identification ) )
            ct.setDsSaludOcu( buildName( contactsData.workSafetyRepresentative ).toUpperCase )
            ct.setEmailSaludOcu( contactsData.workSafetyRepresentative.email.toUpperCase )

            // DATOS CT
            ct.setCdActividad( wc.commercialActivity.economicActivityId )
            ct.setCdMunicipio( wc.workcenterAddressData.municipalityCode )
            ct.setNmConsecutivo( wc.workcenterCode.toInt )
            ct.setNmTrabajadoresCT( employeesData.employees.map( _.count( _.workcenter == wc.workcenterName ) ).getOrElse( 0 ) )
            ct.setNombreCT( wc.workcenterName.toUpperCase )
            ct.setSnCTPagador( if ( index == 0 ) "S" else "N" )
            ct.setDsSede( wc.workcenterAddressData.toString.toUpperCase )

            ct.setSnSuministraTransporte( "N" ) // SE ENVÍA POR DEFECTO 'N'

            // ----------------
            // CAMPOS SIN USAR (2)
            // ----------------

            //ct.setCdSede("")
            //ct.setSnCTReclasificar("")

            ct
        }

        logger.debug( s"Lista ControlCentroTrabajoDTO ${responseArray.toList}" )

        Right( responseArray )
      case _ =>
        Left( "No se obtuvieron resultados de centros de trabajo y empleados para la búsqueda por dni." )
    }
  }

  /**
   * Method that builds an object of ControlEmpresaAfiliacionDTO
   * @param cDataOp Contacts data loaded from affiliation_contacts_data collection
   * @param bDataOp Basic data loaded from affiliation_basic_data collection
   * @return An Either.
   *         Left if not data was found.
   *         Right with built object otherwise
   */
  private def buildControlEmpresaAfiliacionDTO(
    cDataOp:  Option[ AffiliationContactsData ],
    bDataOp:  Option[ AffiliationBasicData ],
    eDataOp:  Option[ AffiliationEmployeesData ],
    wcDataOp: Option[ AffiliationWorkCentersData ]
  ): Either[ String, ControlEmpresaAfiliacionDTO ] = {
    ( cDataOp, bDataOp, eDataOp, wcDataOp ) match {
      case ( Some( contacts ), Some( basicData ), Some( empData ), Some( wcData ) ) =>

        val controlEmpresaAfiliacionDTO: ControlEmpresaAfiliacionDTO = new ControlEmpresaAfiliacionDTO()

        // DATOS GERENTE
        controlEmpresaAfiliacionDTO.setCdCargoGerente( "2" ) // TODO QUEMADO
        controlEmpresaAfiliacionDTO.setDniGerente( DNIBuilder.build( contacts.manager.identificationType, contacts.manager.identification ) )
        controlEmpresaAfiliacionDTO.setEmailGerente( contacts.manager.email.toUpperCase )

        // DATOS REPRESENTANTE
        controlEmpresaAfiliacionDTO.setCdCargoRepresentante( "3" ) // TODO QUEMADO
        controlEmpresaAfiliacionDTO.setDniRepresentante( DNIBuilder.build( contacts.legalRepresentative.identificationType, contacts.legalRepresentative.identification ) )
        controlEmpresaAfiliacionDTO.setEmailRepresentante( contacts.legalRepresentative.email.toUpperCase )

        // DATOS RELACIONES
        controlEmpresaAfiliacionDTO.setCdCargoRelaciones( 638 ) // TODO QUEMADO
        controlEmpresaAfiliacionDTO.setDniRelaciones( DNIBuilder.build( contacts.humanResourcesRepresentative.identificationType, contacts.humanResourcesRepresentative.identification ) )
        controlEmpresaAfiliacionDTO.setEmailRelaciones( contacts.humanResourcesRepresentative.email.toUpperCase )

        // DATOS CONTROLEMPRESAAFILIACION
        controlEmpresaAfiliacionDTO.setCdArp( basicData.previousARL.getOrElse( "00" ) )
        controlEmpresaAfiliacionDTO.setFeAfiliacion( basicData.coverageStartDate.map( _.toGregorianCalendar ).getOrElse( Calendar.getInstance() ) )
        controlEmpresaAfiliacionDTO.setFeAniversario( basicData.foundationDate.map( _.toGregorianCalendar ).getOrElse( Calendar.getInstance() ) )

        controlEmpresaAfiliacionDTO.setSnEmpresaCentralizada( "S" ) // SE ENVÍA POR DEFECTO 'S'
        controlEmpresaAfiliacionDTO.setCdTipoOferta( "1" ) // SE ENVÍA POR DEFECTO '1'
        controlEmpresaAfiliacionDTO.setCdMotivoFueraNorma( "12" ) // SE ENVÍA POR DEFECTO '12'
        controlEmpresaAfiliacionDTO.setSnCooperativa( "N" ) // SE ENVÍA POR DEFECTO 'N'

        controlEmpresaAfiliacionDTO.setCdEstadoVenta( "D" ) // QUEMADO
        controlEmpresaAfiliacionDTO.setPoinvesion( 7.0 ) // QUEMADO

        // Internal function that sums salaries
        def sumSalaries( employees: List[ EmployeeInformation ] ): Double = {
          employees.foldLeft( 0.0 )( ( ac, employee ) => ac + employee.salary.toDouble )
        }

        // IBC
        controlEmpresaAfiliacionDTO.setPtUltimoIBC( empData.employees.map( sumSalaries ).getOrElse( 0.0 ).toInt )

        // PTCOTIZACION
        val workcenterEmployeesOp: Option[ Map[ String, List[ EmployeeInformation ] ] ] = empData.employees.map( _.groupBy( _.workcenter ) )
        val employeeCot: Option[ List[ Double ] ] = workcenterEmployeesOp.map( _.map { data =>
          val wcRate: Double = wcData.workCenters
            .find( _.workcenterName == data._1 )
            .flatMap( _.commercialActivity.rate.map( _.toDouble / 100 ) )
            .getOrElse( 0.0 )
          val wcEmployeesSalariesSum: Double = sumSalaries( data._2 )
          wcEmployeesSalariesSum * wcRate
        }.toList )

        controlEmpresaAfiliacionDTO.setPtCotizacion( employeeCot.map( _.sum.toInt ).getOrElse( 0 ) )

        // ----------------
        // CAMPOS SIN USAR (13)
        // ----------------

        //        controlEmpresaAfiliacionDTO.setDsGerente("")
        //        controlEmpresaAfiliacionDTO.setDsContactos("")
        //        controlEmpresaAfiliacionDTO.setDsResponsable("")
        //        controlEmpresaAfiliacionDTO.setDsRelaciones("")
        //        controlEmpresaAfiliacionDTO.setCdCargo("")
        //        controlEmpresaAfiliacionDTO.setCdAgente("")
        //        controlEmpresaAfiliacionDTO.setCdJustifMotivo("")
        //        controlEmpresaAfiliacionDTO.setCdMercaroObjetivo("")
        //        controlEmpresaAfiliacionDTO.setCdMotivoVenta("")
        //        controlEmpresaAfiliacionDTO.setCdOrigenCarga("")
        //        controlEmpresaAfiliacionDTO.setFeAutorizacionTransicion("")
        //        controlEmpresaAfiliacionDTO.setFeTransicion(Calendar.getInstance())
        //        controlEmpresaAfiliacionDTO.setSnEmpresaxReclasificar("")

        logger.debug( s"ControlEmpresaAfiliacionDTO $controlEmpresaAfiliacionDTO" )

        Right( controlEmpresaAfiliacionDTO )
      case _ =>
        Left( "No se obtuvieron resultados de datos básicos, contactos y empleados para la búsqueda por dni." )
    }
  }

  /**
   * Method that builds an object of EmpresaAfiliacionDTO
   * @param prDataOp Preaffiliation data loaded from preaffiliation collection
   * @param cDataOp Contacts data loaded from affiliation_contacts_data collection
   * @param bDataOp Basic data loaded from affiliation_basic_data collection
   * @return An Either.
   *         Left if not data was found.
   *         Right with built object otherwise
   */
  private def buildEmpresaAfiliacionDTO(
    prDataOp: Option[ PreAffiliation ],
    cDataOp:  Option[ AffiliationContactsData ], bDataOp: Option[ AffiliationBasicData ]
  ): Either[ String, EmpresaAfiliacionDTO ] = {
    ( prDataOp, cDataOp, bDataOp ) match {
      case ( Some( preAffiliation ), Some( contacts ), Some( basicData ) ) =>

        val empresaAfiliacionDTO: EmpresaAfiliacionDTO = new EmpresaAfiliacionDTO()

        // CentroTrabajoXML start --
        val centroTrabajo: CentroTrabajoXmlDTO = new CentroTrabajoXmlDTO()

        // DATOS NOMINA
        centroTrabajo.setCargoNomina( "526" ) // TODO QUEMADO
        centroTrabajo.setCorreoNomina( contacts.rosterRepresentative.email.toUpperCase )
        centroTrabajo.setDniNomina( DNIBuilder.build( contacts.rosterRepresentative.identificationType, contacts.rosterRepresentative.identification ) )

        // DATOS RESPONSABLE
        centroTrabajo.setCargoResponsable( "1" ) // TODO QUEMADO
        centroTrabajo.setCorreoResponsable( contacts.insideTrainingRepresentative.email.toUpperCase )
        centroTrabajo.setDniResponsable( DNIBuilder.build( contacts.insideTrainingRepresentative.identificationType, contacts.insideTrainingRepresentative.identification ) )

        // DATOS SALUDOCU
        centroTrabajo.setCargoSaludOcu( "5" ) // TODO QUEMADO
        centroTrabajo.setCorreoSaludOcu( contacts.workSafetyRepresentative.email.toUpperCase )
        centroTrabajo.setDniSaludOcu( DNIBuilder.build( contacts.workSafetyRepresentative.identificationType, contacts.workSafetyRepresentative.identification ) )

        empresaAfiliacionDTO.setCentroTrabajoXml( centroTrabajo )
        // CentroTrabajoXML end --

        // DATOS EMPRESAAFILIACION
        empresaAfiliacionDTO.setDni( DNIBuilder.build( basicData.contactInformation.identificationType, basicData.contactInformation.identification ) )
        empresaAfiliacionDTO.setEmail( preAffiliation.contactInfo.email.toUpperCase )

        empresaAfiliacionDTO.setCdActividadEconomica( basicData.fullEconomicActivity.economicActivityId )
        empresaAfiliacionDTO.setCdMunicipio( basicData.mainAddress.map( _.municipalityCode ).getOrElse( "" ) )
        empresaAfiliacionDTO.setCdDepartamento( basicData.mainAddress.map( _.municipalityCode ).getOrElse( "" ) )
        empresaAfiliacionDTO.setCdDelegacion( basicData.mainAddress.map( _.delegationCode ).getOrElse( "" ) )

        empresaAfiliacionDTO.setNombre( basicData.commercialName.map( _.toUpperCase ).getOrElse( buildName( basicData.contactInformation ).toUpperCase ) )
        empresaAfiliacionDTO.setDireccion( basicData.mainAddress.map( _.toString.toUpperCase ).getOrElse( preAffiliation.address.toUpperCase ) )
        empresaAfiliacionDTO.setTelefono( preAffiliation.cellphone.getOrElse( preAffiliation.contactInfo.phone.getOrElse( "" ) ) )

        empresaAfiliacionDTO.setFeCartaCuerpoliza( basicData.letterDeliveryDate.map( _.toGregorianCalendar ).getOrElse( Calendar.getInstance() ) )
        empresaAfiliacionDTO.setNaturalezaJuridica( basicData.juridicalNature.map( _.toString ).getOrElse( "4" ) )
        empresaAfiliacionDTO.setNmTrabDirectos( preAffiliation.workers.toInt )
        empresaAfiliacionDTO.setSnNueva( basicData.newCompany.map( n => if ( n ) "S" else "N" ).getOrElse( "N" ) )

        empresaAfiliacionDTO.setCdCategoriaDefinitiva( "55" ) // SE ENVÍA POR DEFECTO '55'
        empresaAfiliacionDTO.setEmpresaExiste( false ) // SE ENVÍA POR DEFECTO false
        empresaAfiliacionDTO.setSnFueraNorma( "S" ) // SE ENVÍA POR DEFECTO 'S'
        empresaAfiliacionDTO.setFeAlta( Calendar.getInstance() ) // SE ENVÍA POR DEFECTO Calendar.getInstance()
        empresaAfiliacionDTO.setSnVenta( "N" ) // SE ENVÍA POR DEFECTO 'N'
        empresaAfiliacionDTO.setCdEti( "0" ) // SE ENVÍA POR DEFECTO 0
        empresaAfiliacionDTO.setCdUenPpal( "0" ) // SE ENVÍA POR DEFECTO 0

        // --------------------
        // CAMPOS SIN USAR (26)
        // --------------------

        //empresaAfiliacionDTO.setCdActividadCentroTrabajo("")
        //empresaAfiliacionDTO.setCdFuenteIngresoCuerpoliza("")
        //empresaAfiliacionDTO.setCdFuenteIngresoPotenciales("")
        //empresaAfiliacionDTO.setCdFuenteIngresoSedeSucur("")
        //empresaAfiliacionDTO.setCdSede("")
        //empresaAfiliacionDTO.setCdTipoEnvio("")
        //empresaAfiliacionDTO.setCentroTrabajo("")
        //empresaAfiliacionDTO.setClaseRiesgoAct("")
        //empresaAfiliacionDTO.setControlAfiliacion(null)
        //empresaAfiliacionDTO.setDniRepresentante("")
        //empresaAfiliacionDTO.setDsSede("")
        //empresaAfiliacionDTO.setFax("")
        //empresaAfiliacionDTO.setFeNacimiento(Calendar.getInstance())
        //empresaAfiliacionDTO.setGenero("")
        //empresaAfiliacionDTO.setGeneroRepresentante("")
        //empresaAfiliacionDTO.setNombreRepresentante("")
        //empresaAfiliacionDTO.setSnAfiliada("")
        //empresaAfiliacionDTO.setSnCentroTrabajoPagador("")
        //empresaAfiliacionDTO.setSnCentroTrabajoReclasificar("")
        //empresaAfiliacionDTO.setSnMagnetico("")
        //empresaAfiliacionDTO.setSnSuministraTransporte("")
        //empresaAfiliacionDTO.setTasaAct(0)
        //empresaAfiliacionDTO.setTipoEmpleador("")
        //empresaAfiliacionDTO.setTipoEmpresa("")

        logger.debug( s"EmpresaAfiliacionDTO $empresaAfiliacionDTO" )

        Right( empresaAfiliacionDTO )
      case _ =>
        Left( "No se obtuvieron resultados de datos básicos, contactos y preafiliación para la búsqueda por dni." )
    }
  }

  /**
   * Method that builds an array of PersonaDTO
   * @param cDataOp Contacts data loaded from affiliation_contacts_data collection
   * @param bDataOp Basic data loaded from affiliation_basic_data collection
   * @return An Either.
   *         Left if not data was found.
   *         Right with built array otherwise
   */
  private def buildPersonas(
    bDataOp: Option[ AffiliationBasicData ],
    cDataOp: Option[ AffiliationContactsData ]
  ): Either[ String, Array[ PersonaDTO ] ] = {
    ( bDataOp, cDataOp ) match {
      case ( Some( basicData ), Some( contactsData ) ) =>

        val companyInformation: PersonaDTO = new PersonaDTO()

        // PostalDTO
        val companyInformationPostal: PostalDTO = new PostalDTO()
        companyInformationPostal.setCodigoMunicipio( basicData.mainAddress.map( _.municipalityCode ).getOrElse( "" ) )

        // DatosAdicionalesPersonaDTO
        val companyInformationData: DatosAdicionalesPersonaDTO = new DatosAdicionalesPersonaDTO()
        companyInformationData.setDomicilio( basicData.mainAddress.map( _.toString.toUpperCase ).getOrElse( "" ) )
        companyInformationData.setMunicipio( companyInformationPostal )
        companyInformationData.setTelefonoDomicilio( basicData.contactInformation.phone.getOrElse( "" ) )

        // NIT verification digit
        DNIBuilder.identificationTypes( basicData.contactInformation.identificationType ).map {
          case "N" =>
            val vDigit: String = getVerificationDigit( basicData.contactInformation.identificationType + basicData.contactInformation.identification )
            companyInformationData.setNumeroVerificacion( vDigit.toInt )
          case _ =>
        }

        // Set datosAdicionales
        companyInformation.setDatosAdicionales( companyInformationData )
        companyInformation.setNombreCompleto( basicData.commercialName.map( _.toUpperCase ).getOrElse( "" ) )

        // Group all 6 contacts into one single list for simplicity
        val contactsList: List[ ContactInformation ] = contactsData.manager :: contactsData.legalRepresentative ::
          contactsData.humanResourcesRepresentative :: contactsData.rosterRepresentative :: contactsData.workSafetyRepresentative ::
          contactsData.insideTrainingRepresentative :: Nil

        // Contacts information
        val personasDTO: List[ PersonaDTO ] = contactsList.map { c =>
          val personaContactoDTO: PersonaDTO = new PersonaDTO()
          personaContactoDTO.setPrimerApellido( c.lastname1.toUpperCase )
          personaContactoDTO.setPrimerNombre( c.name1.toUpperCase )
          personaContactoDTO.setSegundoApellido( c.lastname2.map( _.toUpperCase ).getOrElse( "" ) )
          personaContactoDTO.setSegundoNombre( c.name2.map( _.toUpperCase ).getOrElse( "" ) )
          personaContactoDTO
        }

        logger.debug( s"PersonasDTO ${companyInformation :: personasDTO}" )

        // Response:
        //    Position 0 --> company information
        //    Positions 1 to 6 --> contacts information
        Right( ( companyInformation :: personasDTO ).toArray )
      case _ =>
        Left( "No se obtuvieron resultados de datos básicos, contactos y preafiliación para la búsqueda por dni." )
    }
  }

  /**
   * Method that builds an array of TrabajadorDTO
   * @param wcDataOp WorkCentersData loaded from affiliation_work_centers_data collection
   * @param empDataOp EmployeesData loaded from affiliation_employees_data collection
   * @return An Either.
   *         Left if not data was found.
   *         Right with built array otherwise
   */
  private def buildTrabajadores(
    wcDataOp:  Option[ AffiliationWorkCentersData ],
    empDataOp: Option[ AffiliationEmployeesData ]
  ): Either[ String, Array[ TrabajadorDTO ] ] = {
    ( wcDataOp, empDataOp ) match {
      case ( Some( wcData ), Some( empData ) ) if empData.employees.isDefined =>

        val responseArray: Array[ TrabajadorDTO ] = empData.employees.get.toArray.map { emp =>

          val trabajador = new TrabajadorDTO()
          trabajador.setCdAfp( emp.afp.getOrElse( "000" ) )
          trabajador.setCdCentroTrabajo( wcData.workCenters.find( _.workcenterName == emp.workcenter ).map( _.workcenterCode ).getOrElse( "" ) )
          trabajador.setCdEps( emp.eps.getOrElse( "000" ) )
          trabajador.setCdMunicipio( emp.employeeAddressData.municipalityCode )
          trabajador.setDniTrabajador( DNIBuilder.build( emp.contactInfo.identificationType, emp.contactInfo.identification ) )
          trabajador.setDsCargo( emp.contactInfo.position.getOrElse( "" ) )
          trabajador.setDsPrimerApellido( emp.contactInfo.lastname1.toUpperCase )
          trabajador.setDsPrimerNombre( emp.contactInfo.name1.toUpperCase )
          trabajador.setDsSegundoApellido( emp.contactInfo.lastname2.map( _.toUpperCase ).getOrElse( "" ) )
          trabajador.setDsSegundoNombre( emp.contactInfo.name2.map( _.toUpperCase ).getOrElse( "" ) )
          trabajador.setFeNacimiento( emp.birthdate.map { bd =>
            val dt: Date = new SimpleDateFormat( "dd/MM/yyyy" ).parse( bd )
            val cal: Calendar = Calendar.getInstance()
            cal.setTime( dt )
            cal
          }.getOrElse( Calendar.getInstance() ) )
          trabajador.setPtSalario( emp.salary.toLong )
          trabajador.setSexo( emp.gender )
          trabajador.setTelefonoPart( emp.cellphone.getOrElse( emp.contactInfo.phone.getOrElse( "" ) ) )
          trabajador.setDireccion( emp.employeeAddressData.toString.toUpperCase )

          // --------------------
          // CAMPOS SIN USAR (2)
          // --------------------

          //trabajador.setCdSubTipoCotizante("")
          //trabajador.setCdTipoCotizante("")

          trabajador
        }

        logger.debug( s"TrabajadoresDTO ${responseArray.toList}" )

        Right( responseArray )
      case _ =>
        Left( "No se obtuvieron resultados de centros de trabajo y empleados para la búsqueda por dni." )
    }
  }

  /**
   * Method that saves affiliation into sura's service.
   * This method calls sura's WSDL
   * @param affiliation Affiliation to save
   * @return A future with a Boolean inside.
   *         True if affiliation was saved successfully.
   *         False otherwise.
   */
  private def saveAffiliation( affiliation: PreAfiliacionDTO )( implicit ec: ExecutionContext ): Future[ Boolean ] = Future {
    val preAffiliationServiceUrl: String = Utils.getProperty( "soap.services.", "pre-affiliation" ).asInstanceOf[ String ]
    val preAffiliationServiceConsumer: PreafiliacionConsumerService = new PreafiliacionConsumerService( this.username, this.password, "1", preAffiliationServiceUrl )
    logger.debug( s"Saving affiliation into VentaInformación. URL: $preAffiliationServiceUrl" )
    preAffiliationServiceConsumer.authenticateToProxy( this.cloudProxyHost, this.cloudProxyPort, this.cloudProxyUser, this.cloudProxyPassword )
    preAffiliationServiceConsumer.CrearPreafiliacion( affiliation )
  }

  // ---------------------------
  // UTILITIES
  // ---------------------------

  /**
   * Method that builds full name
   * @param contact Contact
   * @return Complete name built
   */
  private def buildName( contact: ContactInformation ): String = {
    s"${contact.name1} ${contact.name2.getOrElse( "" )} ${contact.lastname1} ${contact.lastname2.getOrElse( "" )}"
  }

  /**
   * Method that gets NIT verification number
   * @param invDni NIT DNI
   * @return NIT verification digit
   */
  def getVerificationDigit( invDni: String ) = {
    try {
      val invDniTrimmed = invDni.trim
      val prefix = invDniTrimmed.take( 2 )
      val number = invDniTrimmed.drop( 2 )

      //Valida tipo y tamaño de la identificación proveída.
      assert( prefix.equalsIgnoreCase( "ni" ) )
      assert( number.nonEmpty )
      assert( number.length <= 15 )

      //Completa con ceros el NIT, en caso de hacer falta (cuando la longitud del NIT < 15)
      val vDni = prefix.toString ++ ( "0" * 15 ).take( 15 - number.length ) ++ number
      val sum = ( vDni.drop( 2 ) zip List( 71, 67, 59, 53, 47, 43, 41, 37, 29, 23, 19, 17, 13, 7, 3 ) ).foldLeft( 0 ) {
        ( accum: Int, pair: ( Char, Int ) ) => accum + pair._1.asDigit * pair._2
      }

      val residuum = sum % 11

      residuum match {
        case 0 => "0"
        case 1 => "1"
        case _ => ( 11 - residuum ).toString
      }
    }
    catch {
      case _: Throwable => "-1"
    }
  }

}