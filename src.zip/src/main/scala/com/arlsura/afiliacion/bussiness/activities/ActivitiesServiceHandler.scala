package com.arlsura.afiliacion.bussiness.activities

import akka.actor.{ ActorSelection, ActorRef }
import akka.pattern._
import com.arlsura.afiliacion.actors.cache.CacheRefresherActor
import com.arlsura.afiliacion.bussiness.RequestContextSupport
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.{ GeneralJsonResponseData, Activity }
import com.arlsura.afiliacion.persistence.entities.DomesticEmployerActivity
import com.arlsura.afiliacion.persistence.cache.entities.EconomicActivityCache
import com.arlsura.afiliacion.utils.GlobalParamsProvider
import scala.util.matching.Regex
import scala.util.{ Success, Failure }
import com.arlsura.afiliacion.utils.messages.MessagesRetriever
import reactivemongo.core.commands.LastError
import spray.http.{ StatusCode, StatusCodes }
import spray.routing.RequestContext
import scala.concurrent.Future
import scala.concurrent.ExecutionContext

/**
 * Created by Jesús Martínez on 4/02/15.
 */
class ActivitiesServiceHandler( requestContext: RequestContext, cacheActor: Option[ ActorSelection ] = None )( implicit ec: ExecutionContext ) extends RequestContextSupport with GlobalParamsProvider {
  import ActivitiesServiceHandler._
  private lazy val activitiesManager: ActivitiesManager = ActivitiesManager()

  /**
   *
   * @param code
   * @param name
   */
  def retrieveActivities( code: Option[ String ] = None, name: Option[ String ] = None ) = {
    //Si el nombre está definido, se arma un regex con él; si no, el patrón admite cualquier número y tipo
    //de caracteres.
    val pattern: Regex = if ( name.isDefined && name.get.nonEmpty ) s"(?i).*(${name.get}).*".r else ".*".r

    /*
      Convierte un elemento EconomicActivityCache a Activity.
     */
    def marshallActivity( a: EconomicActivityCache ): Activity = Activity(
      acName = a.name,
      cdActivity = a.code,
      cdClass = a.classCode,
      rate = a.rate
    )

    /*
      Predicado utilizado para filtrar los elementos del catálogo de actividades.
     */
    def predicate( elem: EconomicActivityCache ): Boolean = {
      var validation = true //El elemento es válido en un principio.

      //Si existe código, verificar que el elemento tenga ese código.
      if ( code.isDefined && code.get.nonEmpty )
        validation = code.get == elem.code

      //Validar que el nombre del elemento coincida con el patrón.
      validation && pattern.findFirstIn( elem.name ).isDefined
    }

    /*
    Trae el catálogo de actividades económicas desde el cache.
     */
    def getActivitiesCatalog: Future[ Seq[ EconomicActivityCache ] ] = {
      val askableActor = new AskableActorSelection( cacheActor.get )
      val ask = ( askableActor ask CacheRefresherActor.GetEconomicActivitiesCatalog ).mapTo[ CacheRefresherActor.EconomicActivitiesCatalogReturned ]
      ask.map( _.catalog )
    }

    val activitiesFuture = getActivitiesCatalog.map( _.filter( predicate ) )

    activitiesFuture onComplete {
      case Success( activities ) =>
        val response: GeneralJsonResponseData = GeneralJsonResponseData( "", Some( activities map marshallActivity ) )
        complete( requestContext, StatusCodes.OK, response )
      case Failure( e ) =>
        completeWithFailure( requestContext, e.toString )
    }
  }

  /**
   *
   * @param code
   * @return
   */
  def retrieveDomesticEmployerActivities( code: Option[ String ] ): Unit = {
    def marshallActivity( a: DomesticEmployerActivity ) =
      ARLJsonMarshaller.DomesticEmployerActivity(
        id = Some( a._id.stringify ),
        code = a.code,
        description = a.description,
        name = a.name
      )
    /**
     * Trae todas las actividades en base de datos.
     */
    def retrieveAll(): Unit = {
      val domesticActivities: Future[ List[ DomesticEmployerActivity ] ] = activitiesManager.getDomesticEmployerActivities

      //En caso de éxito, completar con la lista resultante.
      domesticActivities onSuccess {
        case activities: List[ DomesticEmployerActivity ] =>
          val activitiesMarshaller: List[ ARLJsonMarshaller.DomesticEmployerActivity ] = activities map marshallActivity
          val response: GeneralJsonResponseData =
            GeneralJsonResponseData( domesticActivityGetAll, Some( activitiesMarshaller ) )
          complete( requestContext, StatusCodes.OK, response )
      }

      //En caso de falla, notificar.
      domesticActivities onFailure {
        case e: Throwable => completeWithFailure( requestContext, e.toString )
      }
    }

    /**
     * Busca una actividad acorde al código provisto.
     * @param code Code utilizado como clave para buscar la actividad.
     */
    def retrieveByCode( code: String ): Unit =
      try {
        //LLAMADA A MONGO
        val domesticActivity: Future[ Option[ DomesticEmployerActivity ] ] = activitiesManager.getDomesticEmployerActivitiesById( code )

        //En caso de éxito, completar con la lista resultante.
        domesticActivity onSuccess {
          case activity: Option[ DomesticEmployerActivity ] =>
            val ( s: StatusCode, r: GeneralJsonResponseData ) = activity map {
              a =>
                val activityMarshaller = marshallActivity( a )
                val response = GeneralJsonResponseData( domesticActivityGetOne, Some( activityMarshaller ) )
                ( StatusCodes.OK, response )
            } getOrElse {
              val response = GeneralJsonResponseData( domesticActivityNotFound )
              ( StatusCodes.NotFound, response )
            }

            //Completar exitosamente.
            complete( requestContext, s, r )
        }

        //En caso de falla, escalar.
        domesticActivity onFailure {
          case e: Throwable => throw e
        }
      }
      catch {
        case e: Throwable =>
          completeWithFailure( requestContext, e.toString )
      }

    //Si hay un código, utilizarlo como clave para la búsqueda.
    //Si no, traer todo.
    code match {
      case Some( cd ) => retrieveByCode( cd )
      case None       => retrieveAll()
    }
  }

  /**
   * Crea una actividad en base de datos.
   * @param activity Objeto con la información de la actividad que se creará.
   */
  def createDomesticActivity( activity: ARLJsonMarshaller.DomesticEmployerActivity ): Unit = {
    val domesticActivityEntity = DomesticEmployerActivity(
      code = activity.code,
      description = activity.description,
      name = activity.name
    )

    val insertDomesticActivity: Future[ LastError ] = activitiesManager.createDomesticEmployerActivity( domesticActivityEntity )

    //Si tiene éxito, devolver una respuesta apropiada.
    insertDomesticActivity onSuccess {
      case result: LastError =>
        val ( status, response ) =
          if ( result.ok )
            ( StatusCodes.OK, GeneralJsonResponseData( successCreationActivityMessage ) )
          else
            ( StatusCodes.InternalServerError, GeneralJsonResponseData( errorUpdateActivity ) )

        complete( requestContext, status, response )
    }

    //Si falla, notificar.
    insertDomesticActivity onFailure {
      case e: Throwable =>
        completeWithFailure( requestContext, e.toString )
    }
  }

  /**
   * Modifica una actividad en base de datos.
   * @param activity Objeto con la información que será modificada.
   * @param id Identificador de la actividad a ser modificada.
   */
  def updateDomesticActivity( activity: ARLJsonMarshaller.DomesticEmployerActivity, id: String ): Unit = {
    try {
      val domesticActivity: Future[ Option[ DomesticEmployerActivity ] ] = activitiesManager.getDomesticEmployerActivitiesById( id )

      domesticActivity onSuccess {
        case Some( a ) =>
          val activityUpdate: Future[ LastError ] =
            activitiesManager.updateDomesticEmployerActivity( id, a.code, a.description, a.name )

          //Si el futuro es exitoso, analizar el resultado y enviar la respuesta que corresponda.
          activityUpdate onSuccess {
            case result: LastError =>
              if ( result.ok )
                complete( requestContext, StatusCodes.OK, GeneralJsonResponseData( domesticActivityUpdate ) )
              else
                complete( requestContext, StatusCodes.InternalServerError, GeneralJsonResponseData( errorCreationActivityMessage ) )
          }

          //Si falló, escalar.
          activityUpdate onFailure {
            case e: Throwable => throw e
          }
        case None =>
          complete( requestContext, StatusCodes.NotFound, GeneralJsonResponseData( domesticActivityNotFound ) )
      }

      //Si falló, escalar.
      domesticActivity onFailure {
        case e: Throwable => throw e
      }
    }
    catch {
      case e: Throwable =>
        completeWithFailure( requestContext, e.toString )
    }

  }

  /**
   * Elimina una actividad de base de datos.
   * @param id Identificador de la actividad que se eliminará.
   */
  def deleteDomesticActivity( id: String ): Unit = {
    val domesticActivity: Future[ Option[ DomesticEmployerActivity ] ] = activitiesManager.getDomesticEmployerActivitiesById( id )

    domesticActivity onSuccess {
      case Some( a ) =>
        val activityUpdate: Future[ LastError ] = activitiesManager.deleteDomesticEmployerActivity( id )

        //Si el futuro es exitoso, analizar el resultado y enviar la respuesta que corresponda.
        activityUpdate onSuccess {
          case result: LastError =>
            if ( result.ok )
              complete( requestContext, StatusCodes.OK, GeneralJsonResponseData( domesticActivityUpdate ) )
            else
              complete( requestContext, StatusCodes.InternalServerError, GeneralJsonResponseData( errorCreationActivityMessage ) )
        }

        //Si falló, escalar.
        activityUpdate onFailure {
          case e: Throwable => throw e
        }
      case None =>
        complete( requestContext, StatusCodes.NotFound, GeneralJsonResponseData( domesticActivityNotFound ) )
    }

    //Si falló, escalar.
    domesticActivity onFailure {
      case e: Throwable => throw e
    }
  }
}

object ActivitiesServiceHandler {
  //Funciones que traen diversos mensajes.
  def successCreationActivityMessage: String = MessagesRetriever.getSuccessMessage( "domesticActivity", "DOMESTIC_EMPLOYER_ACTIVITY_CREATE_SUCCESS" )
  def errorCreationActivityMessage: String = MessagesRetriever.getErrorMessage( "domesticActivity", "DOMESTIC_EMPLOYER_ACTIVITY_CREATE_ERROR" )
  def domesticActivityNotFound: String = MessagesRetriever.getErrorMessage( "domesticActivity", "DOMESTIC_EMPLOYER_ACTIVITY_NOT_FOUND" )
  def domesticActivityUpdate: String = MessagesRetriever.getSuccessMessage( "domesticActivity", "DOMESTIC_EMPLOYER_ACTIVITY_UPDATE_SUCCESS" )
  def domesticActivityDelete: String = MessagesRetriever.getSuccessMessage( "domesticActivity", "DOMESTIC_EMPLOYER_ACTIVITY_DELETE_SUCCESS" )
  def domesticActivityGetAll: String = MessagesRetriever.getSuccessMessage( "domesticActivity", "DOMESTIC_EMPLOYER_ACTIVITY_GET_ALL_SUCCESS" )
  def domesticActivityGetOne: String = MessagesRetriever.getSuccessMessage( "domesticActivity", "DOMESTIC_EMPLOYER_ACTIVITY_GET_SUCCESS" )
  def errorUpdateActivity: String = MessagesRetriever.getErrorMessage( "domesticActivity", "DOMESTIC_EMPLOYER_ACTIVITY_UPDATE_ERROR" )
}
