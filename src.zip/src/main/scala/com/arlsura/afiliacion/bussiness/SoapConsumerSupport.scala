package com.arlsura.afiliacion.bussiness

import com.arlsura.afiliacion.utils.Utils

/**
 * Created by juanmartinez on 15/11/14.
 */
trait SoapConsumerSupport {
  //Usuario nombrado para consumir los servicios de venta información
  lazy val username = Utils.getProperty( "soap.credentials.", "username" ).asInstanceOf[ String ]

  //Password del usuario nombrado para consumir los servicios de venta informacion
  lazy val password = Utils.getProperty( "soap.credentials.", "password" ).asInstanceOf[ String ]

  //Hostname del proxy para consumir los servicios de Venta Información desde una IP estática.
  lazy val cloudProxyHost = Utils.getProperty( "authentication.cloud_proxy.", "host" ).asInstanceOf[ String ]

  //Puerto del proxy para consumir los servicios de Venta Información desde una IP estática.
  lazy val cloudProxyPort = Utils.getProperty( "authentication.cloud_proxy.", "port" ).asInstanceOf[ String ]

  //Usuario nombrado del proxy para consumir los servicios de Venta Información desde una IP estática.
  lazy val cloudProxyUser = Utils.getProperty( "authentication.cloud_proxy.", "user" ).asInstanceOf[ String ]

  //Contraseña del usuario nombrado del proxy para consumir los servicios de Venta Información desde una IP estática.
  lazy val cloudProxyPassword = Utils.getProperty( "authentication.cloud_proxy.", "password" ).asInstanceOf[ String ]

  println( s"USERNAME <<<<< $username" )
  println( s"PASSWORD <<<<<< $password" )
  println( s"PROXY HOST <<<<<< $cloudProxyHost" )
  println( s"PROXY PORT <<<<<< $cloudProxyPort" )
  println( s"PROXY USER <<<<<< $cloudProxyUser" )
  println( s"PROXY PASSWORD <<<<< $cloudProxyPassword" )
}
