package com.arlsura.afiliacion.bussiness.affiliation

import com.arlsura.afiliacion.bussiness.affiliation.contacts.ContactDataRepository
import com.arlsura.afiliacion.persistence.daos.affiliation.wrappers.{ AffiliationContactsDataWrapper, AffiliationBasicDataWrapper }
import com.arlsura.afiliacion.persistence.daos.wrappers.PreAffiliationWrapper
import com.google.inject.AbstractModule
import net.codingwell.scalaguice.ScalaModule

/**
 * Created by Jesús Martínez on 20/05/15.
 */
class BasicDataServiceModule extends AbstractModule with ScalaModule {
  override def configure(): Unit = {
    bind[ AffiliationBasicDataWrapper ]
    bind[ BasicDataRepository ]
    bind[ AffiliationContactsDataWrapper ]
    bind[ ContactDataRepository ]
    bind[ PreAffiliationWrapper ]
    bind[ PreaffiliationManager ]
  }
}
