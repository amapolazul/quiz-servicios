package com.arlsura.afiliacion.bussiness.affiliation.contacts

import com.arlsura.afiliacion.persistence.daos.affiliation.AffiliationContactsDataDAO
import com.arlsura.afiliacion.persistence.daos.affiliation.wrappers.AffiliationContactsDataWrapper
import com.arlsura.afiliacion.persistence.entities.affiliation.contacts_data.{ ContactInformation, AffiliationContactsData }
import com.arlsura.afiliacion.utils.CipherFacility
import com.google.inject.Inject
import reactivemongo.bson.{ BSONString, BSONDocument }
import reactivemongo.core.commands.LastError

import scala.concurrent.{ ExecutionContext, Future }

/**
 * Created by juanmartinez on 16/04/15.
 */
class ContactDataRepository @Inject() ( private val contactsDao: AffiliationContactsDataWrapper ) extends CipherFacility {
  private def decryptDocument( a: AffiliationContactsData ) = AffiliationContactsData(
    _id = a._id,
    dni = decode( a.dni ),
    securityCode = a.securityCode,
    manager = ContactInformation.decrypt( a.manager ),
    legalRepresentative = ContactInformation.decrypt( a.legalRepresentative ),
    humanResourcesRepresentative = ContactInformation.decrypt( a.humanResourcesRepresentative ),
    insideTrainingRepresentative = ContactInformation.decrypt( a.insideTrainingRepresentative ),
    rosterRepresentative = ContactInformation.decrypt( a.rosterRepresentative ),
    workSafetyRepresentative = ContactInformation.decrypt( a.workSafetyRepresentative )
  )

  private def encryptDocument( a: AffiliationContactsData ) = AffiliationContactsData(
    _id = a._id,
    dni = encode( a.dni ),
    securityCode = a.securityCode,
    manager = ContactInformation.encrypt( a.manager ),
    legalRepresentative = ContactInformation.encrypt( a.legalRepresentative ),
    humanResourcesRepresentative = ContactInformation.encrypt( a.humanResourcesRepresentative ),
    insideTrainingRepresentative = ContactInformation.encrypt( a.insideTrainingRepresentative ),
    rosterRepresentative = ContactInformation.encrypt( a.rosterRepresentative ),
    workSafetyRepresentative = ContactInformation.encrypt( a.workSafetyRepresentative )
  )

  def create( affiliationContact: AffiliationContactsData )( implicit executionContext: ExecutionContext ): Future[ LastError ] = {
    contactsDao.insert( encryptDocument( affiliationContact ) )
  }

  def findByDni( dni: String )( implicit executionContext: ExecutionContext ): Future[ Option[ AffiliationContactsData ] ] =
    contactsDao.findOne( BSONDocument( "dni" -> encode( dni ) ) ) map ( _.map( decryptDocument ) )

  def updateByDni( affiliationContacts: AffiliationContactsData, dni: String )( implicit executionContext: ExecutionContext ) = {
    contactsDao.update( BSONDocument( "dni" -> encode( dni ) ), encryptDocument( affiliationContacts ) )
  }

}
