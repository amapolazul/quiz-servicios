package com.arlsura.afiliacion.bussiness.blacklist

import com.arlsura.afiliacion.persistence.blacklist.BlacklistWrapper
import com.google.inject.AbstractModule
import net.codingwell.scalaguice.ScalaModule

/**
 * Created by Jesús Martínez on 9/06/15.
 */
class BlacklistServiceModule extends AbstractModule with ScalaModule {
  override def configure(): Unit = {
    bind[ BlacklistWrapper ]
    bind[ BlacklistRepository ]
  }
}
