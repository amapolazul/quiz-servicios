package com.arlsura.afiliacion.bussiness.activities

import com.arlsura.afiliacion.persistence.daos.DomesticEmployerActivityDAO
import com.arlsura.afiliacion.persistence.entities.DomesticEmployerActivity
import reactivemongo.bson.{ BSONString, BSONObjectID }
import reactivemongo.core.commands.LastError
import reactivemongo.extensions.dsl.BsonDsl._
import scala.concurrent.Future
import scala.concurrent.ExecutionContext.Implicits.global

/**
 * Created by juanmartinez on 6/01/15.
 */
class ActivitiesManager {

  /**
   * Retorna la lista de actividades economicas para la opcion de empleador domestico
   * @return
   */
  def getDomesticEmployerActivities: Future[ List[ DomesticEmployerActivity ] ] = DomesticEmployerActivityDAO.findAll()

  /**
   * Retorna la actividad economica para la opcion de empleador domestico encontrada por su Id
   * @param id
   * @return
   */
  def getDomesticEmployerActivitiesById( id: String ): Future[ Option[ DomesticEmployerActivity ] ] = DomesticEmployerActivityDAO.findById( BSONObjectID( id ) )

  /**
   * Actualiza la actividad econímica de un empleador domestico
   * @param id
   * @param code
   * @param description
   * @return
   */
  def updateDomesticEmployerActivity( id: String, code: String, description: String, name: String ): Future[ LastError ] = {
    DomesticEmployerActivityDAO.updateById(
      BSONObjectID( id ),
      $set(
        "code" -> BSONString( code ),
        "description" -> BSONString( description ),
        "name" -> BSONString( name )
      )
    )
  }

  /**
   * Borra la actividad economica
   * @param id
   * @return
   */
  def deleteDomesticEmployerActivity( id: String ): Future[ LastError ] = DomesticEmployerActivityDAO.removeById( BSONObjectID( id ) )

  /**
   * Crea una nueva actividad economica para un empleador domestico
   * @param domesticActivity
   * @return
   */
  def createDomesticEmployerActivity( domesticActivity: DomesticEmployerActivity ): Future[ LastError ] = DomesticEmployerActivityDAO.insert( domesticActivity )

}

/**
 * Companion object para la clase ActivitiesManager
 */
object ActivitiesManager {
  def apply() = new ActivitiesManager
}