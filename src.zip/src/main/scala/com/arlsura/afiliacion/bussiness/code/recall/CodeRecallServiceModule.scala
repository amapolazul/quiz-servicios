package com.arlsura.afiliacion.bussiness.code.recall

import com.arlsura.afiliacion.bussiness.affiliation.PreaffiliationManager
import com.arlsura.afiliacion.persistence.daos.wrappers.{ PreAffiliationWrapper, SecurityCodeWrapper }
import com.google.inject.AbstractModule
import net.codingwell.scalaguice.ScalaModule

/**
 * Created by Jesús Martínez on 2/06/15.
 */
class CodeRecallServiceModule extends AbstractModule with ScalaModule {
  override def configure(): Unit = {
    bind[ SecurityCodeWrapper ]
    bind[ PreAffiliationWrapper ]
    bind[ SecurityManager ]
    bind[ PreaffiliationManager ]
    bind[ CodeRecallRepository ]
  }
}
