package com.arlsura.afiliacion.bussiness.affiliation.workcenters

import java.util.Date
import com.arlsura.afiliacion.bussiness.HandlerSupport
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.{ SaveWorkCentersData, GeneralJsonResponseData }
import com.arlsura.afiliacion.utils.Utils
import com.arlsura.afiliacion.utils.messages.MessagesRetriever
import com.arlsura.afiliacion.bussiness.affiliation.workcenters.WorkCentersDataServiceHandler._
import com.google.inject.Inject
import scala.concurrent.{ ExecutionContext, Future }

/**
 * Created by Jesús Martínez on 6/05/15.
 * @param repo [Dependencia] Repositorio utilizado para interactuar con la capa de persistencia.
 */
class WorkCentersDataServiceHandler @Inject() ( private val repo: WorkCentersDataRepository ) {
  import HandlerSupport._

  /**
   * Obtiene el documento asociado al DNI ingresado y retorna la respuesta apropaida para completar la solicitud.
   * @param dni DNI que identifica
   * @return Resultado de la operación (Right con una respuesta afirmativa y el documento; Left con una respuesta de error)
   */
  def retrieveWorkCenters( dni: String )( implicit ec: ExecutionContext ): Future[ ServiceHandlerResponse ] = {
    repo.findByDni( dni ) map {
      option =>
        val payload = option.map {
          r =>
            GeneralJsonResponseData( retrieveWorkCentersSuccessMessage, suraSessionManager = getSessionString( dni ), data = Some( r ) )
        } getOrElse {
          GeneralJsonResponseData( noWorkCentersSuccessMessage, suraSessionManager = getSessionString( dni ) )
        }
        Right( payload )
    } recover {
      case e: Throwable =>
        Left( errorOccurredMessage( e.toString ) )
    }
  }

  /**
   * Guarda la información de centros de trabajo en base de datos, bien sea creando un nuevo documento o
   * actualizando uno ya existente.
   * @param request Información a ser guardada.
   * @return Resultado de la operación (Right con una respuesta afirmativa y el documento; Left con una respuesta de error)
   */
  def saveWorkCenters( request: SaveWorkCentersData )( implicit ec: ExecutionContext ): Future[ ServiceHandlerResponse ] = {
    repo.createOrUpdate( request.dni, request.securityCode, request.workCenters ) map {
      status =>
        if ( status.ok )
          Right {
            GeneralJsonResponseData( message = saveWorkCentersSuccessMessage, suraSessionManager = getSessionString( request.dni ) )
          }
        else
          Left {
            errorOccurredMessage( status.errMsg.getOrElse( "MongoDB-Error" ) )
          }
    } recover {
      case e: Throwable =>
        Left( errorOccurredMessage( e.toString ) )
    }
  }

  /**
   * Genera una cadena de caracteres de sesión con base en el DNI.
   * @param dni DNI usado para generar la cadena.
   * @return
   */
  private def getSessionString( dni: String ): Option[ String ] = {
    val d = s"$dni-${new Date().getTime.toString}"
    Some( Utils.encodeFile( d.getBytes ) )
  }
}

private object WorkCentersDataServiceHandler {
  //mensajes de error y de exito para las respuestas
  val retrieveWorkCentersSuccessMessage: String = MessagesRetriever.getSuccessMessage( "affiliation.work_centers", "RETRIEVE" )
  val noWorkCentersSuccessMessage: String = MessagesRetriever.getSuccessMessage( "affiliation.work_centers", "NO_WORK_CENTERS" )
  val saveWorkCentersSuccessMessage: String = MessagesRetriever.getSuccessMessage( "affiliation.work_centers", "SAVE" )
  def errorOccurredMessage( error: String ): String = s"Ocurrió un error: $error"
}
