package com.arlsura.afiliacion.bussiness.occupational_health

import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.CreateOHvsRUTRecordRequest
import com.arlsura.afiliacion.persistence.daos.OccupationalHealthRUTSummaryDAO
import com.arlsura.afiliacion.persistence.entities.OccupationalHealthRUTSummary
import com.arlsura.afiliacion.utils.Utils

import scala.concurrent.ExecutionContext.Implicits.global

/**
 * Created by juanmartinez on 4/02/15.
 */
class OccupationalHealthManager {

  /**
   *
   * @param request
   * @return
   */
  def createOccupationalHealthActivity( request: CreateOHvsRUTRecordRequest ) = {
    val entity: OccupationalHealthRUTSummary = getOccupationalHealthEntity( request )
    OccupationalHealthRUTSummaryDAO.insert( entity )
  }

  /**
   * Transorma la entidad
   * @param request
   * @return
   */
  private def getOccupationalHealthEntity( request: CreateOHvsRUTRecordRequest ): OccupationalHealthRUTSummary = {
    OccupationalHealthRUTSummary(
      rutStartDate = Utils.stringToDate( request.rutStartDate ),
      rutExpirationDate = Utils.stringToDate( request.rutExpirationDate ),
      CIIUActivityCode = request.CIIUActivityCode,
      OHActivityCode = request.OHActivityCode,
      quotationRate = request.quotationRate,
      description = request.description
    )
  }

}
