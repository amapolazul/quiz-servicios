package com.arlsura.afiliacion.bussiness.arp

import akka.actor.{ ActorSelection, ActorRef }
import akka.pattern.{ AskableActorSelection, AskableActorRef, ask }
import com.arlsura.afiliacion.actors.cache.CacheRefresherActor
import com.arlsura.afiliacion.bussiness.RequestContextSupport
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.GeneralJsonResponseData
import com.arlsura.afiliacion.utils.GlobalParamsProvider
import spray.http.StatusCodes
import spray.routing.RequestContext
import scala.concurrent.ExecutionContext
import scala.util.{ Failure, Success }

/**
 * Clase encargada de interactuar con el servicio ARPFacadeWSImpl expuesto en venta información de sura
 * Created by juanmartinez on 20/11/14.
 */
class ARPServiceHandler( context: RequestContext, cacheActor: ActorSelection )( implicit ec: ExecutionContext ) extends RequestContextSupport with GlobalParamsProvider {

  def retrieveARPsCatalog(): Unit = {
    getAllARPs onComplete {
      case Success( list ) =>
        val response = GeneralJsonResponseData( "Respuesta exitosa", Some( list ) )
        complete( context, StatusCodes.OK, response )
      case Failure( e ) =>
        completeWithFailure( context, e.toString )
    }
  }
  /**
   * Retorna todas las ARPS dentro del sistema de SURA
   * @return
   */
  //def getAllArps: Array[Arpdto] = arpConsumer.getArps
  private def getAllARPs = {
    val askableActor = new AskableActorSelection( cacheActor )
    val ask = ( askableActor ? CacheRefresherActor.GetARPsCatalog ).mapTo[ CacheRefresherActor.ARPsCatalogReturned ]
    ask.map( _.catalog )
  }
}
