package com.arlsura.afiliacion.bussiness.code

/**
 * Clase para manejar las tres fuentes de generacion de los codigos
 * Created by root on 26/11/14.
 */
object CodeSourceIdentifiers {

  /**
   * Usado cuando el codigo lo genera el cliente al entrar al portal
   */
  val STANDARD = "S"

  /**
   * Usado cuando el codigo lo genera un asesor comercial
   */
  val COMMERCIAL = "C"

  /**
   * Usuado cuando el codigo se genera desde las oficinas
   */
  val OFFICES = "O"

}
