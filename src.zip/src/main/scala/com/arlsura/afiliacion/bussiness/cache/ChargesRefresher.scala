package com.arlsura.afiliacion.bussiness.cache

import java.sql.{ ResultSet, Connection, DriverManager }

import com.arlsura.afiliacion.persistence.cache.entities.ChargeCache
import com.arlsura.afiliacion.utils.Utils

/**
 * Created by Jesús Martínez on 26/08/15.
 */
object ChargesRefresher {

  private val URL = Utils.getProperty( "persistence.atep.", "jdbc_url" ).asInstanceOf[ String ]
  private val USERNAME = Utils.getProperty( "persistence.atep.", "username" ).asInstanceOf[ String ]
  private val PASSWORD = Utils.getProperty( "persistence.atep.", "password" ).asInstanceOf[ String ]
  private val QUERY = Utils.getProperty( "persistence.atep.", "retrieve_all_charges_query" ).asInstanceOf[ String ]
  private var connection: Connection = _

  private def initConnection(): Unit = connection = DriverManager.getConnection( URL, USERNAME, PASSWORD )
  private def closeConnection(): Unit = connection.close()
  private def obtainResultSet: ResultSet = connection.createStatement().executeQuery( QUERY )

  def refresh: Seq[ ChargeCache ] = {
    initConnection()
    val resultSet = obtainResultSet
    var results = List.empty[ ChargeCache ]

    while ( resultSet.next() )
      results = ChargeCache( resultSet.getInt( "CDCARGO" ), resultSet.getString( "DSCARGO" ), resultSet.getString( "CDTIPO" ) ) :: results

    closeConnection()
    results
  }
}
