package com.arlsura.afiliacion.bussiness.cache

import co.com.sura.ventainformacion.service
import co.com.sura.ventainformacion.service.{ PaisDTO, PostalDTO, ProvinciaDTO }
import com.arlsura.afiliacion.bussiness.cache.CustomAddressTypes.{ CountryData, ProvinceData }
import com.arlsura.afiliacion.bussiness.postal.PostalManager
import com.arlsura.afiliacion.persistence.cache.entities.{ MunicipalityElement, ProvinceElement, AddressCache }
import com.arlsura.afiliacion.utils.Utils
import com.sura.arl.serviciopaises.consumer.CountriesServiceConsumer
import com.sura.arl.servicioprovincias.consumer.ProvinceServiceConsumer

/**
 * Created by Jesús Martínez on 24/04/15.
 */
object AddressesRefresher extends CacheLoader[ CountryData, AddressCache ] {
  private lazy val countriesServiceURL = Utils.getProperty( "soap.services.", "countries" ).asInstanceOf[ String ]
  private lazy val provincesServiceURL = Utils.getProperty( "soap.services.", "provinces" ).asInstanceOf[ String ]
  private lazy val countriesServiceConsumer = new CountriesServiceConsumer( this.username, this.password, "123", countriesServiceURL )
  private lazy val provincesServiceConsumer = new ProvinceServiceConsumer( this.username, this.password, "123", provincesServiceURL )

  private def getProvinces( countryCode: Int ) = {
    provincesServiceConsumer.authenticateToProxy( this.cloudProxyHost, this.cloudProxyPort, this.cloudProxyUser, this.cloudProxyPassword )
    val result: Array[ ProvinciaDTO ] = provincesServiceConsumer.consultarProvinciasPorPais( countryCode )

    if ( result == null ) List( new service.ProvinciaDTO( "", "", "", "", null ) ) else result.toList
  }

  /**
   * @return Colección de datos provenientes del servicio exterior.
   */
  override def consumeService(): Option[ Seq[ CountryData ] ] = {
    //    logger.debug( s"COUNTRIES SERVICE URL: $countriesServiceURL" )
    //    logger.debug( s"PROVINCES SERVICE URL: $provincesServiceURL" )
    countriesServiceConsumer.authenticateToProxy( this.cloudProxyHost, this.cloudProxyPort, this.cloudProxyUser, this.cloudProxyPassword )
    val countries = countriesServiceConsumer.consultarPaises()

    if ( countries != null && countries.length > 0 ) {
      val countriesSeq = countries.toSeq.filter( _.getCodigoPais == "57" )

      //TODO Descomentar esta línea cuando sea imperante contar con información de otros países distintos a Colombia.
      //val countriesSeq = countries.toSeq
      val countriesData: Seq[ CountryData ] = for ( c <- countriesSeq ) yield {
        val provinces = getProvinces( c.getCodigoPais.toInt )

        val provincesData: List[ ProvinceData ] = for ( p <- provinces ) yield {
          val municipalities: List[ PostalDTO ] = if ( c.getCodigoPais == "57" ) PostalManager.getSettlements( p.getCodigoProvincia, p.getCodigoDelegacion ) else List( new PostalDTO( "", "", "", "", null, null, -1, null, "" ) )
          ( p, municipalities )
        }
        ( c, provincesData )
      }
      Some( countriesData )
    }
    else None
  }

  /**
   * @param data Colección de datos "crudos" provenientes del servicio de terceros.
   * @return Colección de documentos que serán almacenados en Mongo.
   */
  override def prepareData( data: Seq[ CountryData ] ): Seq[ AddressCache ] = {
    def parseProvince( province: ProvinceData ): ProvinceElement = province match {
      case ( p, municipalities ) =>
        ProvinceElement(
          delegationCode = p.getCodigoDelegacion,
          provinceCode = p.getCodigoProvincia,
          zoneCode = p.getCodigoZona,
          provinceName = p.getNombreProvincia,
          municipalities = municipalities.map( m => MunicipalityElement( m.getPoblacion, m.getDelegacion.getCodigoDelegacion, m.getDepartamento.getCodigoProvincia, m.getCodigoMunicipio ) )
        )
    }

    for ( cd <- data ) yield {
      cd match {
        case ( country, provinces ) =>
          val ps = provinces.map( parseProvince )
          AddressCache( countryName = country.getNombrePais, countryCode = country.getCodigoPais.toInt, provinces = ps )
      }
    }
  }
}

/**
 * Alias para tipos de datos usados frecuentemente en el AddressesRefresher
 */
object CustomAddressTypes {
  type ProvinceData = ( ProvinciaDTO, List[ PostalDTO ] )
  type CountryData = ( PaisDTO, List[ ProvinceData ] )
}