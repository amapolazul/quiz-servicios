package com.arlsura.afiliacion.bussiness.segmentation

import com.arlsura.afiliacion.bussiness.RequestContextSupport
import com.arlsura.afiliacion.bussiness.segmentation.SegmentationServiceHandler._
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller._
import com.arlsura.afiliacion.persistence.daos.SegmentationRulesDAO
import com.arlsura.afiliacion.persistence.entities.SegmentationRules
import com.arlsura.afiliacion.utils.messages.MessagesRetriever
import reactivemongo.bson.BSONObjectID
import spray.http.StatusCodes
import spray.routing.RequestContext

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future
import scala.util.{ Failure, Success }

/**
 * clase encargada de realizar los procesos de segmentacion
 * Contiene la relacion de todos los metodos GET,POST,DELETE,PUT de
 * la interfaz de servicio de segmentacion
 *
 * Created by juanmartinez on 03/02/15.
 */
class SegmentationServiceHandler( ctx: RequestContext ) extends RequestContextSupport {
  lazy val segmentationManager: SegmentationManager = new SegmentationManager

  /**
   * Crea una regla de segmentación
   * @param segEntityRequest
   */
  def createSegmentationRule( segEntityRequest: SegmentationEntityRequest ) = {
    val segEntity: SegmentationRules = SegmentationManager.getSegmentationDataBaseEntity( segEntityRequest )
    val existSegmentationRule: Future[ List[ SegmentationRules ] ] = segmentationManager.getSegmentationRules( segEntity.ciiu, segEntity.city )

    existSegmentationRule onComplete {
      case Success( segRules ) =>
        if ( segRules.isEmpty )
          segmentationManager.saveSegmentationRule( segEntity ) onComplete {
            case Success( e ) =>
              val response: GeneralJsonResponseData = GeneralJsonResponseData( createSegmentationRuleMessage )
              this.complete( ctx, StatusCodes.OK, response )
            case Failure( ex ) =>
              this.completeWithFailure( ctx, s"${RequestContextSupport.internalServerErrorMessage} ${ex.getMessage}" )
          }
        else {
          this.completeWithConflict( ctx, segmentationRuleAlreadyExistMessage )
        }
      case Failure( ex ) =>
        this.completeWithFailure( ctx, s"${RequestContextSupport.internalServerErrorMessage} ${ex.getMessage}" )
    }
  }

  /**
   * Borra una regla se segmentacion por su identificador
   */
  def deleteSegmentationRule( segRuleId: String ): Unit = {
    val segmentationRule: Future[ Option[ SegmentationRules ] ] = SegmentationRulesDAO.findById( BSONObjectID( segRuleId ) )
    segmentationRule onComplete {
      case Success( segRule ) =>
        segRule match {
          case Some( ex: SegmentationRules ) =>
            segmentationManager.deleteSegmentationRule( BSONObjectID( segRuleId ) ) onComplete {
              case Success( e ) =>
                val generalJsonResponse: GeneralJsonResponseData = GeneralJsonResponseData( deletedSegmentationRuleMessage )
                this.complete( ctx, StatusCodes.OK, generalJsonResponse )

              case Failure( ex ) =>
                this.completeWithFailure( ctx, s"${RequestContextSupport.internalServerErrorMessage} ${ex.getMessage}" )
            }

          case None =>
            this.completeWithNotFound( ctx, segmentationRuleNotFoundMessage )
        }

      case Failure( ex ) =>
        this.completeWithFailure( ctx, s"${RequestContextSupport.internalServerErrorMessage} ${ex.getMessage}" )
    }
  }

  /**
   * Consulta todas las reglas de segmentacion
   */
  def getAllSegmentationRules() = {
    segmentationManager.getSegmentationRules() onComplete {
      case Success( segResults ) =>
        val mappedValues: List[ SegmentationEntityResponse ] =
          for ( segRule <- segResults )
            yield SegmentationEntityResponse(
            ciiu = segRule.ciiu,
            city = segRule.city,
            num_workers = segRule.num_workers,
            operator = segRule.operator,
            id = Some( segRule._id.stringify )
          )

        val generalJsonResponse: GeneralJsonResponseData = GeneralJsonResponseData(
          getSegmentationRulesMessage,
          Some( SegmentationRulesResponse( mappedValues ) )
        )
        this.complete( ctx, StatusCodes.OK, generalJsonResponse )

      case Failure( ex ) =>
        this.completeWithFailure( ctx, s"${RequestContextSupport.internalServerErrorMessage} ${ex.getMessage}" )
    }
  }

  /**
   * Trae las reglas de segmentación por ciudad o por codigo ciiu
   */
  def getSegmentationRules( ciiu: Option[ String ], city: Option[ String ] ) = {
    ( ciiu, city ) match {
      case ( Some( ci ), Some( ct ) ) =>
        val segRulesFuture: Future[ List[ SegmentationRules ] ] = segmentationManager.getSegmentationRules( ciiu = ci, city = ct )
        processSegmentationResponse( segRulesFuture )
      case ( Some( ci ), None ) =>
        val segRulesFuture: Future[ List[ SegmentationRules ] ] = segmentationManager.getSegmentationRules( ciiu = ci )
        processSegmentationResponse( segRulesFuture )
      case ( None, Some( ct ) ) =>
        val segRulesFuture: Future[ List[ SegmentationRules ] ] = segmentationManager.getSegmentationRules( city = ct )
        processSegmentationResponse( segRulesFuture )
      case ( None, None ) =>
        val segRulesFuture: Future[ List[ SegmentationRules ] ] = segmentationManager.getSegmentationRules()
        processSegmentationResponse( segRulesFuture )

    }
  }

  /**
   * trae una regla de segmentacion por su Id correspondiente
   */
  def getSegmentationRuleById( id: String ) = {
    val segmentationRule: Future[ Option[ SegmentationRules ] ] = SegmentationRulesDAO.findById( BSONObjectID( id ) )
    segmentationRule onComplete {
      case Success( segRule ) =>
        segRule match {
          case Some( e ) =>
            val segEntity: SegmentationEntityResponse = SegmentationEntityResponse(
              ciiu = e.ciiu,
              city = e.city,
              id = Some( e._id.stringify ),
              num_workers = e.num_workers,
              operator = e.operator
            )
            val generalJsonResponse: GeneralJsonResponseData = GeneralJsonResponseData(
              getSegmentationRuleMessage,
              Some( segEntity )
            )
            this.complete( ctx, StatusCodes.OK, generalJsonResponse )

          case None =>
            this.completeWithNotFound( ctx, segmentationRuleNotFoundMessage )
        }

      case Failure( ex ) =>
        this.completeWithFailure( ctx, s"${RequestContextSupport.internalServerErrorMessage} ${ex.getMessage}" )
    }
  }

  /**
   * Actualiza la regla de segmentación
   * @param segId
   * @param segEntity
   */
  def updateSegmentationRule( segId: String, segEntity: SegmentationEntityRequest ): Unit = {
    val segEnt: SegmentationRules = SegmentationRules(
      ciiu = segEntity.ciiu,
      city = segEntity.city,
      operator = segEntity.operator,
      num_workers = segEntity.num_workers
    )

    segmentationManager.findSegmentationById( BSONObjectID( segId ) ) onComplete {
      case Success( segRule ) =>
        segRule match {
          case Some( e ) =>
            segmentationManager.updateSegmentationRule( BSONObjectID( segId ), segEnt ) onComplete {
              case Success( up ) =>
                val generalJsonResponse: GeneralJsonResponseData = GeneralJsonResponseData(
                  updateSegmentationRuleMessage,
                  Some( segEntity )
                )
                this.complete( ctx, StatusCodes.OK, generalJsonResponse )
              case Failure( ex ) =>
                this.completeWithFailure( ctx, s"${RequestContextSupport.internalServerErrorMessage} ${ex.getMessage}" )
            }
          case None =>
            this.completeWithNotFound( ctx, segmentationRuleNotFoundMessage )
        }

      case Failure( ex ) =>
        this.completeWithFailure( ctx, s"${RequestContextSupport.internalServerErrorMessage} ${ex.getMessage}" )
    }
  }

  /**
   * Devuelve todos los operadores definidos para las reglas
   */
  def getAllSegmentationOperators() = {
    val operatorsList: Iterable[ SegmentationOperator ] = SegmentationManager.getAvailableOperators().map(
      operator =>
        SegmentationOperator( operator._1, operator._2 )
    )
    val operatorsResponse = SegmentationOperators( operatorsList.toList )
    val generalJsonResponse: GeneralJsonResponseData = GeneralJsonResponseData(
      segmentationOperatorsMessage,
      Some( operatorsResponse )
    )
    this.complete( ctx, StatusCodes.OK, generalJsonResponse )
  }

  /**
   * Procesa los resultados de buscar reglas de segmentación basadas en los filtros anteriores
   * @param segRulesFuture
   */
  private def processSegmentationResponse( segRulesFuture: Future[ List[ SegmentationRules ] ] ): Unit = {
    segRulesFuture onComplete {
      case Success( segResults ) =>
        val mappedValues: List[ SegmentationEntityResponse ] =
          for ( segRule <- segResults )
            yield SegmentationEntityResponse(
            ciiu = segRule.ciiu,
            city = segRule.city,
            num_workers = segRule.num_workers,
            operator = segRule.operator,
            id = Some( segRule._id.stringify )
          )

        val generalJsonResponse: GeneralJsonResponseData = GeneralJsonResponseData(
          deletedSegmentationRuleMessage,
          Some( SegmentationRulesResponse( mappedValues ) )
        )

        this.complete( ctx, StatusCodes.OK, generalJsonResponse )
      case Failure( ex ) =>
        this.completeWithFailure( ctx, s"${RequestContextSupport.internalServerErrorMessage} ${ex.getMessage}" )
    }
  }

}

object SegmentationServiceHandler {

  def createSegmentationRuleMessage = MessagesRetriever.getSuccessMessage( "segmentation", "SEGMENTATION_CREATED_SUCCESS" )

  def updateSegmentationRuleMessage = MessagesRetriever.getSuccessMessage( "segmentation", "SEGMENTATION_UPDATED_SUCCESS" )

  def deletedSegmentationRuleMessage = MessagesRetriever.getSuccessMessage( "segmentation", "SEGMENTATION_DELETED_SUCCESS" )

  def getSegmentationRuleMessage = MessagesRetriever.getSuccessMessage( "segmentation", "SEGMENTATION_GET_ONE_SUCCESS" )

  def getSegmentationRulesMessage = MessagesRetriever.getSuccessMessage( "segmentation", "SEGMENTATION_GET_ALL_SUCCESS" )

  def segmentationRuleAlreadyExistMessage = MessagesRetriever.getErrorMessage( "segmentation", "SEGMENTATION_RULE_EXIST_ERROR" )

  def segmentationRuleNotFoundMessage = MessagesRetriever.getErrorMessage( "segmentation", "SEGMENTATION_RULE_NOT_FOUND_ERROR" )

  def segmentationOperatorsMessage = MessagesRetriever.getSuccessMessage( "segmentation.operators", "OPERATORS_GET_ALL_SUCCESS" )

}
