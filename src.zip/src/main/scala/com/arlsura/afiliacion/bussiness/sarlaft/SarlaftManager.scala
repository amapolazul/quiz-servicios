package com.arlsura.afiliacion.bussiness.sarlaft

import com.arlsura.afiliacion.bussiness.SoapConsumerSupport
import com.arlsura.afiliacion.utils.Utils
import com.suramericana.serviciosarlaft.consumer.SarlaftServiceConsumer

/**
 * Created by Jesús Martínez on 27/02/15.
 */
object SarlaftManager extends SoapConsumerSupport {

  //URL del servicio.
  private val url = Utils.getProperty( "soap.services.", "sarlaft" ).asInstanceOf[ String ]
  private val consumer = new SarlaftServiceConsumer( this.username, this.password, "1234,", this.url )

  /**
   * Consulta los riesgos morales asociados a un cliente.
   * @param idType Tipo del número de identificación del cliente.
   * @param idNumber Número de identificación del cliente.
   * @return Tupla donde el primer valor indica si hay riesgo moral (true/false) y el segundo
   *         si existe riesgo moral grave (true/false).
   */
  def consultRisk( idType: String, idNumber: String ): ( Boolean, Boolean ) = {
    consumer.authenticateToProxy( this.cloudProxyHost, this.cloudProxyPort, this.cloudProxyUser, this.cloudProxyPassword )
    val response = consumer.consultarRiesgoMoral( idType, idNumber ).getRiesgo
    ( response.getRiesgoMoral.booleanValue(), response.getRiesgoMoralGrave.booleanValue() )
  }
}
