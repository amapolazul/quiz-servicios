package com.arlsura.afiliacion.bussiness.cache

import co.com.sura.ventainformacion.service.NaturalezaJuridicaDTO

//import co.com.sura.ventainformacion.service.consumer.LegalNatureConsumerService
import co.com.sura.ventainformacion.service.EmpresaAfiliacionesFacadeWSInterfaceProxy
import com.arlsura.afiliacion.persistence.cache.entities.LegalNaturesCache
import com.arlsura.afiliacion.utils.Utils

/**
 * Created by Jorge Vargas on 26/05/15.
 */
object LegalNatureSoapRefresher extends CacheLoader[ NaturalezaJuridicaDTO, LegalNaturesCache ] {
  private lazy val naturesServiceUrl = Utils.getProperty( "soap.services.", "natures" ).asInstanceOf[ String ]
  private lazy val legalNaturesConsumer = new EmpresaAfiliacionesFacadeWSInterfaceProxy( naturesServiceUrl, this.username, this.password )
  //new ARPConsumerService( this.username, this.password, "123", arpServiceUrl )

  /**
   * @return Colección de datos provenientes del servicio exterior.
   */
  override def consumeService(): Option[ Seq[ NaturalezaJuridicaDTO ] ] = {
    //    logger.debug( s"NATURES SERVICE URL: $naturesServiceUrl" )
    legalNaturesConsumer.authenticateToProxy( this.cloudProxyHost, this.cloudProxyPort, this.cloudProxyUser, this.cloudProxyPassword )
    val result = legalNaturesConsumer.consultarNaturalezaJuridica
    if ( result != null && result.length > 0 ) Some( result.toSeq ) else None
  }

  /**
   * @param data Colección de datos "crudos" provenientes del servicio de terceros.
   * @return Colección de documentos que serán almacenados en Mongo.
   */
  override def prepareData( data: Seq[ NaturalezaJuridicaDTO ] ): Seq[ LegalNaturesCache ] =
    for ( a <- data ) yield LegalNaturesCache( code = a.getCdNaturalezaJuridica, description = a.getDsNaturaleza, officialEntityCode = "0", dni = "" )
}
