package com.arlsura.afiliacion.bussiness.cache

import co.com.sura.ventainformacion.service.Afpdto
import com.arlsura.afiliacion.persistence.cache.entities.AFPCache
import com.arlsura.afiliacion.utils.Utils
import com.suramericana.servicioafp.AFPServiceConsumer

/**
 * Created by Jesús Martínez on 24/04/15.
 */
object AFPRefresher extends CacheLoader[ Afpdto, AFPCache ] {
  private lazy val afpServiceUrl = Utils.getProperty( "soap.services.", "afp" ).asInstanceOf[ String ]
  private lazy val afpServiceConsumer = new AFPServiceConsumer( this.username, this.password, "1", afpServiceUrl )

  /**
   * @return Colección de datos provenientes del servicio exterior.
   */
  override def consumeService(): Option[ Seq[ Afpdto ] ] = {
    //    logger.debug( s"AFP SERVICE URL: $afpServiceUrl" )
    afpServiceConsumer.authenticateToProxy( this.cloudProxyHost, this.cloudProxyPort, this.cloudProxyUser, this.cloudProxyPassword )
    val results = afpServiceConsumer.consultarAFP()
    if ( results != null && results.length > 0 ) Some( results.toSeq ) else None
  }

  /**
   * @param data Colección de datos "crudos" provenientes del servicio de terceros.
   * @return Colección de documentos que serán almacenados en Mongo.
   */
  override def prepareData( data: Seq[ Afpdto ] ): Seq[ AFPCache ] =
    for ( a <- data ) yield AFPCache( code = Utils.replaceNullIfAny( a.getCodigoAfp ), dni = Utils.replaceNullIfAny( a.getDni ), ministryCode = Utils.replaceNullIfAny( a.getDsCodigoMinisterio ), name = Utils.replaceNullIfAny( a.getDsNombre ) )
}
