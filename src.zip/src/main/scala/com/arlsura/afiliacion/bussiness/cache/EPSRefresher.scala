package com.arlsura.afiliacion.bussiness.cache

import co.com.sura.ventainformacion.service.Epsdto
import com.arlsura.afiliacion.persistence.cache.entities.EPSCache
import com.arlsura.afiliacion.utils.Utils._
import com.suramericana.servicioeps.consumer.EPSServiceConsumer

/**
 * Created by Jesús Martínez on 24/04/15.
 */
object EPSRefresher extends CacheLoader[ Epsdto, EPSCache ] {
  private lazy val epsServiceUrl = getProperty( "soap.services.", "eps" ).asInstanceOf[ String ]
  private lazy val epsServiceConsumer = new EPSServiceConsumer( this.username, this.password, "1", epsServiceUrl )

  /**
   * @return Colección de datos provenientes del servicio exterior.
   */
  override def consumeService(): Option[ Seq[ Epsdto ] ] = {
    //    logger.debug( s"EPS SERVICE URL: $epsServiceUrl" )
    epsServiceConsumer.authenticateToProxy( this.cloudProxyHost, this.cloudProxyPort, this.cloudProxyUser, this.cloudProxyPassword )
    val results = epsServiceConsumer.consultarEPS()
    if ( results != null && results.length > 0 ) Some( results.toSeq ) else None
  }

  /**
   * @param data Colección de datos "crudos" provenientes del servicio de terceros.
   * @return Colección de documentos que serán almacenados en Mongo.
   */
  override def prepareData( data: Seq[ Epsdto ] ): Seq[ EPSCache ] =
    for ( e <- data ) yield EPSCache( code = replaceNullIfAny( e.getCodigoEps ), dni = replaceNullIfAny( e.getDni ), ministryCode = replaceNullIfAny( e.getDsCodigoMinisterio ), name = replaceNullIfAny( e.getDsNombre ) )
}
