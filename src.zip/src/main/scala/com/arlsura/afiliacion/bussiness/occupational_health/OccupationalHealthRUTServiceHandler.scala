package com.arlsura.afiliacion.bussiness.occupational_health

import com.arlsura.afiliacion.bussiness.RequestContextSupport
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.{ GeneralJsonResponseData, CreateOHvsRUTRecordRequest, ExceptionOccurred, UpdateOHvsRUTRecordRequest }
import com.arlsura.afiliacion.persistence.daos.OccupationalHealthRUTSummaryDAO
import com.arlsura.afiliacion.persistence.entities.OccupationalHealthRUTSummary
import com.arlsura.afiliacion.utils.Utils
import com.arlsura.afiliacion.utils.messages.MessagesRetriever
import com.typesafe.scalalogging.LazyLogging
import reactivemongo.bson.{ BSONDocument, BSONDouble, BSONObjectID }
import reactivemongo.core.commands.LastError
import reactivemongo.extensions.dao.Handlers._
import spray.http.StatusCodes
import spray.routing.RequestContext

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future
import scala.util.{ Failure, Success }

/**
 * Actor encargado de administrar y realizar las consultas sobre la tabla
 * de equivalencias entre RUT y actividades de salud ocupacional.
 * Created by root on 30/12/14.
 */
class OccupationalHealthRUTServiceHandler( ctx: RequestContext ) extends RequestContextSupport with LazyLogging {

  /**
   * Maneja la peticion para crear la actividad de salud ocupacional
   * @param request
   */
  def occupationalHealthRUTCreate( request: CreateOHvsRUTRecordRequest ) = {
    //    logger.debug( s"Creando actividad de salud ocupacional ${request.toString}" )
    val model: OccupationalHealthRUTSummary = OccupationalHealthRUTSummary(
      rutExpirationDate = Utils.stringToDate( request.rutExpirationDate ),
      rutStartDate = Utils.stringToDate( request.rutStartDate ),
      CIIUActivityCode = request.CIIUActivityCode,
      OHActivityCode = request.OHActivityCode,
      quotationRate = request.quotationRate,
      description = request.description
    )
    val operation: Future[ LastError ] = OccupationalHealthRUTSummaryDAO.insert( model )
    handleFutureOfNoResult( operation, OccupationalHealthRUTServiceHandler.occupationalHealthCreateMessage )
  }

  /**
   * Consulta todas las actividades de salud ocupacional
   */
  def occupationalHealthRUTServiceHandlerGetAll() = {
    //    logger.debug( s"Consultando todas las actividades de salud ocupacional" )
    val operation = OccupationalHealthRUTSummaryDAO.findAll()
    handleFutureOfMultipleResults( operation, OccupationalHealthRUTServiceHandler.occupationalHealthGetAllMessage )
  }

  /**
   * Consulta la actividad de salud ocupacional por una serie de parametros
   * @param ciiuCodeOption
   * @param ohCodeOption
   * @param expeditionDateOption
   */
  def occupationalHealthRUTServiceHandlerGetBy( ciiuCodeOption: Option[ String ], ohCodeOption: Option[ String ], expeditionDateOption: Option[ String ] ) = {
    //    logger.debug( s"Consultando la activadad de salud ocupacional por los parametros " +
    //      s"\n\tciiuCodeOption: ${ciiuCodeOption.getOrElse( "None" )}" +
    //      s"\n\tohCodeOption: ${ohCodeOption.getOrElse( "None" )}" )
    val query: BSONDocument = obtainDocument( ciiuCodeOption, ohCodeOption, expeditionDateOption )
    val operation: Future[ List[ OccupationalHealthRUTSummary ] ] = OccupationalHealthRUTSummaryDAO.findAll( query )
    handleFutureOfMultipleResults( operation, OccupationalHealthRUTServiceHandler.occupationalHealthGetAllMessage )
  }

  /**
   * Consulta la actividad de salud ocupacional por el identificador
   * @param id
   */
  def occupationalHealthRUTServiceHandlerGet( id: String ) = {
    //    logger.debug( s"Consultando actividad de salud ocupaciona por el Id: $id" )
    BSONObjectID.parse( id ) match {
      case Success( bsonId ) =>
        val operation = OccupationalHealthRUTSummaryDAO.findById( bsonId )
        handleFutureOfSingleResult( operation, OccupationalHealthRUTServiceHandler.occupationalHealthGetMessage )
      case Failure( ex ) =>
        this.completeWithFailure( ctx, s"${RequestContextSupport.internalServerErrorMessage} ${ex.getMessage}" )
    }
  }

  /**
   * Actualiza la actividad de salud ocupacional
   * @param r
   * @return
   */
  def occupationalHealthRUTServiceHandlerUpdate( r: UpdateOHvsRUTRecordRequest ) = {
    //    logger.debug( s"Realizando Update: \n\t id: ${r.id}" +
    //      s"\n\trutStartDate: ${r.rutStartDate.getOrElse( "None" )}" +
    //      s"\n\trutExpirationDate: ${r.rutExpirationDate.getOrElse( "None" )}" +
    //      s"\n\tCIIUActivityCode: ${r.CIIUActivityCode.getOrElse( "None" )}" +
    //      s"\n\tOHActivityCode: ${r.OHActivityCode.getOrElse( "None" )}" +
    //      s"\n\tquotationRate: ${r.quotationRate.getOrElse( "None" )}" +
    //      s"\n\tdescription: ${r.description.getOrElse( "None" )}" )
    BSONObjectID.parse( r.id ) match {
      case Success( bsonId ) =>
        val modifications = obtainDocument( r.rutStartDate, r.CIIUActivityCode, r.OHActivityCode, r.quotationRate, r.description )
        val operation = OccupationalHealthRUTSummaryDAO.updateById( bsonId, BSONDocument( "$set" -> modifications ) )
        handleFutureOfNoResult( operation, OccupationalHealthRUTServiceHandler.occupationalHealthUpdateMessage )
      case Failure( ex ) =>
        this.completeWithFailure( ctx, s"${RequestContextSupport.internalServerErrorMessage} ${ex.getMessage}" )
    }
  }

  /**
   * Borra todas las activades de salud ocupacional
   */
  def occupationalHealthRUTServiceHandlerDeleteAll() = {
    //    logger.debug( "realizando operacion deleteAll para actividades de salud ocupaccional" )
    val operation = OccupationalHealthRUTSummaryDAO.removeAll()
    handleFutureOfNoResult( operation, OccupationalHealthRUTServiceHandler.occupationalHealthDeleteMessage )
  }

  /**
   * Borra la actividad de salud ocupacional por una serie de parametros
   * @param ciiuCodeOption
   * @param ohCodeOption
   * @param expeditionDateOption
   */
  def occupationalHealthRUTServiceHandlerDeleteBy( ciiuCodeOption: Option[ String ], ohCodeOption: Option[ String ], expeditionDateOption: Option[ String ] ) = {
    //    logger.debug( s"Recibido mensaje DeleteBy: " +
    //      s"\n\tciiuCodeOption: ${ciiuCodeOption.getOrElse( "None" )}" +
    //      s"\n\tohCodeOption: ${ohCodeOption.getOrElse( "None" )}" )
    val query = obtainDocument( ciiuCodeOption, ohCodeOption, expeditionDateOption )
    val operation = OccupationalHealthRUTSummaryDAO.remove( query )
    handleFutureOfNoResult( operation, OccupationalHealthRUTServiceHandler.occupationalHealthDeleteMessage )
  }

  /**
   * Borra la actividad de salud ocupacional por una serie de parametros
   * @param id
   * @return
   */
  def occupationalHealthRUTServiceHandlerDelete( id: String ) = {
    //    logger.debug( s"Recibido mensaje Delete: $id" )
    BSONObjectID.parse( id ) match {
      case Success( bsonId ) =>
        val operation = OccupationalHealthRUTSummaryDAO.removeById( bsonId )
        handleFutureOfNoResult( operation, OccupationalHealthRUTServiceHandler.occupationalHealthDeleteMessage )
      case Failure( ex ) =>
        this.completeWithFailure( ctx, s"${RequestContextSupport.internalServerErrorMessage} ${ex.getMessage}" )
    }
  }

  /**
   *
   * @param r
   * @return
   */
  private def beautify( r: OccupationalHealthRUTSummary ): Map[ String, String ] = {
    Map(
      "id" -> r._id.stringify,
      "rutStartDate" -> Utils.dateFormatToString( r.rutStartDate ),
      "CIIUActivityCode" -> r.CIIUActivityCode,
      "OHActivityCode" -> r.OHActivityCode,
      "description" -> r.description,
      "quotationRate" -> r.quotationRate.toString
    )
  }

  /**
   * Toma un futuro y lo procesa dependiendo del resultado.
   * @param future Futuro a ser procesado.
   */
  private def handleFutureOfMultipleResults( future: Future[ List[ OccupationalHealthRUTSummary ] ], message: String ): Unit = {
    future onComplete {
      case Success( rs ) =>
        //        logger.debug( s"Procesando informacion de actividades de salud ocupacional correctamente $message" )
        val response = GeneralJsonResponseData(
          message,
          Some( rs.map( beautify ) )
        )
        this.complete( ctx, StatusCodes.OK, response )
      case Failure( ex ) =>
        this.completeWithFailure( ctx, s"${RequestContextSupport.internalServerErrorMessage} ${ex.getMessage}" )
    }
  }

  /**
   *
   * @param future
   * @param message
   */
  private def handleFutureOfSingleResult( future: Future[ Option[ OccupationalHealthRUTSummary ] ], message: String ): Unit = {
    future onComplete {
      case Success( rs ) =>
        //        logger.debug( s"Procesando informacion de actividades de salud ocupacional correctamente $message" )
        val response = GeneralJsonResponseData(
          message,
          Some( rs.map( beautify ) )
        )
        this.complete( ctx, StatusCodes.OK, response )
      case Failure( ex ) =>
        this.completeWithFailure( ctx, s"${RequestContextSupport.internalServerErrorMessage} ${ex.getMessage}" )
    }
  }

  /**
   * Maneja los futuros de las operaciones que no devuelven resultados
   * @param future
   * @param message mensaje en caso de que la operacion sea exitosa
   */
  private def handleFutureOfNoResult( future: Future[ LastError ], message: String ): Unit = {
    future onComplete {
      case Failure( ex ) =>
        this.completeWithFailure( ctx, s"${RequestContextSupport.internalServerErrorMessage} ${ex.getMessage}" )
      case Success( t ) =>
        if ( t.ok ) {
          val response = GeneralJsonResponseData( message )
          this.complete( ctx, StatusCodes.OK, response )
        }
        else this.completeWithFailure( ctx, s"${RequestContextSupport.internalServerErrorMessage}" )
    }
  }

  /**
   *
   * @param ciiuCodeOption
   * @param ohCodeOption
   * @param expeditionDate
   * @return
   */
  private def obtainDocument( ciiuCodeOption: Option[ String ], ohCodeOption: Option[ String ], expeditionDate: Option[ String ] ) = {
    var query = BSONDocument()

    ciiuCodeOption match {
      case Some( code ) => query = query ++ BSONDocument( "CIIUActivityCode" -> code )
      case None         =>
    }

    ohCodeOption match {
      case Some( code ) => query = query ++ BSONDocument( "OHActivityCode" -> code )
      case None         =>
    }

    expeditionDate match {
      case Some( date ) =>
        val formattedDate = Utils.stringToDate( date )
        query = query ++ BSONDocument(
          "rutStartDate" -> BSONDocument( "$lte" -> formattedDate ),
          "rutExpirationDate" -> BSONDocument( "$gte" -> formattedDate )
        )
      case None =>
    }

    query
  }

  /**
   *
   * @param rutStartDate
   * @param ciiuCodeOption
   * @param ohCodeOption
   * @param quotationRate
   * @param description
   * @return
   */
  private def obtainDocument( rutStartDate: Option[ String ], ciiuCodeOption: Option[ String ], ohCodeOption: Option[ String ], quotationRate: Option[ Double ], description: Option[ String ] ) = {
    var query = BSONDocument()

    ciiuCodeOption match {
      case Some( code ) => query = query ++ BSONDocument( "CIIUActivityCode" -> code )
      case None         =>
    }

    ohCodeOption match {
      case Some( code ) => query = query ++ BSONDocument( "OHActivityCode" -> code )
      case None         =>
    }

    description match {
      case Some( d ) => query = query ++ BSONDocument( "description" -> d )
      case None      =>
    }

    quotationRate match {
      case Some( r ) => query = query ++ BSONDocument( "quotationRate" -> BSONDouble( r ) )
      case None      =>
    }

    rutStartDate match {
      case Some( d ) => query = query ++ BSONDocument( "rutStartDate" -> Utils.stringToDate( d ) )
      case None      =>
    }

    query
  }
}

/**
 * Companion object del actor.
 */
object OccupationalHealthRUTServiceHandler {

  def occupationalHealthCreateMessage: String = MessagesRetriever.getSuccessMessage( "occupational_health", "OCCUPATIONAL_HEALTH_CREATE_SUCCESS" )
  def occupationalHealthDeleteMessage: String = MessagesRetriever.getSuccessMessage( "occupational_health", "OCCUPATIONAL_HEALTH_DELETE_SUCCESS" )
  def occupationalHealthUpdateMessage: String = MessagesRetriever.getSuccessMessage( "occupational_health", "OCCUPATIONAL_HEALTH_UPDATE_SUCCESS" )
  def occupationalHealthGetMessage: String = MessagesRetriever.getSuccessMessage( "occupational_health", "OCCUPATIONAL_HEALTH_GET_SUCCESS" )
  def occupationalHealthGetAllMessage: String = MessagesRetriever.getSuccessMessage( "occupational_health", "OCCUPATIONAL_HEALTH_GET_ALL_SUCCESS" )

  def occupationalHealthCreateError: String = MessagesRetriever.getErrorMessage( "occupational_health", "OCCUPATIONAL_HEALTH_EXIST_ERROR" )
  def occupationalHealthNotFoundError: String = MessagesRetriever.getErrorMessage( "occupational_health", "OCCUPATIONAL_HEALTH_NOT_FOUND_ERROR" )
}
