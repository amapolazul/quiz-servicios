package com.arlsura.afiliacion.bussiness.authentication

import com.arlsura.afiliacion.utils.Utils

import scala.concurrent.Future

/**
 * Created by juanmartinez on 16/02/15.
 */
trait AuthenticationService[ T ] {
  /**
   * Define la operacion básica de autenticación
   * En casi de haber varios tipos de autenticación cada uno deberá implementarlo de acuerdo al método respectivo
   * @param user
   * @param pass
   * @return
   */
  def authenticate( user: String, pass: String ): Future[ T ]

  /**
   * Obtiene las credenciales del usuario nombrado para el consumo de los servicios privados de sura
   * @return
   */
  def getCredentials(): Credentials = {
    val username = Utils.getProperty( "soap.credentials", "username" ).asInstanceOf[ String ]
    val password = Utils.getProperty( "soap.credentials", "password" ).asInstanceOf[ String ]
    Credentials(
      username = username,
      password = password
    )
  }

}

/**
 * Clase que modela las credenciales del usuario nombrado para la autenticación
 * @param username
 * @param password
 */
case class Credentials( username: String, password: String )

