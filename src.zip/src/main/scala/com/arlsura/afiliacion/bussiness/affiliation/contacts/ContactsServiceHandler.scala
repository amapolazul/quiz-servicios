package com.arlsura.afiliacion.bussiness.affiliation.contacts

import java.util.Date

import com.arlsura.afiliacion.bussiness.HandlerSupport.ServiceHandlerResponse
import com.arlsura.afiliacion.bussiness.RequestContextSupport
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.{ ContactInformationData, SaveContactInformation, GeneralJsonResponseData }
import com.arlsura.afiliacion.persistence.entities.affiliation.contacts_data.{ ContactInformation, AffiliationContactsData }
import com.arlsura.afiliacion.proceso.pasos.centros_trabajo.WorkCenterPreSaving
import com.arlsura.afiliacion.proceso.pasos.sucursales.BranchDataMarshaller.{ PreSavingData, ContactName }
import com.arlsura.afiliacion.proceso.pasos.sucursales.BranchDataPreSaving
import com.arlsura.afiliacion.utils.Utils
import com.arlsura.afiliacion.utils.messages.MessagesRetriever
import com.google.inject.Inject
import com.typesafe.scalalogging.LazyLogging
import reactivemongo.bson.BSONObjectID
import spray.http.StatusCodes
import spray.routing.RequestContext
import scala.concurrent.{ Future, ExecutionContext }
import scala.util.{ Failure, Success }
import ContactsServiceHandler._

/**
 * Created by juanmartinez on 16/04/15.
 */
class ContactsServiceHandler @Inject() ( private val contactServiceRepository: ContactDataRepository ) {

  def getContactsInfo( dni: String )( implicit executionContext: ExecutionContext ): Future[ ServiceHandlerResponse ] = {
    contactServiceRepository.findByDni( dni ) map {
      option =>
        val payload = option map {
          contact =>
            GeneralJsonResponseData( message = getContactsInfoSuccessMessage, suraSessionManager = getSessionString( dni ), data = Some( contact ) )
        } getOrElse {
          GeneralJsonResponseData( emptyContactsInfoMessage, suraSessionManager = getSessionString( dni ) )
        }
        Right( payload )
    } recover {
      case ex: Throwable =>
        Left( s"Ocurrio un error al consultar los contactos asociados al dni $dni: ${ex.getMessage}" )
    }
  }

  def createOrUpdateContactsInfo( contactsInfoRequest: SaveContactInformation, dni: String )( implicit executionContext: ExecutionContext ): Future[ ServiceHandlerResponse ] = {
    saveDefaultWorkCenters( contactsInfoRequest )
    contactServiceRepository.findByDni( dni ) flatMap {
      option =>
        val response = option map {
          contact =>
            val mappedEntity: AffiliationContactsData = mapSaveContactRequest( contactsInfoRequest, contact._id )

            contactServiceRepository.updateByDni( mappedEntity, dni ) map {
              _ =>
                Right( GeneralJsonResponseData( message = updateContactsInfoSuccessMessage, suraSessionManager = getSessionString( dni ), data = Some( mappedEntity ) ) )
            } recover {
              case ex: Throwable =>
                //                ex.printStackTrace()
                Left( s"Ocurrio un error al consultar los contactos asociados al dni $dni: ${ex.getMessage}" )
            }
        } getOrElse {
          val mappedEntity: AffiliationContactsData = mapSaveContactRequest( contactsInfoRequest, BSONObjectID.generate )
          contactServiceRepository.create( mappedEntity )
          saveDefaultBranch( dni, contactsInfoRequest.legalRepresentative )
          saveDefaultWorkCenters( contactsInfoRequest )
          Future( Right( GeneralJsonResponseData( message = emptyContactsInfoMessage, suraSessionManager = getSessionString( dni ) ) ) )
        }

        response
    } recover {
      case ex: Throwable =>
        Left( s"Ocurrio un error al actualizar los contactos: ${ex.getMessage}" )
    }
  }

  private def saveDefaultWorkCenters( contactsInfoRequest: SaveContactInformation )( implicit executionContext: ExecutionContext ): Unit = {
    val workCenter: WorkCenterPreSaving = new WorkCenterPreSaving()
    workCenter.saveOrUpdate( contactsInfoRequest )
  }

  private def saveDefaultBranch( dni: String, legalRepresentative: ContactInformationData )( implicit executionContext: ExecutionContext ): Unit = {
    val branchDataPreSaving: BranchDataPreSaving = new BranchDataPreSaving()
    val contact = ContactName(
      name1 = legalRepresentative.name1,
      name2 = legalRepresentative.name2,
      lastName1 = legalRepresentative.lastname1,
      lastName2 = legalRepresentative.lastname2
    )
    branchDataPreSaving.save( PreSavingData( dni, contact ) )
  }

  private def mapSaveContactRequest( saveContact: SaveContactInformation, id: BSONObjectID ): AffiliationContactsData = {
    AffiliationContactsData(
      _id = id,
      dni = saveContact.dni,
      securityCode = saveContact.securityCode,
      humanResourcesRepresentative = ContactInformation(
        email = saveContact.humanResourcesRepresentative.email,
        identification = saveContact.humanResourcesRepresentative.identification,
        identificationType = saveContact.humanResourcesRepresentative.identificationType,
        lastname1 = saveContact.humanResourcesRepresentative.lastname1,
        lastname2 = saveContact.humanResourcesRepresentative.lastname2,
        name1 = saveContact.humanResourcesRepresentative.name1,
        name2 = saveContact.humanResourcesRepresentative.name2,
        phone = saveContact.humanResourcesRepresentative.phone,
        position = saveContact.humanResourcesRepresentative.position,
        title = saveContact.humanResourcesRepresentative.title,
        contactId = saveContact.humanResourcesRepresentative.contactId
      ),
      insideTrainingRepresentative = ContactInformation(
        email = saveContact.insideTrainingRepresentative.email,
        identification = saveContact.insideTrainingRepresentative.identification,
        identificationType = saveContact.insideTrainingRepresentative.identificationType,
        lastname1 = saveContact.insideTrainingRepresentative.lastname1,
        lastname2 = saveContact.insideTrainingRepresentative.lastname2,
        name1 = saveContact.insideTrainingRepresentative.name1,
        name2 = saveContact.insideTrainingRepresentative.name2,
        phone = saveContact.insideTrainingRepresentative.phone,
        position = saveContact.insideTrainingRepresentative.position,
        title = saveContact.insideTrainingRepresentative.title,
        contactId = saveContact.insideTrainingRepresentative.contactId
      ),
      legalRepresentative = ContactInformation(
        email = saveContact.legalRepresentative.email,
        identification = saveContact.legalRepresentative.identification,
        identificationType = saveContact.legalRepresentative.identificationType,
        lastname1 = saveContact.legalRepresentative.lastname1,
        lastname2 = saveContact.legalRepresentative.lastname2,
        name1 = saveContact.legalRepresentative.name1,
        name2 = saveContact.legalRepresentative.name2,
        phone = saveContact.legalRepresentative.phone,
        position = saveContact.legalRepresentative.position,
        title = saveContact.legalRepresentative.title,
        contactId = saveContact.legalRepresentative.contactId
      ),
      manager = ContactInformation(
        email = saveContact.manager.email,
        identification = saveContact.manager.identification,
        identificationType = saveContact.manager.identificationType,
        lastname1 = saveContact.manager.lastname1,
        lastname2 = saveContact.manager.lastname2,
        name1 = saveContact.manager.name1,
        name2 = saveContact.manager.name2,
        phone = saveContact.manager.phone,
        position = saveContact.manager.position,
        title = saveContact.manager.title,
        contactId = saveContact.manager.contactId
      ),
      rosterRepresentative = ContactInformation(
        email = saveContact.rosterRepresentative.email,
        identification = saveContact.rosterRepresentative.identification,
        identificationType = saveContact.rosterRepresentative.identificationType,
        lastname1 = saveContact.rosterRepresentative.lastname1,
        lastname2 = saveContact.rosterRepresentative.lastname2,
        name1 = saveContact.rosterRepresentative.name1,
        name2 = saveContact.rosterRepresentative.name2,
        phone = saveContact.rosterRepresentative.phone,
        position = saveContact.rosterRepresentative.position,
        title = saveContact.rosterRepresentative.title,
        contactId = saveContact.rosterRepresentative.contactId
      ),
      workSafetyRepresentative = ContactInformation(
        email = saveContact.workSafetyRepresentative.email,
        identification = saveContact.workSafetyRepresentative.identification,
        identificationType = saveContact.workSafetyRepresentative.identificationType,
        lastname1 = saveContact.workSafetyRepresentative.lastname1,
        lastname2 = saveContact.workSafetyRepresentative.lastname2,
        name1 = saveContact.workSafetyRepresentative.name1,
        name2 = saveContact.workSafetyRepresentative.name2,
        phone = saveContact.workSafetyRepresentative.phone,
        position = saveContact.workSafetyRepresentative.position,
        title = saveContact.workSafetyRepresentative.title,
        contactId = saveContact.workSafetyRepresentative.contactId
      )
    )
  }

  //TODO Sacar esto a un trait.
  private def getSessionString( dni: String ): Option[ String ] = {
    val d = s"$dni-${new Date().getTime.toString}"
    Some( Utils.encodeFile( d.getBytes ) )
  }

}

object ContactsServiceHandler {

  //mensajes de error y de exito para las respuestas
  val getContactsInfoSuccessMessage: String = MessagesRetriever.getSuccessMessage( "affiliation.contacts", "GET_BY_ID" )
  val createContactsInfoSuccessMessage: String = MessagesRetriever.getSuccessMessage( "affiliation.contacts", "CREATE" )
  val updateContactsInfoSuccessMessage: String = MessagesRetriever.getSuccessMessage( "affiliation.contacts", "UPDATE" )
  val emptyContactsInfoMessage: String = MessagesRetriever.getSuccessMessage( "affiliation.contacts", "EMPTY" )

}
