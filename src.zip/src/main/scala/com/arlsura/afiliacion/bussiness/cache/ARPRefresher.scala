package com.arlsura.afiliacion.bussiness.cache

import co.com.sura.ventainformacion.service.Arpdto
import co.com.sura.ventainformacion.service.consumer.ARPConsumerService
import com.arlsura.afiliacion.persistence.cache.entities.ARPCache
import com.arlsura.afiliacion.utils.Utils

/**
 * Created by Jesús Martínez on 24/04/15.
 */
object ARPRefresher extends CacheLoader[ Arpdto, ARPCache ] {
  private lazy val arpServiceUrl = Utils.getProperty( "soap.services.", "arps" ).asInstanceOf[ String ]
  private lazy val arpConsumer = new ARPConsumerService( this.username, this.password, "123", arpServiceUrl )

  /**
   * @return Colección de datos provenientes del servicio exterior.
   */
  override def consumeService(): Option[ Seq[ Arpdto ] ] = {
    //    logger.debug( s"ARP SERVICE URL: $arpServiceUrl" )
    arpConsumer.authenticateToProxy( this.cloudProxyHost, this.cloudProxyPort, this.cloudProxyUser, this.cloudProxyPassword )
    val result = arpConsumer.getArps
    if ( result != null && result.length > 0 ) Some( result.toSeq ) else None
  }

  /**
   * @param data Colección de datos "crudos" provenientes del servicio de terceros.
   * @return Colección de documentos que serán almacenados en Mongo.
   */
  override def prepareData( data: Seq[ Arpdto ] ): Seq[ ARPCache ] =
    for ( a <- data ) yield ARPCache( code = a.getCodigodArp.toInt, dni = a.getDni, groupCode = if ( a.getCodigoGrupo == null ) 0 else a.getCodigoGrupo.toInt, commercialDescription = a.getDsComercial )
}
