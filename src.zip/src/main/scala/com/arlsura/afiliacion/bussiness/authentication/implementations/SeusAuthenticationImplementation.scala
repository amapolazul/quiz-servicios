package com.arlsura.afiliacion.bussiness.authentication.implementations

import akka.actor.ActorSystem
import akka.actor.FSM.Failure
import com.arlsura.afiliacion.bussiness.authentication.AuthenticationService
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.{ SeusAuthenticationResponse, SeusAuthenticationRequest }
import com.arlsura.afiliacion.utils.Utils
import spray.http.HttpRequest
import spray.client.pipelining._

import scala.concurrent.Future

/**
 * Created by juanmartinez on 16/02/15.
 */
class SeusAuthenticationImplementation extends AuthenticationService[ SeusAuthenticationResponse ] {

  /**
   * Define la operacion básica de autenticación
   * En casi de haber varios tipos de autenticación cada uno deberá implementarlo de acuerdo al método respectivo
   * Esta implementacion devuelve el token que indica el estado de la autenticacion del usuario
   * @param user
   * @param pass
   * @return
   */
  override def authenticate( user: String, pass: String ): Future[ SeusAuthenticationResponse ] = {
    implicit val system = ActorSystem()
    import system.dispatcher

    val pipeline: HttpRequest => Future[ SeusAuthenticationResponse ] =
      sendReceive ~> unmarshal[ SeusAuthenticationResponse ]

    val request: SeusAuthenticationRequest = SeusAuthenticationRequest(
      login = user,
      password = pass,
      ip = Utils.getLocalIpAddress
    )

    pipeline( Post( buildSeusAuthenticationURL, request ) )
  }

  /**
   * Construye la ruta del recurso de autenticacion para el servicio de autenticacion de seus
   * @return
   */
  private def buildSeusAuthenticationURL: String = {
    val endpoint = SeusAuthenticationImplementation.getSeusAuthenticationEndPoint
    val resource = SeusAuthenticationImplementation.getSeusAuthenticationResource
    s"${endpoint}${resource}"
  }

}

object SeusAuthenticationImplementation {

  /**
   * Devuelve la ruta para el servicio de autenticacion de seus
   * @return
   */
  def getSeusAuthenticationEndPoint: String = Utils.getProperty( "authentication.seus.", "end_point" ).asInstanceOf[ String ]

  /**
   * Devuelve el recurso asociado a la autenticación de seus en el servicio
   * @return
   */
  def getSeusAuthenticationResource: String = Utils.getProperty( "authentication.seus.", "authentication" ).asInstanceOf[ String ]

}

