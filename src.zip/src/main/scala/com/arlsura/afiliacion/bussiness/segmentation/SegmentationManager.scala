package com.arlsura.afiliacion.bussiness.segmentation

import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.SegmentationEntityRequest
import com.arlsura.afiliacion.persistence.daos.SegmentationRulesDAO
import com.arlsura.afiliacion.persistence.entities.{ LongExtension, SegmentationRules }
import com.arlsura.afiliacion.utils.reflection.ReflectionSupport
import reactivemongo.bson.{ BSONObjectID, BSONString, BSONDocument }
import reactivemongo.core.commands.LastError

import scala.collection.mutable
import scala.concurrent.{ ExecutionContext, Future }

import reactivemongo.extensions.dsl.BsonDsl._

/**
 * Created by juanmartinez on 22/12/14.
 */
class SegmentationManager extends ReflectionSupport {

  /**
   * valida la si el cliente cumple con las condiciones en matriz se segmentacion
   *
   * @param segRule
   * @param numWorkersPar
   * @return retorna un booleano. True para continuar y false para retener la afiliación
   */
  def validateSegmentation( segRule: SegmentationRules, numWorkersPar: Long ): Boolean = {
    val numWorkers = LongExtension( numWorkersPar )
    val operator = segRule.operator
    val reflectedClass = runtimeUniverse.runtimeMirror( getClass.getClassLoader ).reflect( numWorkers )
    val reflectedMethod = reflectedClass.reflectMethod( getReflectedMethod( operator, numWorkers ).asMethod )

    reflectedMethod( segRule.num_workers ).toString.toBoolean
  }

  /**
   * Trae todas las reglas para la segmentacion
   * @param ciiu
   * @param city
   * @return
   */
  def getSegmentationRules( ciiu: String = "", city: String = "" )( implicit executionContext: ExecutionContext ): Future[ List[ SegmentationRules ] ] = {
    import scala.collection.mutable.MutableList
    val query: MutableList[ BSONDocument ] = new mutable.MutableList[ BSONDocument ]
    if ( ciiu.isEmpty && city.isEmpty )
      query += BSONDocument()
    if ( ciiu.nonEmpty )
      query += BSONDocument( "ciiu" -> BSONString( ciiu ) )
    if ( city.nonEmpty )
      query += BSONDocument( "city" -> BSONString( city ) )

    SegmentationRulesDAO.findAll(
      BSONDocument( "$and" -> query )
    )

  }

  /**
   * guarda una regla para la segmentacion
   * @param segRule
   * @return
   */
  def saveSegmentationRule( segRule: SegmentationRules )( implicit executionContext: ExecutionContext ) = SegmentationRulesDAO.insert( segRule )

  /**
   * actualiza una regla para la segmentacion
   * @param idSegRule
   * @param segRule
   * @return
   */
  def updateSegmentationRule( idSegRule: BSONObjectID, segRule: SegmentationRules )( implicit executionContext: ExecutionContext ): Future[ LastError ] = {
    SegmentationRulesDAO.updateById(
      idSegRule, $set(
      "city" -> segRule.city,
      "operator" -> segRule.operator,
      "num_workers" -> segRule.num_workers
    )
    )
  }

  /**
   * borra una regla para la segmentacion
   * @param idSegRule
   * @return
   */
  def deleteSegmentationRule( idSegRule: BSONObjectID )( implicit executionContext: ExecutionContext ) = {
    SegmentationRulesDAO.removeById( idSegRule )
  }

  /**
   * Encuentra una regla de segmentación por su identificador
   * @param idSegRule
   * @return
   */
  def findSegmentationById( idSegRule: BSONObjectID )( implicit executionContext: ExecutionContext ) = {
    SegmentationRulesDAO.findById( idSegRule )
  }

}

object SegmentationManager {

  /**
   * Convierte la entidad de la petición http a entidad para la base de datos
   * @param segEntity
   * @return
   */
  def getSegmentationDataBaseEntity( segEntity: SegmentationEntityRequest ): SegmentationRules = {
    SegmentationRules(
      ciiu = segEntity.ciiu,
      city = segEntity.city,
      num_workers = segEntity.num_workers,
      operator = segEntity.operator
    )
  }

  /**
   * Retorna un mapa de las posibles operaciones y sus mensajes
   * @return
   */
  def getAvailableOperators(): Map[ String, String ] = {
    Map(
      "ltoe" -> "Menor o igual que",
      "gtoe" -> "Mayor o igual que",
      "lt" -> "Menor que",
      "gt" -> "Mayor que",
      "eq" -> "Igual a"
    )
  }
}

