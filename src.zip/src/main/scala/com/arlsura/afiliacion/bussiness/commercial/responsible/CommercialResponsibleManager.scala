package com.arlsura.afiliacion.bussiness.commercial.responsible

import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.{ GetCommercialResponsibleRequest, UpdateCommercialResponsibleRequest, CreateCommercialResponsibleRequest }
import com.arlsura.afiliacion.persistence.daos.wrappers.CommercialResponsibleWrapper
import com.arlsura.afiliacion.persistence.entities.CommercialResponsible
import com.google.inject.Inject
import reactivemongo.bson.{ BSONObjectID, BSONDocument }
import reactivemongo.core.commands.LastError
import scala.concurrent.{ ExecutionContext, Future }
import scala.util.{ Failure, Success }

/**
 * Expone las operaciones disponibles sobre la coleccion CommercialResponsible
 * Created by root on 9/02/15.
 */
class CommercialResponsibleManager @Inject() ( wrapper: CommercialResponsibleWrapper ) {

  /**
   * Crea un documento en la coleccion CommercialResponsible
   * @param request
   * @return
   */
  def create( request: CreateCommercialResponsibleRequest )( implicit ec: ExecutionContext ): Future[ LastError ] = {
    wrapper.insert( CommercialResponsible(
      office = request.office,
      city = request.city.toLowerCase,
      fullName = request.fullName.toLowerCase,
      email = request.email.toLowerCase,
      charge = request.charge.toLowerCase,
      networkUser = request.networkUser,
      dni = request.dni
    ) )
  }

  /**
   * Obtiene todos los documentos de la coleccion CommercialResponsible
   * @return
   */
  def getAll()( implicit ec: ExecutionContext ): Future[ List[ CommercialResponsible ] ] = {
    wrapper.findAll()
  }

  /**
   * Obtiene los documentos de CommercialResponsible que coincidan con los parametros de entrada
   * @param request
   * @return
   */
  def getBy( request: GetCommercialResponsibleRequest )( implicit ec: ExecutionContext ): Future[ List[ CommercialResponsible ] ] = {
    val query = obtainDocument( request.office, request.city, request.fullName, request.email, request.charge, request.networkUser, request.dni )
    wrapper.findAll( query )
  }

  /**
   * Obtiene el documento de CommercialResponsible que tenga el id indicado
   * @param id
   * @return
   */
  def getById( id: String )( implicit ec: ExecutionContext ): Future[ Option[ CommercialResponsible ] ] = {
    BSONObjectID.parse( id ) match {
      case Success( bsonId ) =>
        wrapper.findOne( BSONDocument( "_id" -> bsonId ) )
      case Failure( e ) =>
        throw new IllegalArgumentException( e )
    }
  }

  /**
   * Actualiza el documento de CommercialResponsible que coincida con el id de entrada
   * @param request
   * @return
   */
  def update( request: UpdateCommercialResponsibleRequest )( implicit ec: ExecutionContext ): Future[ LastError ] = {
    BSONObjectID.parse( request.id ) match {
      case Success( bsonId ) =>
        val modifications = obtainDocument( request.office, request.city, request.fullName, request.email, request.charge, request.networkUser, request.dni )
        wrapper.updateById( bsonId, BSONDocument( "$set" -> modifications ) )
      case Failure( e ) =>
        throw new IllegalArgumentException( e )
    }
  }

  /**
   * Elimina todos los documentos de CommercialResponsible
   * @return
   */
  def deleteAll()( implicit ec: ExecutionContext ): Future[ LastError ] = {
    wrapper.removeAll()
  }

  /**
   * Elimina el documento de CommercialResponsible que coincida con el id de entrada
   * @param id
   * @return
   */
  def deleteById( id: String )( implicit ec: ExecutionContext ): Future[ LastError ] = {
    BSONObjectID.parse( id ) match {
      case Success( bsonId ) =>
        wrapper.remove( BSONDocument( "_id" -> bsonId ) )
      case Failure( e ) =>
        throw new IllegalArgumentException( e )
    }
  }

  /**
   * Toma los parámetros (opcionales) y arma un query de mongo.
   * @param office ID de la oficina del responsable comercial.
   * @param city Ciudad donde está la oficina del responsable comercial.
   * @param fullName Nombres y apellidos del responsable comercial.
   * @param email Correo electrónico del responsable comercial.
   * @param charge Cargo del responsable comercial.
   * @return Representación del query como BSONDocument.
   */
  private def obtainDocument( office: Option[ Int ], city: Option[ String ], fullName: Option[ String ], email: Option[ String ], charge: Option[ String ], networkUser: Option[ String ], dni: Option[ String ] ) = {
    var query = BSONDocument()

    office match {
      case Some( o ) => query = query ++ BSONDocument( "office" -> o )
      case _         =>
    }

    city match {
      case Some( c ) => query = query ++ BSONDocument( "city" -> c.toLowerCase )
      case _         =>
    }

    fullName match {
      //case Some(fn) => query = query ++ BSONDocument("fullName" -> BSONDocument("$regex" -> fn.toLowerCase))
      case Some( fn ) => query = query ++ BSONDocument( "fullName" -> fn.toLowerCase )
      case _          =>
    }

    email match {
      case Some( e ) => query = query ++ BSONDocument( "email" -> e.toLowerCase )
      case _         =>
    }

    charge match {
      case Some( ch ) => query = query ++ BSONDocument( "charge" -> ch.toLowerCase )
      case _          =>
    }

    networkUser match {
      case Some( nu ) => query = query ++ BSONDocument( "networkUser" -> nu )
      case _          =>
    }

    dni match {
      case Some( nu ) => query = query ++ BSONDocument( "dni" -> nu )
      case _          =>
    }

    query
  }

}
