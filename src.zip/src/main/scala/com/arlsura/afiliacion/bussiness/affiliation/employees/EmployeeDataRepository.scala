package com.arlsura.afiliacion.bussiness.affiliation.employees

import com.arlsura.afiliacion.persistence.daos.affiliation.wrappers.AffiliationEmployeesDataWrapper
import com.arlsura.afiliacion.persistence.entities.affiliation.basic_data.Address
import com.arlsura.afiliacion.persistence.entities.affiliation.contacts_data.ContactInformation
import com.arlsura.afiliacion.persistence.entities.affiliation.employee_data.{ EmployeeInformation, AffiliationEmployeesData }
import com.arlsura.afiliacion.utils.CipherFacility
import reactivemongo.bson.{ BSONObjectID, BSONDocument }
import reactivemongo.core.commands.LastError
import scala.concurrent.{ Future, ExecutionContext }
import com.google.inject.Inject

/**
 * Created by Jesús Martínez on 29/04/15.
 * @param dao [Dependencia] DAO para interactuar con los datos.
 */
class EmployeeDataRepository @Inject() ( dao: AffiliationEmployeesDataWrapper ) extends CipherFacility {

  /**
   * Actualiza la información de los trabajadores asociados al proceso de afiliación vinculado al DNI ingresado.
   * @param dni DNI utilizado para actualizar la información.
   * @param securityCode Código de seguridad relacionado con el proceso de afiliación.
   * @param employees Lista de objetos con información de trabajadores.
   * @return Futuro con estado de la transacción.
   */
  def createOrUpdate( dni: String, securityCode: String, employees: List[ EmployeeInformation ] )( implicit ec: ExecutionContext ): Future[ LastError ] = {
    findByDni( dni ).flatMap {
      resultMaybe =>
        val id = resultMaybe.map( _._id ).getOrElse( BSONObjectID.generate )
        val document = encryptDocument( AffiliationEmployeesData( id, dni, securityCode, Some( employees ) ) )
        //Si el documento ya existe, solo lo actualiza, si no, lo crea.
        dao.update( BSONDocument( "dni" -> encode( dni ) ), document, upsert = true )
    }
  }

  //TODO Hay que incluir el código de seguridad
  /**
   * Encuentra un documento por el dni del usuario asociado al proceso de afiliación.
   * @param dni Número de identifcación a ser utilizado como clave para la búsqueda.
   * @return Futuro con un posible documento asociado al DNI ingresado.
   */
  def findByDni( dni: String )( implicit ec: ExecutionContext ): Future[ Option[ AffiliationEmployeesData ] ] = {
    dao.findOne( BSONDocument( "dni" -> encode( dni ) ) ) map ( _.map( decryptDocument ) )
  }

  /**
   * Elimina un documento de la colección.
   * @param dni Clave utilizada para buscar el documento que se va a eliminar.
   * @return Futuro con estado de la transacción.
   */
  def removeByDni( dni: String )( implicit ec: ExecutionContext ): Future[ LastError ] = {
    dao.remove( BSONDocument( "dni" -> encode( dni ) ) )
  }

  private def encryptDocument( a: AffiliationEmployeesData ) = {
    val encryptedEmployeeInfo = a.employees.map( _.map {
      e =>
        EmployeeInformation(
          contactInfo = ContactInformation.encrypt( e.contactInfo ),
          cellphone = e.cellphone.map( encode ),
          birthdate = e.birthdate,
          gender = e.gender,
          salary = encode( e.salary ),
          workcenter = e.workcenter,
          jobModality = e.jobModality,
          remoteWorkType = e.remoteWorkType,
          remoteWorkPlace = e.remoteWorkPlace,
          commercialActivity = e.commercialActivity,
          eps = e.eps,
          afp = e.afp,
          contractType = e.contractType,
          contractStartDate = e.contractStartDate,
          contractEndDate = e.contractEndDate,
          contractTotalValue = e.contractTotalValue,
          contractMonthlyValue = e.contractMonthlyValue,
          ibc = e.ibc,
          employeeAddressData = Address.encrypt( e.employeeAddressData )
        )
    } )

    AffiliationEmployeesData(
      _id = a._id,
      dni = encode( a.dni ),
      securityCode = a.securityCode,
      employees = encryptedEmployeeInfo
    )
  }

  private def decryptDocument( a: AffiliationEmployeesData ) = {
    val decryptedEmployeeInfo = a.employees.map( _.map {
      e =>
        EmployeeInformation(
          contactInfo = ContactInformation.decrypt( e.contactInfo ),
          cellphone = e.cellphone.map( decode ),
          birthdate = e.birthdate,
          gender = e.gender,
          salary = decode( e.salary ),
          workcenter = e.workcenter,
          jobModality = e.jobModality,
          remoteWorkType = e.remoteWorkType,
          remoteWorkPlace = e.remoteWorkPlace,
          commercialActivity = e.commercialActivity,
          eps = e.eps,
          afp = e.afp,
          contractType = e.contractType,
          contractStartDate = e.contractStartDate,
          contractEndDate = e.contractEndDate,
          contractTotalValue = e.contractTotalValue,
          contractMonthlyValue = e.contractMonthlyValue,
          ibc = e.ibc,
          employeeAddressData = Address.decrypt( e.employeeAddressData )
        )
    } )

    AffiliationEmployeesData(
      _id = a._id,
      dni = decode( a.dni ),
      securityCode = a.securityCode,
      employees = decryptedEmployeeInfo
    )
  }

}
