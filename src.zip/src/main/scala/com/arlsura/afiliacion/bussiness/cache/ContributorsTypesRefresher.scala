package com.arlsura.afiliacion.bussiness.cache

import co.com.sura.ventainformacion.service.RelacionCotizacionDTO
import com.arlsura.afiliacion.persistence.cache.entities.ContributorTypeCache
import com.arlsura.afiliacion.utils.Utils
import com.suramericana.serviciocotizantes.ContributorServiceConsumer

/**
 * Created by Jesús Martínez on 24/04/15.
 */
object ContributorsTypesRefresher extends CacheLoader[ RelacionCotizacionDTO, ContributorTypeCache ] {
  private lazy val contributorsTypesServiceUrl = Utils.getProperty( "soap.services.", "contributors" ).asInstanceOf[ String ]
  private lazy val contributorsTypesServiceConsumer = new ContributorServiceConsumer( this.username, this.password, "1", contributorsTypesServiceUrl )

  /**
   * @return Colección de datos provenientes del servicio exterior.
   */
  override def consumeService(): Option[ Seq[ RelacionCotizacionDTO ] ] = {
    //    logger.debug( s"CONTRIBUTORS TYPES SERVICE URL: $contributorsTypesServiceUrl" )
    contributorsTypesServiceConsumer.authenticateToProxy( this.cloudProxyHost, this.cloudProxyPort, this.cloudProxyUser, this.cloudProxyPassword )
    val contributors = contributorsTypesServiceConsumer.consultarTiposCotizantes( "" )

    if ( contributors != null && contributors.length > 0 ) Some( contributors.toSeq ) else None
  }

  /**
   * @param data Colección de datos "crudos" provenientes del servicio de terceros.
   * @return Colección de documentos que serán almacenados en Mongo.
   */
  override def prepareData( data: Seq[ RelacionCotizacionDTO ] ): Seq[ ContributorTypeCache ] = {
    def getOrElse[ A ]( value: A, default: A ): A = if ( value == null ) default else value
    for ( ct <- data ) yield ContributorTypeCache(
      affiliateTypeCode = getOrElse( ct.getCdTipoAfiliado, "" ),
      contributorSubtypeCode = getOrElse( ct.getCdSubTipoCotizante, "" ),
      contributorTypeCode = getOrElse( ct.getCdTipoCotizante, "" ),
      relationshipDescription = getOrElse( ct.getDsRelacion, "" ),
      orderNumber = getOrElse( ct.getNmOrden, -1 )
    )
  }
}
