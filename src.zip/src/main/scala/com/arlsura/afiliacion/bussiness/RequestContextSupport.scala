package com.arlsura.afiliacion.bussiness

import com.arlsura.afiliacion.bussiness.HandlerSupport._
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.GeneralJsonResponseData
import com.arlsura.afiliacion.utils.messages.MessagesRetriever
import spray.http.{ StatusCodes, StatusCode }
import spray.routing.RequestContext

import scala.concurrent.{ ExecutionContext, Future }
import scala.util.{ Failure, Success }

/**
 * Define comportamiento general para la terminación de todas las peticiones web que se completan atraves
 * de futuros
 * Created by juanmartinez on 2/02/15.
 */
trait RequestContextSupport {

  /**
   * Define comportamiento comun para completar una peticion
   * @param ctx
   * @param code
   * @param generalJsonResponseData
   */
  def complete( ctx: RequestContext, code: StatusCode, generalJsonResponseData: GeneralJsonResponseData ) =
    ctx.complete( ( code, generalJsonResponseData ) )

  /**
   * Completa la peticion con un error general indicando lo ocurrido. Generalmente el mensaje va con
   * el mensaje de la excepcion que ocurrio
   * @param ctx
   * @param message
   */
  def completeWithFailure( ctx: RequestContext, message: String ) = {
    val generalResponse: GeneralJsonResponseData = GeneralJsonResponseData( message )
    complete( ctx, StatusCodes.InternalServerError, generalResponse )
  }

  /**
   * Completa las peticiones con el código 404 Not Found para todas las peticiones
   * @param ctx
   * @param message
   */
  def completeWithNotFound( ctx: RequestContext, message: String ) = {
    val generalResponse: GeneralJsonResponseData = GeneralJsonResponseData( message )
    complete( ctx, StatusCodes.NotFound, generalResponse )
  }

  /**
   * Completa las peticiones con el código 409 conflict para todas las peticiones.
   * Este código indica que se intentó guardar algo que ya existia en la base de datos
   * @param ctx
   * @param message
   */
  def completeWithConflict( ctx: RequestContext, message: String ) = {
    val response = GeneralJsonResponseData( message )
    this.complete( ctx, StatusCodes.Conflict, response )
  }

  /**
   * Toma el resultado paralelo de una operación y el contexto de la misma para completar
   * una solicitud.
   * @param f Futuro que será utilizada para completar la solicitud.
   * @param ctx Contexto donde se completa la solicitud.
   */
  def completeRequest( f: Future[ ServiceHandlerResponse ], ctx: RequestContext )( implicit ec: ExecutionContext ): Unit = {
    f onComplete {
      case Success( either ) =>
        if ( either.isRight ) {
          complete( ctx, StatusCodes.OK, either.right.get )
        }
        else {
          completeWithFailure( ctx, either.left.get )
        }
      case Failure( e ) =>
        completeWithFailure( ctx, e.toString )
    }
  }

  /**
   * Toma el resultado paralelo de una operación y el contexto de la misma para completar
   * una solicitud, no con un GeneralResponseData,sino con un arrya de bytes que repesntan un archivo.
   * @param future Futuro que será utilizada para completar la solicitud.
   * @param ctx Contexto donde se completa la solicitud.
   */
  def completeRequestWithFileResult( future: Future[ ServiceFileHandlerResponse ], ctx: RequestContext )( implicit ec: ExecutionContext ): Unit = {
    future onComplete {
      case Success( either ) =>
        either match {
          case Right( bytes ) => ctx.complete( ( StatusCodes.OK, bytes ) )
          case Left( error )  => completeWithFailure( ctx, error )
        }
      case Failure( e ) =>
        completeWithFailure( ctx, e.toString )
    }
  }

  def completeAuthorizationRequest( f: Future[ ServiceHandlerResponse ], ctx: RequestContext, notAuthorizedStatusCode: StatusCode )( implicit ec: ExecutionContext ): Unit = {
    f onComplete {
      case Success( either ) =>
        if ( either.isRight ) {
          complete( ctx, StatusCodes.OK, either.right.get )
        }
        else {
          complete( ctx, notAuthorizedStatusCode, GeneralJsonResponseData( either.left.get ) )
        }
      case Failure( e ) =>
        completeWithFailure( ctx, e.toString )
    }
  }

  def completeWithRejection( ctx: RequestContext )( implicit ec: ExecutionContext ): Unit = {
    complete( ctx, StatusCodes.Forbidden, GeneralJsonResponseData( message = "Autenticación fallida." ) )
  }

}

object RequestContextSupport {
  /**
   * Define mensaje estandar para errores internos de servidor
   * @return
   */
  def internalServerErrorMessage = MessagesRetriever.getErrorMessage( "common", "internal_error" )
}
