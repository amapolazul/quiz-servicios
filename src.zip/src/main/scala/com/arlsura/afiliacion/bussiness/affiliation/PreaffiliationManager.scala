package com.arlsura.afiliacion.bussiness.affiliation

import com.arlsura.afiliacion.persistence.daos.wrappers.PreAffiliationWrapper
import com.arlsura.afiliacion.persistence.entities.affiliation.contacts_data.ContactInformation
import com.arlsura.afiliacion.persistence.entities.preaffiliation.{ FullEconomicActivity, ProvinceSelected }
import com.arlsura.afiliacion.persistence.entities.PreAffiliation
import com.arlsura.afiliacion.services.preaffiliation.PreaffiliationMarshaller.{ Province, PreAffiliationSaveRequest }
import com.arlsura.afiliacion.utils.{ CipherFacility, DNIBuilder, Utils }
import com.google.inject.Inject
import com.typesafe.scalalogging.LazyLogging
import org.joda.time.DateTime
import reactivemongo.bson.{ BSONObjectID, BSONString, BSONDocument }
import reactivemongo.core.commands.LastError
import spray.http.HttpData
import scala.collection.mutable
import scala.concurrent.Future
import scala.concurrent.ExecutionContext.Implicits.global

/**
 * Clase encargada de interactuar con las operaciones de preafiliacion para un cliente
 * Created by juanmartinez on 27/11/14.
 */
class PreaffiliationManager @Inject() ( wrapper: PreAffiliationWrapper ) extends LazyLogging with CipherFacility {

  /**
   * Consulta una preafiliacion por el DNI que tiene asociado
   * @param dni
   * @return
   */
  def getPreAffiliationByDni( dni: String ): Future[ Option[ PreAffiliation ] ] =
    wrapper.findOne( BSONDocument( "dni" -> encode( dni ) ) ) map ( _.map( decryptDocument ) )

  def getPreAffiliationByEmail( dni: String, email: String ) = {
    wrapper.findOne( BSONDocument( "dni" -> encode( dni ), "contactInfo.email" -> encode( email ) ) ) map ( _.map( decryptDocument ) )
  }

  def getPreAffiliationByPhone( dni: String, phone: String ) = {
    wrapper.findOne( BSONDocument( "dni" -> encode( dni ), "contactInfo.phone" -> encode( phone ) ) ) map ( _.map( decryptDocument ) )
  }

  /**
   * Inserta la preafiliacion de un cliente
   * @param preAffiliation
   * @return
   */
  def saveClientAffiliation( preAffiliation: PreAffiliation ): Future[ LastError ] = wrapper.insert( encryptDocument( preAffiliation ) )

  /**
   * Actualiza la preafiliacion de un cliente
   * @param preAffiliation
   * @return
   */
  def updateClientAffiliation( preAffiliation: PreAffiliation ): Future[ LastError ] = wrapper.update( BSONDocument( "dni" -> encode( preAffiliation.dni ) ), encryptDocument( preAffiliation ) )

  /**
   * Construye la entidad de preafiliacion para guardar en la base de datos
   * @param requestData: PreAffiliationSaveRequest
   * @return
   */
  def buildPreAffiliationEntity( requestData: PreAffiliationSaveRequest ): PreAffiliation = {
    val dni = DNIBuilder.build( requestData.identificationType, requestData.identification )
    val contactInfo: ContactInformation = mapContactInformation( requestData )
    val fullEconomicActivity: FullEconomicActivity = mapEconomicActivity( requestData )
    val selectedProvinces: List[ ProvinceSelected ] = mapSelectedProvinces( requestData )

    PreAffiliation(
      dni = dni,
      contactInfo = contactInfo,
      prevarp = requestData.previousARL.getOrElse( "" ),
      workers = requestData.workers,
      fullName = requestData.fullName.getOrElse( "" ),
      address = requestData.fullAddress,
      cellphone = requestData.cellphone,
      econoact = requestData.fullEconomicActivity.economicActivityId,
      racea = requestData.racea,
      affiliationType = requestData.affiliationType,
      isNewCompany = Some( requestData.isNewCompany ),
      selectedProvinces = selectedProvinces,
      birthDate = requestData.birthDate.map( Utils.stringToDate ),
      gender = requestData.gender,
      fullEconomicActivity = fullEconomicActivity
    )
  }

  private def mapSelectedProvinces( requestData: PreAffiliationSaveRequest ): List[ ProvinceSelected ] = {
    requestData.provinces.toList.map {
      province: Province => ProvinceSelected( provinceCode = province.provinceCode, provinceName = province.provinceName )
    }
  }

  private def mapEconomicActivity( requestData: PreAffiliationSaveRequest ): FullEconomicActivity = {
    FullEconomicActivity(
      description = Some( requestData.fullEconomicActivity.description ),
      rate = Some( requestData.fullEconomicActivity.rate ),
      economicActivityId = requestData.fullEconomicActivity.economicActivityId
    )
  }

  private def mapContactInformation( requestData: PreAffiliationSaveRequest ): ContactInformation = {
    ContactInformation(
      identificationType = requestData.identificationType,
      identification = requestData.identification,
      phone = requestData.phone,
      email = requestData.email,
      name1 = requestData.name1.getOrElse( "" ),
      name2 = requestData.name2,
      lastname1 = requestData.lastName1.getOrElse( "" ),
      lastname2 = requestData.lastName2,
      contactId = Some( "RL" )
    )
  }

  private def encryptDocument( d: PreAffiliation ) = {
    PreAffiliation(
      _id = d._id,
      dni = encode( d.dni ),
      contactInfo = ContactInformation.encrypt( d.contactInfo ),
      fullName = encode( d.fullName ),
      address = encode( d.address ),
      cellphone = d.cellphone.map( encode ),
      econoact = d.econoact,
      fullEconomicActivity = d.fullEconomicActivity,
      workers = d.workers,
      prevarp = d.prevarp,
      racea = d.racea,
      fileName = d.fileName,
      file = d.file,
      affiliationType = d.affiliationType,
      isNewCompany = d.isNewCompany,
      selectedProvinces = d.selectedProvinces,
      gender = d.gender,
      birthDate = d.birthDate,
      segmentation = d.segmentation
    )
  }

  private def decryptDocument( d: PreAffiliation ) = {
    PreAffiliation(
      _id = d._id,
      dni = decode( d.dni ),
      contactInfo = ContactInformation.decrypt( d.contactInfo ),
      fullName = decode( d.fullName ),
      address = decode( d.address ),
      cellphone = d.cellphone.map( decode ),
      econoact = d.econoact,
      fullEconomicActivity = d.fullEconomicActivity,
      workers = d.workers,
      prevarp = d.prevarp,
      racea = d.racea,
      fileName = d.fileName,
      file = d.file,
      affiliationType = d.affiliationType,
      isNewCompany = d.isNewCompany,
      selectedProvinces = d.selectedProvinces,
      gender = d.gender,
      birthDate = d.birthDate,
      segmentation = d.segmentation
    )
  }

}
