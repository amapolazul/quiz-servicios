package com.arlsura.afiliacion.bussiness.cache

import co.com.sura.ventainformacion.service.ActividadesDTO
import co.com.sura.ventainformacion.service.consumer.ActivitiesConsumerService
import com.arlsura.afiliacion.persistence.cache.entities.EconomicActivityCache
import com.arlsura.afiliacion.utils.Utils

/**
 * Created by Jesús Martínez on 24/04/15.
 */
object EconomicActivitiesRefresher extends CacheLoader[ ActividadesDTO, EconomicActivityCache ] {
  private lazy val activitiesServiceURL = Utils.getProperty( "soap.services.", "activities" ).asInstanceOf[ String ]
  private lazy val activitiesConsumerService = new ActivitiesConsumerService( this.username, this.password, "1", activitiesServiceURL )

  /**
   * @return Colección de datos provenientes del servicio exterior.
   */
  override def consumeService(): Option[ Seq[ ActividadesDTO ] ] = {
    //    logger.debug( s"ACTIVITIES SERVICE URL: $activitiesServiceURL" )
    activitiesConsumerService.authenticateToProxy( this.cloudProxyHost, this.cloudProxyPort, this.cloudProxyUser, this.cloudProxyPassword )
    val result = activitiesConsumerService.consultarActividades( "T", "", "", 0, 0 )
    if ( result != null && result.length > 0 ) Some( result.toSeq ) else None
  }

  /**
   * @param data Colección de datos "crudos" provenientes del servicio de terceros.
   * @return Colección de documentos que serán almacenados en Mongo.
   */
  override def prepareData( data: Seq[ ActividadesDTO ] ): Seq[ EconomicActivityCache ] =
    for ( a <- data ) yield EconomicActivityCache( name = a.getNombreAct, code = a.getCdActividad, classCode = a.getCdClase, rate = a.getTasa )
}