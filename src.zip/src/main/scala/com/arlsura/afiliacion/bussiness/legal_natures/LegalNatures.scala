package com.arlsura.afiliacion.bussiness.legal_natures

import akka.actor.ActorSystem
import com.arlsura.afiliacion.bussiness.authentication.factory.{ AuthenticationFactory, Credentials }
import com.arlsura.afiliacion.bussiness.authentication.implementations.SeusAuthenticationImplementation
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.{ LegalNaturesResponse, SeusAuthenticationResponse }
import com.arlsura.afiliacion.utils.Utils
import com.typesafe.scalalogging.LazyLogging
import spray.can.Http
import spray.client.pipelining._
import akka.io.IO
import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.duration._
import scala.concurrent.{ Await, Future }
import akka.pattern.ask

/**
 * Created by John on 12/03/15.
 * Objeto para consumir servicio de venta informacion REST que retorna una lista con las naturalezas juridicas
 */
object LegalNatures extends LazyLogging {

  implicit val system = ActorSystem( "legal-natures-actor-system" )

  /**
   * Retorna todos los registros directamente desde ATEP.
   * @return Futuro con la estructura de datos que contiene la respuesta del servicio de Venta Información REST.
   */
  def retrieveRecords(): Future[ LegalNaturesResponse ] = {

    val ventaInfoResource: String = Utils.getProperty( "ventainformacion.", "juridical_natures" ).asInstanceOf[ String ]
    val serviceUrl: String = s"${Utils.getVentaInformacionUrl}$ventaInfoResource"

    val authentication: SeusAuthenticationImplementation = AuthenticationFactory.apply( "seus" )
    val credentials: Credentials = AuthenticationFactory.getCredentials()
    val futureResponseAuth: Future[ SeusAuthenticationResponse ] = authentication.authenticate( credentials.username, credentials.password )

    val responseAuth: Future[ LegalNaturesResponse ] = futureResponseAuth flatMap {
      authResponse =>
        {
          val futureResponse: Future[ LegalNaturesResponse ] = consumeService( serviceUrl, authResponse.tokenMus )
          //logger.debug(s"Lista de naturalezas juridicas consultada correctamente: $juridicalNatures")
          futureResponse
        }
    } recover {
      case e =>
        LegalNaturesResponse( s"An error occured: ${e.getMessage}", List.empty )
    }

    responseAuth
  }

  /**
   * Consume el servicio de venta informacion que retorna una lista de las naturalezas juridicas
   * @param url La URL del servicio
   * @return La respuesta del servicio, estructura replicada con las case classes JuridicalNaturesResponseResponse y JuridicalNaturesResponse
   */
  private def consumeService( url: String, token: String ): Future[ LegalNaturesResponse ] = {
    val pipeline =
      addHeader( "Access_Token", token ) ~>
        sendReceive ~> unmarshal[ LegalNaturesResponse ]
    pipeline {
      Get( url )
    }
  }

  private def shutdown(): Unit = {
    IO( Http ).ask( Http.CloseAll )( 50.second )
    system.shutdown()
  }

}
