package com.arlsura.afiliacion.bussiness.eps

import akka.actor.{ ActorSelection, ActorRef }
import com.arlsura.afiliacion.actors.cache.CacheRefresherActor
import com.arlsura.afiliacion.bussiness.RequestContextSupport
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.GeneralJsonResponseData
import spray.http.StatusCodes
import spray.routing.RequestContext
import scala.concurrent.ExecutionContext
import akka.pattern._
import scala.util.{ Failure, Success }
import com.arlsura.afiliacion.utils.GlobalParamsProvider

/**
 * Created by Jesús Martínez on 30/03/15.
 */
class EPSServiceHandler( requestContext: RequestContext, cacheActor: ActorSelection )( implicit ec: ExecutionContext ) extends RequestContextSupport with GlobalParamsProvider {
  /**
   * Trae todas las EPSs almacenadas en cache.
   */
  def retrieveEPSs(): Unit = {
    getAllEPS onComplete {
      case Success( list ) =>
        val response = GeneralJsonResponseData( "Respuesta Exitosa", Some( list ) )
        complete( requestContext, StatusCodes.OK, response )
      case Failure( e ) =>
        completeWithFailure( requestContext, e.toString )
    }
  }

  /**
   * Obtiene el catálogo de EPSs.
   * @return Lista de EPS, traidas directamente desde el cache.
   */
  private def getAllEPS = {
    val askableActor = new AskableActorSelection( cacheActor )
    val ask = ( askableActor ? CacheRefresherActor.GetEPSsCatalog ).mapTo[ CacheRefresherActor.EPSsCatalogReturned ]
    ask.map( _.catalog )
  }
}
