package com.arlsura.afiliacion.bussiness.blacklist

import com.arlsura.afiliacion.persistence.blacklist.{ Blacklist, BlacklistWrapper }
import com.arlsura.afiliacion.utils.CipherFacility
import com.google.inject.Inject
import org.joda.time.DateTime
import reactivemongo.bson.BSONDocument
import reactivemongo.core.commands.LastError

import scala.concurrent.{ ExecutionContext, Future }

/**
 * Created by Jesús Martínez on 9/06/15.
 */
class BlacklistRepository @Inject() ( wrapper: BlacklistWrapper ) extends CipherFacility {

  /**
   * Valida si un dni está en la lista negra. Se obtiene la entrada más reciente.
   * @param dni DNI utilizado para realizar la búsqueda.
   * @return Un futuro con (posiblemente) un conjunto de datos relacionados con el bloqueo del DNI ingresado.
   */
  def findByDni( dni: String )( implicit ec: ExecutionContext ): Future[ Option[ Blacklist ] ] =
    wrapper.findOne( BSONDocument( "dni" -> encode( dni ) ), BSONDocument( "since" -> -1 ) ) map {
      option => option.map( b => Blacklist( _id = b._id, dni = decode( b.dni ), since = b.since, factor = b.factor ) )
    }

  /**
   * @param dni DNI que será bloqueado.
   * @param since Fecha de inicio del bloqueo.
   * @param factor Factor para determinar la duración del bloqueo (Crece a razón de 0.5)
   * @param ec Contexto de ejecución para las operaciones concurrentes.
   * @return Futuro con el estado de la operación.
   */
  def save( dni: String, since: Long, factor: Double )( implicit ec: ExecutionContext ): Future[ LastError ] = wrapper.insert( Blacklist( dni = encode( dni ), since = new DateTime( since ), factor = factor ) )
}
