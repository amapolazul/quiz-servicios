package com.arlsura.afiliacion.bussiness.code

import com.arlsura.afiliacion.persistence.daos.wrappers.SecurityCodeWrapper
import com.google.inject.AbstractModule
import net.codingwell.scalaguice.ScalaModule

/**
 * Created by Jesús Martínez on 25/06/15.
 */
class SecurityCodeServiceHandlerModule extends AbstractModule with ScalaModule {
  def configure(): Unit = {
    bind[ SecurityCodeWrapper ]
    bind[ SecurityCodeManager ]
  }
}
