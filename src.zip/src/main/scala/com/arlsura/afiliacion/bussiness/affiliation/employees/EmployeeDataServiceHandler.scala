package com.arlsura.afiliacion.bussiness.affiliation.employees

import java.util.Date
import com.arlsura.afiliacion.bussiness.HandlerSupport.ServiceHandlerResponse
import com.arlsura.afiliacion.bussiness.RequestContextSupport
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.{ SaveEmployeesData, GeneralJsonResponseData }
import com.arlsura.afiliacion.utils.Utils
import com.arlsura.afiliacion.utils.messages.MessagesRetriever
import spray.http.StatusCodes
import spray.routing.RequestContext
import EmployeeDataServiceHandler._
import scala.concurrent.{ ExecutionContext, Future }
import scala.util.{ Failure, Success }
import com.google.inject.Inject
import scala.concurrent.ExecutionContext.Implicits.global

/**
 * Maneja las peticiones asociadas al guardado parcial de información de trabajadores.
 */
class EmployeeDataServiceHandler @Inject() ( private val repository: EmployeeDataRepository ) {

  /**
   * Obtiene el documento asociado al DNI ingresado y completa la solicitud.
   * @param dni Número de identificación utilizado como clave de búsqueda.
   */
  def retrieveEmployeesData( dni: String )( implicit ec: ExecutionContext ): Future[ ServiceHandlerResponse ] = {
    repository.findByDni( dni ) map {
      option =>

        /*
        Se genera una respuesta adecuada dependiendo de si la consulta produjo o no resultados.
         */
        val payload: GeneralJsonResponseData = option.map {
          r => GeneralJsonResponseData( message = retrieveEmployeesSuccessMessage, suraSessionManager = getSessionString( dni ), data = Some( r ) )
        }.getOrElse {
          GeneralJsonResponseData( message = noEmployeesSuccessMessage, suraSessionManager = getSessionString( dni ) )
        }

        Right( payload )
    } recover {
      case e: Throwable =>
        Left( errorOccurredMessage( e.toString ) )
    }
  }

  /**
   * Guarda la información de contactos en base de datos, bien sea creando un nuevo documento o
   * actualizando uno ya existente.
   * @param request Información a ser guardada.
   */
  def saveEmployeesData( request: SaveEmployeesData )( implicit ec: ExecutionContext ): Future[ ServiceHandlerResponse ] = {
    repository.createOrUpdate( request.dni, request.securityCode, request.employees ) map {
      status =>
        if ( status.ok ) {
          val payload = GeneralJsonResponseData( message = saveEmployeesSuccessMessage, suraSessionManager = getSessionString( request.dni ) )
          Right( payload )
        }
        else {
          Left( errorOccurredMessage( status.errMsg.getOrElse( "MongoDB-Error" ) ) )
        }
    } recover {
      case e: Throwable =>
        Left( errorOccurredMessage( e.toString ) )
    }
  }

  /**
   * Genera una cadena de caracteres de sesión con base en el DNI.
   * @param dni DNI usado para generar la cadena.
   * @return
   */
  private def getSessionString( dni: String ): Option[ String ] = {
    val d = s"$dni-${new Date().getTime.toString}"
    Some( Utils.encodeFile( d.getBytes ) )
  }
}

object EmployeeDataServiceHandler {
  //mensajes de error y de exito para las respuestas
  val retrieveEmployeesSuccessMessage: String = MessagesRetriever.getSuccessMessage( "affiliation.employees", "RETRIEVE" )
  val noEmployeesSuccessMessage: String = MessagesRetriever.getSuccessMessage( "affiliation.employees", "NO_EMPLOYEES" )
  val saveEmployeesSuccessMessage: String = MessagesRetriever.getSuccessMessage( "affiliation.employees", "SAVE" )
  def errorOccurredMessage( error: String ): String = s"Ocurrión un error: $error"
}
