package com.arlsura.afiliacion.bussiness.salary

import akka.actor.ActorSelection
import akka.pattern._
import com.arlsura.afiliacion.actors.cache.CacheRefresherActor
import com.arlsura.afiliacion.bussiness.HandlerSupport.ServiceHandlerResponse
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.GeneralJsonResponseData
import com.arlsura.afiliacion.persistence.cache.entities.SalaryCache
import com.arlsura.afiliacion.utils.GlobalParamsProvider
import scala.concurrent.{ ExecutionContext, Future }

/**
 * Created by Jesús Martínez on 31/03/15.
 */
class SalaryServiceHandler( cacheActor: ActorSelection ) extends GlobalParamsProvider {
  /**
   * Obtiene el valor del salario mínimo vigente almacenado en cache.
   */
  def retrieveMinimumSalary()( implicit ec: ExecutionContext ): Future[ ServiceHandlerResponse ] = {
    getMinimumSalary map {
      salary =>
        Right( GeneralJsonResponseData( "Respuesta exitosa", Some( Map( "salary" -> salary.amount ) ) ) )
    } recover {
      case e: Throwable => Left( e.toString )
    }
  }

  /**
   * Trae el valor del salario mínimo de cache, a través de una consulta al actor que lo contiene.
   * @return Futuro con el valor del salario.
   */
  private def getMinimumSalary( implicit ec: ExecutionContext ): Future[ SalaryCache ] = {
    val askableActor = new AskableActorSelection( cacheActor )
    val ask = ( askableActor ? CacheRefresherActor.GetSalaryValue ).mapTo[ CacheRefresherActor.SalaryValueReturned ]
    ask.map( _.salary )
  }
}
