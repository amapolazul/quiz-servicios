package com.arlsura.afiliacion.bussiness.cache

import com.arlsura.afiliacion.bussiness.legal_natures.LegalNatures
import com.arlsura.afiliacion.persistence.cache.entities.LegalNaturesCache

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

/**
 * Created by Jesús Martínez on 24/04/15.
 */
object LegalNaturesRefresher {
  /**
   * @return Colección de datos provenientes del servicio exterior.
   */
  def consumeService() = {
    for {
      records <- LegalNatures.retrieveRecords().map( _.data )
    } yield if ( records.nonEmpty ) {
      Some( records )
    }
    else {
      None
    }
  }

  /**
   *
   * @return
   */
  def refresh( defaultResult: => Seq[ LegalNaturesCache ] ): Future[ Seq[ LegalNaturesCache ] ] = {
    consumeService().map {
      option =>
        option.map {
          records =>
            for ( r <- records ) yield LegalNaturesCache(
              code = r.cdnaturaleza_juridica,
              description = r.dsnaturaleza,
              dni = r.dni_ingresa,
              officialEntityCode = r.cdentidad_oficial //,
            //startDate = r.fealta.map( new DateTime( _ ) ),
            //endDate = r.febaja.map( new DateTime( _ ) )
            )
        }.getOrElse( defaultResult )
    }.recover {
      case _ => defaultResult
    }
  }
}
