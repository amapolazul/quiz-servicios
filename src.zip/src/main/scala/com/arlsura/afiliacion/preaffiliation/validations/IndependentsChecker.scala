package com.arlsura.afiliacion.preaffiliation.validations
import akka.actor.ActorSystem
import com.arlsura.afiliacion.bussiness.authentication.factory.{ Credentials, AuthenticationFactory }
import com.arlsura.afiliacion.bussiness.authentication.implementations.SeusAuthenticationImplementation
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.SeusAuthenticationResponse
import com.arlsura.afiliacion.utils.Utils
import com.typesafe.scalalogging.LazyLogging
import spray.httpx.SprayJsonSupport
import spray.json.DefaultJsonProtocol
import spray.client.pipelining._
import scala.concurrent.duration._
import scala.concurrent.{ Await, Future }

/**
 * Objeto que consumer servicio de venta informacion rest para consultar si un usuario tiene independientes
 * afiliados a la ARL SURA
 */
object IndependentsChecker extends LazyLogging {
  implicit val system = ActorSystem( "independents-checker-actor-system" )
  import system.dispatcher

  private object JsonFormats extends DefaultJsonProtocol {
    implicit val independentsFormat = jsonFormat1( Independents )
    implicit val independentsCheckerResponseFormat = jsonFormat1( IndependentsCheckerResponse )
    implicit val independentsCheckerServiceResponseFormat = jsonFormat3( IndependentsCheckerServiceResponse )
  }

  /**
   * Verifica si un usuario tiene independientes afiliados a la ARL
   * @param dni
   * @return Futuro con la respuesta, true si tiene independientes, false de lo contrario
   */
  def hasIndependents( dni: String ): Future[ Boolean ] = {
    import JsonFormats._
    import SprayJsonSupport._

    val authentication: SeusAuthenticationImplementation = AuthenticationFactory.apply( "seus" )
    val credentials: Credentials = AuthenticationFactory.getCredentials()
    val responseAuth: Future[ SeusAuthenticationResponse ] = authentication.authenticate( credentials.username, credentials.password )

    val independentsFinalResponse: Future[ Boolean ] = responseAuth map {
      authResponse =>
        {
          val pipeline =
            addHeader( "Access_Token", authResponse.tokenMus ) ~>
              sendReceive ~> unmarshal[ IndependentsCheckerServiceResponse ]
          val response: Future[ IndependentsCheckerServiceResponse ] = pipeline {
            Get( retrieveIndependentsCheckUrl() )
          }

          val futureResult: IndependentsCheckerServiceResponse = Await.result( response, 10 seconds )
          futureResult.data.independents.isEmpty
        }
    } recover {
      case _ =>
        false
    }

    independentsFinalResponse

  }

  /**
   * Construye la URL para llamar al servicio REST de venta informacion rest
   * @return URL : String
   */
  private def retrieveIndependentsCheckUrl(): String = {
    Utils.getVentaInformacionUrl + Utils.getProperty( "ventainformacion.", "independents" ).asInstanceOf[ String ]
  }
}

/**
 *
 * @param dni
 */
case class Independents( dni: String )

/**
 * Respuesta del servicio
 * @param independents Lista de independientes
 */
case class IndependentsCheckerResponse( independents: List[ Independents ] )

/**
 * Respuesta estandar del servicio de venta informacion en donde data es de tipo IndependentsCheckerResponse
 * @param status
 * @param message
 * @param data Respuesta del servicio
 */
case class IndependentsCheckerServiceResponse( status: Int, message: String, data: IndependentsCheckerResponse )
