package com.arlsura.afiliacion.preaffiliation.validations

import com.arlsura.afiliacion.bussiness.SoapConsumerSupport
import org.joda.time.DateTime
import org.joda.time.format.DateTimeFormat

import scala.concurrent.Future
import co.com.sura.ventainformacion.service.{ EmpresasActivasDTO, EmpresaAfiliacionesFacadeWSInterfaceProxy }
import com.arlsura.afiliacion.utils.Utils
import scala.concurrent.ExecutionContext.Implicits.global

import AffiliationSoapChecker._

/**
 * Created by Jorge Vargas on 26/05/15.
 */
class AffiliationSoapChecker extends SoapConsumerSupport {

  private lazy val naturesServiceUrl = Utils.getProperty( "soap.services.", "affiliation" ).asInstanceOf[ String ]
  private lazy val legalNaturesConsumer = new EmpresaAfiliacionesFacadeWSInterfaceProxy( naturesServiceUrl, this.username, this.password )

  val format = DateTimeFormat.forPattern( "YYYY-MM-dd" )

  def loadAffiliationState( dni: String ): Future[ State ] = {
    Future {
      val companies: Array[ EmpresasActivasDTO ] = legalNaturesConsumer.validarEmpresasActivas( Array( dni ) )
      if ( companies != null && companies.length > 0 && companies( 0 ).getFechaBaja != null ) {
        val company: EmpresasActivasDTO = companies( 0 )
        val datetime: DateTime = format.parseDateTime( company.getFechaBaja )
        if ( dateIsGreaterOrEqual( datetime, new DateTime() ) && company.getSnAfiliada == null )
          State( affiliated = true, withIndependents = false, notAffiliated = false )
        else if ( dateIsGreaterOrEqual( datetime, new DateTime() ) && company.getSnAfiliada == "N" ) {
          State( affiliated = false, withIndependents = true, notAffiliated = false )
        }
        else {
          State( affiliated = false, withIndependents = false, notAffiliated = true )
        }
      }
      else {
        State( affiliated = false, withIndependents = false, notAffiliated = true )
      }
    }
  }

  private def dateIsGreaterOrEqual( date1: DateTime, date2: DateTime ): Boolean = date1.compareTo( date2 ) >= 0

}

object AffiliationSoapChecker {

  case class State( affiliated: Boolean, withIndependents: Boolean, notAffiliated: Boolean )

}