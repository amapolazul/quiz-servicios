package com.arlsura.afiliacion.preaffiliation.validations

import com.arlsura.afiliacion.bussiness.SoapConsumerSupport
import com.arlsura.afiliacion.utils.Utils
import com.sura.arl.servicioportales.consumer.ServicioPortalesConsumer
import com.typesafe.scalalogging.LazyLogging

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

/**
 * Created by Jesús Martínez on 13/11/14.
 * Objecto encargado de validar que una empresa tiene clave de Servicios en Línea.
 * Para ello, debe consumir un servicio SOAP provisto por Sura.
 */
object KeyExistenceChecker extends LazyLogging with SoapConsumerSupport {

  private val admin: String = "ArpSura"
  private val clientType: String = "Administrador Empresa"
  private val serviceUrl: String = Utils.getProperty( "soap.services.", "portales" ).asInstanceOf[ String ]

  /**
   * Consume servicio SOAP para verificar si un afiliado a la ARL SURA tiene clave para acceder al portal de
   * servicios en linea
   * @param dni
   * @return Futuro de la respuesta del servicio, true si tiene clave, false de lo contrario
   */
  def checkKeyExistence( dni: String ): Future[ Boolean ] = {
    val consumer: ServicioPortalesConsumer = new ServicioPortalesConsumer( serviceUrl )
    Future {
      consumer.authenticateToProxy( this.cloudProxyHost, this.cloudProxyPort, this.cloudProxyUser, this.cloudProxyPassword )
      val response = consumer.validateAdministratorByEnterprise( dni, admin, clientType )
      //      logger.debug( s"KeyExistence service response: $response" )
      response
    }
  }

}
