package com.arlsura.afiliacion.preaffiliation

import java.util.Date

import com.arlsura.afiliacion.bussiness.RequestContextSupport
import com.arlsura.afiliacion.bussiness.affiliation.PreaffiliationManager
import com.arlsura.afiliacion.bussiness.code.SecurityCodeManager
import com.arlsura.afiliacion.bussiness.code.SecurityCodeManager.SecurityCodeDigest
import com.arlsura.afiliacion.bussiness.independents.IndependentsManager
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.GeneralJsonResponseData
import com.arlsura.afiliacion.persistence.daos.wrappers.{ SecurityCodeWrapper, PreAffiliationWrapper }
import com.arlsura.afiliacion.persistence.entities.{ PreAffiliation, SelfEmployee }
import com.arlsura.afiliacion.preaffiliation.validations.AffiliationSoapChecker
import com.arlsura.afiliacion.preaffiliation.validations.AffiliationSoapChecker.State
import com.arlsura.afiliacion.utils.messages.MessagesRetriever
import com.arlsura.afiliacion.utils.{ DNIBuilder, GlobalParamsProvider }
import spray.http.StatusCodes
import spray.routing.RequestContext

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future
import scala.concurrent.duration._
import scala.util.{ Failure, Success }

/**
 * Created by root on 5/02/15.
 */
class PreaffiliationPrevalidation( requestContext: RequestContext ) extends GlobalParamsProvider with RequestContextSupport {

  import PreaffiliationPrevalidation._

  def futureRequests( implicit after: Duration, docType: String, document: String ): Future[ PreaffiliationPrevalidationState ] = {
    val dni = DNIBuilder.build( docType, document )
    val affiliationStateFuture: Future[ State ] = new AffiliationSoapChecker().loadAffiliationState( dni )
    val hasCodeFuture: Future[ Option[ SecurityCodeDigest ] ] = new SecurityCodeManager( new SecurityCodeWrapper ).hasCode( dni )
    val preAffiliationFuture: Future[ Option[ PreAffiliation ] ] = new PreaffiliationManager( new PreAffiliationWrapper ).getPreAffiliationByDni( dni )
    val independentFuture: Future[ Option[ SelfEmployee ] ] = new IndependentsManager().get( dni )

    for {
      affiliationState <- affiliationStateFuture
      code <- hasCodeFuture
      preAffiliation <- preAffiliationFuture
      independent <- independentFuture
    } yield buildResponse( affiliationState.affiliated, affiliationState.withIndependents, false, preAffiliation, code, independent )

  }

  /**
   * Realiza las diferentes validaciones sobre un usuario con un DNI dado. Las validaciones que se hacen son:
   *  -es afiliado
   *  -tiene clave para servicios en linea
   *  -tiene independientes afiliados
   *  -tiene preafiliacion
   * @param docType
   * @param document
   */
  def check( docType: String, document: String ): Unit = {
    futureRequests( TIMEOUT, docType, document ) onComplete {
      case Success( prevalidationState ) =>
        complete( requestContext, StatusCodes.OK, GeneralJsonResponseData( getSuccessMessage, Some( prevalidationState ) ) )
      case Failure( t ) =>
        //        t.printStackTrace
        completeWithFailure( requestContext, t.getMessage )
    }
  }

  def buildResponse( isAffiliated: Boolean, hasIndependents: Boolean, hasKey: Boolean, preaffiliation: Option[ PreAffiliation ], code: Option[ SecurityCodeDigest ] = None, independentOption: Option[ SelfEmployee ] ): PreaffiliationPrevalidationState = {
    val lastEntranceDate: Option[ Date ] = independentOption match {
      case Some( independent ) =>
        Some( independent.lastEntrance.toDate )
      case None =>
        None
    }
    PreaffiliationPrevalidationState(
      isAffiliated = isAffiliated,
      hasIndependents = hasIndependents,
      hasKey = hasKey,
      code = code,
      hasPreaffiliation = preaffiliation.isDefined,
      lastEntranceDate = lastEntranceDate,
      rejectedBySegementation = preaffiliation match {
      case None => None
      case Some( pre ) => pre.segmentation match {
        case None                 => None
        case Some( segmentation ) => Some( !segmentation.affiliationApproved )
      }
    }
    )
  }

}

/**
 * Companion Object PreaffiliationPrevalidation
 */
object PreaffiliationPrevalidation {

  def getSuccessMessage = MessagesRetriever.getSuccessMessage( "preaffiliationValidation", "ALL_REQUESTS_COMPLETED_SUCCESFULLY" )

}

/**
 * Respuesta de todas las validaciones
 * @param isAffiliated
 * @param hasIndependents
 * @param hasKey
 * @param hasPreaffiliation
 * @param code
 */
case class PreaffiliationPrevalidationState(
  isAffiliated:            Boolean,
  hasIndependents:         Boolean,
  hasKey:                  Boolean,
  hasPreaffiliation:       Boolean,
  code:                    Option[ SecurityCodeDigest ] = None,
  lastEntranceDate:        Option[ Date ]               = None,
  isNewCompany:            Option[ Boolean ]            = None,
  rejectedBySegementation: Option[ Boolean ]            = Some( false )
)
