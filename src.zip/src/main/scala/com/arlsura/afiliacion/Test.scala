//package com.arlsura.afiliacion
//
//  private lazy val injector = Guice.createInjector( new PDFFileGeneratorServiceModule() )
//
//  lazy val handler: PDFFileGeneratorServiceHandler = injector.instance[ PDFFileGeneratorServiceHandler ]
//  val pdfFuture: Future[ ServiceFileHandlerResponse ] = handler.createPDF( "1122" )
//  //  val salt = "This is salty."
//import com.typesafe.scalalogging.LazyLogging
//import scala.io.Source
//import com.arlsura.afiliacion.persistence.scripts.CacheBackupManager._
//import spray.json._
//
//import scala.util.control.NonFatal
//
//
///**
// * Created by Jesús Martínez on 28/07/15.
// */
//object Test extends App with LazyLogging {
//
//  import com.arlsura.afiliacion.persistence.scripts.CacheBackupManager._
//  import spray.json._
//
//  private val salary: SalaryCache = SalaryRefresher.refresh(SalaryCache(amount = 0.0))
//  private val econActs: Seq[EconomicActivityCache] = EconomicActivitiesRefresher.refresh(List.empty)
//  private val addresses: Seq[AddressCache] = AddressesRefresher.refresh(List.empty)
//  private val arps: Seq[ARPCache] = ARPRefresher.refresh(List.empty)
//  private val afps: Seq[AFPCache] = AFPRefresher.refresh(List.empty)
//  private val eps: Seq[EPSCache] = EPSRefresher.refresh(List.empty)
//  private val contributors: Seq[ContributorTypeCache] = ContributorsTypesRefresher.refresh(List.empty)
////  //val legalNatures :  [ Seq[ LegalNaturesCache ] ] = LegalNaturesRefresher.refresh( legalNaturesCatalog
//  private val legalNatures: Seq[LegalNaturesCache] = LegalNatureSoapRefresher.refresh(List.empty)
//
//
//
//  private def writeBackup[T](collectionName: String, collection: Seq[T])(implicit jsonWriter: JsonWriter[T]) = {
//
//    logger.debug(s"Writing backup for collection: $collectionName")
//    logger.debug(s"These are the objects before serialization: $collection")
//    logger.debug(s"${collection.length} elements to save in collection $collectionName")
//
//    val filename = s"/opt/app/backups/${collectionName}_backup.txt"
//    val fileWriter = new FileWriter(filename, false)
//
//    val data = collection.map(_.toJson).mkString("%%%")
//    logger.debug(s"About to write $data in file named $filename...")
//
//    try {
//      fileWriter.write(data)
//    } catch {
//      case NonFatal(t) =>
//        logger.debug(s"There was an error writing into file $filename.")
//        logger.debug(s"Description: ${t.toString}")
//        t.printStackTrace()
//    } finally {
//      logger.debug(s"Closing file $filename...")
//      fileWriter.close()
//    }
//  }
//
//  private def loadBackup[T](collectionName: String)(implicit jsonReader: JsonReader[T]): Seq[T] = {
//    //logger.debug(s"Loading backup for collection: $collectionName")
//
//    val filename = s"/opt/app/backups/${collectionName}_backup.txt"
//    val data = Source.fromFile(filename).getLines().next().filterNot(_.isControl)
//    println(data)
//
//    val result = data.split("%%%").toSeq.map(_.parseJson.convertTo[T])
//
//    //logger.debug(s"Successfully read file. Here's the data:\n $result")
//    result
//  }
//
//
////  writeBackup("addresses", addresses)
////  writeBackup("afps", afps)
////  writeBackup("arps", arps)
////  writeBackup("eps", eps)
////  writeBackup("legal_natures", legalNatures)
////  writeBackup("contributor_types", contributors)
////  writeBackup("salary", List(salary))
//  //writeBackup("economic_activities", econActs)
////
////  logger.debug("----------------------------------------------------------------------------------------------------------------------------------------\n" * 5)
////  loadBackup[AFPCache]("afps")
////  loadBackup[ARPCache]("arps")
////  loadBackup[EPSCache]("eps")
////  loadBackup[LegalNaturesCache]("legal_natures")
////  loadBackup[ContributorTypeCache]("contributor_types")
////  loadBackup[SalaryCache]("salary")
////  loadBackup[AddressCache]("addresses")
////  loadBackup[EconomicActivityCache]("economic_activities")
//
//  val data: String = Utils.getProperty("backups.", "addresses").asInstanceOf[String]
//
//  data.split("%%%").foreach {
//    element => println(element.parseJson.convertTo[AddressCache])
//  }
//
//  val data2: String = Utils.getProperty("backups.", "eps").asInstanceOf[String]
//  data2.split("%%%").foreach {
//    element => println(element.parseJson.convertTo[EPSCache])
//  }
//
//  val data3: String = Utils.getProperty("backups.", "afps").asInstanceOf[String]
//  data3.split("%%%").foreach {
//    element => println(element.parseJson.convertTo[AFPCache])
//  }
//
//  val data4: String = Utils.getProperty("backups.", "arps").asInstanceOf[String]
//  data4.split("%%%").foreach {
//    element => println(element.parseJson.convertTo[ARPCache])
//  }
//
//  val data5: String = Utils.getProperty("backups.", "legal_natures").asInstanceOf[String]
//  data5.split("%%%").foreach {
//    element => println(element.parseJson.convertTo[LegalNaturesCache])
//  }
//
//  val data6: String = Utils.getProperty("backups.", "salary").asInstanceOf[String]
//  data6.split("%%%").foreach {
//    element => println(element.parseJson.convertTo[SalaryCache])
//  }
//
//  val data7: String = Utils.getProperty("backups.", "contributor_types").asInstanceOf[String]
//  data7.split("%%%").foreach {
//    element => println(element.parseJson.convertTo[ContributorTypeCache])
//  }
//
//  val data8: String = Utils.getProperty("backups.", "economic_activities").asInstanceOf[String]
//  data8.split("%%%").foreach {
//    element => println(element.parseJson.convertTo[EconomicActivityCache])
//  }
//
//
//}
