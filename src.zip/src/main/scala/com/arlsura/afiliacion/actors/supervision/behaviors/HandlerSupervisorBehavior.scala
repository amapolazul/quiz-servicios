package com.arlsura.afiliacion.actors.supervision.behaviors

import akka.actor.SupervisorStrategy.{ Resume, Stop }
import akka.actor.{ Actor, ActorInitializationException, ActorKilledException, DeathPactException }
import com.arlsura.afiliacion.actors.supervision.factories.OneForOneStrategyFactory
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.GeneralJsonResponseData
import spray.http.StatusCodes
import spray.routing.RequestContext

import scala.concurrent.duration.Duration

/**
 * Created by Jesús Martínez on 3/02/15.
 */

/**
 * Se define el comportamiento de los handlers de aquellos servicios que consultan recursos externos a la aplicación.
 */
trait HandlerSupervisorBehavior extends Actor with OneForOneStrategyFactory {
  //Contexto del request atendido por el handler.
  private var requestContext: Option[ RequestContext ] = None

  protected final def setContext( context: RequestContext ): Unit = {
    requestContext = Some( context )
  }

  //El supervisor matará a sus hijos si tienen problemas en su ciclo de vida. En otro caso, retornará el error
  //como respuesta y dará continuidad al trabajo de sus subordinados.
  override final def supervisorStrategy = makeStrategy( -1, Duration.Inf ) {
    case _: ActorInitializationException => Stop
    case _: ActorKilledException         => Stop
    case _: DeathPactException           => Stop
    case e: Throwable =>
      complete( e )
      Resume
  }

  //Completa el contexto con un error.
  private final def complete( e: Throwable ) = {
    val response: GeneralJsonResponseData =
      GeneralJsonResponseData( "Ha ocurrido un error", Some( e.toString ) )
    requestContext.foreach( _ complete response )
    requestContext = None
  }

  //Completa el context con una respuesta distinta a error.
  protected final def complete( r: GeneralJsonResponseData ) = {
    requestContext.foreach( _ complete r )
    requestContext = None
  }
}
