package com.arlsura.afiliacion.actors.cache

import akka.actor.{ ActorRef, Props }
import com.arlsura.afiliacion.actors.cache.CacheRefresherActor._
import com.arlsura.afiliacion.actors.commons.VerboseActor
import com.arlsura.afiliacion.bussiness.cache._
import com.arlsura.afiliacion.persistence.cache.entities._
import com.arlsura.afiliacion.utils.cache._
import com.arlsura.afiliacion.utils.cache.CacheBackupManager._
import com.typesafe.scalalogging.LazyLogging
import spray.json.JsonReader
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future
import scala.util.{ Failure, Success }

/**
 * Created by Jesús Martínez on 24/03/15.
 */
class CacheRefresherActor extends VerboseActor with LazyLogging {

  private lazy val EPS = "eps"
  private lazy val AFPS = "afps"
  private lazy val ECON_ACTS = "economic_activities"
  private lazy val SALARY = "salary"
  private lazy val ARPS = "arps"
  private lazy val LEGAL_NATS = "legal_natures"
  private lazy val CONTR_TYPES = "contributor_types"
  private lazy val ADDRSS = "addresses"
  private lazy val CHARGES = "charges"

  lazy val backupManager = new CacheBackupManager()
  /*
    Variables de estado del actor:
    Acá se almacenan cada uno de los catálogos. Este es nuestro cache.
   */
  private var minimumSalary: SalaryCache = SalaryCache( amount = 0.0 )
  private var legalNaturesCatalog: Seq[ LegalNaturesCache ] = List.empty
  private var epsCatalog: Seq[ EPSCache ] = List.empty
  private var addressesInformationCatalog: Seq[ AddressCache ] = List.empty
  private var arpCatalog: Seq[ ARPCache ] = List.empty
  private var contributorsTypesCatalog: Seq[ ContributorTypeCache ] = List.empty
  private var afpCatalog: Seq[ AFPCache ] = List.empty
  private var economicActivitiesCatalog: Seq[ EconomicActivityCache ] = List.empty
  private var chargesCatalog: Seq[ ChargeCache ] = List.empty

  private def spawnHandler( os: ActorRef, data: Any ): ActorRef = context.actorOf( AnonymousHandler.props( os, data ) )

  // Sobreescribimos postRestart para no llamar preStart, evitando encolar un nuevo mensaje.
  override def postRestart( reason: Throwable ): Unit = {}

  private def getOrUseBackup[ T ]( l: Seq[ T ], collectionName: => String )( implicit jReader: JsonReader[ T ] ): Seq[ T ] = {
    if ( l.nonEmpty ) {
      //      logger.debug( s"Non empty collection: $l" )
      l
    }
    else {
      //      logger.debug( s"The collection $collectionName is empty. Using backup..." )
      backupManager.loadBackup[ T ]( collectionName )
    }
  }

  override def receive = {
    case Refresh =>
      //      logger.debug( s"'REFRESH' message received at ${new GregorianCalendar().getTime}" )
      context.system.scheduler.scheduleOnce( 24.hours, self, CacheRefresherActor.Refresh )

      /*
         Se inician los futuros.
       */
      val chargesFuture: Future[ Seq[ ChargeCache ] ] = Future( backupManager.loadBackup[ ChargeCache ]( CHARGES ) )
      val salaryFuture: Future[ SalaryCache ] = Future( SalaryRefresher.refresh( minimumSalary ) )
      val econActsFuture: Future[ Seq[ EconomicActivityCache ] ] = Future( EconomicActivitiesRefresher.refresh( economicActivitiesCatalog ) )
      val addressesFuture: Future[ Seq[ AddressCache ] ] = Future( AddressesRefresher.refresh( addressesInformationCatalog ) )
      val arpsFuture: Future[ Seq[ ARPCache ] ] = Future( ARPRefresher.refresh( arpCatalog ) )
      val afpsFuture: Future[ Seq[ AFPCache ] ] = Future( AFPRefresher.refresh( afpCatalog ) )
      val epsFuture: Future[ Seq[ EPSCache ] ] = Future( EPSRefresher.refresh( epsCatalog ) )
      val contributorsFuture: Future[ Seq[ ContributorTypeCache ] ] = Future( ContributorsTypesRefresher.refresh( contributorsTypesCatalog ) )
      val legalNaturesFuture: Future[ Seq[ LegalNaturesCache ] ] = Future( LegalNatureSoapRefresher.refresh( legalNaturesCatalog ) )

      salaryFuture onComplete {
        case Success( ms ) =>
          if ( ms.amount != 0.0 ) {
            minimumSalary = ms
          }
          else {
            minimumSalary = backupManager.loadBackup[ SalaryCache ]( SALARY ).head
          }
        //          logger.debug( "Minimum wage: " + minimumSalary.amount )
        case Failure( f ) =>
          //          logger.debug( "An error has occurred: " + f.getCause.toString )
          //          logger.debug( "Using backup..." )
          minimumSalary = backupManager.loadBackup[ SalaryCache ]( SALARY ).head
      }

      econActsFuture onComplete {
        case Success( eas ) =>
          economicActivitiesCatalog = getOrUseBackup( eas, ECON_ACTS )
        //          logger.debug( "Actividades económicas: " + economicActivitiesCatalog.length )
        case Failure( f ) =>
          //          logger.debug( "An error has occurred: " + f.getCause.toString )
          //          logger.debug( "Using backup..." )
          economicActivitiesCatalog = backupManager.loadBackup[ EconomicActivityCache ]( ECON_ACTS )
      }

      addressesFuture onComplete {
        case Success( as ) =>
          addressesInformationCatalog = getOrUseBackup( as, ADDRSS )
        //          logger.debug( "Addresses: " + addressesInformationCatalog.length )
        case Failure( f ) =>
          //          logger.debug( "An error has occurred: " + f.getCause.toString )
          //          logger.debug( "Using backup..." )
          addressesInformationCatalog = backupManager.loadBackup[ AddressCache ]( ADDRSS )
      }

      arpsFuture onComplete {
        case Success( arps ) =>
          arpCatalog = getOrUseBackup( arps, ARPS )
        //          logger.debug( "ARPs: " + arpCatalog.length )
        case Failure( f ) =>
          //          logger.debug( "An error has occurred: " + f.getCause.toString )
          //          logger.debug( "Using backup..." )
          arpCatalog = backupManager.loadBackup[ ARPCache ]( ARPS )
      }

      afpsFuture onComplete {
        case Success( afps ) =>
          afpCatalog = getOrUseBackup( afps, AFPS )
        //          logger.debug( "AFPs: " + afpCatalog.length )
        case Failure( f ) =>
          //          logger.debug( "An error has occurred: " + f.getCause.toString )
          //          logger.debug( "Using backup..." )
          afpCatalog = backupManager.loadBackup[ AFPCache ]( AFPS )
      }

      epsFuture onComplete {
        case Success( eps ) =>
          epsCatalog = getOrUseBackup( eps, EPS )
        //          logger.debug( "EPSs: " + epsCatalog.length )
        case Failure( f ) =>
          //          logger.debug( "An error has occurred: " + f.getCause.toString )
          //          logger.debug( "Using backup..." )
          epsCatalog = backupManager.loadBackup[ EPSCache ]( EPS )
      }

      contributorsFuture onComplete {
        case Success( cts ) =>
          contributorsTypesCatalog = getOrUseBackup( cts, CONTR_TYPES )
        //          logger.debug( "Contributor types: " + contributorsTypesCatalog.length )
        case Failure( f ) =>
          //          logger.debug( "An error has occurred: " + f.getCause.toString )
          //          logger.debug( "Using backup..." )
          contributorsTypesCatalog = backupManager.loadBackup[ ContributorTypeCache ]( CONTR_TYPES )
      }

      legalNaturesFuture onComplete {
        case Success( lns ) =>
          legalNaturesCatalog = getOrUseBackup( lns, LEGAL_NATS )
        //          logger.debug( "Juridical Natures (SOAP): " + legalNaturesCatalog.length )
        case Failure( f ) =>
          //          logger.debug( "An error has occurred: " + f.getCause.toString )
          //          logger.debug( "Using backup..." )
          legalNaturesCatalog = backupManager.loadBackup[ LegalNaturesCache ]( LEGAL_NATS )
      }

      chargesFuture onComplete {
        case Success( chs ) =>
          chargesCatalog = getOrUseBackup( chs, CHARGES )
        case Failure( f ) =>
          chargesCatalog = backupManager.loadBackup[ ChargeCache ]( CHARGES )
      }

    case m @ GetAddressesInfoCatalog =>
      spawnHandler( sender(), addressesInformationCatalog ) ! m
    case m @ GetSalaryValue =>
      spawnHandler( sender(), minimumSalary ) ! m
    case m @ GetARPsCatalog =>
      spawnHandler( sender(), arpCatalog ) ! m
    case m @ GetAFPsCatalog =>
      spawnHandler( sender(), afpCatalog ) ! m
    case m @ GetEPSsCatalog =>
      spawnHandler( sender(), epsCatalog ) ! m
    case m @ GetContributorsTypes =>
      spawnHandler( sender(), contributorsTypesCatalog ) ! m
    case m @ GetLegalNaturesCatalog =>
      spawnHandler( sender(), legalNaturesCatalog ) ! m
    case m @ GetEconomicActivitiesCatalog =>
      spawnHandler( sender(), economicActivitiesCatalog ) ! m
    case m @ GetChargesCatalog =>
      spawnHandler( sender(), chargesCatalog ) ! m
  }
}

/**
 * Actor anónimo para manejar las solicitudes de CacheRefresherActor
 * @param originalSender Sender al que hay que enviar la respuesta.
 */
private class AnonymousHandler( originalSender: ActorRef, data: Any ) extends VerboseActor with LazyLogging {
  override def receive = {
    case GetAddressesInfoCatalog =>
      val msg = AddressInfoCatalogReturned( data.asInstanceOf[ Seq[ AddressCache ] ] )
      //      log.debug( "ANONYMOUS HANDLER::::: " + msg.catalog )
      sendAndTerminate( msg )
    case GetSalaryValue =>
      val msg = SalaryValueReturned( data.asInstanceOf[ SalaryCache ] )
      sendAndTerminate( msg )
    case GetARPsCatalog =>
      val msg = ARPsCatalogReturned( data.asInstanceOf[ Seq[ ARPCache ] ] )
      sendAndTerminate( msg )
    case GetAFPsCatalog =>
      val msg = AFPsCatalogReturned( data.asInstanceOf[ Seq[ AFPCache ] ] )
      sendAndTerminate( msg )
    case GetEPSsCatalog =>
      val msg = EPSsCatalogReturned( data.asInstanceOf[ Seq[ EPSCache ] ] )
      sendAndTerminate( msg )
    case GetContributorsTypes =>
      val msg = ContributorsTypesCatalogReturned( data.asInstanceOf[ Seq[ ContributorTypeCache ] ] )
      sendAndTerminate( msg )
    case GetLegalNaturesCatalog =>
      val msg = LegalNaturesCatalogReturned( data.asInstanceOf[ Seq[ LegalNaturesCache ] ] )
      sendAndTerminate( msg )
    case GetEconomicActivitiesCatalog =>
      val msg = EconomicActivitiesCatalogReturned( data.asInstanceOf[ Seq[ EconomicActivityCache ] ] )
      sendAndTerminate( msg )
    case GetChargesCatalog =>
      val msg = ChargesCatalogReturned( data.asInstanceOf[ Seq[ ChargeCache ] ] )
      sendAndTerminate( msg )
  }

  private def sendAndTerminate( msg: Any ): Unit = {
    //    logger.debug( s"Sending message $msg to actor ${originalSender.path}" )
    originalSender ! msg
    //    logger.debug( s"Stopping actor... ${self.path}" )
    context.stop( self )
  }
}

private object AnonymousHandler {
  //Factory method para obtener el 'props' de este actor.
  def props( os: ActorRef, d: Any ): Props = Props( new AnonymousHandler( os, d ) )
}

object CacheRefresherActor {
  /*
   *Mensajes de petición
   */
  case object Refresh
  case object GetAddressesInfoCatalog
  case object GetSalaryValue
  case object GetARPsCatalog
  case object GetAFPsCatalog
  case object GetEPSsCatalog
  case object GetContributorsTypes
  case object GetLegalNaturesCatalog
  case object GetEconomicActivitiesCatalog
  case object GetChargesCatalog

  /*
    Mensajes de respuesta
   */
  case class AddressInfoCatalogReturned( catalog: Seq[ AddressCache ] )
  case class SalaryValueReturned( salary: SalaryCache )
  case class ARPsCatalogReturned( catalog: Seq[ ARPCache ] )
  case class AFPsCatalogReturned( catalog: Seq[ AFPCache ] )
  case class EPSsCatalogReturned( catalog: Seq[ EPSCache ] )
  case class ContributorsTypesCatalogReturned( catalog: Seq[ ContributorTypeCache ] )
  case class LegalNaturesCatalogReturned( catalog: Seq[ LegalNaturesCache ] )
  case class EconomicActivitiesCatalogReturned( catalog: Seq[ EconomicActivityCache ] )
  case class ChargesCatalogReturned( catalog: Seq[ ChargeCache ] )

  //Factory method para obtener el 'props' de este actor.
  def props: Props = Props( new CacheRefresherActor )
}
