package com.arlsura.afiliacion.actors.handler

import akka.actor.{ PoisonPill, Props, ActorRef }
import com.arlsura.afiliacion.actors.commons.VerboseActor
import com.arlsura.afiliacion.actors.handler.ActorRequestHandler.{ SendResponseMessage, SendRequestMessage }
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.{ GeneralJsonResponseData, ExceptionOccurred }
import spray.http.StatusCodes
import spray.http.StatusCodes.{ ServerError, ClientError, Success }
import spray.routing.RequestContext

/**
 * Created by juanmartinez on 22/01/15.
 */
class ActorRequestHandler( actor: ActorRef, ctx: RequestContext ) extends VerboseActor {

  override def receive: Receive = {
    case SendRequestMessage( message ) =>
      actor ! message

    case SendResponseMessage( successResponse ) =>
      val response = GeneralJsonResponseData( successResponse.message, successResponse.data )
      sendAndComplete( response, successResponse.code )

    case ex: ExceptionOccurred =>
      val response = GeneralJsonResponseData( "Ocurrio un error consultando las actividades", Some( ex ) )
      sendAndComplete( response, StatusCodes.InternalServerError )
  }

  private def sendAndComplete( response: GeneralJsonResponseData, statusCode: Any ) = {
    statusCode match {
      case msg: Success =>
        ctx.complete( ( msg, response ) )
        context.stop( self )

      case msg: ClientError =>
        ctx.complete( ( msg, response ) )
        context.stop( self )

      case msg: ServerError =>
        ctx.complete( ( msg, response ) )
        context.stop( self )
    }
  }
}

object ActorRequestHandler {
  case class StandardResponse( data: Option[ Any ], message: String, code: Any )
  case class SendRequestMessage( message: Any )
  case class SendResponseMessage( response: StandardResponse )

  def props( actor: ActorRef, context: RequestContext ) = Props( new ActorRequestHandler( actor, context ) )

}
