package com.arlsura.afiliacion.actors.supervision

import akka.actor.{ Props, ActorRef, Actor }

/**
 * Created by Jesús Martínez on 28/01/15.
 * Supervisor que no mata a sus hijos cuando es reiniciado.
 *
 * NOTA IMPORTANTE: Ya no vamos a mantener una referencia a sus supervisados. ¿Por qué?
 * ¿Qué pasa si el supervisor muere? ¿Cómo recupera la referencia a esos actores?
 * En cambio, cada vez que creemos algún actor, se le asiganará un nombre proveniente de un archivo de configuración.
 * Así, cuando se necesite ese actor, se obtiene directamente esa referencia buscándolo por el nombre.
 */
trait IsolatedLifeCycleSupervisor extends Actor {

  //Debe ser definida por la subclase.
  def childStarter(): Unit

  //Antes de crear el supervisor, crear a sus hijos.
  final override def preStart(): Unit = {
    childStarter()
  }

  //No llamar a preStart, pues eso crearía clones de los hijos.
  final override def postRestart( reason: Throwable ): Unit = {}

  //No se detienen a los hijos, el cual sería el comportamiento por defecto.s
  final override def preRestart( reason: Throwable, message: Option[ Any ] ): Unit = {}
}
