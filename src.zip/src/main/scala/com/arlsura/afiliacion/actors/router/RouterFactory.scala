package com.arlsura.afiliacion.actors.router

import akka.actor.{ Props, OneForOneStrategy, SupervisorStrategy }
import akka.routing._

trait RouterFactory extends RouterDefaultsProvider {

  def makeRouter( routerType: String = "round-robin", nrOfInstances: Int = DEFAULT_POOL_SIZE, resizer: DefaultResizer = DEFAULT_RESIZER )( supervisionStrategy: Option[ SupervisorStrategy ] = None ) = {
    //Si hay una estrategia definida, se utiliza. Si no, se escalan todos los errores por defecto.
    val strategy: SupervisorStrategy = supervisionStrategy.getOrElse( OneForOneStrategy() {
      case _ ⇒ SupervisorStrategy.Escalate
    } )
    val rsz: Option[ DefaultResizer ] = Some( resizer )

    routerType.toLowerCase match {
      case "round-robin" => RoundRobinPool( nrOfInstances = nrOfInstances, resizer = rsz, supervisorStrategy = strategy )
    }
  }

  //Crea un router. Los hijos deben implementar esta función.
  def router: Props
}
