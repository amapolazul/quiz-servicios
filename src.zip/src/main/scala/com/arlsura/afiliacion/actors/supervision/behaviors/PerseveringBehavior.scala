package com.arlsura.afiliacion.actors.supervision.behaviors

import akka.actor.Actor

/**
 * Created by root on 2/02/15.
 */
trait PerseveringBehavior extends Actor {
  override final def preRestart( reason: Throwable, message: Option[ Any ] ) = {
    //Analizar bien esta opción. Lo que estamos haciendo es reenviar el mensaje al router para que lo atienda otro actor hermano mientras
    //este actor reinicia.
    //    context.parent.tell(message.get, sender)

    message foreach { self.forward }
  }
}
