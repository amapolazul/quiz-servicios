package com.arlsura.afiliacion.actors.supervision.factories

import akka.actor.AllForOneStrategy
import akka.actor.SupervisorStrategy._

import scala.concurrent.duration.Duration

/**
 * Created by Jesús Martínez on 28/01/15.
 */
trait AllForOneStrategyFactory extends SupervisionStrategyFactory {
  def makeStrategy( maxNumberOfRetries: Int, withinTimeRange: Duration )( decider: Decider ): AllForOneStrategy = AllForOneStrategy( maxNumberOfRetries, withinTimeRange )( decider )
}
