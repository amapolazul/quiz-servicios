package com.arlsura.afiliacion.actors

import java.net.MalformedURLException
import java.rmi.RemoteException
import javax.xml.soap.SOAPException

import akka.actor.SupervisorStrategy.{ Stop, Restart, Escalate }
import akka.actor._
import co.com.sura.ventainformacion.service._
import com.arlsura.afiliacion.actors.PersonsActor.{ GetPersonResponse, GetPersonRequest }
import com.arlsura.afiliacion.actors.commons.VerboseActor
import com.arlsura.afiliacion.actors.router.RouterFactory
import com.arlsura.afiliacion.actors.supervision.factories.OneForOneStrategyFactory
import com.arlsura.afiliacion.bussiness.persons.PersonsManager
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller._
import com.arlsura.afiliacion.utils.GlobalParamsProvider
import com.suramericana.assets.exceptions.{ TechnicalException, BusinessException }
import scala.concurrent.{ Await, Future }
import scala.concurrent.ExecutionContext.Implicits.global

/**
 * Created by juanmartinez on 15/11/14.
 */
class PersonsActor extends VerboseActor {
  this: /*PerseveringBehavior with */ GlobalParamsProvider =>
  override def receive: Receive = {

    case GetPersonRequest( dni ) =>
      val originalSender: ActorRef = sender
      val person: PersonaDTO = Await.result( Future( PersonsManager.getPersonExistByDni( dni ) ), TIMEOUT )

      //      log.debug( s"Consulta correctamente la persona $person" )
      val personaJsonMarshaller: Person =
        if ( person != null ) {
          new Person(
            dni = person.getDniPersona,
            docType = person.getTipoDocCortoPersona,
            document = person.getNumeroDocPersona,
            name = person.getPrimerNombre,
            secondName = person.getSegundoNombre,
            lastName = person.getSegundoApellido,
            secondLastName = person.getSegundoApellido,
            fullName = person.getNombreCompleto,
            exist = true
          )
        }
        else {
          new Person( exist = false )
        }

      originalSender ! GetPersonResponse( personaJsonMarshaller )
  }
}

/**
 * Companion object del actor.
 */
object PersonsActor extends RouterFactory with OneForOneStrategyFactory with GlobalParamsProvider {

  //Mensajes.
  case class GetPersonRequest( dni: String )
  case class GetPersonResponse( person: Person )

  val supervisionStrategy: OneForOneStrategy = makeStrategy( MX_NR_OF_RETRIES, TIME_WINDOW ) { //Estos valores deberían ir en un archivo de configuración
    case _: BusinessException     => Escalate //Si es un problema de negocio, se debe notificar.
    case _: TechnicalException    => Restart
    case _: RemoteException       => Restart //Si hay problemas en la red, reintentar.
    case _: MalformedURLException => Stop //Si la URL está mal formada, matar el actor, puesto que es un problema que debe ser
    //atendido estáticamente.
    case _: SOAPException         => Restart //Si sucedió algún problema, reintentar.
    case _: java.util.concurrent.TimeoutException =>
      Restart
    case _: Throwable => Escalate
  }

  //Factory method.
  def props(): Props = Props( new PersonsActor /*with PerseveringBehavior*/ with GlobalParamsProvider )

  //Factory para crear router.
  def router: Props = props().withRouter( makeRouter()( /*Some(supervisionStrategy)*/ ) )
}
