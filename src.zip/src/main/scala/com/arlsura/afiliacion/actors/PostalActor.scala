package com.arlsura.afiliacion.actors

import java.net.MalformedURLException
import java.rmi.RemoteException
import javax.xml.soap.SOAPException
import akka.actor.SupervisorStrategy.{ Stop, Restart, Escalate }
import akka.actor.{ OneForOneStrategy, ActorRef, Props }
import akka.pattern.AskTimeoutException
import com.arlsura.afiliacion.actors.PostalActor.{ MunicipalityConsultResponse, ConsultMunicipality }
import com.arlsura.afiliacion.actors.commons.VerboseActor
import com.arlsura.afiliacion.actors.router.RouterFactory
import com.arlsura.afiliacion.actors.supervision.behaviors.PerseveringBehavior
import com.arlsura.afiliacion.actors.supervision.factories.OneForOneStrategyFactory
import com.arlsura.afiliacion.bussiness.postal.PostalManager
import com.arlsura.afiliacion.utils.GlobalParamsProvider
import scala.concurrent.{ Future, Await }
import scala.concurrent.duration._
import com.suramericana.assets.exceptions.{ TechnicalException, BusinessException }
import scala.concurrent.ExecutionContext.Implicits.global

/**
 * Created by Jesús Martínez on 15/12/14.
 */
class PostalActor extends VerboseActor {
  this: /*PerseveringBehavior with */ GlobalParamsProvider =>
  override def receive = {
    case ConsultMunicipality( code ) =>
      val originalSender: ActorRef = sender
      //log.debug( s"Recibido mensaje ConsultMunicipality: $code" )
      val ( dc: String, bc: String ) = Await.result( Future( PostalManager.consultMunicipality( code ) ), TIMEOUT )
      originalSender ! MunicipalityConsultResponse( dc, bc )
  }

}

/**
 * Companion object del actor.
 */
object PostalActor extends RouterFactory with OneForOneStrategyFactory with GlobalParamsProvider {
  //Mensajes
  case class ConsultMunicipality( code: String )
  case class MunicipalityConsultResponse( delegationCode: String, branchCode: String )

  val supervisionStrategy: OneForOneStrategy = makeStrategy( MX_NR_OF_RETRIES, TIME_WINDOW ) { //Estos valores deberían ir en un archivo de configuración
    case _: java.util.concurrent.TimeoutException =>
      Restart
      Escalate //Si es un problema de negocio, se debe notificar.
    case _: TechnicalException =>
      Restart //ESTO DEBE CAMBIAR
    case _: RemoteException =>
      Restart //Si hay problemas en la red, reintentar.
    case _: MalformedURLException =>
      Stop //Si la URL está mal formada, matar el actor, puesto que es un problema que debe ser
    //atendido estáticamente.
    case _: SOAPException =>
      Restart //Si sucedió algún problema, reintentar.
    case t: Throwable =>
      Escalate
  }

  //Factory method
  def props(): Props = Props( new PostalActor /*with PerseveringBehavior*/ with GlobalParamsProvider )
  //Factory para crear router.
  def router: Props = props().withRouter( makeRouter()( /*Some(supervisionStrategy)*/ ) )
}
