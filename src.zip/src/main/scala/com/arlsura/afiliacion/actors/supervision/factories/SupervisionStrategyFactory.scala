package com.arlsura.afiliacion.actors.supervision.factories

import akka.actor.SupervisorStrategy
import akka.actor.SupervisorStrategy.Decider

import scala.concurrent.duration.Duration

/**
 * Created by root on 28/01/15.
 */
trait SupervisionStrategyFactory {
  /**
   * Toma una serie de parámetros y devuelve la estrategia correspondiente.
   * @param maxNumberOfRetries
   * @param withinTimeRange
   * @param decider
   * @return
   */
  def makeStrategy( maxNumberOfRetries: Int, withinTimeRange: Duration )( decider: Decider ): SupervisorStrategy
}
