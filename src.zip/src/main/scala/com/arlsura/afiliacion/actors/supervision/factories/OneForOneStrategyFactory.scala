package com.arlsura.afiliacion.actors.supervision.factories

import akka.actor.OneForOneStrategy
import akka.actor.SupervisorStrategy.Decider

import scala.concurrent.duration.Duration

/**
 * Created by root on 28/01/15.
 */
trait OneForOneStrategyFactory
    extends SupervisionStrategyFactory {

  def makeStrategy( maxNumberOfRetries: Int, withinTimeRange: Duration )( decider: Decider ) = OneForOneStrategy( maxNumberOfRetries, withinTimeRange )( decider )
}
