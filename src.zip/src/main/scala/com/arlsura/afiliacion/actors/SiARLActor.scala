package com.arlsura.afiliacion.actors

import akka.actor.{ Actor, Props }
import akka.event.LoggingReceive
import com.arlsura.afiliacion.actors.SiARLActor.{ PreValidationResponse, PreValidateARL }
import com.arlsura.afiliacion.actors.commons.VerboseActor
import com.arlsura.afiliacion.bussiness.siarl.SiARLManager
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.ExceptionOccurred
import scala.concurrent.Future
import scala.util.{ Failure, Success }
import scala.concurrent.ExecutionContext.Implicits.global

/**
 * Actor encargado de consumir los servicios SOAP de SiARL.
 * Created by Jesús Martínez on 27/11/14.
 */
class SiARLActor extends VerboseActor {
  override def receive = {
    case PreValidateARL( dni, isCompany ) =>
      val originalSender = sender
      val handler = context.actorOf( Props( new Actor {
        override def receive = LoggingReceive {
          case msg @ PreValidationResponse( canProceed ) =>
            //            log.debug( s"Recibido mensaje PreValidationResponse: [$canProceed]" )
            sendMessageAndShutdown( msg )
          case ex @ ExceptionOccurred( c, m ) =>
            //            log.debug( s"Recibido mensaje ExceptionOccurred: \n\tcause: $c\n\tmessage: $m" )
            sendMessageAndShutdown( ex )
        }

        /**
         * Envía un mensaje al sender original y luego se detiene a sí mismo.
         * @param message Mensaje que será enviado.
         */
        private def sendMessageAndShutdown( message: Any ): Unit = {
          //          log.debug( "Deteniendo handler anónimo." )
          originalSender ! message
          context.stop( self )
        }
      } ), s"SiARL-anonymous-handler-${com.arlsura.afiliacion.utils.Utils.getTimestamp}" )

      //El consumo del servicio se hará en un hilo aparte.
      val executePreValidation = Future {
        SiARLManager.prevalidateByDni( dni, isCompany )
      }

      executePreValidation onComplete {
        case Success( response ) => handler ! PreValidationResponse( response )
        case Failure( e ) =>
          handler ! ExceptionOccurred( e.getCause.toString, e.getMessage )
      }
  }
}

/**
 * Companion del actor.
 */
object SiARLActor {
  //Mensajes
  case class PreValidateARL( dni: String, isCompany: Boolean )
  case class PreValidationResponse( canProceed: Boolean )

  //Factory method.
  def props = Props( new SiARLActor )
}
