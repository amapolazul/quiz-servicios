package com.arlsura.afiliacion.actors.router

import akka.routing.DefaultResizer
import com.arlsura.afiliacion.utils.Utils

/**
 * Created by root on 30/01/15.
 */
trait RouterDefaultsProvider {
  final val DEFAULT_POOL_SIZE = Utils.getProperty( "pool.", "default-size" ).asInstanceOf[ Int ]
  final val LOWER_BOUND_POOL_SIZE = Utils.getProperty( "pool.", "lower-bound" ).asInstanceOf[ Int ]
  final val UPPER_BOUND_POOL_SIZE = Utils.getProperty( "pool.", "upper-bound" ).asInstanceOf[ Int ]
  final lazy val DEFAULT_RESIZER = DefaultResizer( lowerBound = LOWER_BOUND_POOL_SIZE, upperBound = UPPER_BOUND_POOL_SIZE )
}
