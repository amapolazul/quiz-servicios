package com.arlsura.afiliacion.actors.supervision

import akka.actor.SupervisorStrategy.Escalate
import com.arlsura.afiliacion.actors.supervision.factories.SupervisionStrategyFactory

import scala.concurrent.duration.Duration

/**
 * Created by Jesús Martínez on 28/01/15.
 * Supervisa los actores que hacen llamadas a servicios de terceros, como por ejemplo, Venta Información.
 */
abstract class IsolatedExternalSupervisor( maxNumberOfRetries: Int = -1, withinTimeRange: Duration = Duration.Inf )
    extends IsolatedLifeCycleSupervisor {

  this: SupervisionStrategyFactory =>

  override val supervisorStrategy = makeStrategy( maxNumberOfRetries, withinTimeRange ) {
    //TODO En esta función se debe definir qué directiva aplicar para cada tipo de exceción.
    //    case _: ActorInitializationException => Stop
    //    case _: ActorKilledException => Stop
    //    case _: Exception =>
    case _: Throwable => Escalate
  }
}
