package com.arlsura.afiliacion.actors

import java.util.Date

import akka.actor.{ ActorLogging, Props, Actor }
import akka.event.LoggingReceive
import com.arlsura.afiliacion.actors.commons.VerboseActor
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.{ ExceptionOccurred, AffiliationValidationResponse }
import com.arlsura.afiliacion.utils.Utils
import spray.client.pipelining._
import scala.concurrent.Future
import scala.concurrent.ExecutionContext.Implicits.global
import scala.util.{ Failure, Success }

/**
 * Created by juanmartinez on 13/11/14.
 */
class VentaInformacionConsumerActor extends VerboseActor {

  import com.arlsura.afiliacion.actors.VentaInformacionConsumerActor._

  override def receive: Receive = {
    case AffiliateValidationRequest( dni ) =>
      val originalSender = sender
      val handler = context.actorOf( Props( new Actor() {
        def receive = LoggingReceive {
          case message @ AffiliateValidationResponse( response ) =>
            //            log.debug( s"Recibiendo mensaje AffiliateValidationResponse: $response" )
            sendResponseAndShutdown( message )
          case ex @ ExceptionOccurred( c, m ) =>
            //            log.debug( s"Recibiendo mensaje ExceptionOccurred: \n\tcause: $c\n\tmessage: $m" )
            sendResponseAndShutdown( ex )
        }

        def sendResponseAndShutdown( response: Any ) = {
          originalSender ! response
          //          log.debug( "Deteniendo actor extra." )
          context.stop( self )
        }
      } ), s"venta-informacion-consumer-anonymous-handler-${Utils.getTimestamp}" )

      val checkAffiliationResp = checkAffiliationCustomer( dni )

      checkAffiliationResp onComplete {
        case Success( checkResp ) => handler ! AffiliateValidationResponse( checkResp )
        case Failure( ex )        => handler ! ExceptionOccurred( ex.getCause.toString, ex.getMessage )
      }
  }

  /**
   *
   * @param dni
   * @return
   */
  private def checkAffiliationCustomer( dni: String ): Future[ AffiliationValidationResponse ] = {
    val urlService = s"${Utils.getVentaInformacionUrl}affiliationValidator?dni=${dni}"
    val pipeline = sendReceive ~> unmarshal[ AffiliationValidationResponse ]

    pipeline( Get( urlService ) )
  }
}

object VentaInformacionConsumerActor {
  //Mensajes.
  case class AffiliateValidationRequest( dni: String )
  case class AffiliateValidationResponse( resp: AffiliationValidationResponse )

  //Factory method.
  def props() = Props( new VentaInformacionConsumerActor )
}
