package com.arlsura.afiliacion.actors.commons

import akka.actor.{ Actor, ActorLogging }

/**
 * Created by Jesús Martínez on 27/11/14.
 */
trait VerboseActor extends Actor with ActorLogging
