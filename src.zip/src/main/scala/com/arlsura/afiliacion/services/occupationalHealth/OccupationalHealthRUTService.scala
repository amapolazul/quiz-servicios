package com.arlsura.afiliacion.services.occupationalHealth

import akka.actor.{ Props, ActorRef }
import com.arlsura.afiliacion.actors.commons.VerboseActor
import com.arlsura.afiliacion.authentication.CookieSessionAuthentication
import com.arlsura.afiliacion.bussiness.occupational_health.{ OccupationalHealthRUTServiceHandler, OccupationalHealthRUTServiceHandler$ }
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.{ ExceptionOccurred, GeneralJsonResponseData, UpdateOHvsRUTRecordRequest, CreateOHvsRUTRecordRequest }
import com.arlsura.afiliacion.persistence.entities.OccupationalHealthRUTSummary
import com.arlsura.afiliacion.utils.Utils
import com.arlsura.afiliacion.utils.resources.ResourcesNameRetriever
import spray.http.StatusCodes
import spray.routing.{ RequestContext, HttpService }

/**
 * Created by Jesús Martínez on 2/01/15.
 */
trait OccupationalHealthRUTService extends HttpService with CookieSessionAuthentication {

  private[ this ] implicit val executionContext = actorRefFactory.dispatcher

  val occupationalHealthService = ResourcesNameRetriever.getResource( "occupational_health", "MAIN_RESOURCE" )

  private val createRecordRoute = {
    pathPrefix( occupationalHealthService ) {
      pathEndOrSingleSlash {
        entity( as[ CreateOHvsRUTRecordRequest ] ) {
          request =>
            post {
              authenticate( authenticateCaptcha() ) { user =>
                ( ctx: RequestContext ) =>
                  val occupationalHealthHandler = new OccupationalHealthRUTServiceHandler( ctx )
                  occupationalHealthHandler.occupationalHealthRUTCreate( request )
              }
            }
        }
      }
    }
  }

  private val retrieveSingleRecordRoute = {
    pathPrefix( occupationalHealthService / Segment ) {
      id =>
        pathEndOrSingleSlash {
          get {
            authenticate( authenticateCaptcha() ) { user =>
              ( ctx: RequestContext ) =>
                val occupationalHealthHandler = new OccupationalHealthRUTServiceHandler( ctx )
                occupationalHealthHandler.occupationalHealthRUTServiceHandlerGet( id )
            }
          }
        }
    }
  }

  private val retrieveRecords = {
    pathPrefix( occupationalHealthService ) {
      pathEndOrSingleSlash {
        parameters( 'ciiu?, 'oh?, 'expeditionDate? ) {
          ( ciiu: Option[ String ], oh: Option[ String ], expeditionDate: Option[ String ] ) =>
            get {
              authenticate( authenticateCaptcha() ) { user =>
                ( ctx: RequestContext ) =>
                  val occupationalHealthHandler = new OccupationalHealthRUTServiceHandler( ctx )
                  ( ciiu, oh, expeditionDate ) match {
                    case ( None, None, None ) =>
                      occupationalHealthHandler.occupationalHealthRUTServiceHandlerGetAll
                    case ( _, _, _ ) =>
                      occupationalHealthHandler.occupationalHealthRUTServiceHandlerGetBy( ciiu, oh, expeditionDate )
                  }
              }
            }
        }
      }
    }
  }

  private val removeSingleRecordRoute = {
    pathPrefix( occupationalHealthService / Segment ) {
      id =>
        pathEndOrSingleSlash {
          delete {
            authenticate( authenticateCaptcha() ) { user =>
              ( ctx: RequestContext ) =>
                val occupationalHealthHandler = new OccupationalHealthRUTServiceHandler( ctx )
                occupationalHealthHandler.occupationalHealthRUTServiceHandlerDelete( id )
            }
          }
        }
    }
  }

  private val removeRecords = {
    pathPrefix( occupationalHealthService ) {
      pathEndOrSingleSlash {
        parameters( 'ciiu?, 'oh?, 'expeditionDate? ) {
          ( ciiu: Option[ String ], oh: Option[ String ], expeditionDate: Option[ String ] ) =>
            delete {
              authenticate( authenticateCaptcha() ) { user =>
                ( ctx: RequestContext ) =>
                  val occupationalHealthHandler = new OccupationalHealthRUTServiceHandler( ctx )
                  ( ciiu, oh, expeditionDate ) match {
                    case ( None, None, None ) =>
                      occupationalHealthHandler.occupationalHealthRUTServiceHandlerDeleteAll()
                    case ( _, _, _ ) =>
                      occupationalHealthHandler.occupationalHealthRUTServiceHandlerDeleteBy( ciiu, oh, expeditionDate )
                  }
              }
            }
        }
      }
    }
  }

  private val updateRecordsRoute = {
    pathPrefix( occupationalHealthService ) {
      pathEndOrSingleSlash {
        entity( as[ UpdateOHvsRUTRecordRequest ] ) {
          request =>
            put {
              authenticate( authenticateCaptcha() ) { user =>
                ( ctx: RequestContext ) =>
                  val occupationalHealthHandler = new OccupationalHealthRUTServiceHandler( ctx )
                  occupationalHealthHandler.occupationalHealthRUTServiceHandlerUpdate( request )
              }
            }
        }
      }
    }
  }

  val occupationalHealthServiceRoute =
    createRecordRoute ~
      retrieveSingleRecordRoute ~
      removeSingleRecordRoute ~
      retrieveRecords ~
      removeRecords ~
      updateRecordsRoute
}
