package com.arlsura.afiliacion.services.preaffiliation

import com.arlsura.afiliacion.persistence.entities.affiliation.basic_data.Address
import com.arlsura.afiliacion.utils.FormatValidator
import org.json4s.{ DefaultFormats, Formats }
import spray.httpx.Json4sSupport

/**
 * Created by John on 7/07/15.
 */
object PreaffiliationMarshaller extends Json4sSupport {

  override implicit def json4sFormats: Formats = DefaultFormats

  case class PreAffiliationSaveRequest(
      fullName:             Option[ String ] = None,
      commercialName:       Option[ String ] = None,
      name1:                Option[ String ] = None,
      name2:                Option[ String ] = None,
      lastName1:            Option[ String ] = None,
      lastName2:            Option[ String ] = None,
      identificationType:   String,
      identification:       String,
      verificationDigit:    Option[ String ] = None,
      email:                String,
      phone:                Option[ String ] = None,
      cellphone:            Option[ String ] = None,
      fullEconomicActivity: EconomicActivity,
      workers:              Int,
      previousARL:          Option[ String ] = None,
      racea:                String,
      affiliationType:      String,
      birthDate:            Option[ String ],
      gender:               Option[ String ],
      isNewCompany:         Boolean,
      provinces:            List[ Province ],
      fullAddress:          String,
      address:              Address
  ) {
    require( name1.forall( FormatValidator.alphabetic( _ ) ), "El nombre 1 sólo puede contener letras y espacios." )
    require( name2.forall( FormatValidator.alphabetic( _ ) ), "El nombre 2 sólo puede contener letras y espacios." )
    require( lastName1.forall( FormatValidator.alphabetic( _ ) ), "El apellido 1 sólo puede contener letras y espacios." )
    require( lastName2.forall( FormatValidator.alphabetic( _ ) ), "El apellido 2 sólo puede contener letras y espacios." )
    require( fullName.forall( FormatValidator.alphabetic( _ ) ), "El nombre completo sólo puede contener letras y espacios." )
    require( commercialName.forall( FormatValidator.alphabetic( _ ) ), "El nombre completo sólo puede contener letras y espacios." )
    require( verificationDigit.forall( FormatValidator.numeric ), "El digito de verificacion tiene que ser numerico" )
    require( FormatValidator.validEmail( email ), "Correo electrónico inválido." )
    require( phone.forall( FormatValidator.validPhone ), "Teléfono inválido." )
    require( cellphone.forall( FormatValidator.validCellphone ), "Celular inválido." )
    require( previousARL.forall( FormatValidator.alphanumeric( _ ) ), "La ARL anterior debe ser alfanumerico." )
    require( Address.validFormat( address ) )
  }

  case class EconomicActivity(
    economicActivityId: String,
    rate:               String,
    description:        String
  )

  case class Province(
    provinceCode: String,
    provinceName: String
  )

  case class SegmentationDecision(
      commercialConsultantDni: String,
      affiliationApproved:     Boolean,
      rejectionCause:          Option[ String ] = None
  ) {
    require( FormatValidator.alphanumeric( commercialConsultantDni ), "DNI inválido." )
  }
}
