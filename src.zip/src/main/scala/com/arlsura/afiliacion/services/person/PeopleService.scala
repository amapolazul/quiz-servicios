package com.arlsura.afiliacion.services.person

import akka.actor._
import com.arlsura.afiliacion.actors.PersonsActor
import com.arlsura.afiliacion.actors.PersonsActor.GetPersonResponse
import com.arlsura.afiliacion.actors.commons.VerboseActor
import com.arlsura.afiliacion.actors.supervision.behaviors.HandlerSupervisorBehavior
import com.arlsura.afiliacion.authentication.CookieSessionAuthentication
import com.arlsura.afiliacion.headers.CORSHeaders
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.GeneralJsonResponseData
import com.arlsura.afiliacion.utils.Utils
import com.arlsura.afiliacion.utils.resources.ResourcesNameRetriever
import spray.routing.{ Route, RequestContext, HttpService }

/**
 * Created by juanmartinez on 15/11/14.
 */
trait PeopleService extends HttpService with CORSHeaders with CookieSessionAuthentication {

  private[ this ] implicit val executionContext = actorRefFactory.dispatcher

  val peopleRoute = ResourcesNameRetriever.getResource( "people", "MAIN_RESOURCE" )

  private val handler: ActorRef =
    actorRefFactory.actorOf( PeopleServiceHandler.props(), s"person-service-handler-${Utils.getTimestamp}" )
  val personasServicePath: Route = {
    pathPrefix( peopleRoute / Segment ) {
      dni =>
        pathEndOrSingleSlash {
          get {
            authenticate( authenticateCaptcha() ) { user =>
              ( ctx: RequestContext ) =>
                handler ! PeopleServiceHandler.GetPersonRequest( dni, ctx )
            }
          }
        }
    }
  }

}

private class PeopleServiceHandler extends VerboseActor with HandlerSupervisorBehavior {
  private val personRouter: ActorRef = context.actorOf( PersonsActor.router, s"person-router-${Utils.getTimestamp}" )

  override def receive: Receive = {
    case PeopleServiceHandler.GetPersonRequest( dni, ctx ) =>
      setContext( ctx )
      //      log.debug( "accediendo al actor Person" )
      personRouter ! PersonsActor.GetPersonRequest( dni )
    case GetPersonResponse( person ) =>
      val response: GeneralJsonResponseData =
        GeneralJsonResponseData( "Persona consultada con exito", Some( person ) )
      complete( response )
  }
}

private object PeopleServiceHandler {

  case class GetPersonRequest( dni: String, requestContext: RequestContext )
  def props(): Props = Props( new PeopleServiceHandler )

}

