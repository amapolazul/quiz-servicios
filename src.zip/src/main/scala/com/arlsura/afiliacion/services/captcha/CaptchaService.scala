package com.arlsura.afiliacion.services.captcha

import com.arlsura.afiliacion.bussiness.HandlerSupport.ServiceHandlerResponse
import com.arlsura.afiliacion.bussiness.RequestContextSupport
import com.arlsura.afiliacion.bussiness.security.TokenServiceModule
import com.arlsura.afiliacion.services.captcha.CaptchaJsonMarshaller.CaptchaServiceRequest
import com.arlsura.afiliacion.utils.resources.ResourcesNameRetriever
import spray.routing._
import CaptchaService._
import com.google.inject.Guice
import net.codingwell.scalaguice.InjectorExtensions._
import scala.concurrent.ExecutionContext

import scala.concurrent.Future

/**
 * Servicio para la verificacion del captcha
 * Created by John on 14/04/15.
 */
trait CaptchaService extends HttpService with RequestContextSupport {

  private lazy val injector = Guice.createInjector( new CaptchaServiceModule() )
  private lazy val injectorToken = Guice.createInjector( new TokenServiceModule() )

  private implicit val executionContext: ExecutionContext = actorRefFactory.dispatcher

  val recaptchaRoute = {
    pathPrefix( recaptchaPath ) {
      pathEndOrSingleSlash {
        post {
          entity( as[ CaptchaServiceRequest ] ) {
            data =>
              ( requestContext: RequestContext ) =>
                lazy val handler: CaptchaServiceHandler = injector.instance[ CaptchaServiceHandler ]
                lazy val tokenHandler = injectorToken.instance[ TokenManagerServiceHandler ]
                val captchaValidationFuture: Future[ Either[ String, Boolean ] ] = handler.executeValidation( data )
                val tokenGenerationFuture: Future[ ServiceHandlerResponse ] = captchaValidationFuture flatMap {
                  response =>
                    {
                      response match {
                        case Right( success ) =>
                          if ( success ) {
                            tokenHandler.createSessionToken( data.captchaResponse, data.dni )
                          }
                          else {
                            Future { Left( "Error de validacion del captcha" ) }
                          }
                        case Left( error ) =>
                          Future { Left( s"Error de validacion del captcha ${error}" ) }

                      }
                    }
                }
                completeRequest( tokenGenerationFuture, requestContext )
          }
        }
      }
    }
  }
}

object CaptchaService {
  val recaptchaPath = ResourcesNameRetriever.getResource( "captcha", "MAIN_RESOURCE" )
}
