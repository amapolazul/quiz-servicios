package com.arlsura.afiliacion.services.arp

import akka.actor._
import com.arlsura.afiliacion.authentication.CookieSessionAuthentication
import com.arlsura.afiliacion.headers.CORSHeaders
import com.arlsura.afiliacion.utils.Utils
import com.arlsura.afiliacion.utils.resources.ResourcesNameRetriever
import spray.routing.{ Route, RequestContext, HttpService }
import com.arlsura.afiliacion.actors.cache.CacheRefresherActor
import com.arlsura.afiliacion.bussiness.arp.ARPServiceHandler

/**
 * Created by juanmartinez on 20/11/14.
 */
trait ARPService extends HttpService with CORSHeaders with CookieSessionAuthentication {
  private implicit val ec = actorRefFactory.dispatcher
  private val path = ResourcesNameRetriever.getResource( "arls", "MAIN_RESOURCE" )
  private val cacheActor = actorRefFactory.actorSelection( "akka://ARLSura-backend/user/cache-refresher-actor" )

  val getArps: Route = {
    path( path ) {
      get {
        authenticate( authenticateCaptcha ) {
          user =>
            ( ctx: RequestContext ) =>
              val handler = new ARPServiceHandler( ctx, cacheActor )
              handler.retrieveARPsCatalog()
        }
      }
    }
  }

  /**
   * Metodo encargado de retornar todas las rutas pertientes a la consulta de arps
   */
  def getArpRoutes: Route = getArps
}