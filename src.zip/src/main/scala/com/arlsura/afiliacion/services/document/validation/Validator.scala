package com.arlsura.afiliacion.services.document.validation

/**
 * Validador de números de documento.
 * ATENCIÓN: En esta clase se utiliza el patrón de diseño "Chain of Responsability" con funciones parciales.
 * Si desea agregar una nueva validación al validador (es decir, añadir un nuevo elemento a la cadena de
 * responsabilidad) debe:
 *  1. Definir una función parcial que lleve a cabo dicha validación
 *      private def myValidator: ValidatorElement = { case (caso a ser validado) => ... }
 *  2. Agregar el elemento a la cadena (en la función validationChain):
 *      ...
 *      myValidator orElse
 *      defaultValidator
 *
 */
class Validator {
  import Validator._
  private type ValidatorElement = PartialFunction[ List[ Char ], Boolean ]

  /*Elementos de la cadena de responsabilidad */

  private val defaultValidator: ValidatorElement = { case _: List[ Char ] => false }

  private def aliensCardIDValidator: ValidatorElement = {
    case 'C' :: 'E' :: value =>
      isNonEmpty( value ) && ( value.length < 8 ) && nonLeadingZeroes( value ) && numericOnly( value )
  }

  private def citizenCardIDValidator: ValidatorElement = {
    case 'C' :: 'C' :: value =>
      val cardIDLength = value.length
      ( cardIDLength != 9 && cardIDLength < 11 && cardIDLength > 5 ) && nonLeadingZeroes( value ) && numericOnly( value )
  }

  private def passportValidator: ValidatorElement = {
    case 'P' :: 'A' :: value =>
      isNonEmpty( value ) && ( value.length < 17 ) && alphanumericOnly( value )
  }

  private def nitValidator( verificationDigit: Option[ String ] ): ValidatorElement = {
    case value @ 'N' :: 'I' :: nit =>
      nit.length == 9 &&
        ( nit.head == '7' || nit.head == '8' || nit.head == '9' ) &&
        numericOnly( nit ) &&
        ( verificationDigit match {
          case None      => true
          case Some( d ) => validateVerificationDigit( value.mkString, d )
        } )
  }

  private def validateVerificationDigit( nit: String, digit: String ): Boolean = {

    /*
     * Calcula el dígito de verificación de un NIT.
     * @param invDni NIT que se debe validar.
     * @return Un string con el número (>= 0) de validación correspondiente al NIT. Si ocurre un error, se retorna -1.
     */
    def getVerificationDigit( invDni: String ) = {
      try {
        val invDniTrimmed = invDni.trim
        val prefix = invDniTrimmed.take( 2 )
        val number = invDniTrimmed.drop( 2 )

        //Valida tipo y tamaño de la identificación proveída.
        assert( prefix.equalsIgnoreCase( "ni" ) )
        assert( number.nonEmpty )
        assert( number.length <= 15 )

        //Completa con ceros el NIT, en caso de hacer falta (cuando la longitud del NIT < 15)
        val vDni = prefix.toString ++ ( "0" * 15 ).take( 15 - number.length ) ++ number
        val sum = ( vDni.drop( 2 ) zip List( 71, 67, 59, 53, 47, 43, 41, 37, 29, 23, 19, 17, 13, 7, 3 ) ).foldLeft( 0 ) {
          ( accum: Int, pair: ( Char, Int ) ) => accum + pair._1.asDigit * pair._2
        }

        val residuum = sum % 11

        residuum match {
          case 0 => "0"
          case 1 => "1"
          case _ => ( 11 - residuum ).toString
        }
      }
      catch {
        case _: Throwable => "-1"
      }
    }

    digit == getVerificationDigit( nit )
  }

  private def identityCardValidator: ValidatorElement = {
    case 'T' :: 'I' :: ic =>
      ( ic.length == 10 || ic.length == 11 ) &&
        nonLeadingZeroes( ic ) &&
        numericOnly( ic )
  }

  private def civilRegistryValidator: ValidatorElement = {
    case 'R' :: 'C' :: cr =>
      ( ( cr.length == 8 ) || ( cr.length == 10 ) || ( cr.length == 11 ) ) && numericOnly( cr )
  }

  private def diplomaticCardValidator: ValidatorElement = {
    case 'C' :: 'D' :: dc =>
      numericOnly( dc ) && dc.length > 0 && dc.length <= 20
  }

  /**
   * Función que ensambla la cadena de responsabilidad.
   * @param digit None si no se va a validar el dígito de verificación; Some(<digito>) si sí.
   * @return Función que valida un número de documento.
   */
  private def validatorChain( digit: Option[ String ] ): PartialFunction[ List[ Char ], Boolean ] =
    aliensCardIDValidator orElse
      citizenCardIDValidator orElse
      passportValidator orElse
      nitValidator( digit ) orElse
      identityCardValidator orElse
      civilRegistryValidator orElse
      diplomaticCardValidator orElse
      defaultValidator

  /**
   * Realiza la validación de un número de documento.
   * @param value Número de documento a ser validado.
   * @param verificationDigit None si no se va a validar el dígito de verificación; Some(<digito>) si sí.
   * @return true si la validación fue exitosa; false si no.
   */
  def validate( value: String, verificationDigit: Option[ String ] = None ): Boolean = validatorChain( verificationDigit )( value.toUpperCase.toList )

}

private object Validator {
  private def isNonEmpty( input: List[ Char ] ) = input.nonEmpty
  private def nonLeadingZeroes( input: List[ Char ] ): Boolean = input.head != '0'
  private def numericOnly( input: List[ Char ] ): Boolean = input forall ( _.isDigit )
  private def alphanumericOnly( input: List[ Char ] ): Boolean = input forall ( _.isLetterOrDigit )
}