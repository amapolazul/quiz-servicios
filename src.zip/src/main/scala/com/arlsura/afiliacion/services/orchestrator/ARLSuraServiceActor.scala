package com.arlsura.afiliacion.services.orchestrator

import akka.actor.{ Props, Actor, ActorRefFactory }
import com.arlsura.afiliacion.auditing.AuditingHelper
import com.arlsura.afiliacion.authentication.CookieSessionAuthentication
import com.arlsura.afiliacion.headers.CORSHeaders
import com.arlsura.afiliacion.proceso.pasos.resumen.PDFFileGeneratorService
import com.arlsura.afiliacion.proceso.pasos.sucursales.BranchDataService
import com.arlsura.afiliacion.security.cookies.CookiesEncryptionService
import com.arlsura.afiliacion.services.ClientsService
import com.arlsura.afiliacion.services.activities.ActivitiesService
import com.arlsura.afiliacion.services.address.AddressService
import com.arlsura.afiliacion.services.affiliation.BasicDataService
import com.arlsura.afiliacion.services.affiliation.completion.CompleteAffiliationService
import com.arlsura.afiliacion.services.affiliation.contacts.ContactsService
import com.arlsura.afiliacion.services.affiliation.employees.EmployeesDataService
import com.arlsura.afiliacion.services.affiliation.key.KeyService
import com.arlsura.afiliacion.services.affiliation.workcenters.WorkCentersDataService
import com.arlsura.afiliacion.services.arp.ARPService
import com.arlsura.afiliacion.services.afp.AFPService
import com.arlsura.afiliacion.services.blacklist.BlacklistService
import com.arlsura.afiliacion.services.captcha.CaptchaService
import com.arlsura.afiliacion.services.charge.ChargeService
import com.arlsura.afiliacion.services.code.SecurityCodeService
import com.arlsura.afiliacion.services.commercial.CommercialResponsibleService
import com.arlsura.afiliacion.services.contacts.ContactNamesService
import com.arlsura.afiliacion.services.contributors.ContributorsService
import com.arlsura.afiliacion.services.document.validation.{ SiARLPreValidationService }
import com.arlsura.afiliacion.services.customer.CustomerAffiliationValidateService
import com.arlsura.afiliacion.services.employer.DomesticEmployerService
import com.arlsura.afiliacion.services.eps.EPSService
import com.arlsura.afiliacion.services.independents.services.IndependentsService
import com.arlsura.afiliacion.services.legal_natures.LegalNaturesService
import com.arlsura.afiliacion.services.occupationalHealth.OccupationalHealthRUTService
import com.arlsura.afiliacion.services.person.PeopleService
import com.arlsura.afiliacion.services.postal.PostalService
import com.arlsura.afiliacion.services.preaffiliation.{ PreAffiliationService, PreaffiliationPrevalidationService }
import com.arlsura.afiliacion.services.salary.SalaryService
import com.arlsura.afiliacion.services.segmentation.SegmentationService
import com.arlsura.afiliacion.utils.directives.CustomDirectives
import spray.http.StatusCodes
import spray.routing._
import scala.concurrent.ExecutionContext.Implicits.global

/**
 * Created by juanmartinez on 4/11/14.
 */
class ARLSuraServiceActor extends Actor with ARLSuraServiceRoute {

  def actorRefFactory: ActorRefFactory = context

  override def receive = runRoute( suraServiceRoutes )
}

/**
 * En este trait se define la ruta base de todos los servicios REST que habitarán
 * en Sura en linea.
 */
trait ARLSuraServiceRoute extends HttpService
    with CustomerAffiliationValidateService
    with PeopleService
    with ARPService
    with SecurityCodeService
    with SiARLPreValidationService
    with PreAffiliationService
    with PostalService
    with AddressService
    with CORSHeaders
    with CustomDirectives
    with CommercialResponsibleService
    with OccupationalHealthRUTService
    with SegmentationService
    with ActivitiesService
    with DomesticEmployerService
    with IndependentsService
    with ClientsService
    with ContributorsService
    with LegalNaturesService
    with PreaffiliationPrevalidationService
    with BasicDataService
    with AFPService
    with EPSService
    with SalaryService
    with CaptchaService
    with ContactsService
    with EmployeesDataService
    with BranchDataService
    with WorkCentersDataService
    with PDFFileGeneratorService
    with CookiesEncryptionService
    with BlacklistService
    with ContactNamesService
    with KeyService
    with CompleteAffiliationService with ChargeService {

  val suraServiceRoutes = {
    CORSRejectionAndExceptionSupport { // TODO URGENT: quitar
      pathPrefix( "sura" ) {
        pathPrefix( "arl" ) {
          mapRequestContext( r => AuditingHelper.auditAction( r ) ) {
            independentsPath ~
              chargesRoutes ~
              personasServicePath ~
              getArpRoutes ~
              securityCodeRoutes ~
              preaffiliationRoutes ~
              preValidationRoute ~
              consultMunicipalityRoute ~
              consultAddressRoute ~
              commercialResponsibleServiceRoutes ~
              occupationalHealthServiceRoute ~
              getSegmentationRoutes ~
              getActivitiesRoutes ~
              getDomesticActivityRoute ~
              preaffiliationPrevalidationRoute ~
              clientRoutes ~
              contributorsServiceRoutes ~
              legalNaturesServiceRoutes ~
              afpRoutes ~
              epsRoutes ~
              salaryRoutes ~
              basicDataServiceRoutes ~
              recaptchaRoute ~
              getContactsRoute ~
              getEmployeesRoute ~
              branchDataRoutes ~
              getWorkCentersRoute ~
              pdfRoutes ~
              cookieTokenRoute ~
              blacklistRoutes ~
              contactNamesRoute ~
              getKeyRoutes ~
              getCompletionRoutes
          }
        }
      } ~ options {
        complete( StatusCodes.OK )
      }
    }
  }
}

/**
 * Companion object del orquestador.
 */
object ARLSuraServiceActor {
  //Factory method para crear el orquestador.
  def props = Props( new ARLSuraServiceActor )
}
