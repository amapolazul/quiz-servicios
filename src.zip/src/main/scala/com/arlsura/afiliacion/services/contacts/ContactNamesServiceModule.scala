package com.arlsura.afiliacion.services.contacts

import com.arlsura.afiliacion.persistence.daos.wrappers.ContactNamesWrapper
import com.google.inject.AbstractModule
import net.codingwell.scalaguice.ScalaModule

/**
 * Created by John on 5/08/15.
 */
class ContactNamesServiceModule extends AbstractModule with ScalaModule {

  override def configure(): Unit = {
    bind[ ContactNamesRepository ]
    bind[ ContactNamesWrapper ]
  }

}
