package com.arlsura.afiliacion.services.captcha

import java.util.UUID

import com.arlsura.afiliacion.authentication.SessionData
import com.arlsura.afiliacion.bussiness.HandlerSupport.ServiceHandlerResponse
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.GeneralJsonResponseData
import com.arlsura.afiliacion.persistence.security.{ TokenSession, TokenSessionRepository }
import com.arlsura.afiliacion.utils.Utils
import com.google.common.base.Charsets
import com.google.common.hash.Hashing
import com.google.inject.Inject
import com.sura.sessionmanager.{ Found, AlreadyExist, Created }
import org.apache.commons.codec.binary.Base64
import org.joda.time.DateTime

import scala.concurrent.{ ExecutionContext, Future }
import scala.util.control.NonFatal

/**
 * Created by juanmartinez on 23/06/15.
 */
class TokenManagerServiceHandler @Inject() ( private val tokenRepository: TokenSessionRepository ) {
  import com.arlsura.afiliacion.ARLContext._
  import TokenManagerServiceHandler._

  /**
   * Crea el token de sesion y lo guarda en la base de datos
   * @param key
   * @param dni
   * @return
   */
  //  def createSessionToken( key: String, dni: String )( implicit ec: ExecutionContext ): Future[ ServiceHandlerResponse ] = {
  //    val generatedToken: String = buildToken( key, dni )
  //    val tokenEntity: TokenSession = TokenSession(
  //      dni = dni,
  //      token = generatedToken,
  //      creationDate = DateTime.now(),
  //      expirationDate = DateTime.now().plus( getExpirationTimeToken )
  //    )
  //
  //    tokenRepository.createSessionToken( tokenEntity ) map {
  //      tokenResponse =>
  //        {
  //          if ( tokenResponse.ok ) {
  //            Right( GeneralJsonResponseData( "Login correcto", data = Some( generatedToken ) ) )
  //          }
  //          else {
  //            Left( s"Ocurrio un error guardando el token de seguridad ${tokenResponse.message}" )
  //          }
  //        }
  //    } recover {
  //      case t: Throwable =>
  //        t.printStackTrace()
  //        Left( s"Ocurrio un error guardando el token de seguridad ${t.getMessage}" )
  //    }
  //  }

  def createSessionToken( key: String, dni: String )( implicit executionContext: ExecutionContext ): Future[ ServiceHandlerResponse ] = {
    val salt = encode( s"$key-$getRandomSequence" )
    val sessionData = SessionData( salt, dni )
    val token = encode( salt, dni, sep = "%%%" )
    sessionManager.createSession( id = dni, update = true, sessionData ) map {
      case Created( _ ) =>
        Right( GeneralJsonResponseData( "Login correcto", data = Some( token ) ) )
      case AlreadyExist( _, _, dataG ) =>
        val data: SessionData = dataG.asInstanceOf[ SessionData ]
        Right( GeneralJsonResponseData( "Sesión ya existente", data = Some( encode( data.salt, data.dni, sep = "%%%" ) ) ) )
    } recover {
      case NonFatal( t ) =>
        //        t.printStackTrace()
        Left( s"Ocurrio un error guardando el token de seguridad ${t.getMessage}" )
    }
  }

  /**
   * Construye el string que define el token
   * @param key
   * @param dni
   * @return
   */
  def buildToken( key: String, dni: String ): String = {
    val timeStamp: Long = DateTime.now().getMillis
    val keySha256 = toSha256( key )
    val dniBase64: String = Base64.encodeBase64String( dni.getBytes )
    val token: String = s"$keySha256-$timeStamp-$dniBase64"
    Base64.encodeBase64String( token.getBytes )
  }

  /**
   * Toma un valor y le aplica el algoritmo de sha256
   * @param value
   * @return
   */
  def toSha256( value: String ): String = {
    Hashing.sha256()
      .hashString( value, Charsets.UTF_8 )
      .toString()
  }

  private def getRandomSequence = UUID.randomUUID().toString

}

object TokenManagerServiceHandler {
  /**
   * Devuelve el tiempo de expiracion del token de sesion
   * @return
   */
  def getExpirationTimeToken: Long = Utils.getProperty( "startup.", "sessionTimeOut" ).asInstanceOf[ Int ].toLong
}