package com.arlsura.afiliacion.services.commercial

import com.arlsura.afiliacion.bussiness.affiliation.BasicDataRepository
import com.arlsura.afiliacion.bussiness.commercial.responsible.CommercialResponsibleManager
import com.arlsura.afiliacion.persistence.daos.affiliation.wrappers.AffiliationBasicDataWrapper
import com.arlsura.afiliacion.persistence.daos.wrappers.CommercialResponsibleWrapper
import com.google.inject.AbstractModule
import net.codingwell.scalaguice.ScalaModule

/**
 * Created by jesus on 18/06/15.
 */
class CommercialResponsibleServiceModule extends AbstractModule with ScalaModule {
  override def configure(): Unit = {
    bind[ CommercialResponsibleWrapper ]
    bind[ CommercialResponsibleManager ]
    bind[ BasicDataRepository ]
    bind[ AffiliationBasicDataWrapper ]
  }
}
