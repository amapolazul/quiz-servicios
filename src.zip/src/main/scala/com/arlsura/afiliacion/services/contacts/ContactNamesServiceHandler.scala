package com.arlsura.afiliacion.services.contacts

import com.arlsura.afiliacion.bussiness.HandlerSupport._
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.GeneralJsonResponseData
import com.arlsura.afiliacion.persistence.entities.ContactNames
import com.arlsura.afiliacion.services.contacts.ContactNamesMarshaller.{ ContactNamesServiceResponse, ContactName }
import com.google.inject.Inject

import scala.concurrent.{ Future, ExecutionContext }

/**
 * Created by John on 31/07/15.
 */
class ContactNamesServiceHandler @Inject() ( contactNamesRepository: ContactNamesRepository ) {

  def getAll()( implicit ec: ExecutionContext ): Future[ ServiceHandlerResponse ] = {
    contactNamesRepository.getAll() map {
      case contacts =>
        Right( GeneralJsonResponseData( "Los nombres de los contactos fueron cargados correctamente", Some( ContactNamesServiceResponse( mapEntityListToServiceList( contacts ) ) ) ) )
    } recover {
      case e: Throwable =>
        //        e.printStackTrace()
        Left( s"Ocurrio un error al intentar cargar los cargos de los contactos. Mensaje: ${e.getMessage}. Causa: ${e.getCause}" )
    }
  }

  private def mapEntityListToServiceList( contactNames: List[ ContactNames ] ): List[ ContactName ] = {
    contactNames map {
      contact =>
        ContactName( contact.contactId, contact.contactDescription, contact.isMainContact, contact.neededForWorkcenters )
    }
  }

}
