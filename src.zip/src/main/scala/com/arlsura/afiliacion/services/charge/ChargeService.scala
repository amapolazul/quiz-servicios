package com.arlsura.afiliacion.services.charge

import com.arlsura.afiliacion.authentication.CookieSessionAuthentication
import com.arlsura.afiliacion.bussiness.charge.ChargeServiceHandler
import com.arlsura.afiliacion.utils.resources.ResourcesNameRetriever
import spray.routing.{ RequestContext, HttpService }

/**
 * Created by Jesús Martínez on 26/08/15.
 */
trait ChargeService extends HttpService with CookieSessionAuthentication {
  private implicit val ec = actorRefFactory.dispatcher
  private val path = ResourcesNameRetriever.getResource( "charges", "MAIN_RESOURCE" )
  private val cacheActor = actorRefFactory.actorSelection( "akka://ARLSura-backend/user/cache-refresher-actor" )

  private val getCharges = {
    println( path )
    path( path ) {
      get {
        authenticate( authenticateCaptcha() ) {
          user =>
            ( ctx: RequestContext ) =>
              val handler = new ChargeServiceHandler( ctx, cacheActor )
              handler.retrieveCharges()
        }
      }
    }
  }

  val chargesRoutes = getCharges
}
