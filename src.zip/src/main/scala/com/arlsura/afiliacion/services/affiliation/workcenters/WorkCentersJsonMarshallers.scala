package com.arlsura.afiliacion.services.affiliation.workcenters

import com.arlsura.afiliacion.persistence.entities.affiliation.work_center_data.WorkCenterInformation
import org.json4s.{ DefaultFormats, Formats }
import spray.httpx.Json4sSupport

/**
 * Created by juanmartinez on 1/07/15.
 */
object WorkCentersJsonMarshallers extends Json4sSupport {

  override implicit def json4sFormats: Formats = DefaultFormats

  case class SaveWorkCentersData( dni: String, securityCode: String, workCenters: List[ WorkCenterInformation ] )
}
