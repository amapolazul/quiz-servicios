package com.arlsura.afiliacion.services.affiliation.contacts

import com.arlsura.afiliacion.authentication.CookieSessionAuthentication
import com.arlsura.afiliacion.bussiness.RequestContextSupport
import com.arlsura.afiliacion.bussiness.affiliation.contacts.ContactsServiceHandler
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.SaveContactInformation
import com.arlsura.afiliacion.utils.resources.ResourcesNameRetriever
import com.google.inject.Guice
import spray.routing.{ Route, RequestContext, HttpService }
import net.codingwell.scalaguice.InjectorExtensions._
import ContactsService._

/**
 * Created by juanmartinez on 16/04/15.
 */
trait ContactsService extends HttpService with CookieSessionAuthentication with RequestContextSupport {

  private[ ContactsService ] implicit val executionContext = actorRefFactory.dispatcher
  private[ ContactsService ] lazy val injector = Guice.createInjector( new ContactsServiceModule() )

  val getContactInformation = {
    pathPrefix( affiliationsMainRouteBD / Segment ) {
      dni =>
        pathPrefix( dataMainRouteBD ) {
          pathPrefix( contactsMainRoute ) {
            pathEndOrSingleSlash {
              get {
                authenticate( authenticateBothCookies ) {
                  user =>
                    ( ctx: RequestContext ) =>

                      if ( dni == user.dni ) {
                        lazy val contactsHandler = injector.instance[ ContactsServiceHandler ]
                        completeRequest( contactsHandler.getContactsInfo( dni ), ctx )
                      }
                      else {
                        completeWithRejection( ctx )
                      }
                }
              }
            }
          }
        }
    }
  }

  val createContactInformation = {
    pathPrefix( affiliationsMainRouteBD / Segment ) {
      dni =>
        pathPrefix( dataMainRouteBD ) {
          pathPrefix( contactsMainRoute ) {
            pathEndOrSingleSlash {
              post {
                entity( as[ SaveContactInformation ] ) {
                  data =>
                    authenticate( authenticateBothCookies ) {
                      user =>
                        ( ctx: RequestContext ) =>
                          if ( dni == user.dni ) {
                            lazy val contactsHandler = injector.instance[ ContactsServiceHandler ]
                            completeRequest( contactsHandler.createOrUpdateContactsInfo( data, dni ), ctx )
                          }
                          else {
                            completeWithRejection( ctx )
                          }
                    }
                }
              }
            }
          }
        }
    }
  }

  def getContactsRoute: Route = getContactInformation ~ createContactInformation

}

object ContactsService {

  val affiliationsMainRouteBD = ResourcesNameRetriever.getResource( "affiliations", "MAIN_RESOURCE" )
  val dataMainRouteBD = ResourcesNameRetriever.getResource( "affiliations", "DATA" )
  val contactsMainRoute = ResourcesNameRetriever.getResource( "affiliations", "CONTACTS" )

}
