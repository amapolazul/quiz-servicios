package com.arlsura.afiliacion.services.affiliation.key

import com.arlsura.afiliacion.authentication.CookieSessionAuthentication
import com.arlsura.afiliacion.bussiness.RequestContextSupport
import com.arlsura.afiliacion.bussiness.affiliation.key.OnlineServicesKeyServiceHandler
import com.arlsura.afiliacion.utils.resources.ResourcesNameRetriever
import com.google.inject.Guice

import net.codingwell.scalaguice.InjectorExtensions._

import spray.routing.{ RequestContext, HttpService, Route }

import scala.concurrent.ExecutionContext

/**
 * Trait that provides routes implementation for affiliation key
 */
trait KeyService extends HttpService with CookieSessionAuthentication with RequestContextSupport {

  /**
   * Defines execution context for this route
   */
  private[ this ] implicit val executionContext: ExecutionContext = actorRefFactory.dispatcher

  /**
   * Defines main resource path for affiliations
   */
  private[ this ] val mainPath: String = ResourcesNameRetriever.getResource( "affiliations", "MAIN_RESOURCE" )

  /**
   * Defines key resource path for affiliations
   */
  private[ this ] val keyPath: String = ResourcesNameRetriever.getResource( "affiliations", "KEY" )

  /**
   * Defines summary resource path for affiliations
   */
  private[ this ] val summaryPath: String = ResourcesNameRetriever.getResource( "affiliations", "SUMMARY" )

  /**
   * Defines and initializes a new injector of KeyServiceModule
   */
  private[ this ] lazy val injector = Guice.createInjector( new KeyServiceModule() )

  /**
   * Method that defines the route for getting the online services key
   * HTTP_VERB: GET
   * HTTP_URL: /sura/arl/affiliations/{DNI}/key/summary
   */
  private[ this ] val getKeyInformationRoute: Route = pathPrefix( mainPath / Segment / keyPath / summaryPath ) { dni =>
    pathEndOrSingleSlash {
      get {
        authenticate( authenticateCaptcha() ) { user =>
          ( ctx: RequestContext ) =>
            if ( dni == user.dni ) {
              lazy val keyServiceHandler: OnlineServicesKeyServiceHandler = injector.instance[ OnlineServicesKeyServiceHandler ]
              completeRequest( keyServiceHandler.getSummaryData( dni ), ctx )
            }
            else {
              completeWithRejection( ctx )
            }
        }
      }
    }
  }

  // -------------------------------------
  // ROUTES COMPOSITION
  // -------------------------------------

  /**
   * Defines all routes composition
   */
  def getKeyRoutes: Route = getKeyInformationRoute

}
