package com.arlsura.afiliacion.services.code

import java.util.Date

import com.arlsura.afiliacion.ARLContext
import com.arlsura.afiliacion.authentication.CookieSessionAuthentication
import com.arlsura.afiliacion.bussiness.RequestContextSupport
import com.arlsura.afiliacion.bussiness.code.{ SecurityCodeServiceHandlerModule, SecurityCodeServiceHandler }
import com.arlsura.afiliacion.bussiness.code.recall.{ CodeRecallServiceHandler, CodeRecallServiceModule }
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.{ CodeRecallData, CodeValidationData, GeneralJsonResponseData, ClientMatchesCodeServiceResponse }
import com.arlsura.afiliacion.utils.Utils
import com.arlsura.afiliacion.utils.resources.ResourcesNameRetriever
import com.google.inject.Guice
import spray.http.{ StatusCodes, HttpCookie }
import net.codingwell.scalaguice.InjectorExtensions._
import spray.routing.{ HttpService, RequestContext }

import scala.concurrent.Future

/**
 * Created by Jesús Martínez on 24/11/14.
 */
trait SecurityCodeService extends HttpService with CookieSessionAuthentication with RequestContextSupport {
  private val path = ResourcesNameRetriever.getResource( "code", "MAIN_RESOURCE" )
  private[ SecurityCodeService ] implicit val _ = actorRefFactory.dispatcher
  private[ SecurityCodeService ] val codeRecallInjector = Guice.createInjector( new CodeRecallServiceModule() )
  private[ SecurityCodeService ] val generationInjector = Guice.createInjector( new SecurityCodeServiceHandlerModule() )

  private val codeGenerationServiceRoute = {
    path( path ) {
      pathEndOrSingleSlash {
        parameters( 'length?, 'alphanumeric? ) {
          ( length: Option[ String ], alphanumeric: Option[ String ] ) =>
            get {
              ( ctx: RequestContext ) =>
                val handler = generationInjector.instance[ SecurityCodeServiceHandler ]
                val l = length map ( _.toInt ) getOrElse 8
                val a = alphanumeric map ( _.toBoolean ) getOrElse true
                completeRequest( Future.successful( handler.generateSecurityCode( l, a ) ), ctx )
            }
        }
      }
    }
  }

  private val codeMatchesRoute = {
    pathPrefix( path ) {
      pathPrefix( "clients" ) {
        pathEndOrSingleSlash {
          post {
            entity( as[ CodeValidationData ] ) {
              data =>
                authenticate( authenticateCodeAndDni( data.code, data.dni ) ) {
                  user =>
                    val d = s"${data.dni}-${new Date().getTime.toString}"
                    val t = Utils.encodeFile( d.getBytes )
                    setCookie( HttpCookie( "suraSessionManager", content = t ) ) {

                      //TODO: Modificar esto. ¿Quizás manejar un solo status code?
                      ( ctx: RequestContext ) =>
                        val response = ClientMatchesCodeServiceResponse( user.codeMatches, user.isExpired, user.sourceCode, t )

                        if ( response.hasExpired ) {
                          ARLContext.sessionManager.deleteSession( data.dni )
                          ctx.complete( ( StatusCodes.Conflict, GeneralJsonResponseData( "Expired", Some( response ) ) ) )
                        }
                        else if ( !response.codeMatches ) {
                          //Si el código introducido no es correcto, inmediatamente elimina la sesión.
                          ARLContext.sessionManager.deleteSession( data.dni )
                          ctx.complete( ( StatusCodes.Conflict, GeneralJsonResponseData( "Code doesn't match", Some( response ) ) ) )
                        }
                        else
                          ctx.complete( ( StatusCodes.OK, GeneralJsonResponseData( "OK", Some( response ) ) ) )

                    }
                }
            }
          }
        }
      }
    }
  }

  //Recordatorio de código.
  // /codes/:dni/recall
  // body {by: [email|phone], key: ...}
  private val codeRecallRoute = pathPrefix( path / Segment ) { dni =>
    pathPrefix( "recall" ) {
      pathEndOrSingleSlash {
        post {
          entity( as[ CodeRecallData ] ) { data =>
            authenticate( authenticateCaptcha() ) { user =>
              ( ctx: RequestContext ) =>
                lazy val handler = codeRecallInjector.instance[ CodeRecallServiceHandler ]
                completeRequest( handler.recallCode( dni, data.by, data.key ), ctx )
            }
          }
        }
      }
    }
  }

  val securityCodeRoutes = codeGenerationServiceRoute ~ codeMatchesRoute ~ codeRecallRoute
}
