package com.arlsura.afiliacion.services.commercial

import java.util.Date

import com.arlsura.afiliacion.bussiness.HandlerSupport.ServiceHandlerResponse
import com.arlsura.afiliacion.bussiness.RequestContextSupport
import com.arlsura.afiliacion.bussiness.commercial.responsible.CommercialResponsibleManager
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.{ UpdateCommercialResponsibleRequest, GetCommercialResponsibleRequest, GeneralJsonResponseData, CreateCommercialResponsibleRequest }
import com.arlsura.afiliacion.persistence.entities.CommercialResponsible
import com.arlsura.afiliacion.utils.Utils
import com.arlsura.afiliacion.utils.messages.MessagesRetriever
import com.google.inject.Inject
import com.typesafe.scalalogging.LazyLogging
import reactivemongo.core.commands.LastError
import scala.concurrent.{ ExecutionContext, Future }
import CommercialResponsibleServiceHandler._

/**
 * Soporta las operaciones del recurso CommercialResponsible a través de su manager y completa las perticiones a travez
 * del RequestContext
 * @author John Cely
 * Created by root on 9/02/15.
 */
class CommercialResponsibleServiceHandler @Inject() ( manager: CommercialResponsibleManager ) extends LazyLogging {

  /**
   * Permite crear un documento CommercialResponsible
   * @param request
   */
  def create( request: CreateCommercialResponsibleRequest )( implicit ec: ExecutionContext ): Future[ ServiceHandlerResponse ] = {
    //    logRequest( "Create", request )
    val createRequest: Future[ LastError ] = manager.create( request )
    mapFutureOfNoResult( createRequest, commercialResponsibleCreateMessage )
  }

  /**
   * Retorna todos los documentos de la coleccion CommercialResponsible
   */
  def getAll()( implicit ec: ExecutionContext ): Future[ ServiceHandlerResponse ] = {
    //    logRequest( "Get All", None )
    val getAllRequest: Future[ List[ CommercialResponsible ] ] = manager.getAll()
    mapFutureOfMultipleResults( getAllRequest, commercialResponsibleGetAllMessage )
  }

  /**
   * Retorna los documentos de la coleccion CommercialResponsible que cumplean con los parametros de busqueda
   * @param request
   */
  def getBy( request: GetCommercialResponsibleRequest )( implicit ec: ExecutionContext ): Future[ ServiceHandlerResponse ] = {
    //    logRequest( "getBy", request )
    val getByRequest: Future[ List[ CommercialResponsible ] ] = manager.getBy( request )
    mapFutureOfMultipleResults( getByRequest, commercialResponsibleGetByMessage )
  }

  /**
   * Retorna el documento CommercialResponsible que coincida con el ID
   * @param id
   */
  def getById( id: String )( implicit ec: ExecutionContext ): Future[ ServiceHandlerResponse ] = {
    //    logRequest( "getById", id )
    val getByIdRequest: Future[ Option[ CommercialResponsible ] ] = manager.getById( id )
    mapFutureOfSingleResult( getByIdRequest, commercialResponsibleDeleteByIdMessage )
  }

  /**
   * Permite actualizar un documento CommercialResponsible
   * @param request
   */
  def update( request: UpdateCommercialResponsibleRequest )( implicit ec: ExecutionContext ): Future[ ServiceHandlerResponse ] = {
    //    logRequest( "Update", request )
    val updateRequest: Future[ LastError ] = manager.update( request )
    mapFutureOfNoResult( updateRequest, commercialResponsibleUpdateMessage )
  }

  /**
   * Permite eliminar todos los documentos de la coleccion CommercialResponsible
   */
  def deleteAll()( implicit ec: ExecutionContext ): Future[ ServiceHandlerResponse ] = {
    //    logRequest( "Delete All", None )
    val deleteAllRequest: Future[ LastError ] = manager.deleteAll()
    mapFutureOfNoResult( deleteAllRequest, commercialResponsibleDeleteAllMessage )
  }

  /**
   * Permite eliminar un documento CommercialResponsible
   * @param id
   */
  def deleteById( id: String )( implicit ec: ExecutionContext ): Future[ ServiceHandlerResponse ] = {
    //    logRequest( "Delete By", id )
    val deleteByIdRequest: Future[ LastError ] = manager.deleteById( id )
    mapFutureOfNoResult( deleteByIdRequest, commercialResponsibleDeleteByIdMessage )
  }

  /**
   * Transforma el contenido del futuro de una operación a una respuesta propia del servicio.
   * @param future Futuro que será transformado.
   * @param message Mensaje asociado a la ejecución exitosa del futuro.
   * @return Futuro con la respuesta apropiada, dependiendo del estado de la operación.
   */
  private def mapFutureOfNoResult( future: Future[ LastError ], message: String )( implicit ec: ExecutionContext ): Future[ ServiceHandlerResponse ] = {
    future map {
      result =>
        if ( result.ok ) Right( GeneralJsonResponseData( message ) ) else Left( RequestContextSupport.internalServerErrorMessage )
    } recover {
      case exception: Throwable =>
        Left( s"${RequestContextSupport.internalServerErrorMessage} ${exception.getMessage}" )
    }
  }

  /**
   * Transforma el contenido del futuro de una operación a una respuesta propia del servicio.
   * @param future Futuro que será transformado.
   * @param message Mensaje asociado a la ejecución exitosa del futuro.
   * @return Futuro con la respuesta apropiada, dependiendo del estado de la operación.
   */
  private def mapFutureOfSingleResult( future: Future[ Option[ CommercialResponsible ] ], message: String )( implicit ec: ExecutionContext ): Future[ ServiceHandlerResponse ] = {
    future map {
      resultSet =>
        val response = GeneralJsonResponseData( message, resultSet map formattedResponse )
        Right( response )
    } recover {
      case e: Throwable =>
        Left( s"${RequestContextSupport.internalServerErrorMessage} ${e.getMessage}" )
    }
  }

  /**
   * Transforma el contenido del futuro de una operación a una respuesta propia del servicio.
   * @param future Futuro que será transformado.
   * @param message Mensaje asociado a la ejecución exitosa del futuro.
   * @return Futuro con la respuesta apropiada, dependiendo del estado de la operación.
   */
  private def mapFutureOfMultipleResults( future: Future[ List[ CommercialResponsible ] ], message: String )( implicit ec: ExecutionContext ): Future[ ServiceHandlerResponse ] = {
    future map {
      resultSet =>
        val response = GeneralJsonResponseData( message, Some( resultSet map formattedResponse ) )
        Right( response )
    } recover {
      case exception: Throwable =>
        Left( s"${RequestContextSupport.internalServerErrorMessage} ${exception.getMessage}" )
    }
  }

  /**
   * Guarda una entrada en el log.
   * @param operation Operación que será guardada en el log.
   * @param request Parámetros de la operación.
   */
  private def logRequest( operation: String, request: Any ) = logger.debug( s"Commercial Responsible $operation Request: $request" )

  /**
   * Adapta el formato de una respuesta para ser devuelva por la red.
   * @param response Documento que será formateado.
   * @return Mapa con los valores de la respuesta formateados.
   */
  private def formattedResponse( response: CommercialResponsible ): Map[ String, Any ] = {
    Map(
      "id" -> response._id.stringify,
      "office" -> response.office,
      "city" -> response.city,
      "fullName" -> response.fullName,
      "email" -> response.email,
      "charge" -> response.charge,
      "networkUser" -> response.networkUser
    )
  }

  /**
   * Genera una cadena de caracteres de sesión con base en el DNI.
   * @param dni DNI usado para generar la cadena.
   * @return
   */
  private def getSessionString( dni: String ): Option[ String ] = {
    val d = s"$dni-${new Date().getTime.toString}"
    Some( Utils.encodeFile( d.getBytes ) )
  }

}

/**
 * Companion Object
 */
object CommercialResponsibleServiceHandler {

  def commercialResponsibleCreateMessage: String = MessagesRetriever.getSuccessMessage( "commercial_responsible", "CREATE" )

  def commercialResponsibleGetAllMessage: String = MessagesRetriever.getSuccessMessage( "commercial_responsible", "GET_ALL" )

  def commercialResponsibleGetByMessage: String = MessagesRetriever.getSuccessMessage( "commercial_responsible", "GET_BY" )

  def commercialResponsibleGetByIdMessage: String = MessagesRetriever.getSuccessMessage( "commercial_responsible", "GET_BY_ID" )

  def commercialResponsibleUpdateMessage: String = MessagesRetriever.getSuccessMessage( "commercial_responsible", "UPDATE" )

  def commercialResponsibleDeleteAllMessage: String = MessagesRetriever.getSuccessMessage( "commercial_responsible", "DELETE_ALL" )

  def commercialResponsibleDeleteByIdMessage: String = MessagesRetriever.getSuccessMessage( "commercial_responsible", "DELETE_BY_ID" )

}