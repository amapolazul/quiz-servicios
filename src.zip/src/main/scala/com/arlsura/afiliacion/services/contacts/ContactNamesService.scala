package com.arlsura.afiliacion.services.contacts

import com.arlsura.afiliacion.bussiness.RequestContextSupport
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.GeneralJsonResponseData
import com.arlsura.afiliacion.utils.resources.ResourcesNameRetriever
import com.google.inject.Guice
import spray.http.StatusCodes
import spray.routing.{ RequestContext, HttpService }
import net.codingwell.scalaguice.InjectorExtensions._

import scala.concurrent.ExecutionContext
import ContactNamesService._

/**
 * Created by John on 31/07/15.
 */
trait ContactNamesService extends HttpService with RequestContextSupport {

  private[ ContactNamesService ] implicit val _: ExecutionContext = actorRefFactory.dispatcher
  private[ ContactNamesService ] lazy val injector = Guice.createInjector( new ContactNamesServiceModule() )

  val contactNamesRoute = {
    pathPrefix( contactNamesServiceRoute ) {
      pathEndOrSingleSlash {
        get {
          requestContext: RequestContext =>
            lazy val handler = injector.instance[ ContactNamesServiceHandler ]
            val futureContactsList = handler.getAll()
            completeRequest( futureContactsList, requestContext )
        }
      }
    }
  }

}

object ContactNamesService {

  val contactNamesServiceRoute: String = ResourcesNameRetriever.getResource( "contactNames", "MAIN_RESOURCE" )

}