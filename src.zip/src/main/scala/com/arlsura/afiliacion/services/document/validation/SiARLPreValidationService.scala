package com.arlsura.afiliacion.services.document.validation

import akka.actor.{ ActorRef, Props }
import com.arlsura.afiliacion.actors.SiARLActor
import com.arlsura.afiliacion.actors.commons.VerboseActor
import com.arlsura.afiliacion.authentication.CookieSessionAuthentication
import com.arlsura.afiliacion.headers.CORSHeaders
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.{ PreValidateARLWebResponse, ExceptionOccurred, GeneralJsonResponseData, KeyExistenceCheckWebResponse }
import com.arlsura.afiliacion.utils.Utils
import spray.http.StatusCodes
import spray.routing.{ RequestContext, HttpService }

/**
 * Created by Jesús Martínez on 27/11/14.
 */
trait SiARLPreValidationService extends HttpService with CookieSessionAuthentication {

  private[ this ] implicit val executionContext = actorRefFactory.dispatcher

  private val actor = actorRefFactory.actorOf( SiARLActor.props, s"SiARL-actor-${Utils.getTimestamp}" )

  val preValidationRoute = {
    path( "prevalidate" ) {
      pathEndOrSingleSlash {
        parameters( 'document, 'isCompany ) {
          ( document: String, isCompany: String ) =>
            {
              get {
                authenticate( authenticateCaptcha() ) { user =>
                  ( ctx: RequestContext ) =>
                    try {
                      isCompany.toBoolean
                    }
                    catch {
                      //TODO Manejar esto de manera diferente.
                      case _: Exception => ctx.complete( GeneralJsonResponseData( "El parámetro 'isCompany' debe ser booleano", Some( Map( "document" -> document, "isCompany" -> isCompany ) ) ) )
                    }
                    val handler = actorRefFactory.actorOf( SiARLPreValidationServiceHandler.props( actor, ctx ), s"prevalidation-service-handler-${Utils.getTimestamp}" )
                    handler ! SiARLActor.PreValidateARL( document, isCompany.toBoolean )
                }
              }
            }
        }
      }
    }
  }
}

/**
 * Actor encargado de tomar las peticiones hechas al servicio y delegarlas en el actor
 * consumidor de los servicios de SiARL.
 * @param actor Referencia al actor consumidor de los servicios SOAP de SiARL.
 * @param ctx Contexto de la petición, utilizado para retornar la respusta.
 */
class SiARLPreValidationServiceHandler( actor: ActorRef, ctx: RequestContext ) extends VerboseActor {
  override def receive = {
    case msg @ SiARLActor.PreValidateARL( dni, isCompany ) =>
      //      log debug s"Recibido mensaje PreValidateARL: [$dni, $isCompany]"
      actor ! msg
    case SiARLActor.PreValidationResponse( canProceed ) =>
      //      log debug s"Recibido mensaje PreValidationResponse: $canProceed"
      completeAndShutdown( canProceed )
    case ex @ ExceptionOccurred( c, m ) =>
      //      log debug s"Recibido mensaje ExceptionOccurred: \n\tcause: $c \n\tmessage: $m"
      notifyErrorAndShutdown( ex )
  }

  private def completeAndShutdown( response: Boolean ): Unit = {
    val data = PreValidateARLWebResponse( response )
    val serviceResponse = GeneralJsonResponseData( "La consulta a SiARL se completo satisfactoriamente", Some( data ) )
    ctx.complete( serviceResponse )
    shutdown()
  }

  private def notifyErrorAndShutdown( exception: ExceptionOccurred ): Unit = {
    ctx.complete( GeneralJsonResponseData( "No fue posible consumir el servicio de SiARL", Some( exception ) ) )
    shutdown()
  }

  private def shutdown(): Unit = {
    context.stop( self )
  }
}

/**
 * Companion object del actor.
 */
object SiARLPreValidationServiceHandler {
  //Factory method.
  def props( actor: ActorRef, requestContext: RequestContext ) = Props( new SiARLPreValidationServiceHandler( actor, requestContext ) )
}
