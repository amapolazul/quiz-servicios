package com.arlsura.afiliacion.services.contributors

import com.arlsura.afiliacion.actors.cache.CacheRefresherActor
import com.arlsura.afiliacion.authentication.CookieSessionAuthentication
import com.arlsura.afiliacion.bussiness.contributors.ContributorsTypesServiceHandler
import com.arlsura.afiliacion.utils.resources.ResourcesNameRetriever
import spray.routing.{ Route, RequestContext, HttpService }
import com.arlsura.afiliacion.utils.Utils

/**
 * Created by root on 10/02/15.
 */
trait ContributorsService extends HttpService with CookieSessionAuthentication {

  private implicit val ec = actorRefFactory.dispatcher
  private val CACHE_ACTOR_NAME = s"contributors-service-cache-actor-${Utils.getTimestamp}"
  private val cacheActor = actorRefFactory.actorSelection( "akka://ARLSura-backend/user/cache-refresher-actor" )
  private val contributorsRoute = ResourcesNameRetriever.getResource( "contributors", "MAIN_RESOURCE" )
  private val typesRoute = ResourcesNameRetriever.getResource( "contributors", "TYPES" )

  val getContributorRoute = {
    pathPrefix( contributorsRoute / Segment ) {
      id =>
        pathEndOrSingleSlash {
          get {
            authenticate( authenticateCaptcha() ) { user =>
              ( requestContext: RequestContext ) =>
                val handler = new ContributorsServiceHandler( requestContext )
                handler.getById( id )
            }
          }
        }
    }
  }

  val getContributorsRoute = {
    pathPrefix( contributorsRoute ) {
      pathEndOrSingleSlash {
        parameter( 'type?, 'code? ) {
          ( t: Option[ String ], code: Option[ String ] ) =>
            get {
              authenticate( authenticateCaptcha() ) { user =>
                ( requestContext: RequestContext ) =>
                  if ( t.isDefined ) {
                    if ( t.map( _.toBoolean ).get ) {
                      val handler = new ContributorsTypesServiceHandler( requestContext, cacheActor )
                      code match {
                        case Some( c ) => handler.retrieveContributorsTypesByAffiliateCode( c )
                        case None      => handler.retrieveAllContributorsTypes()
                      }
                    }
                    else {
                      new ContributorsServiceHandler( requestContext ).getAll()
                    }
                  }
                  else {
                    new ContributorsServiceHandler( requestContext ).getAll()
                  }
              }
            }
        }
      }
    }
  }

  val contributorsServiceRoutes: Route =
    getContributorRoute ~
      getContributorsRoute

}
