package com.arlsura.afiliacion.services.contacts

import org.json4s.{ DefaultFormats, Formats }
import spray.httpx.Json4sSupport

/**
 * Created by John on 5/08/15.
 */
object ContactNamesMarshaller extends Json4sSupport {

  override implicit def json4sFormats: Formats = DefaultFormats

  case class ContactNamesServiceResponse( contactNames: List[ ContactName ] )

  case class ContactName(
    contactId:            String,
    contactDescription:   String,
    isMainContact:        Boolean,
    neededForWorkcenters: Boolean
  )

}
