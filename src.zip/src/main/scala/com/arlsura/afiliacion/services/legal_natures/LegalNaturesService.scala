package com.arlsura.afiliacion.services.legal_natures

import com.arlsura.afiliacion.authentication.CookieSessionAuthentication
import com.arlsura.afiliacion.utils.resources.ResourcesNameRetriever
import com.arlsura.afiliacion.bussiness.legal_natures.LegalNaturesServiceHandler
import spray.routing._
import com.arlsura.afiliacion.utils.Utils
import com.arlsura.afiliacion.actors.cache.CacheRefresherActor
/**
 * Created by root on 12/03/15.
 */
trait LegalNaturesService extends HttpService with CookieSessionAuthentication {
  private implicit val ec = actorRefFactory.dispatcher
  private val cacheActor = actorRefFactory.actorSelection( "akka://ARLSura-backend/user/cache-refresher-actor" )
  private val legalNaturesMainPath = ResourcesNameRetriever.getResource( "juridical_natures", "MAIN_RESOURCE" )

  private val getAllRoute = {
    pathPrefix( legalNaturesMainPath ) {
      pathEndOrSingleSlash {
        get {
          authenticate( authenticateCaptcha() ) {
            user =>
              ( ctx: RequestContext ) => new LegalNaturesServiceHandler( ctx, cacheActor ).retrieveLegalNaturesCatalog()
          }

        }
      }
    }
  }

  val legalNaturesServiceRoutes: Route = getAllRoute

}
