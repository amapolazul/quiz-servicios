package com.arlsura.afiliacion.services.affiliation

import java.util.Date

import com.arlsura.afiliacion.authentication.CookieSessionAuthentication
import com.arlsura.afiliacion.bussiness.RequestContextSupport
import com.arlsura.afiliacion.bussiness.affiliation.{ BasicDataServiceModule, BasicDataServiceHandler }
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.SaveAffiliationBasicData
import com.arlsura.afiliacion.utils.Utils
import com.arlsura.afiliacion.utils.resources.ResourcesNameRetriever
import com.google.inject.Guice
import spray.http.HttpCookie
import spray.routing.{ RequestContext, HttpService }
import net.codingwell.scalaguice.InjectorExtensions._

/**
 * Servicio para el guardado parcial y precargado de los datos basicos
 * Created by John on 31/03/15.
 */
trait BasicDataService extends HttpService with CookieSessionAuthentication with RequestContextSupport {
  private[ BasicDataService ] implicit val _ = actorRefFactory.dispatcher
  private[ BasicDataService ] lazy val injector = Guice.createInjector( new BasicDataServiceModule() )

  val affiliationsMainRouteBD = ResourcesNameRetriever.getResource( "affiliations", "MAIN_RESOURCE" )
  val dataMainRouteBD = ResourcesNameRetriever.getResource( "affiliations", "DATA" )
  val basciDataMainRouteBD = ResourcesNameRetriever.getResource( "affiliations", "BASIC_DATA" )

  val getAffiliationBasicDataRoute = {
    pathPrefix( affiliationsMainRouteBD / Segment ) {
      dni =>
        pathPrefix( dataMainRouteBD ) {
          pathPrefix( basciDataMainRouteBD ) {
            pathEndOrSingleSlash {
              get {
                authenticate( authenticateBothCookies ) {
                  user =>
                    val d = s"${user.dni}-${new Date().getTime.toString}"
                    val t = Utils.encodeFile( d.getBytes )
                    setCookie( HttpCookie( "suraSessionManager", content = t ) ) {
                      ( requestContext: RequestContext ) =>

                        if ( user.dni == dni ) {
                          lazy val handler = injector.instance[ BasicDataServiceHandler ]
                          completeRequest( handler.getBasicData( dni ), requestContext )
                        }
                        else {
                          completeWithRejection( requestContext )
                        }
                    }
                }
              }
            }
          }
        }
    }
  }

  val postAffiliationBasicDataRoute = {
    pathPrefix( affiliationsMainRouteBD / Segment ) {
      dni =>
        pathPrefix( dataMainRouteBD ) {
          pathPrefix( basciDataMainRouteBD ) {
            pathEndOrSingleSlash {
              post {
                authenticate( authenticateBothCookies ) {
                  user =>
                    entity( as[ SaveAffiliationBasicData ] ) {
                      data =>
                        ( requestContext: RequestContext ) =>
                          if ( dni == user.dni ) {
                            lazy val handler = injector.instance[ BasicDataServiceHandler ]
                            completeRequest( handler.saveBasicData( dni, data ), requestContext )
                          }
                          else {
                            completeWithRejection( requestContext )
                          }
                    }
                }
              }
            }
          }
        }
    }
  }

  def basicDataServiceRoutes = getAffiliationBasicDataRoute ~ postAffiliationBasicDataRoute

}
