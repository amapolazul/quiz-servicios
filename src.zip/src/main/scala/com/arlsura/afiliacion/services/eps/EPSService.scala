package com.arlsura.afiliacion.services.eps

import com.arlsura.afiliacion.actors.cache.CacheRefresherActor
import com.arlsura.afiliacion.authentication.CookieSessionAuthentication
import com.arlsura.afiliacion.bussiness.eps.EPSServiceHandler
import com.arlsura.afiliacion.headers.CORSHeaders
import com.arlsura.afiliacion.utils.Utils
import com.arlsura.afiliacion.utils.resources.ResourcesNameRetriever
import spray.routing.{ RequestContext, HttpService }

/**
 * Created by root on 30/03/15.
 */
trait EPSService extends HttpService with CookieSessionAuthentication {
  private implicit val ec = actorRefFactory.dispatcher
  private val path = ResourcesNameRetriever.getResource( "eps", "MAIN_RESOURCE" )
  private val cacheActor = actorRefFactory.actorSelection( "akka://ARLSura-backend/user/cache-refresher-actor" )

  private val getEps = {
    path( path ) {
      get {
        authenticate( authenticateCaptcha() ) {
          user =>
            ( ctx: RequestContext ) =>
              val handler = new EPSServiceHandler( ctx, cacheActor )
              handler.retrieveEPSs()
        }
      }
    }
  }

  val epsRoutes = getEps
}
