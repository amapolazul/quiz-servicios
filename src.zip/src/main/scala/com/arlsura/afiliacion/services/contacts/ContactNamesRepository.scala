package com.arlsura.afiliacion.services.contacts

import com.arlsura.afiliacion.persistence.daos.wrappers.ContactNamesWrapper
import com.arlsura.afiliacion.persistence.entities.ContactNames
import com.google.inject.Inject

import scala.concurrent.{ Future, ExecutionContext }

/**
 * Created by John on 31/07/15.
 */
class ContactNamesRepository @Inject() ( val dao: ContactNamesWrapper ) {

  def getAll()( implicit ec: ExecutionContext ): Future[ List[ ContactNames ] ] = dao.findAll()

}
