package com.arlsura.afiliacion.services.activities

import akka.actor.ActorRef
import com.arlsura.afiliacion.actors.cache.CacheRefresherActor
import com.arlsura.afiliacion.authentication.CookieSessionAuthentication
import com.arlsura.afiliacion.bussiness.activities.ActivitiesServiceHandler
import com.arlsura.afiliacion.utils.Utils
import com.arlsura.afiliacion.utils.resources.ResourcesNameRetriever
import spray.routing.{ RequestContext, HttpService }

/**
 * Created by juanmartinez on 7/01/15.
 */
trait ActivitiesService extends HttpService with CookieSessionAuthentication {
  private implicit val ec = actorRefFactory.dispatcher
  private val cacheActor = actorRefFactory.actorSelection( "akka://ARLSura-backend/user/cache-refresher-actor" )
  private val path: String = ResourcesNameRetriever.getResource( "activities", "MAIN_RESOURCE" )

  val activitiesServicePath = {
    path( path ) {
      parameters( 'code.?, 'name.? ) {
        ( code: Option[ String ], name: Option[ String ] ) =>
          get {
            authenticate( authenticateCaptcha() ) {
              user =>
                ( ctx: RequestContext ) =>
                  val handler = new ActivitiesServiceHandler( ctx, Some( cacheActor ) )
                  handler.retrieveActivities( code, name )
            }
          }
      }
    }
  }

  def getActivitiesRoutes = activitiesServicePath

}