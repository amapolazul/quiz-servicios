package com.arlsura.afiliacion.services.segmentation

import com.arlsura.afiliacion.authentication.CookieSessionAuthentication
import com.arlsura.afiliacion.bussiness.RequestContextSupport
import com.arlsura.afiliacion.bussiness.segmentation.SegmentationServiceHandler

import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller._
import com.arlsura.afiliacion.utils.resources.ResourcesNameRetriever
import spray.routing.{ Route, RequestContext, HttpService }

/**
 * Created by juanmartinez on 23/12/14.
 */

trait SegmentationService extends HttpService with RequestContextSupport with CookieSessionAuthentication {

  import SegmentationService._

  implicit val exContext = actorRefFactory.dispatcher

  val segmentationServicePath = ResourcesNameRetriever.getResource( "segmentation", "MAIN_RESOURCE" )
  val segmentationOperators = ResourcesNameRetriever.getResource( "segmentation", "OPERATORS" )

  val segmentationServiceCreate = {
    pathPrefix( segmentationServicePath ) {
      pathEndOrSingleSlash {
        detach() {
          post {
            entity( as[ SegmentationEntityRequest ] ) {
              segmentationEntity =>
                authenticate( authenticateCaptcha() ) { user =>
                  ( context: RequestContext ) =>
                    val handler: SegmentationServiceHandler = new SegmentationServiceHandler( context )
                    handler.createSegmentationRule( segmentationEntity )
                }
            }
          }
        }
      }
    }
  }

  val segmentationServiceGetAll = {
    pathPrefix( segmentationServicePath ) {
      parameters( 'ciiu.?, 'city.? ) {
        ( ciiu, city ) =>
          pathEndOrSingleSlash {
            detach() {
              get {
                authenticate( authenticateCaptcha() ) { user =>
                  ( ctx: RequestContext ) =>
                    val handler: SegmentationServiceHandler = new SegmentationServiceHandler( ctx )
                    ( ciiu, city ) match {
                      case ( None, None ) =>
                        handler.getAllSegmentationRules()
                      case _ =>
                        handler.getSegmentationRules( ciiu, city )
                    }
                }
              }
            }
          }
      }
    }
  }

  val segmentationServiceGetById = {
    pathPrefix( segmentationServicePath / Segment ) {
      ( segRuleId: String ) =>
        pathEndOrSingleSlash {
          detach() {
            get {
              authenticate( authenticateCaptcha() ) { user =>
                ( ctx: RequestContext ) =>
                  val handler: SegmentationServiceHandler = new SegmentationServiceHandler( ctx )
                  handler.getSegmentationRuleById( segRuleId )
              }
            }
          }

        }
    }
  }

  val segmentationOperatorsGet = {
    pathPrefix( segmentationOperators ) {
      pathEndOrSingleSlash {
        detach() {
          get {
            authenticate( authenticateCaptcha() ) { user =>
              ( ctx: RequestContext ) =>
                val handler: SegmentationServiceHandler = new SegmentationServiceHandler( ctx )
                handler.getAllSegmentationOperators()
            }
          }
        }
      }
    }
  }

  val updateSegmentationRule = {
    pathPrefix( segmentationServicePath / Segment ) {
      ( segRuleId: String ) =>
        detach() {
          put {
            authenticate( authenticateCaptcha() ) { user =>
              entity( as[ SegmentationEntityRequest ] ) {
                ( segEntity: SegmentationEntityRequest ) =>
                  ( ctx: RequestContext ) =>
                    val handler: SegmentationServiceHandler = new SegmentationServiceHandler( ctx )
                    handler.updateSegmentationRule( segRuleId, segEntity )
              }
            }
          }
        }
    }
  }

  val segmentationServiceDeleteById = {
    pathPrefix( segmentationServicePath / Segment ) {
      ( segRuleId: String ) =>
        pathEndOrSingleSlash {
          detach() {
            delete {
              authenticate( authenticateCaptcha() ) { user =>
                ( ctx: RequestContext ) =>
                  val handler: SegmentationServiceHandler = new SegmentationServiceHandler( ctx )
                  handler.deleteSegmentationRule( segRuleId )
              }
            }
          }
        }
    }
  }

  /**
   * Devuelve la ruta total de los servicios
   */
  def getSegmentationRoutes: Route = {
    segmentationServiceCreate ~
      segmentationServiceGetAll ~
      segmentationServiceGetAll ~
      segmentationServiceGetById ~
      updateSegmentationRule ~
      segmentationOperatorsGet ~
      segmentationServiceDeleteById
  }
}

object SegmentationService {
  val segmentationServicePath = ResourcesNameRetriever.getResource( "segmentation", "MAIN_RESOURCE" )
  val segmentationOperators = ResourcesNameRetriever.getResource( "segmentation", "OPERATORS" )
}