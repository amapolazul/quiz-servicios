package com.arlsura.afiliacion.services.independents.services

import com.arlsura.afiliacion.authentication.CookieSessionAuthentication
import com.arlsura.afiliacion.bussiness.independents.IndependentsServiceHandler
import com.arlsura.afiliacion.headers.CORSHeaders
import com.arlsura.afiliacion.utils.resources.ResourcesNameRetriever
import spray.routing.{ RequestContext, HttpService }

/**
 * Created by root on 6/02/15.
 */
trait IndependentsService extends HttpService with CookieSessionAuthentication {

  private[ this ] implicit val executionContext = actorRefFactory.dispatcher

  private val saveLastEntranceDatePath = {
    pathPrefix( IndependentsService.path / Segment ) {
      dni =>
        pathEndOrSingleSlash {
          post {
            authenticate( authenticateCaptcha() ) { user =>
              ( ctx: RequestContext ) =>
                val handler = new IndependentsServiceHandler( ctx )
                handler.recordLastEntranceDate( dni )
            }
          }
        }
    }
  }

  private val getLastEntranceDatePath = {
    pathPrefix( IndependentsService.path / Segment ) {
      dni =>
        pathEndOrSingleSlash {
          get {
            authenticate( authenticateCaptcha() ) { user =>
              ( ctx: RequestContext ) =>
                val handler = new IndependentsServiceHandler( ctx )
                handler.retrieveLastEntranceDate( dni )
            }
          }
        }
    }
  }

  val independentsPath = getLastEntranceDatePath ~ saveLastEntranceDatePath

}

object IndependentsService {

  val path = ResourcesNameRetriever.getResource( "independents", "MAIN_RESOURCE" )

}