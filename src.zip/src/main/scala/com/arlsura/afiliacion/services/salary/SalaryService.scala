package com.arlsura.afiliacion.services.salary

import com.arlsura.afiliacion.actors.cache.CacheRefresherActor
import com.arlsura.afiliacion.authentication.CookieSessionAuthentication
import com.arlsura.afiliacion.bussiness.RequestContextSupport
import com.arlsura.afiliacion.bussiness.salary.SalaryServiceHandler
import com.arlsura.afiliacion.headers.CORSHeaders
import com.arlsura.afiliacion.utils.Utils
import com.arlsura.afiliacion.utils.resources.ResourcesNameRetriever
import spray.routing.{ RequestContext, HttpService }

/**
 * Created by root on 31/03/15.
 */
trait SalaryService extends HttpService with CookieSessionAuthentication with RequestContextSupport {
  private[ SalaryService ] implicit val _ = actorRefFactory.dispatcher
  private val path = ResourcesNameRetriever.getResource( "salaries", "MAIN_RESOURCE" )
  private val cacheActor = actorRefFactory.actorSelection( "akka://ARLSura-backend/user/cache-refresher-actor" )

  private val getSalaryPath = {
    path( path ) {
      get {
        authenticate( authenticateCaptcha() ) {
          user =>
            ( ctx: RequestContext ) =>
              val handler = new SalaryServiceHandler( cacheActor )
              completeRequest( handler.retrieveMinimumSalary(), ctx )
        }
      }
    }
  }

  val salaryRoutes = getSalaryPath
}
