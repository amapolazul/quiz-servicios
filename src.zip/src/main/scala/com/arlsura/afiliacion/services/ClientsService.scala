package com.arlsura.afiliacion.services

import com.arlsura.afiliacion.authentication.CookieSessionAuthentication
import com.arlsura.afiliacion.bussiness.RequestContextSupport
import com.arlsura.afiliacion.bussiness.client.ClientServiceHandler
import com.arlsura.afiliacion.headers.CORSHeaders
import com.arlsura.afiliacion.utils.DNIBuilder
import com.arlsura.afiliacion.utils.resources.ResourcesNameRetriever
import spray.routing.{ RequestContext, HttpService }

import scala.concurrent.ExecutionContext.Implicits.global

/**
 * Created by root on 11/02/15.
 */
trait ClientsService extends HttpService with CORSHeaders with CookieSessionAuthentication with RequestContextSupport {
  private val path = ResourcesNameRetriever.getResource( "clients", "MAIN_RESOURCE" )

  private val hasIndependentsPath =
    pathPrefix( path / Segment ) {
      dni =>
        pathEndOrSingleSlash {
          get {
            authenticate( authenticateCaptcha ) {
              user =>
                ( ctx: RequestContext ) =>

                  if ( dni == user.dni ) {
                    val handler = new ClientServiceHandler( ctx )
                    handler.checkIndependents( dni )
                  }
                  else {
                    completeWithRejection( ctx )
                  }
            }
          }
        }
    }

  private val validateDocFormatPath =
    pathPrefix( path / Segment ) {
      dni =>
        path( "validate" ) {
          pathEndOrSingleSlash {
            parameter( 'digit.? ) {
              digit =>
                get {
                  authenticate( authenticateCaptcha ) {
                    user =>
                      ( ctx: RequestContext ) =>
                        val builtDni = DNIBuilder.build( dni.take( 2 ).mkString, dni.drop( 2 ).mkString.mkString )
                        if ( builtDni == user.dni ) {
                          val handler = new ClientServiceHandler( ctx )
                          handler.validateDocumentFormat( dni, digit )
                        }
                        else {
                          completeWithRejection( ctx )
                        }
                  }
                }
            }
          }
        }
    }

  //TODO Acá debe ir el recurso para traer el código del usuario.

  val clientRoutes = hasIndependentsPath ~ validateDocFormatPath
}
