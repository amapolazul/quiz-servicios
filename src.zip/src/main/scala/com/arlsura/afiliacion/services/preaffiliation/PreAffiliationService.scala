package com.arlsura.afiliacion.services.preaffiliation

import com.arlsura.afiliacion.bussiness.HandlerSupport.ServiceHandlerResponse
import com.arlsura.afiliacion.bussiness.{ RequestContextSupport, PreAffiliationServiceHandler }
import com.arlsura.afiliacion.authentication.CookieSessionAuthentication
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.GeneralJsonResponseData
import com.arlsura.afiliacion.proceso.pasos.segmentacion.PreAffiliationSegmentationDecisionHandler
import com.arlsura.afiliacion.services.preaffiliation.PreaffiliationMarshaller.{ SegmentationDecision, PreAffiliationSaveRequest }
import com.arlsura.afiliacion.utils.DNIBuilder
import com.arlsura.afiliacion.utils.resources.ResourcesNameRetriever
import com.google.inject.Guice
import spray.http._
import net.codingwell.scalaguice.InjectorExtensions._
import spray.routing.{ Route, RequestContext, HttpService }

import PreAffiliationService._

import scala.concurrent.Future

/**
 * Created by juanmartinez on 26/11/14.
 */
trait PreAffiliationService extends HttpService with RequestContextSupport with CookieSessionAuthentication {

  private[ PreAffiliationService ] implicit val _ = actorRefFactory.dispatcher
  private[ PreAffiliationService ] val injector = Guice.createInjector( new PreaffiliationServiceHandlerModule() )

  val createAffiliationRoute = {
    pathPrefix( affiliationsMainRoute ) {
      pathEndOrSingleSlash {
        post {
          authenticate( authenticateCaptcha ) {
            user =>
              entity( as[ PreAffiliationSaveRequest ] ) {
                data =>
                  ( requestContext: RequestContext ) =>

                    val builtDni = DNIBuilder.build( data.identificationType, data.identification )

                    if ( builtDni == user.dni ) {
                      val handler: PreAffiliationServiceHandler = injector.instance[ PreAffiliationServiceHandler ]
                      completeRequest( handler.savePreAffiliationData( data ), requestContext )
                    }
                    else {
                      completeWithRejection( requestContext )
                    }
              }
          }
        }
      }
    }
  }

  val updateSegmentationStateRoute = {
    pathPrefix( affiliationsMainRoute / Segment ) {
      dni =>
        pathPrefix( segmentationUpdate ) {
          pathEndOrSingleSlash {
            post {
              authenticate( authenticateCaptcha() ) { user =>
                entity( as[ SegmentationDecision ] ) {
                  data =>
                    ( requestContext: RequestContext ) =>
                      val handler: PreAffiliationSegmentationDecisionHandler = injector.instance[ PreAffiliationSegmentationDecisionHandler ]
                      val futureResponse: Future[ ServiceHandlerResponse ] = handler.updateSegmentatioDecision( dni, data )
                      completeRequest( futureResponse, requestContext )
                }
              }
            }
          }
        }
    }
  }

  val getAffiliationRoute = {
    pathPrefix( affiliationsMainRoute / Segment ) {
      dni =>
        pathEndOrSingleSlash {
          get {
            authenticate( authenticateCaptcha() ) {
              user =>
                ( requestContext: RequestContext ) =>
                  if ( user.dni == dni ) {
                    val handler = injector.instance[ PreAffiliationServiceHandler ]
                    completeRequest( handler.getPreAffiliation( dni ), requestContext )
                  }
                  else {
                    completeWithRejection( requestContext )
                  }
            }
          }
        }
    }
  }

  /**
   * retorna las rutas concatenadas
   */
  def preaffiliationRoutes: Route =
    createAffiliationRoute ~
      getAffiliationRoute ~
      updateSegmentationStateRoute

}

object PreAffiliationService {

  val affiliationsMainRoute = ResourcesNameRetriever.getResource( "affiliations", "MAIN_RESOURCE" )

  val segmentationUpdate = ResourcesNameRetriever.getResource( "affiliations", "SEGMENTATION" )

}