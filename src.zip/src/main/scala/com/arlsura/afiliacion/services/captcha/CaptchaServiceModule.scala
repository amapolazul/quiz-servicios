package com.arlsura.afiliacion.services.captcha

import com.google.inject.AbstractModule
import net.codingwell.scalaguice.ScalaModule

/**
 * Created by John on 20/05/15.
 */
class CaptchaServiceModule extends AbstractModule with ScalaModule {

  override def configure(): Unit = {
    bind[ GoogleReCaptchaService ]
  }

}
