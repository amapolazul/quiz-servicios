package com.arlsura.afiliacion.services.contributors

import com.arlsura.afiliacion.bussiness.RequestContextSupport
import com.arlsura.afiliacion.bussiness.contributors.ContributorsManager
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.{ GeneralJsonResponseData }
import com.arlsura.afiliacion.persistence.entities.Contributor
import com.arlsura.afiliacion.services.contributors.ContributorsServiceHandler._
import com.arlsura.afiliacion.utils.messages.MessagesRetriever
import com.typesafe.scalalogging.LazyLogging
import spray.http.StatusCodes
import spray.routing.RequestContext
import scala.concurrent.ExecutionContext
import scala.concurrent.Future
import scala.util.{ Failure, Success }

class ContributorsServiceHandler( requestContext: RequestContext )( implicit ec: ExecutionContext ) extends RequestContextSupport with LazyLogging {

  /**
   * Manager de la coleccion Contributor
   */
  private val manager: ContributorsManager = new ContributorsManager()

  /**
   * Retorna todos los documentos de la coleccion Contributor
   */
  def getAll(): Unit = {
    //    logRequest( "Get All", None )
    val getAllRequest = manager.getAll()
    handleFutureOfMultipleResults( getAllRequest, contributorsGetAllMessage )
  }

  /**
   * Retorna el documento Contributor que coincida con el ID
   * @param id
   */
  def getById( id: String ): Unit = {
    //    logRequest( "getById", id )
    val getByIdRequest = manager.getById( id )
    handleFutureOfSingleResult( getByIdRequest, contributorsGetByIdMessage )
  }

  private def handleFutureOfSingleResult( future: Future[ Option[ Contributor ] ], message: String ): Unit = {
    future onComplete {
      case Success( resultSet ) =>
        val response = GeneralJsonResponseData( message, Some( resultSet map formattedResponse ) )
        complete( requestContext, StatusCodes.OK, response )
      case Failure( exception ) =>
        completeWithFailure( requestContext, s"${RequestContextSupport.internalServerErrorMessage} ${exception.getMessage}" )
    }
  }

  private def handleFutureOfMultipleResults( future: Future[ List[ Contributor ] ], message: String ): Unit = {
    future onComplete {
      case Success( resultSet ) =>
        val response = GeneralJsonResponseData( message, Some( GetAllContributorsServiceResponse( resultSet map formattedResponse ) ) )
        complete( requestContext, StatusCodes.OK, response )
      case Failure( exception ) =>
        completeWithFailure( requestContext, s"${RequestContextSupport.internalServerErrorMessage} ${exception.getMessage}" )
    }
  }

  private def logRequest( operation: String, request: Any ) = logger.debug( s"Contributors $operation Request: $request" )

  private def formattedResponse( response: Contributor ): Map[ String, Any ] = {
    Map(
      "_id" -> response._id.stringify,
      "id" -> response.id,
      "name" -> response.name
    )
  }

}

/**
 * Companion Object
 */
object ContributorsServiceHandler {

  def contributorsGetAllMessage: String = MessagesRetriever.getSuccessMessage( "contributors", "GET_ALL" )

  def contributorsGetByIdMessage: String = MessagesRetriever.getSuccessMessage( "contributors", "GET_BY_ID" )

  case class GetAllContributorsServiceResponse( contributors: List[ Map[ String, Any ] ] )

}