package com.arlsura.afiliacion.services.preaffiliation

import com.arlsura.afiliacion.authentication.CookieSessionAuthentication
import com.arlsura.afiliacion.bussiness.RequestContextSupport
import com.arlsura.afiliacion.preaffiliation.PreaffiliationPrevalidation
import com.arlsura.afiliacion.utils.DNIBuilder
import spray.routing.HttpService
import spray.routing.RequestContext
import scala.concurrent.ExecutionContext.Implicits.global

/**
 * Created by root on 6/02/15.
 */
trait PreaffiliationPrevalidationService extends HttpService with CookieSessionAuthentication with RequestContextSupport {

  val preaffiliationPrevalidationRoute = {
    pathPrefix( "preaffiliations" / Segment / Segment / "prevalidate" ) {
      ( docType, document ) =>
        pathEndOrSingleSlash {
          get {
            authenticate( authenticateCaptcha ) {
              user =>
                ( requestContext: RequestContext ) =>
                  val builtDni = DNIBuilder.build( docType, document )

                  if ( builtDni == user.dni ) {
                    val preaffiliationPrevalidation = new PreaffiliationPrevalidation( requestContext )
                    preaffiliationPrevalidation.check( docType, document )
                  }
                  else {
                    completeWithRejection( requestContext )
                  }
            }
          }
        }
    }
  }
}
