package com.arlsura.afiliacion.services.captcha

import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.GeneralJsonResponseData
import com.arlsura.afiliacion.services.captcha.CaptchaJsonMarshaller.{ CaptchaServiceResponse, CaptchaServiceRequest }
import com.google.inject.Inject

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

/**
 * Tiene la logica para verificar el resultado del CAPTCHA
 * Created by John on 14/04/15.
 */
class CaptchaServiceHandler @Inject() ( recaptcha: GoogleReCaptchaService ) {

  /**
   * Ejecuta la validacion de captcha
   * @param requestData
   * @return
   */
  def executeValidation( requestData: CaptchaServiceRequest ): Future[ Either[ String, Boolean ] ] = {
    recaptcha.validate( requestData ) map {
      captchaResult =>
        Right( captchaResult.success )
    } recover {
      case e: Throwable =>
        //        e.printStackTrace()
        // TODO: MODIFICAR mientras se aclara si es un problema con el proxy de SURA
        Left( "Ocurrio un error al consumir el servicio ReCaptcha de Google: " + e.toString )
      //Right( GeneralJsonResponseData( "El servicio ReCaptcha de Google fue consumido, pero ocurrio un problema, se permite continuar temporalmente, no es para una version de pruebas/produccion", Some( CaptchaServiceResponse( true ) ) ) )
    }
  }
}
