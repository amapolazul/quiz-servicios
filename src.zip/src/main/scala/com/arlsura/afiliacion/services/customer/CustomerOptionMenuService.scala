//package com.arlsura.afiliacion.services.customer
//
//import java.util.Date
//
//import akka.actor._
//import com.arlsura.afiliacion.actors.CustomerMenuActor
//import com.arlsura.afiliacion.actors.commons.VerboseActor
//import com.arlsura.afiliacion.headers.CORSHeaders
//import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.{ExceptionOccurred, CustomerOptionMenuResponse, GeneralJsonResponseData}
//import com.arlsura.afiliacion.utils.Utils
//import spray.http.StatusCodes
//import spray.routing.{RequestContext, HttpService}
//
///**
// * Created by juanmartinez on 5/11/14.
// */
//trait CustomerOptionMenuService extends HttpService with CORSHeaders{
//
//  private val customerActor = actorRefFactory.actorOf(CustomerMenuActor.props, s"customerOptionsActor-${Utils.getTimestamp}")
//
//  val customerOptionService = {
//      pathPrefix("customer") {
//        path("menu"){
//          pathEndOrSingleSlash {
//            parameter('docType) {
//              docType =>
//                get {
//
//                    (ctx: RequestContext) =>
//                      val handler = actorRefFactory.actorOf(CustomerOptionMenuServiceHandler.props(customerActor, ctx), s"customerOptionsActor-handler-${Utils.getTimestamp}" )
//                      handler ! CustomerMenuActor.GetCustomerOptionMenu(docType)
//                  }
//                }
//
//          }
//       }
//     }
//  }
//}
//
///**
// * Actor encargado de manejar la solicitud hecha al servicio, así como enviar de vuelta la respuesta, una vez
// * recibida.
// * @param actor
// * @param ctx RequestContext para completar la solicitud una vez obtenida la respuesta.
// */
//private class CustomerOptionMenuServiceHandler(actor: ActorRef, ctx: RequestContext) extends VerboseActor {
//  override def receive = {
//    case CustomerMenuActor.GetCustomerOptionMenu(docType) =>
//      log.debug("Entrando a consultar el menu para el tipo de documento ")
//      actor ! CustomerMenuActor.GetCustomerOptionMenu(docType)
//    case CustomerMenuActor.CustomerOptionResponse(response) =>
//      log.debug(s"Recibido mensaje CustomerOptionResponse: $response")
//      response match {
//        case Some(res) =>
//          val customerOptions = CustomerOptionMenuResponse(res.options)
//          val responseData = GeneralJsonResponseData(StatusCodes.OK.intValue, "Trasacción ejecutada correctamente", Some(customerOptions))
//          log.debug(s"Se encontraron registros: $customerOptions")
//          completeAndShutDown(responseData)
//        case None =>
//          val responseData = GeneralJsonResponseData(StatusCodes.OK.intValue, "Trasacción ejecutada correctamente", Some("No se encontraron registros"))
//          log.debug(s"No se encontraron registros")
//          completeAndShutDown(responseData)
//      }
//    case ex @ ExceptionOccurred(c, m) =>
//      log.debug(s"Recibido mensaje ExceptionOcurred:\n\tcause: $c\n\t$m")
//      completeAndShutDown(GeneralJsonResponseData(StatusCodes.InternalServerError.intValue, "Ha ocurrido una excepción", Some(ex)))
//  }
//
//  private def completeAndShutDown(response: GeneralJsonResponseData): Unit = {
//    log.debug("Enviando respuesta.")
//    ctx.complete(response)
//    log.debug("Deteniendo el handler.")
//    context.stop(self)
//  }
//}
//
///**
// * Companion object del handler.
// */
//private object CustomerOptionMenuServiceHandler {
//  //Factory method del handler.
//  def props(actor: ActorRef, context: RequestContext) = Props(new CustomerOptionMenuServiceHandler(actor, context))
//}