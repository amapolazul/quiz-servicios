package com.arlsura.afiliacion.services.affiliation.contacts

import com.arlsura.afiliacion.bussiness.affiliation.contacts.ContactDataRepository
import com.arlsura.afiliacion.persistence.daos.affiliation.wrappers.AffiliationContactsDataWrapper
import com.google.inject.AbstractModule
import net.codingwell.scalaguice.ScalaModule

/**
 * Created by Jesús Martínez on 20/05/15.
 */
class ContactsServiceModule extends AbstractModule with ScalaModule {
  override def configure(): Unit = {
    bind[ AffiliationContactsDataWrapper ]
    bind[ ContactDataRepository ]
  }
}
