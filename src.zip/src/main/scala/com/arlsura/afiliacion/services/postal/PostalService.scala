package com.arlsura.afiliacion.services.postal

import akka.actor.SupervisorStrategy.{ Resume, Stop }
import akka.actor._
import com.arlsura.afiliacion.actors.PostalActor
import com.arlsura.afiliacion.actors.commons.VerboseActor
import com.arlsura.afiliacion.actors.supervision.behaviors.HandlerSupervisorBehavior
import com.arlsura.afiliacion.actors.supervision.factories.OneForOneStrategyFactory
import com.arlsura.afiliacion.authentication.CookieSessionAuthentication
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.{ MunicipalityConsultWebResponse, ExceptionOccurred, GeneralJsonResponseData }
import com.arlsura.afiliacion.utils.Utils
import spray.http.StatusCodes
import spray.routing.{ Route, RequestContext, HttpService }

import scala.concurrent.duration.Duration
import scala.util.Try

/**
 * Created by Jesús Martínez on 15/12/14.
 */
trait PostalService extends HttpService with CookieSessionAuthentication {

  private[ this ] implicit val executionContext = actorRefFactory.dispatcher

  private val handler: ActorRef =
    actorRefFactory.actorOf( PostalServiceHandler.props, s"postal-service-handler-${Utils.getTimestamp}" )
  val consultMunicipalityRoute: Route =
    pathPrefix( "postal" ) {
      path( "municipality" ) {
        pathEndOrSingleSlash {
          parameter( 'code ) {
            code =>
              get {
                authenticate( authenticateCaptcha() ) { user =>
                  ( ctx: RequestContext ) =>
                    handler ! PostalServiceHandler.ConsultMunicipality( code, ctx )
                }
              }
          }
        }
      }
    }
}

/**
 * Actor encargado de ejecutar la lógica del servicio.
 */
private class PostalServiceHandler extends VerboseActor with HandlerSupervisorBehavior {
  private val postalRouter: ActorRef =
    context.actorOf( PostalActor.router, s"postal-service-postal-router-instance-${Utils.getTimestamp}" )

  /**
   *
   */
  override def receive: Receive = {
    case PostalServiceHandler.ConsultMunicipality( code, ctx ) =>
      setContext( ctx )
      //      log.debug( s"Recibido mensaje ConsultMunicipality: $code" )
      postalRouter ! PostalActor.ConsultMunicipality( code )
    case PostalActor.MunicipalityConsultResponse( dc, bc ) =>
      //      log.debug( s"Recibido mensaje MunicipalityConsultResponse: [$dc, $bc]" )
      val response: GeneralJsonResponseData =
        GeneralJsonResponseData( "Municipio consultado exitosamente", Some( MunicipalityConsultWebResponse( dc, bc ) ) )
      complete( response )
  }
}

/**
 * Companion object del actor handler.
 */
private object PostalServiceHandler {
  def props: Props = Props( new PostalServiceHandler )

  case class ConsultMunicipality( code: String, ctx: RequestContext )
}
