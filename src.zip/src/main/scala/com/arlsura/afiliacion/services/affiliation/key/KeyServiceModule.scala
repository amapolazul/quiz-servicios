package com.arlsura.afiliacion.services.affiliation.key

import com.arlsura.afiliacion.bussiness.affiliation.{ BasicDataRepository, PreaffiliationManager }
import com.arlsura.afiliacion.persistence.daos.affiliation.wrappers.AffiliationBasicDataWrapper
import com.arlsura.afiliacion.persistence.daos.wrappers.PreAffiliationWrapper

import com.google.inject.AbstractModule

import net.codingwell.scalaguice.ScalaModule

class KeyServiceModule extends AbstractModule with ScalaModule {

  override def configure(): Unit = {
    bind[ AffiliationBasicDataWrapper ]
    bind[ BasicDataRepository ]
  }

}
