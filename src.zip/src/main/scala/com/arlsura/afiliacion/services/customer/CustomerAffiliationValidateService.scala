package com.arlsura.afiliacion.services.customer

import java.util.Date

import akka.actor._
import com.arlsura.afiliacion.actors.VentaInformacionConsumerActor
import com.arlsura.afiliacion.actors.commons.VerboseActor
import com.arlsura.afiliacion.authentication.CookieSessionAuthentication
import com.arlsura.afiliacion.headers.CORSHeaders
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.{ ExceptionOccurred, GeneralJsonResponseData }
import spray.http.StatusCodes
import spray.routing.{ RequestContext, HttpService }
import com.arlsura.afiliacion.utils.Utils

/**
 * Created by juanmartinez on 13/11/14.
 */
trait CustomerAffiliationValidateService extends HttpService with CORSHeaders with CookieSessionAuthentication {

  private[ this ] implicit val executionContext = actorRefFactory.dispatcher

  private val ventaInformacionActor = actorRefFactory.actorOf( VentaInformacionConsumerActor.props(), s"ventaInformacionActor-${Utils.getTimestamp}" )

  val customerAffiliateService = {
    pathPrefix( "customer" ) {
      path( "affiliateValidation" ) {
        pathEnd {
          parameter( 'dni ) {
            dni =>
              get {
                authenticate( authenticateCaptcha() ) { user =>
                  ( ctx: RequestContext ) =>
                    val handler = actorRefFactory.actorOf( ServiceHandlerVentaInfo.props( ventaInformacionActor, ctx ), s"ventaInformacionActorService-handler-${Utils.getTimestamp}" )
                    handler ! VentaInformacionConsumerActor.AffiliateValidationRequest( dni )
                }
              }
          }
        }
      }
    }
  }
}

/**
 * Actor encargado de manejar la solicitud hecha al servicio, así como enviar de vuelta la respuesta, una vez
 * recibida.
 * @param actor Referencia al actor que ejecuta el chequeo de la afiliación en base de datos.
 * @param ctx RequestContext para completar la solicitud una vez obtenida la respuesta.
 */
private class ServiceHandlerVentaInfo( actor: ActorRef, ctx: RequestContext ) extends VerboseActor {
  override def receive = {
    case VentaInformacionConsumerActor.AffiliateValidationRequest( dni ) =>
      //      log.debug( s"Entrando a consultar el menu para el documento ${dni}" )
      actor ! VentaInformacionConsumerActor.AffiliateValidationRequest( dni )

    case VentaInformacionConsumerActor.AffiliateValidationResponse( response ) =>
      val responseData = GeneralJsonResponseData( "Estado del afiliado consultado con éxito", Some( response.data ) )
      completeAndShutDown( responseData )
    case ex @ ExceptionOccurred( c, m ) =>
      //      log.debug( s"Recibido mensaje ExceptionOccurred: \n\tcause: $c, \n\tmessage: $m" )
      completeAndShutDown( GeneralJsonResponseData( "Ha ocurrido un error", Some( ex ) ) )
  }

  private def completeAndShutDown( response: GeneralJsonResponseData ): Unit = {
    ctx.complete( response )
    context.stop( self )
  }
}

/**
 * Companion object del handler.
 */
private object ServiceHandlerVentaInfo {
  //Factory method del handler.
  def props( actor: ActorRef, context: RequestContext ) = Props( new ServiceHandlerVentaInfo( actor, context ) )
}
