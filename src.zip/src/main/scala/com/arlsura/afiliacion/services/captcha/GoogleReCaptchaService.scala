package com.arlsura.afiliacion.services.captcha

import java.io.{ BufferedReader, InputStreamReader }
import java.util

import com.arlsura.afiliacion.services.captcha.CaptchaJsonMarshaller.{ CaptchaServiceRequest, CaptchaServiceResponse }
import com.arlsura.afiliacion.utils.ProxyParameters
import org.apache.http.client.config.RequestConfig
import org.apache.http.client.entity.UrlEncodedFormEntity
import org.apache.http.client.methods.HttpPost
import org.apache.http.impl.client.{ CloseableHttpClient, HttpClientBuilder }
import org.apache.http.message.BasicNameValuePair
import org.apache.http.{ HttpHost, HttpResponse, NameValuePair }
import org.json4s.DefaultFormats
import org.json4s.jackson.JsonMethods._

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

/**
 * Created by John on 21/05/15.
 */
class GoogleReCaptchaService() {

  implicit val formats = DefaultFormats
  private val reCaptchaURL = "https://www.google.com/recaptcha/api/siteverify"
  private val reCaptchaSecret = "6Lcu8gMTAAAAAG_YXBLF6QHBH9xJKG06MPnqbBtR"

  def validate( requestData: CaptchaServiceRequest ): Future[ CaptchaServiceResponse ] = {
    Future {
      val config: Option[ RequestConfig ] = buildConfig()
      val request: HttpPost = buildRequest( requestData, config )
      val client: CloseableHttpClient = HttpClientBuilder.create().build()
      val httpResponse: HttpResponse = client.execute( request )
      val response: CaptchaServiceResponse = buildResponse( httpResponse )
      response
    }
  }

  private def buildConfig(): Option[ RequestConfig ] = {
    val proxyParams: ProxyParameters = new ProxyParameters()
    proxyParams.environmentHasProxy match {
      case true =>
        val proxy: HttpHost = new HttpHost( proxyParams.URL.get, proxyParams.port.get, proxyParams.protocol.get )
        Some( RequestConfig.custom().setProxy( proxy ).build() )
      case false =>
        None
    }
  }

  private def buildRequest( requestData: CaptchaServiceRequest, config: Option[ RequestConfig ] = None ): HttpPost = {
    val request: HttpPost = new HttpPost( reCaptchaURL )
    request.setEntity( new UrlEncodedFormEntity( buildPostData( requestData ) ) )
    config match {
      case Some( configObject ) => request.setConfig( configObject )
      case None                 => //No action needed
    }
    request
  }

  private def buildResponse( httpResponse: HttpResponse ): CaptchaServiceResponse = {
    val responseAsString = getResponseAsString( httpResponse )
    val responseAsJSON = parse( responseAsString )
    responseAsJSON.extract[ CaptchaServiceResponse ]
  }

  private def buildPostData( requestData: CaptchaServiceRequest ): util.ArrayList[ NameValuePair ] = {
    val nameValuePairs: util.ArrayList[ NameValuePair ] = new util.ArrayList[ NameValuePair ]()
    nameValuePairs.add( new BasicNameValuePair( "secret", reCaptchaSecret ) )
    nameValuePairs.add( new BasicNameValuePair( "response", requestData.captchaResponse ) )
    nameValuePairs
  }

  private def getResponseAsString( response: HttpResponse ): String = {
    val bufferedReader = new BufferedReader( new InputStreamReader( response.getEntity().getContent() ) )
    val serviceResponse = new StringBuffer()
    var line = bufferedReader.readLine()
    while ( line != null ) {
      serviceResponse.append( line )
      line = bufferedReader.readLine()
    }
    serviceResponse.toString
  }

}
