package com.arlsura.afiliacion.services.afp

import com.arlsura.afiliacion.actors.cache.CacheRefresherActor
import com.arlsura.afiliacion.authentication.CookieSessionAuthentication
import com.arlsura.afiliacion.bussiness.afp.AFPServiceHandler
import com.arlsura.afiliacion.headers.CORSHeaders
import com.arlsura.afiliacion.utils.Utils
import com.arlsura.afiliacion.utils.resources.ResourcesNameRetriever
import spray.routing.{ RequestContext, HttpService }

/**
 * Created by Jesús Martínez on 30/03/15.
 */
trait AFPService extends HttpService with CookieSessionAuthentication {
  private implicit val ec = actorRefFactory.dispatcher
  private val path = ResourcesNameRetriever.getResource( "afps", "MAIN_RESOURCE" )
  private val cacheActor = actorRefFactory.actorSelection( "akka://ARLSura-backend/user/cache-refresher-actor" )

  private val getAfps = {
    path( path ) {
      get {
        authenticate( authenticateCaptcha() ) {
          user =>
            ( ctx: RequestContext ) =>
              val handler = new AFPServiceHandler( ctx, cacheActor )
              handler.retrieveAFPs()
        }
      }
    }
  }

  val afpRoutes = getAfps
}
