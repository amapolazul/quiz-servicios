package com.arlsura.afiliacion.services.affiliation.completion

import com.arlsura.afiliacion.authentication.CookieSessionAuthentication
import com.arlsura.afiliacion.bussiness.RequestContextSupport
import com.arlsura.afiliacion.bussiness.affiliation.completion.CompleteAffiliationServiceHandler
import com.arlsura.afiliacion.utils.resources.ResourcesNameRetriever
import com.google.inject.Guice

import net.codingwell.scalaguice.InjectorExtensions._

import spray.routing.{ Route, RequestContext, HttpService }

import scala.concurrent.ExecutionContext

/**
 * Route definition for affiliation completion
 */
trait CompleteAffiliationService extends HttpService with CookieSessionAuthentication with RequestContextSupport {

  /**
   * Import all routes from companion object
   */
  import CompleteAffiliationService._

  /**
   * Execution context for futures manipulation
   */
  private[ this ] implicit val ec: ExecutionContext = actorRefFactory.dispatcher

  /**
   * Injector for Guice framework
   */
  private[ this ] lazy val injector = Guice.createInjector( new CompleteAffiliationServiceModule() )

  /**
   * Route that completes an existent affiliation
   * POST ->
   */
  private[ this ] val postCompleteAffiliation = pathPrefix( affiliationsMainRouteBD / Segment ) { dni =>
    pathEndOrSingleSlash {
      post {
        authenticate( authenticateCaptcha() ) { user =>
          ( ctx: RequestContext ) =>
            if ( dni == user.dni ) {
              lazy val handler: CompleteAffiliationServiceHandler = injector.instance[ CompleteAffiliationServiceHandler ]
              completeRequest( handler.completeAffiliation( dni ), ctx )
            }
            else {
              completeWithRejection( ctx )
            }
        }
      }
    }
  }

  // -------------------------------------
  // ROUTES COMPOSITION
  // -------------------------------------

  /**
   * Defines all routes composition
   */
  def getCompletionRoutes: Route = postCompleteAffiliation

}

/**
 * Companion object for affiliation completion
 */
object CompleteAffiliationService {

  /**
   * Main resource path -> "affiliations"
   */
  val affiliationsMainRouteBD = ResourcesNameRetriever.getResource( "affiliations", "MAIN_RESOURCE" )

}