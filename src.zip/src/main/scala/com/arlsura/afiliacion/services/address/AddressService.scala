package com.arlsura.afiliacion.services.address

import com.arlsura.afiliacion.authentication.CookieSessionAuthentication
import com.arlsura.afiliacion.utils.resources.ResourcesNameRetriever
import spray.routing.{ Route, RequestContext, HttpService }
import com.arlsura.afiliacion.bussiness.address.AddressServiceHandler

/**
 * Created by Jesús Martínez on 18/12/14.
 */
trait AddressService extends HttpService with CookieSessionAuthentication {
  private implicit val ec = actorRefFactory.dispatcher
  private val path = ResourcesNameRetriever.getResource( "address", "MAIN_RESOURCE" )
  private val cacheActor = actorRefFactory.actorSelection( "akka://ARLSura-backend/user/cache-refresher-actor" )

  private def executeQuery( by: Option[ String ], value: Option[ String ], handler: AddressServiceHandler ): Unit = {
    by.map( _.toLowerCase ) match {
      case None           => handler.retrieveAll()
      case Some( "name" ) => if ( value.isDefined ) handler.retrieveByCountryName( value.get ) else handler.retrieveAll()
      case Some( "code" ) => if ( value.isDefined ) handler.retrieveByCountryCode( value.get.toInt ) else handler.retrieveAll()
      case Some( _ )      => //TODO Error
    }
  }

  val consultAddressRoute: Route = {
    pathPrefix( path ) {
      pathEndOrSingleSlash {
        parameters( 'by.?, 'value.? ) {
          ( by: Option[ String ],
          value: Option[ String ] ) =>
            {
              get {
                authenticate( authenticateCaptcha ) {
                  user =>
                    ( ctx: RequestContext ) =>
                      val handler = new AddressServiceHandler( ctx, cacheActor )
                      executeQuery( by, value, handler )
                }
              }
            }
        }
      }
    }
  }
}

