package com.arlsura.afiliacion.services.affiliation.workcenters

import com.arlsura.afiliacion.authentication.CookieSessionAuthentication
import com.arlsura.afiliacion.bussiness.RequestContextSupport
import com.arlsura.afiliacion.bussiness.affiliation.workcenters.WorkCentersDataServiceHandler
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.SaveWorkCentersData
import com.arlsura.afiliacion.utils.resources.ResourcesNameRetriever
import com.google.inject.Guice
import spray.routing._
import net.codingwell.scalaguice.InjectorExtensions._
import scala.concurrent.ExecutionContext

/**
 * Created by Jesús Martínez on 6/05/15.
 */
trait WorkCentersDataService extends HttpService with CookieSessionAuthentication with RequestContextSupport {

  import com.arlsura.afiliacion.services.affiliation.workcenters.WorkCentersDataService._
  private[ WorkCentersDataService ] implicit val ec: ExecutionContext = actorRefFactory.dispatcher
  private[ WorkCentersDataService ] lazy val injector = Guice.createInjector( new WorkCentersDataServiceModule() )

  val getWorkCentersInformation: Route = {
    pathPrefix( affiliationsMainRouteBD / Segment ) {
      dni =>
        pathPrefix( dataMainRouteBD ) {
          pathPrefix( workCentersMainRoute ) {
            pathEndOrSingleSlash {
              get {
                authenticate( authenticateBothCookies ) {
                  user =>
                    ( ctx: RequestContext ) =>
                      if ( dni == user.dni ) {
                        lazy val handler = injector.instance[ WorkCentersDataServiceHandler ]
                        completeRequest( handler.retrieveWorkCenters( dni ), ctx )
                      }
                      else {
                        completeWithRejection( ctx )
                      }
                }
              }
            }
          }
        }
    }
  }

  val createOrUpdateWorkCentersInformation: Route = {
    pathPrefix( affiliationsMainRouteBD / Segment ) {
      dni =>
        pathPrefix( dataMainRouteBD ) {
          pathPrefix( workCentersMainRoute ) {
            pathEndOrSingleSlash {
              post {
                entity( as[ SaveWorkCentersData ] ) {
                  data =>
                    authenticate( authenticateBothCookies ) {
                      user =>
                        ( ctx: RequestContext ) =>
                          if ( dni == user.dni ) {
                            lazy val handler = injector.instance[ WorkCentersDataServiceHandler ]
                            completeRequest( handler.saveWorkCenters( data ), ctx )
                          }
                          else {
                            completeWithRejection( ctx )
                          }
                    }
                }
              }
            }
          }
        }
    }
  }

  def getWorkCentersRoute: Route = getWorkCentersInformation ~ createOrUpdateWorkCentersInformation
}

object WorkCentersDataService {

  val affiliationsMainRouteBD = ResourcesNameRetriever.getResource( "affiliations", "MAIN_RESOURCE" )
  val dataMainRouteBD = ResourcesNameRetriever.getResource( "affiliations", "DATA" )
  val workCentersMainRoute = ResourcesNameRetriever.getResource( "affiliations", "WORK_CENTERS" )
}
