package com.arlsura.afiliacion.services.employer

import com.arlsura.afiliacion.authentication.CookieSessionAuthentication
import com.arlsura.afiliacion.bussiness.activities.ActivitiesServiceHandler
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.DomesticEmployerActivity
import com.arlsura.afiliacion.utils.resources.ResourcesNameRetriever
import spray.routing.{ Route, RequestContext, HttpService }

/**
 * Created by juanmartinez on 16/01/15.
 */
trait DomesticEmployerService extends HttpService with CookieSessionAuthentication {
  private implicit val ec = actorRefFactory.dispatcher
  private val mainResourcePath = ResourcesNameRetriever.getResource( "domestic_employer", "MAIN_RESOURCE" )
  private val activitiesPath = ResourcesNameRetriever.getResource( "domestic_employer", "ACTIVITIES" )

  val domesticActivitiesGet = {
    pathPrefix( mainResourcePath ) {
      path( activitiesPath ) {
        pathEndOrSingleSlash {
          get {
            authenticate( authenticateCaptcha ) {
              user =>
                ( ctx: RequestContext ) =>
                  val handler = new ActivitiesServiceHandler( ctx )
                  handler.retrieveDomesticEmployerActivities( None )
            }
          }
        }
      } ~ pathPrefix( mainResourcePath / Segment ) {
        activityId =>
          get {
            authenticate( authenticateCaptcha ) {
              user =>
                ( ctx: RequestContext ) =>
                  val handler = new ActivitiesServiceHandler( ctx )
                  handler.retrieveDomesticEmployerActivities( Some( activityId ) )
            }
          }
      }
    }
  }

  val domesticActivitiesPost = {
    pathPrefix( mainResourcePath ) {
      path( activitiesPath ) {
        pathEndOrSingleSlash {
          post {
            entity( as[ DomesticEmployerActivity ] ) {
              activity =>
                authenticate( authenticateCaptcha() ) { user =>
                  ( ctx: RequestContext ) =>
                    val handler = new ActivitiesServiceHandler( ctx )
                    handler.createDomesticActivity( activity )
                }
            }

          }
        }
      }
    }
  }

  val domesticActivitiesPut = {
    pathPrefix( mainResourcePath ) {
      pathPrefix( activitiesPath / Segment ) {
        activityId =>
          put {
            entity( as[ DomesticEmployerActivity ] ) {
              activity =>
                authenticate( authenticateCaptcha() ) { user =>
                  ( ctx: RequestContext ) =>
                    val handler = new ActivitiesServiceHandler( ctx )
                    handler.updateDomesticActivity( activity, activityId )
                }
            }
          }
      }
    }
  }

  val domesticActivitiesDelete = {
    pathPrefix( mainResourcePath ) {
      pathPrefix( activitiesPath / Segment ) {
        activityId =>
          delete {
            authenticate( authenticateCaptcha() ) { user =>
              ( ctx: RequestContext ) =>
                val handler = new ActivitiesServiceHandler( ctx )
                handler.deleteDomesticActivity( activityId )
            }
          }
      }
    }
  }

  def getDomesticActivityRoute: Route = domesticActivitiesGet ~ domesticActivitiesPost ~ domesticActivitiesPut ~ domesticActivitiesDelete

}

