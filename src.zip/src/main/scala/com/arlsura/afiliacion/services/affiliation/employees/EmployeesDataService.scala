package com.arlsura.afiliacion.services.affiliation.employees

import com.arlsura.afiliacion.authentication.CookieSessionAuthentication
import com.arlsura.afiliacion.bussiness.RequestContextSupport
import com.arlsura.afiliacion.bussiness.affiliation.employees.EmployeeDataServiceHandler
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.SaveEmployeesData
import com.arlsura.afiliacion.utils.resources.ResourcesNameRetriever
import com.google.inject.Guice
import spray.routing._
import EmployeesDataService._
import scala.concurrent.ExecutionContext
import net.codingwell.scalaguice.InjectorExtensions._

trait EmployeesDataService extends HttpService with CookieSessionAuthentication with RequestContextSupport {

  private[ EmployeesDataService ] implicit val ec: ExecutionContext = actorRefFactory.dispatcher
  private[ EmployeesDataService ] lazy val injector = Guice.createInjector( new EmployeesDataServiceModule() )

  val getEmployeesInformation: Route = {
    pathPrefix( affiliationsMainRouteBD / Segment ) {
      dni =>
        pathPrefix( dataMainRouteBD ) {
          pathPrefix( employeesMainRoute ) {
            pathEndOrSingleSlash {
              get {
                authenticate( authenticateBothCookies ) {
                  user =>
                    ( ctx: RequestContext ) =>

                      if ( user.dni == dni ) {
                        lazy val handler: EmployeeDataServiceHandler = injector.instance[ EmployeeDataServiceHandler ]
                        completeRequest( handler.retrieveEmployeesData( dni ), ctx )
                      }
                      else {
                        completeWithRejection( ctx )
                      }
                }
              }
            }
          }
        }
    }
  }

  val createOrUpdateEmployeesInformation: Route = {
    pathPrefix( affiliationsMainRouteBD / Segment ) {
      dni =>
        pathPrefix( dataMainRouteBD ) {
          pathPrefix( employeesMainRoute ) {
            pathEndOrSingleSlash {
              post {
                entity( as[ SaveEmployeesData ] ) {
                  data =>
                    authenticate( authenticateBothCookies ) {
                      user =>
                        ( ctx: RequestContext ) =>
                          if ( user.dni == dni ) {
                            lazy val handler: EmployeeDataServiceHandler = injector.instance[ EmployeeDataServiceHandler ]
                            completeRequest( handler.saveEmployeesData( data ), ctx )
                          }
                          else {
                            completeWithRejection( ctx )
                          }
                    }
                }
              }
            }
          }
        }
    }
  }

  def getEmployeesRoute: Route = getEmployeesInformation ~ createOrUpdateEmployeesInformation
}

object EmployeesDataService {

  val affiliationsMainRouteBD = ResourcesNameRetriever.getResource( "affiliations", "MAIN_RESOURCE" )
  val dataMainRouteBD = ResourcesNameRetriever.getResource( "affiliations", "DATA" )
  val employeesMainRoute = ResourcesNameRetriever.getResource( "affiliations", "EMPLOYEES" )
}
