package com.arlsura.afiliacion.services.affiliation.workcenters

import com.arlsura.afiliacion.bussiness.affiliation.workcenters.{ WorkCentersDataRepository }
import com.arlsura.afiliacion.persistence.daos.affiliation.wrappers.AffiliationWorkCentersDataWrapper
import com.google.inject.AbstractModule
import net.codingwell.scalaguice.ScalaModule

/**
 * Created by Jesús Martínez on 20/05/15.
 */
class WorkCentersDataServiceModule extends AbstractModule with ScalaModule {
  override def configure(): Unit = {
    bind[ AffiliationWorkCentersDataWrapper ]
    bind[ WorkCentersDataRepository ]
  }
}
