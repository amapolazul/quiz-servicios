package com.arlsura.afiliacion.services

import java.util.Date

import com.arlsura.afiliacion.authentication.CookieSessionAuthentication
import com.arlsura.afiliacion.utils.Utils
import spray.http.HttpCookie
import spray.routing.{ RequestContext, HttpService }
import scala.concurrent.ExecutionContext.Implicits.global

/**
 * Created by juanmartinez on 9/04/15.
 */
trait CookieTest extends HttpService with CookieSessionAuthentication {

  private val hasIndependentsPath =
    pathPrefix( "setcookie" / Segment ) {
      dni =>
        pathEndOrSingleSlash {
          get {
            val d = s"${dni}-${new Date().getTime.toString}"
            val t = Utils.encodeFile( d.getBytes )
            setCookie( HttpCookie( "suraSessionManager", content = t ) ) {
              ( ctx: RequestContext ) =>
                ctx.complete( "mas bien lokita " + t )
            }
          }
        }
    }

  private val validateDocFormatPath =
    pathPrefix( "updateCookie" / Segment ) {
      dni =>
        pathEndOrSingleSlash {
          get {
            val d = s"${dni}-${new Date().getTime.toString}"
            val t = Utils.encodeFile( d.getBytes )
            setCookie( HttpCookie( "suraSessionManager", content = t ) ) {
              ( ctx: RequestContext ) =>
                ctx.complete( "actualizaste loquita " + t )
            }
          }

        }
    }

  private val validatecokFormatPath =
    pathPrefix( "evalCookie" / Segment ) {
      dni =>
        pathEndOrSingleSlash {
          authenticate( authenticateSession ) {
            user =>
              get {
                ( ctx: RequestContext ) =>
                  ctx.complete( "aqui estoy con sesión" )
              }
          }
        }
    }

  //TODO Acá debe ir el recurso para traer el código del usuario.

  val clientCookies = hasIndependentsPath ~ validateDocFormatPath ~ validatecokFormatPath

}
