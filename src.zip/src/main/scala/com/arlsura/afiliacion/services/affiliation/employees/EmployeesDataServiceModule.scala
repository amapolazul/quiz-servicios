package com.arlsura.afiliacion.services.affiliation.employees

import com.arlsura.afiliacion.bussiness.affiliation.employees.EmployeeDataRepository
import com.arlsura.afiliacion.persistence.daos.affiliation.wrappers.AffiliationEmployeesDataWrapper
import com.google.inject.AbstractModule
import net.codingwell.scalaguice.ScalaModule

class EmployeesDataServiceModule extends AbstractModule with ScalaModule {

  override def configure(): Unit = {
    bind[ AffiliationEmployeesDataWrapper ]
    bind[ EmployeeDataRepository ]
  }
}
