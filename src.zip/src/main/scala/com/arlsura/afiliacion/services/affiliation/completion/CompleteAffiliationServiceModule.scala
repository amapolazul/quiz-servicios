package com.arlsura.afiliacion.services.affiliation.completion

import com.arlsura.afiliacion.bussiness.affiliation.{ PreaffiliationManager, BasicDataRepository }
import com.arlsura.afiliacion.bussiness.affiliation.contacts.ContactDataRepository
import com.arlsura.afiliacion.bussiness.affiliation.employees.EmployeeDataRepository
import com.arlsura.afiliacion.bussiness.affiliation.workcenters.WorkCentersDataRepository
import com.arlsura.afiliacion.persistence.daos.affiliation.wrappers.{ AffiliationWorkCentersDataWrapper, AffiliationEmployeesDataWrapper, AffiliationContactsDataWrapper, AffiliationBasicDataWrapper }
import com.arlsura.afiliacion.persistence.daos.wrappers.PreAffiliationWrapper
import com.google.inject.AbstractModule
import net.codingwell.scalaguice.ScalaModule

class CompleteAffiliationServiceModule extends AbstractModule with ScalaModule {
  override def configure(): Unit = {
    bind[ PreAffiliationWrapper ]
    bind[ PreaffiliationManager ]

    bind[ AffiliationBasicDataWrapper ]
    bind[ BasicDataRepository ]

    bind[ AffiliationContactsDataWrapper ]
    bind[ ContactDataRepository ]

    bind[ AffiliationEmployeesDataWrapper ]
    bind[ EmployeeDataRepository ]

    bind[ AffiliationWorkCentersDataWrapper ]
    bind[ WorkCentersDataRepository ]
  }
}