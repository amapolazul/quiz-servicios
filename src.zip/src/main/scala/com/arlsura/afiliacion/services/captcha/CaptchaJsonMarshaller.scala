package com.arlsura.afiliacion.services.captcha

import com.arlsura.afiliacion.utils.FormatValidator
import org.json4s.{ DefaultFormats, Formats }
import spray.httpx.Json4sSupport

/**
 * Created by juanmartinez on 23/06/15.
 */
object CaptchaJsonMarshaller extends Json4sSupport {

  override implicit def json4sFormats: Formats = DefaultFormats

  case class CaptchaServiceRequest( captchaResponse: String, dni: String, ipAddress: Option[ String ] = None ) {
    require( ipAddress.forall( FormatValidator.validIPv4 ), "IP inválida." )
  }

  case class CaptchaServiceResponse( success: Boolean )
}
