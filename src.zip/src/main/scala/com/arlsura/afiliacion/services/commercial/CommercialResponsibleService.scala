package com.arlsura.afiliacion.services.commercial

import com.arlsura.afiliacion.authentication.CookieSessionAuthentication
import com.arlsura.afiliacion.bussiness.HandlerSupport.ServiceHandlerResponse
import com.arlsura.afiliacion.bussiness.RequestContextSupport
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.{ GeneralJsonResponseData, UpdateCommercialResponsibleRequest, GetCommercialResponsibleRequest, CreateCommercialResponsibleRequest }
import com.arlsura.afiliacion.segmentacion.comercial.CommercialResponsibleAuthHandler
import com.arlsura.afiliacion.segmentacion.comercial.CommercialResponsibleMarshaller.CommercialResponsibleAuth
import com.arlsura.afiliacion.utils.resources.ResourcesNameRetriever
import com.google.inject.Guice
import spray.http.{ StatusCodes, StatusCode }
import spray.routing.{ Route, RequestContext, HttpService }
import net.codingwell.scalaguice.InjectorExtensions._
import scala.concurrent.{ Future, ExecutionContext }

import CommercialResponsibleService._

/**
 * Created by Jesús Martínez on 10/02/15.
 */
trait CommercialResponsibleService extends HttpService with RequestContextSupport with CookieSessionAuthentication {

  private[ CommercialResponsibleService ] implicit val _: ExecutionContext = actorRefFactory.dispatcher
  private[ CommercialResponsibleService ] lazy val injector = Guice.createInjector( new CommercialResponsibleServiceModule() )

  val createCommercialResponsibleRoute = {
    pathPrefix( commercialResponsibleRoute ) {
      pathEndOrSingleSlash {
        entity( as[ CreateCommercialResponsibleRequest ] ) {
          request =>
            post {
              authenticate( authenticateCaptcha() ) { user =>
                ( requestContext: RequestContext ) =>
                  lazy val handler = injector.instance[ CommercialResponsibleServiceHandler ]
                  completeRequest( handler.create( request ), requestContext )
              }
            }
        }
      }
    }
  }

  val getCommercialResponsibleRoute = {
    pathPrefix( commercialResponsibleRoute / Segment ) {
      id =>
        pathEndOrSingleSlash {
          get {
            authenticate( authenticateCaptcha() ) { user =>
              ( requestContext: RequestContext ) =>
                lazy val handler = injector.instance[ CommercialResponsibleServiceHandler ]
                completeRequest( handler.getById( id ), requestContext )
            }
          }
        }
    }
  }

  val getCommercialResponsiblesRoute = {
    pathPrefix( commercialResponsibleRoute ) {
      pathEndOrSingleSlash {
        parameters( 'office.as[ Int ]?, 'city?, 'fullname?, 'email?, 'charge?, 'user? ) {
          ( office: Option[ Int ], city: Option[ String ], fullName: Option[ String ], email: Option[ String ], charge: Option[ String ], networkUser: Option[ String ] ) =>
            get {
              authenticate( authenticateCaptcha() ) { user =>
                ( requestContext: RequestContext ) =>
                  lazy val handler = injector.instance[ CommercialResponsibleServiceHandler ]
                  ( office, city, fullName, email, charge, networkUser ) match {
                    case ( None, None, None, None, None, None ) =>
                      completeRequest( handler.getAll(), requestContext )
                    case ( _, _, _, _, _, _ ) =>
                      completeRequest( handler.getBy( GetCommercialResponsibleRequest( office, city, fullName, email, charge, networkUser ) ), requestContext )
                  }
              }
            }
        }

      }
    }
  }

  val deleteCommercialResponsibleRoute = {
    pathPrefix( commercialResponsibleRoute / Segment ) {
      id =>
        pathEndOrSingleSlash {
          delete {
            ( requestContext: RequestContext ) =>
              {
                lazy val handler = injector.instance[ CommercialResponsibleServiceHandler ]
                completeRequest( handler.deleteById( id ), requestContext )
              }
          }
        }
    }
  }

  val deleteAllCommercialResponsiblesRoute = {
    pathPrefix( commercialResponsibleRoute ) {
      pathEndOrSingleSlash {
        delete {
          ( requestContext: RequestContext ) =>
            lazy val handler = injector.instance[ CommercialResponsibleServiceHandler ]
            completeRequest( handler.deleteAll(), requestContext )
        }
      }
    }
  }

  val updateCommercialResponsibleRoute = {
    pathPrefix( commercialResponsibleRoute ) {
      pathEndOrSingleSlash {
        entity( as[ UpdateCommercialResponsibleRequest ] ) {
          request =>
            put {
              ( requestContext: RequestContext ) =>
                lazy val handler = injector.instance[ CommercialResponsibleServiceHandler ]
                completeRequest( handler.update( request ), requestContext )
            }
        }
      }
    }
  }

  val authCommercialResponsibleInCityRoute = {
    pathPrefix( commercialResponsibleRoute / Segment ) {
      clientDni =>
        pathPrefix( segmentationRoute ) {
          pathEndOrSingleSlash {
            post {
              entity( as[ CommercialResponsibleAuth ] ) {
                data =>
                  ( requestContext: RequestContext ) =>
                    lazy val handler: CommercialResponsibleAuthHandler = injector.instance[ CommercialResponsibleAuthHandler ]
                    val future: Future[ ServiceHandlerResponse ] = handler.auth( clientDni, data )
                    completeAuthorizationRequest( future, requestContext, StatusCodes.UnavailableForLegalReasons )
              }
            }
          }
        }
    }
  }

  val commercialResponsibleServiceRoutes: Route =
    createCommercialResponsibleRoute ~
      getCommercialResponsibleRoute ~
      getCommercialResponsiblesRoute ~
      deleteCommercialResponsibleRoute ~
      deleteAllCommercialResponsiblesRoute ~
      updateCommercialResponsibleRoute ~
      authCommercialResponsibleInCityRoute

}

object CommercialResponsibleService {

  val commercialResponsibleRoute = ResourcesNameRetriever.getResource( "commercial_responsible", "MAIN_RESOURCE" )
  val segmentationRoute = ResourcesNameRetriever.getResource( "commercial_responsible", "SEGMENTATION" )

}