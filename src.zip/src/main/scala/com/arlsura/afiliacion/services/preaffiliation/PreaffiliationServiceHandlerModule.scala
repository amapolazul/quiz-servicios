package com.arlsura.afiliacion.services.preaffiliation

import com.arlsura.afiliacion.bussiness.affiliation.PreaffiliationManager
import com.arlsura.afiliacion.bussiness.code.SecurityCodeManager
import com.arlsura.afiliacion.bussiness.segmentation.SegmentationManager
import com.arlsura.afiliacion.persistence.daos.wrappers.PreAffiliationWrapper
import com.google.inject.AbstractModule
import net.codingwell.scalaguice.ScalaModule

/**
 * Created by Jesús Martínez on 24/06/15.
 */
class PreaffiliationServiceHandlerModule extends AbstractModule with ScalaModule {

  override def configure(): Unit = {
    bind[ SecurityCodeManager ]
    bind[ SegmentationManager ]
    bind[ PreAffiliationWrapper ]
    bind[ PreaffiliationManager ]
  }
}
