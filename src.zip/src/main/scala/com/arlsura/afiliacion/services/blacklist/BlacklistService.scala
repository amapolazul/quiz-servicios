package com.arlsura.afiliacion.services.blacklist

import com.arlsura.afiliacion.authentication.CookieSessionAuthentication
import com.arlsura.afiliacion.bussiness.RequestContextSupport
import com.arlsura.afiliacion.bussiness.blacklist.{ BlacklistServiceHandler, BlacklistServiceModule }
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.BlacklistEntry
import com.arlsura.afiliacion.utils.resources.ResourcesNameRetriever
import com.google.inject.Guice
import spray.routing.{ RequestContext, HttpService }
import net.codingwell.scalaguice.InjectorExtensions._
/**
 * Created by Jesús Martínez on 9/06/15.
 */
trait BlacklistService extends HttpService with CookieSessionAuthentication with RequestContextSupport {
  private val path = ResourcesNameRetriever.getResource( "blacklist", "MAIN_RESOURCE" )
  private[ BlacklistService ] implicit val _ = actorRefFactory.dispatcher
  private[ BlacklistService ] val injector = Guice.createInjector( new BlacklistServiceModule() )

  private val saveEntry = {
    pathPrefix( path ) {
      pathEndOrSingleSlash {
        post {
          authenticate( authenticateCaptcha() ) { user =>
            entity( as[ BlacklistEntry ] ) {
              entry =>
                ( ctx: RequestContext ) =>
                  lazy val handler = injector.instance[ BlacklistServiceHandler ]
                  completeRequest( handler.save( entry ), ctx )
            }
          }
        }
      }
    }
  }

  // Entrada insegura a propósito.
  private val getEntry = {
    pathPrefix( path / Segment ) {
      dni =>
        pathEndOrSingleSlash {
          get {
            ( ctx: RequestContext ) =>
              lazy val handler = injector.instance[ BlacklistServiceHandler ]
              completeRequest( handler.get( dni ), ctx )
          }
        }
    }
  }

  val blacklistRoutes = getEntry ~ saveEntry
}
