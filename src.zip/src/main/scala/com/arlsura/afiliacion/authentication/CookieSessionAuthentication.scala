package com.arlsura.afiliacion.authentication

import com.arlsura.afiliacion.ARLContext
import com.arlsura.afiliacion.bussiness.blacklist.BlacklistRepository
import com.arlsura.afiliacion.bussiness.code.SecurityCodeManager
import com.arlsura.afiliacion.headers.CORSHeaders
import com.arlsura.afiliacion.persistence.blacklist.BlacklistWrapper
import com.arlsura.afiliacion.persistence.daos.wrappers.SecurityCodeWrapper
import com.arlsura.afiliacion.persistence.entities.SecurityCode
import com.arlsura.afiliacion.persistence.security.{ TokenSession, TokenSessionDAO }
import com.arlsura.afiliacion.utils.Utils
import com.sura.sessionmanager.{ NotFound, GenericData, Found }

import org.joda.time.DateTime

import reactivemongo.bson.{ BSONString, BSONDocument }

import spray.http.HttpHeader
import spray.routing.{ Rejection, MissingCookieRejection, AuthenticationFailedRejection }
import spray.routing.authentication._

import scala.concurrent.{ ExecutionContext, Future }

/**
 * Rejection for sessions in the
 * @param msg rejection description
 */
case class BlockedUserRejection( msg: String = "El usuario està bloqueado" ) extends Rejection

/**
 * Class that represents data stored in the session
 * @param salt Salt
 * @param dni DNI
 */
case class SessionData( salt: String, dni: String ) extends GenericData

/**
 * Trait that defines authentication methods
 */
trait CookieSessionAuthentication extends CORSHeaders {
  import ARLContext._

  lazy val blacklistRepository: BlacklistRepository = new BlacklistRepository( new BlacklistWrapper )
  lazy val securityCodeManager: SecurityCodeManager = new SecurityCodeManager( new SecurityCodeWrapper )
  lazy val tokenDao = TokenSessionDAO

  /**
   * Valida si un usuario posee tanto un Session-Tag cookie, como un suraSessionManager cookie.
   * @param ec Contexto de ejecución concurrente.
   */
  def authenticateBothCookies()( implicit ec: ExecutionContext ): ContextAuthenticator[ SessionUser ] = {
    ( context ) =>
      {
        val suraSessionManagerHeader = context.request.headers.find( _.name == "Set-Cookie" )
        val sessionTagHeader = context.request.headers.find( _.name == "Session-Tag" )

        ( suraSessionManagerHeader, sessionTagHeader ) match {
          case ( Some( h1 ), Some( h2 ) ) =>
            validateBothCookies( h1, h2 )
          case ( None, _ ) =>
            Future( Left( MissingCookieRejection( "suraSessionManager" ) ) )
          case ( _, None ) =>
            Future( Left( AuthenticationFailedRejection( AuthenticationFailedRejection.CredentialsMissing, this.getChallengeHeaders ) ) )
          case ( _, _ ) =>
            Future( Left( AuthenticationFailedRejection( AuthenticationFailedRejection.CredentialsMissing, this.getChallengeHeaders ) ) )
        }
      }
  }

  /**
   * Metodo de autenticación que valida si un usuario ha iniciado sesión dentro de la aplicacion
   * @return
   */
  def authenticateSession()( implicit ec: ExecutionContext ): ContextAuthenticator[ SessionUser ] = {
    ( context ) =>
      {
        val sessionCookieHeader: Option[ HttpHeader ] = context.request.headers.find( _.name == "Set-Cookie" )
        if ( sessionCookieHeader.isDefined )
          this.validateSessionCookie( sessionCookieHeader.get )
        else
          Future( Left( MissingCookieRejection( "suraSessionManager" ) ) )
      }
  }

  def authenticateCaptcha()( implicit ec: ExecutionContext ): ContextAuthenticator[ SessionUser ] = {
    ( context ) =>
      {
        val header: Option[ HttpHeader ] = context.request.headers.find( _.name == "Session-Tag" )
        if ( header.isDefined )
          this.validateCaptchaCookie( header.get )
        else
          Future( Left( AuthenticationFailedRejection( AuthenticationFailedRejection.CredentialsMissing, this.getChallengeHeaders ) ) )
      }
  }

  /**
   * Method that verifies security code and session
   * @param code Code to verify
   * @param dni Dni to verify
   * @param ec Implicit execution context
   * @return ContextAuthenticator[ SessionUser ] with expands to Future[ Either[Rejection, SessionUser] ]
   */
  def authenticateCodeAndDni( code: String, dni: String )( implicit ec: ExecutionContext ): ContextAuthenticator[ SessionUser ] = {
    ( context ) =>
      {
        val header: Option[ HttpHeader ] = context.request.headers.find( _.name == "Session-Tag" )
        if ( header.isDefined ) {
          val cookieValue: String = header.get.value
          val ( cookieSalt, cookieDni, _ ) = decode( cookieValue, timestamp = true, sep = "%%%" ).right.get
          ( for {
            validSessionE <- verifyAndValidateSession( cookieSalt, cookieDni )
            validCodeE <- verifyCodeValidity( code, dni )
            unblockedE <- verifyUnblocked( dni )
          } yield {
            for {
              validSession <- validSessionE.right
              validCode <- validCodeE.right
              unblocked <- unblockedE.right
            } yield SessionUser( dni, isExpired = validCode._1, codeMatches = true, validCode._2.source )
          } ).flatMap {
            case valid @ Right( user )       => Future( valid )
            case invalid @ Left( rejection ) => sessionManager.deleteSession( dni ).map( _ => invalid )
          }
        }
        else
          Future( Left( AuthenticationFailedRejection( AuthenticationFailedRejection.CredentialsMissing, this.getChallengeHeaders ) ) )
      }
  }

  private def validateBothCookies( sessionCookie: HttpHeader, captchaCookie: HttpHeader )( implicit ec: ExecutionContext ): Future[ Authentication[ SessionUser ] ] = {
    this.validateSessionCookie( sessionCookie ) flatMap {
      case Right( u ) =>
        this.validateCaptchaCookie( captchaCookie )
      case Left( r ) =>
        Future.successful( Left( r ) )
    }
  }

  /**
   * Valida que la cookie enviada tenga el valor correcto y que la estampa de tiempo enviada
   * @param cookie
   * @return
   */
  private def validateSessionCookie( cookie: HttpHeader )( implicit ec: ExecutionContext ): Future[ Authentication[ SessionUser ] ] = {
    val cookieValue = cookie.value.split( "=" )( 1 )
    val convertedValue = new String( Utils.decodeFile( cookieValue ) )
    val timeStamp = convertedValue.split( "-" )( 1 ).toLong
    val dni = convertedValue.split( "-" )( 0 )
    val currentTimeStamp = DateTime.now().toDate.getTime
    if ( ( currentTimeStamp - timeStamp ) > CookieSessionAuthentication.getSessionTimeOut ) {
      Future( Left( AuthenticationFailedRejection( AuthenticationFailedRejection.CredentialsRejected, this.getChallengeHeaders ) ) )
    }
    else {
      Future( Right( SessionUser( dni ) ) )
    }
  }

  /**
   * Valida que la cookie enviada tenga el valor correcto y que la estampa de tiempo enviada
   * @param cookie
   * @return
   */
  private def validateSessionCookieInit( cookie: HttpHeader )( implicit ec: ExecutionContext ): Future[ Authentication[ SessionUser ] ] = {
    val cookieValue = cookie.value
    val convertedValue = new String( Utils.decodeFile( cookieValue ) )
    val dniBase64 = convertedValue.split( "-" )( 2 )
    val dni = new String( Utils.decodeFile( dniBase64 ) )
    val futureTokenResponse: Future[ Option[ TokenSession ] ] = tokenDao.findOne( BSONDocument( "dni" -> dni ) )
    futureTokenResponse flatMap {
      case Some( e ) =>
        val currentDate: DateTime = DateTime.now()
        val expirationDate: DateTime = e.expirationDate
        if ( currentDate.isAfter( expirationDate ) ) {
          tokenDao.remove( BSONDocument( "dni" -> BSONString( dni ) ) )
          Future( Left( AuthenticationFailedRejection( AuthenticationFailedRejection.CredentialsRejected, this.getChallengeHeaders ) ) )
        }
        else {
          Future( Right( SessionUser( dni ) ) )
        }
      case None =>
        Future( Left( AuthenticationFailedRejection( AuthenticationFailedRejection.CredentialsRejected, this.getChallengeHeaders ) ) )
    }
  }

  /**
   * Method that verifies captcha session.
   * @param cookie Cookie value
   * @param ec Implicit execution context
   * @return
   */
  private def validateCaptchaCookie( cookie: HttpHeader )( implicit ec: ExecutionContext ): Future[ Authentication[ SessionUser ] ] = {
    val cookieValue: String = cookie.value
    val ( cookieSalt, cookieDni, _ ) = decode( cookieValue, timestamp = true, sep = "%%%" ).right.get
    verifyAndValidateSession( cookieSalt, cookieDni ).map {
      case Right( _ )        => Right( SessionUser( cookieDni ) )
      case Left( rejection ) => Left( rejection )
    }
  }

  object CookieSessionAuthentication {
    def getSessionTimeOut: Long = Utils.getProperty( "startup.", "sessionTimeOut" ).asInstanceOf[ Int ].toLong
  }

  // -------------------------------------------
  // Verification methods
  // -------------------------------------------

  /**
   * Method that verifies the session
   * Para codificar:
   *    1. Generar salt aleatorio y utilizar función encode(salt, dni) -> string
   *    2. Tomar el string y pasarle un true que indica que sí se cifró con timestamp.
   *    3. Buscar la sesión identificado con el dni.
   *    4. Pedir la data de esa sesión.
   *    5. Comparar la data en la sesión con la decodificada en el paso 2; específicamente los salts y los dnis deben coincidir.
   * @param cookieSalt Salt inside decrypted cookie
   * @param cookieDni Dni inside decrypted cookie
   * @return A future with an Either inside
   *         Left with a Rejection if session does not exist or cookie is invalid
   *         Right with Session data if session and data are valid
   */
  private def verifyAndValidateSession( cookieSalt: String, cookieDni: String ): Future[ Either[ Rejection, SessionData ] ] = {
    sessionManager.findSession( cookieDni, update = true ).map {
      case NotFound( _ ) => Left( AuthenticationFailedRejection( AuthenticationFailedRejection.CredentialsRejected, this.getChallengeHeaders ) )
      case Found( _, updated, data: GenericData ) =>
        val sessionData: SessionData = data.asInstanceOf[ SessionData ]
        if ( sessionData.salt == cookieSalt && sessionData.dni == cookieDni ) Right( sessionData )
        else Left( AuthenticationFailedRejection( AuthenticationFailedRejection.CredentialsRejected, this.getChallengeHeaders ) )
    }
  }

  /**
   * Method that verifies the code validity
   * @param code Code to validate
   * @param dni Session dni
   * @return A future with an Either inside
   *         Left with a Rejection code does not match
   *         Right with a tuple (Boolean, SecurityCode) if code matches (tuple._1 indicates if code is expired. tuple._2 contains security code data)
   */
  private def verifyCodeValidity( code: String, dni: String ): Future[ Either[ Rejection, ( Boolean, SecurityCode ) ] ] = {
    securityCodeManager.codeMatches( dni, code ).map {
      case None => Left( AuthenticationFailedRejection( AuthenticationFailedRejection.CredentialsRejected, this.getChallengeHeaders ) )
      case Some( securityCode ) =>
        if ( !securityCodeManager.validateSecurityCode( securityCode ) ) Right( ( false, securityCode ) )
        else Right( ( true, securityCode ) )
    }
  }

  /**
   * Method that verifies if a dni is in application blacklist
   * @param dni Dni to verify
   * @return A future with an Either inside
   *         Left with a Rejection is dni is the blacklist
   *         Right with Boolean (always true) if dni is not in the blacklist
   */
  private def verifyUnblocked( dni: String ): Future[ Either[ Rejection, Boolean ] ] = {
    blacklistRepository.findByDni( dni ).map {
      case None          => Right( true )
      case Some( found ) => Left( BlockedUserRejection() )
    }
  }

}
