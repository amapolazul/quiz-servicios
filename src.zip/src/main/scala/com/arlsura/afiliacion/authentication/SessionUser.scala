package com.arlsura.afiliacion.authentication

/**
 * Created by juanmartinez on 10/04/15.
 */
case class SessionUser( dni: String, isExpired: Boolean = false, codeMatches: Boolean = false, sourceCode: String = "NA" )
