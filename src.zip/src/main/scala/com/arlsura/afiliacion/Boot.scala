package com.arlsura.afiliacion

import akka.actor.ActorSystem
import akka.io.IO
import akka.pattern.ask
import akka.util.Timeout
import com.arlsura.afiliacion.actors.cache.CacheRefresherActor
import com.arlsura.afiliacion.bussiness.SoapConsumerSupport
import com.arlsura.afiliacion.services.orchestrator.ARLSuraServiceActor
import com.arlsura.afiliacion.utils.{ CipherFacility, Utils }
import com.sura.sessionmanager.SessionManager
import com.typesafe.scalalogging.LazyLogging
import slick.backend.DatabaseConfig
import spray.can.Http

import scala.concurrent.duration._

sealed trait ARLContext extends CipherFacility {
  implicit val conf = Utils.conf
  implicit val system = ActorSystem( "ARLSura-backend" )
  implicit val executionContext = system.dispatcher
  lazy val sessionManager = new SessionManager()
}

object ARLContext extends ARLContext

/**
 * Boot del orquestador del backend de ARL Sura.
 * Created by Jesús Martínez on 2/10/14.
 */
object Boot extends App with SoapConsumerSupport with LazyLogging {

  import ARLContext._

  implicit val timeout = Timeout( 50.seconds )

  system.actorOf( CacheRefresherActor.props, "cache-refresher-actor" ) ! CacheRefresherActor.Refresh

  val orchestrator = system.actorOf( ARLSuraServiceActor.props, "ARL-Sura-Service-Actor-orchestrator" )

  val fileConfPort = Utils.getProperty( "startup.", "port" ).asInstanceOf[ Int ]

  val host = Utils.getProperty( "startup.", "host" ).asInstanceOf[ String ]
  val port = Option( System.getenv( "PORT" ) ).getOrElse( String.valueOf( fileConfPort ) ).toInt
  IO( Http ) ? Http.Bind( orchestrator, interface = host, port = port )

}
