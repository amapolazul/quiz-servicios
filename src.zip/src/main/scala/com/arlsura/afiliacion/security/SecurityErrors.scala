package com.arlsura.afiliacion.security

/**
 * Created by Jesús Martínez on 24/11/14.
 */
object SecurityErrors {
  case class LengthOutOfBounds( length: Int, message: String )
}
