package com.arlsura.afiliacion.security.cookies

/**
 * Created by John on 11/06/15.
 */
object CookiesEncryption {

  val token: String = "dqE9dUu7Vfl3rd1VPyMB0ls8CBwfP8CWKBG7qIWleRa3eDKtWeLZqoL1MXvu02wyOZKl97zX3tCQpY1Esf10ojDOrdzLbwI8R5tnIIaQJ747y2MvPaJj0cwi76ldoHNoxT5n24fQXhZWcX8i3NzMm12nkX5fvTwNS72p0PgkWOoLJhUk9Nm2DQ9wpkEv2CLIgPXov7Y"

}
