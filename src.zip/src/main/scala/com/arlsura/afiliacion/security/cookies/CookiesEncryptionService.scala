package com.arlsura.afiliacion.security.cookies

import com.arlsura.afiliacion.bussiness.RequestContextSupport
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.GeneralJsonResponseData
import spray.http.StatusCodes
import spray.routing.{ HttpService, RequestContext }

/**
 * Created by John on 11/06/15.
 */
trait CookiesEncryptionService extends HttpService with RequestContextSupport {

  val cookieTokenRoute = {
    pathPrefix( "cookie" ) {
      pathEndOrSingleSlash {
        get {
          detach() {
            ( requestContext: RequestContext ) =>
              val response: GeneralJsonResponseData = GeneralJsonResponseData( "", Some( CookiesEncryption.token ) )
              complete( requestContext, StatusCodes.OK, response )
          }
        }
      }
    }
  }

}
