package com.arlsura.afiliacion.security

import java.util.Date

import com.arlsura.afiliacion.security.SecurityErrors.LengthOutOfBounds
import com.arlsura.afiliacion.utils.Utils
import com.google.common.base.Charsets
import com.google.common.hash.Hashing
import org.apache.commons.codec.binary.Base64
import org.joda.time.DateTime

/**
 * Created by John on 2/05/15.
 */
object TokenManager {

  val tokenName: String = "suraSessionManager"

  def buildSessionToken( dni: String ): Option[ String ] = {
    val d = s"$dni-${new Date().getTime.toString}"
    Some( Utils.encodeFile( d.getBytes ) )
  }

}
