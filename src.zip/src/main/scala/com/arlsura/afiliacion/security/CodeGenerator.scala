package com.arlsura.afiliacion.security

import com.arlsura.afiliacion.security.SecurityErrors._
import scala.util.Random

/**
 * Created by Jesús Martínez on 21/11/14.
 */
object CodeGenerator {
  private lazy val random = new Random()

  /**
   * Genera un código de seguridad con las especificaciones pasadas en los parámetros de entrada.
   * @param length Longitud del código. Por defecto: 4. Debe estar entre 4 y 32.
   * @param alphanumeric True si el código contendrá letras (mayúsculas y minúsculas) y números; false si solo números.
   * @return Representación del código como un string.
   */
  def generate( length: Int = 8, alphanumeric: Boolean = true ): Either[ LengthOutOfBounds, String ] = {
    if ( length < 4 || length > 32 )
      Left( LengthOutOfBounds( length, "El tamaño debe estar entre 4 y 32" ) ) //TODO ¿Mejor mandar el código de error? Revisar.
    else {
      val code = if ( alphanumeric )
        random.alphanumeric.take( length ).toList
      else for ( _ <- 1 to length ) yield random.nextInt( 9 )
      Right( code.mkString )
    }
  }

}
