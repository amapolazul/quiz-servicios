package com.arlsura.afiliacion.proceso.pasos.centros_trabajo

import com.arlsura.afiliacion.bussiness.affiliation.workcenters.WorkCentersDataRepository
import com.arlsura.afiliacion.bussiness.affiliation.{ BasicDataRepository, BasicDataServiceHandler }
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.{ ContactInformationData, SaveContactInformation }
import com.arlsura.afiliacion.persistence.daos.affiliation.wrappers.{ AffiliationBasicDataWrapper, AffiliationWorkCentersDataWrapper }
import com.arlsura.afiliacion.persistence.entities.affiliation.basic_data.AffiliationBasicData
import com.arlsura.afiliacion.persistence.entities.affiliation.contacts_data.ContactInformation
import com.arlsura.afiliacion.persistence.entities.affiliation.work_center_data.{ AffiliationWorkCentersData, WorkCenterInformation }
import com.arlsura.afiliacion.persistence.entities.preaffiliation.ProvinceSelected
import com.typesafe.scalalogging.LazyLogging
import reactivemongo.bson.{ BSONString, BSONDocument }
import reactivemongo.core.commands.LastError
import scala.collection.immutable.IndexedSeq
import scala.concurrent.Future
import scala.concurrent.ExecutionContext.Implicits.global

/**
 * Created by juanmartinez on 7/05/15.
 */
class WorkCenterPreSaving extends LazyLogging {

  private def defaultBranchName = "SEDE PRINCIPAL"
  private def defaultWorkCenter = "PRINCIPAL"
  private val workCenterRepo = new WorkCentersDataRepository( new AffiliationWorkCentersDataWrapper() )
  private val affiliationBasicDataManager: BasicDataRepository = new BasicDataRepository( new AffiliationBasicDataWrapper )

  def saveOrUpdate( contactsInfoRequest: SaveContactInformation ): Future[ Any ] = {
    val basicDataInformationFuture: Future[ Option[ AffiliationBasicData ] ] = getBasicDataInformation( contactsInfoRequest.dni )

    val processInformation: Future[ Any ] = basicDataInformationFuture map {
      case Some( bd: AffiliationBasicData ) =>
        val provincesSelected: List[ ProvinceSelected ] = bd.provincesSelected
        val contactList: List[ ContactInformationData ] = List(
          contactsInfoRequest.humanResourcesRepresentative,
          contactsInfoRequest.insideTrainingRepresentative,
          contactsInfoRequest.legalRepresentative,
          contactsInfoRequest.manager,
          contactsInfoRequest.rosterRepresentative,
          contactsInfoRequest.workSafetyRepresentative
        )

        val contactListInformation: List[ ContactInformation ] = buildContactsInformation( contactList )
        val workCenterInformation = buildWorkCenterInformation( provincesSelected, contactListInformation, bd )

        val workCenterEntity = AffiliationWorkCentersData(
          dni = contactsInfoRequest.dni,
          securityCode = contactsInfoRequest.securityCode,
          workCenters = workCenterInformation.toList
        )

        val workCenters: Future[ Option[ AffiliationWorkCentersData ] ] = workCenterRepo.findByDni( contactsInfoRequest.dni )

        val workCentersResponse: Future[ LastError ] = workCenters flatMap {
          case Some( wci ) =>
            workCenterRepo.updateByDni(
              contactsInfoRequest.dni,
              workCenterEntity.copy(
                _id = wci._id,
                dni = contactsInfoRequest.dni,
                securityCode = contactsInfoRequest.securityCode,
                workCenters = workCenterInformation.toList
              )
            )
          case None =>
            workCenterRepo.create( workCenterEntity )
        }

        workCentersResponse
      case None =>
      //        logger.debug( "No existe coleccion de datos basicos" )
    }
    processInformation
  }

  private def buildContactsInformation( contactList: List[ ContactInformationData ] ): List[ ContactInformation ] = {
    for (
      contact <- contactList
    ) yield ContactInformation(
      email = contact.email,
      identification = contact.identification,
      identificationType = contact.identificationType,
      lastname1 = contact.lastname1,
      lastname2 = contact.lastname2,
      name1 = contact.name1,
      name2 = contact.name2,
      phone = contact.phone,
      position = contact.position,
      title = contact.title,
      contactId = contact.contactId
    )
  }

  private def buildWorkCenterInformation( provincesSelected: List[ ProvinceSelected ], contactsInformation: List[ ContactInformation ], bd: AffiliationBasicData ): IndexedSeq[ WorkCenterInformation ] = {
    for {
      i <- 0 to provincesSelected.size - 1
    } yield WorkCenterInformation(
      branch = defaultBranchName,
      workcenterAddressData = bd.mainAddress.get,
      workcenterName = s"${defaultWorkCenter} ${provincesSelected( i ).provinceName}",
      workcenterCode = ( i + 1 ).toString,
      commercialActivity = bd.fullEconomicActivity,
      fax = bd.contactInformation.phone,
      phone = bd.contactInformation.phone,
      contacts = Some( contactsInformation )
    )
  }

  private def getBasicDataInformation( dni: String ): Future[ Option[ AffiliationBasicData ] ] = {
    affiliationBasicDataManager.getByDni( dni )
  }

}
