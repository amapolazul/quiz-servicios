package com.arlsura.afiliacion.proceso.pasos.segmentacion

import com.arlsura.afiliacion.bussiness.HandlerSupport._
import com.arlsura.afiliacion.bussiness.affiliation.PreaffiliationManager
import com.arlsura.afiliacion.bussiness.code.{ CodeSourceIdentifiers, SecurityCodeManager }
import com.arlsura.afiliacion.bussiness.segmentation.SegmentationManager
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.GeneralJsonResponseData
import com.arlsura.afiliacion.persistence.entities.{ SecurityCode, PreAffiliation }
import com.arlsura.afiliacion.persistence.entities.preaffiliation.SegmentationInformation
import com.arlsura.afiliacion.services.preaffiliation.PreaffiliationMarshaller.SegmentationDecision
import com.arlsura.afiliacion.utils.SecurityCodeHelper
import com.google.inject.Inject
import com.typesafe.scalalogging.LazyLogging

import scala.concurrent.{ Future, ExecutionContext }

/**
 * Created by John on 23/07/15.
 */
class PreAffiliationSegmentationDecisionHandler @Inject() ( securityCodeManager: SecurityCodeManager, segmentationManager: SegmentationManager, affiliationManager: PreaffiliationManager ) extends LazyLogging {

  def updateSegmentatioDecision( dni: String, segmentationDecision: SegmentationDecision )( implicit ec: ExecutionContext ): Future[ ServiceHandlerResponse ] = {
    affiliationManager.getPreAffiliationByDni( dni ) flatMap {
      result =>
        result match {
          case Some( preaffiliation ) =>
            val updatedPreaffiliation: PreAffiliation = updateEntity( preaffiliation, segmentationDecision )
            affiliationManager.updateClientAffiliation( updatedPreaffiliation ) flatMap {
              _ =>
                if ( segmentationDecision.affiliationApproved ) {
                  val securityCode: SecurityCode = SecurityCodeHelper.buildSecurityCode( updatedPreaffiliation, CodeSourceIdentifiers.COMMERCIAL )
                  securityCodeManager.saveSecurityCodeManager( securityCode ) flatMap {
                    _ =>
                      SecurityCodeHelper.sendCodeNotification( preaffiliation, securityCode )
                      Future.successful( Right( GeneralJsonResponseData( s"Se actualizo la preafiliacion asociada al DNI $dni y se creo el codigo de seguridad" ) ) )
                  }
                }
                else {
                  Future.successful( Right( GeneralJsonResponseData( s"Se actualizo la preafiliacion asociada al DNI $dni (afiliación denegada)" ) ) )
                }
            }
          case None => Future.successful( Left( s"Ocurrio un error. No se encontro la preafiliacion asociada al DNI $dni" ) )
        }
    } recover {
      case e: Throwable =>
        //        e.printStackTrace()
        Left( s"Ocurrio un error. DNI: $dni. Error: ${e.getMessage}" )
    }
  }

  /**
   * Actualiza la preafiliacion con los datos de segmentacion
   * @param preaffiliation
   * @param segmentationDecision
   * @return
   */
  private def updateEntity( preaffiliation: PreAffiliation, segmentationDecision: SegmentationDecision ): PreAffiliation = {
    PreAffiliation(
      _id = preaffiliation._id,
      dni = preaffiliation.dni,
      contactInfo = preaffiliation.contactInfo,
      fullName = preaffiliation.fullName,
      address = preaffiliation.address,
      cellphone = preaffiliation.cellphone,
      econoact = preaffiliation.econoact,
      fullEconomicActivity = preaffiliation.fullEconomicActivity,
      workers = preaffiliation.workers,
      prevarp = preaffiliation.prevarp,
      racea = preaffiliation.racea,
      fileName = preaffiliation.fileName,
      file = preaffiliation.file,
      affiliationType = preaffiliation.affiliationType,
      isNewCompany = preaffiliation.isNewCompany,
      selectedProvinces = preaffiliation.selectedProvinces,
      gender = preaffiliation.gender,
      birthDate = preaffiliation.birthDate,
      segmentation = Some( SegmentationInformation(
        commercialConsultantDni = segmentationDecision.commercialConsultantDni,
        affiliationApproved = segmentationDecision.affiliationApproved,
        rejectionCause = segmentationDecision.rejectionCause
      ) )
    )
  }

}
