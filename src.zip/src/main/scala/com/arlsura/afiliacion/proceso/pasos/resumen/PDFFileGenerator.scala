package com.arlsura.afiliacion.proceso.pasos.resumen

import java.io.FileOutputStream

import com.arlsura.afiliacion.utils.Utils
import com.arlsura.afiliacion.utils.messages.MessagesFormRetriever
import com.itextpdf.text.Font.FontFamily
import com.itextpdf.text.pdf.draw.LineSeparator
import com.itextpdf.text.pdf._
import com.itextpdf.text._
import org.joda.time.DateTime

import PDFFileGenerator._

import scala.collection.immutable

/**
 * Created by John on 24/05/15.
 */
class PDFFileGenerator {

  def generatePDF( employerData: EmployerData, footerData: FooterData, dni: String ): String = {
    val document: Document = new Document()
    document.setMargins( 0, 5, 7, 0 )
    val fullPath: String = generateFullFilePath( dni )
    val formDataDocument = new FileOutputStream( fullPath )
    val writer = PdfWriter.getInstance( document, formDataDocument )
    writer.setInitialLeading( 20 )
    document.open()
    val header: ( PdfPTable, LineSeparator ) = buildFormHeader( createTextHeader() )
    document.add( header._1 )
    document.add( header._2 )
    document.add( buildContextualHelp( MessagesFormRetriever.getMessage( "form", "contextual_help", "text" ) ) )
    document.add( createFormSectionTittle( MessagesFormRetriever.getMessage( "form", "employeer_data", "title" ) ) )
    val data: ( PdfPTable, PdfPTable, PdfPTable, PdfPTable, PdfPTable, PdfPTable, PdfPTable ) = createEmployeerData(
      employerData.name.toUpperCase,
      employerData.identification,
      employerData.commercialName.toUpperCase,
      employerData.legalName.toUpperCase,
      employerData.docIdRep,
      employerData.cotRate,
      employerData.mainActivity,
      employerData.legalCodeInForce,
      employerData.mainAddress.toUpperCase,
      employerData.city,
      employerData.province,
      employerData.phone,
      employerData.riskCode,
      employerData.mail.toUpperCase
    )

    document.add( data._1 )
    document.add( data._2 )
    document.add( data._3 )
    document.add( data._4 )
    document.add( data._5 )
    document.add( data._6 )
    document.add( data._7 )

    document.add( createFormSectionTittle( MessagesFormRetriever.getMessage( "form", "affiliation_type", "title" ) ) )
    document.add( createTypeAffiliation( employerData.fromAnotherArl, employerData.otherArl, employerData.dateAnotherArl ) )
    document.add( buildParagraphFooterAfiliacionClass() )
    document.add( createFormSectionTittle( MessagesFormRetriever.getMessage( "form", "work_centers", "title" ) ) )
    document.add( buildContextualHelp( MessagesFormRetriever.getMessage( "form", "contextual_help", "text_work_center" ) ) )
    val table: ( PdfPTable, PdfPTable, PdfPTable ) = createWorkCenterTable( employerData.listWorkCenters )
    document.add( table._1 )
    document.add( table._2 )
    document.add( table._3 )
    document.add( createFooterWorkCenters() )
    //Termina primer parte del formulario
    document.newPage()
    val header1: ( PdfPTable, LineSeparator ) = buildFormHeader( createTextHeader() )
    document.add( header._1 )
    document.add( header._2 )

    document.add( createFormSectionTittle( MessagesFormRetriever.getMessage( "form", "workers", "title" ) ) )
    val table1: ( PdfPTable, PdfPTable, PdfPTable ) = createWorkersTable( employerData.listWorkers )
    document.add( table1._1 )
    document.add( table1._2 )
    document.add( table1._3 )
    document.add( createFormSectionTittle( MessagesFormRetriever.getMessage( "form", "general_conditions", "title" ) ) )
    document.add( buildGeneralConditionsContent() )
    document.add( buildAuthorizationSignFields( employerData.legalName, employerData.docIdRep, employerData.name, employerData.identification ) )
    val footer: ( PdfPTable, PdfPTable ) = buildAuthorizationFooter()
    document.add( footer._2 )
    document.add( createFooter() )
    document.add( footer._1 )
    //Termina carta de condiciones generales y tabla de trabajaores
    document.newPage()
    val signImage = Image.getInstance( s"${basePath}deberesderechos.png" )
    signImage.scaleToFit( 800, 800 )
    signImage.setAlignment( Element.ALIGN_CENTER )
    document.add( signImage )
    //Termina imagen deberes de derecho
    document.newPage()
    val header5: ( PdfPTable, LineSeparator ) = buildFormAuthHeader( createLetterHeader() )
    document.add( header5._1 )
    document.add( buildRightsLetter( footerData.companyName.toUpperCase, footerData.nit ) )
    document.add( buildRightsFooter( employerData.legalName, employerData.docIdRep, employerData.name, employerData.identification ) )
    //Termina autorizaciones reporte
    document.newPage()
    document.add( buildMovilityLetter() )
    document.add( buildMovilityFooter( employerData.legalName, employerData.docIdRep, employerData.name, employerData.identification ) )
    document.newPage()
    document.add( buildMovilityARLLetter() )
    document.add( buildMovilityFooter( employerData.legalName, employerData.docIdRep, employerData.name, employerData.identification ) )
    document.newPage()
    val header2: ( PdfPTable, LineSeparator ) = buildFormHeader( createBankAccountHeader() )
    document.add( header2._1 )
    document.add( header2._2 )
    document.add( createFormSectionTittle( MessagesFormRetriever.getMessage( "form", "electronic_transfer_account", "signed_account" ) ) )
    document.add( buildContextualHelp( MessagesFormRetriever.getMessage( "form", "electronic_transfer_account", "contextual_help" ) ) )
    document.add( createFormSectionTittle( MessagesFormRetriever.getMessage( "form", "electronic_transfer_account", "employeer_data" ) ) )

    val account1: ( PdfPTable, PdfPTable, PdfPTable, PdfPTable, PdfPTable ) = createEmployeerDatabankAccount( employerData.name.toUpperCase, employerData.identification,
      employerData.city, employerData.province, employerData.phone, employerData.mainAddress, employerData.mail )
    document.add( account1._1 )
    document.add( account1._2 )
    document.add( account1._3 )
    document.add( account1._4 )
    document.add( account1._5 )
    document.add( buildParagraphBankAccount() )
    document.add( buildBankAccountFooter( employerData.legalName, employerData.docIdRep, employerData.name, employerData.identification, employerData.city ) )
    document.close()
    fullPath
  }

  private def generateFullFilePath( dni: String ): String = {
    outputPath + outputFileName + "-" + dni + "-" + new java.util.Date().getTime + "." + outputFileExtension
  }

  val baseColorTitle = new BaseColor( 110, 199, 45 )
  val baseColorTableHeader = new BaseColor( 35, 149, 70 )
  val fontTitle = new Font( FontFamily.HELVETICA, 11, Font.BOLD, baseColorTitle )
  val fontFieldTitles = new Font( FontFactory.getFont( "arial" ).getFamily, 10, Font.BOLD, BaseColor.BLACK )
  val fontFieldContent = new Font( FontFactory.getFont( "din-regular" ).getFamily, 10, Font.NORMAL, new BaseColor( 64, 64, 65 ) )
  val fontHeaderText = new Font( FontFamily.UNDEFINED, 8, Font.BOLD, baseColorTableHeader )
  val generalConditionsFont = new Font( FontFamily.UNDEFINED, 12, Font.NORMAL, BaseColor.BLACK )
  val fontContextualHelp = new Font( FontFamily.UNDEFINED, 8, Font.NORMAL, BaseColor.BLACK )
  val fontSecondParagraph = new Font( FontFamily.UNDEFINED, 12, Font.NORMAL, BaseColor.BLACK )
  val fontFooterParagraphClase = new Font( FontFamily.UNDEFINED, 9, Font.NORMAL, new BaseColor( 64, 64, 65 ) )

  def buildParagraphBankAccount(): PdfPTable = {
    val pdfPTable: PdfPTable = new PdfPTable( 1 )
    pdfPTable.setWidthPercentage( 95 )

    pdfPTable.addCell( buildParagraphContent( s"\n\n${MessagesFormRetriever.getMessage( "form", "electronic_transfer_account", "paragraph_1" )}", fontSecondParagraph ) )
    pdfPTable.addCell( buildParagraphContent( s"\n${MessagesFormRetriever.getMessage( "form", "electronic_transfer_account", "paragraph_2" )}", fontSecondParagraph ) )
    pdfPTable.addCell( buildParagraphContent( s"\n${MessagesFormRetriever.getMessage( "form", "electronic_transfer_account", "paragraph_3" )}", fontSecondParagraph ) )

    pdfPTable

  }

  def buildParagraphFooterAfiliacionClass(): PdfPTable = {

    val pdfPTable: PdfPTable = new PdfPTable( 1 )
    pdfPTable.setWidthPercentage( 95 )
    pdfPTable.addCell( buildParagraphContent( s"\n${MessagesFormRetriever.getMessage( "form", "footerClaseAfilaicion", "texto_clase" )}", fontFooterParagraphClase ) )
    pdfPTable.addCell( buildParagraphContent( s"\n${MessagesFormRetriever.getMessage( "form", "footerClaseAfilaicion", "sub_texto" )}", fontFooterParagraphClase ) )
    pdfPTable

  }

  def buildBankAccountFooter( representanteLegalName: String, representanteId: String, companyName: String, CompanyNit: String, ciudad: String ): PdfPTable = {
    val pdfPTable: PdfPTable = new PdfPTable( 3 )
    pdfPTable.setSpacingBefore( 100f )
    pdfPTable.setWidthPercentage( 95 )

    val lineSeparator_1 = new LineSeparator()
    lineSeparator_1.setLineColor( BaseColor.GRAY )
    val cell_1 = new PdfPCell()
    val city = new Paragraph( ciudad )
    city.setFont( fontSecondParagraph )
    city.setAlignment( Element.ALIGN_CENTER )
    cell_1.setBorder( Rectangle.NO_BORDER )
    cell_1.addElement( city )
    cell_1.addElement( lineSeparator_1 )
    cell_1.setPaddingLeft( 40f )
    cell_1.setPaddingRight( 40f )
    cell_1.setPaddingTop( 60f )

    val lineSeparator_2 = new LineSeparator()
    lineSeparator_2.setLineColor( BaseColor.GRAY )
    val cell_2 = new PdfPCell()
    cell_2.setBorder( Rectangle.NO_BORDER )
    val signImage = Image.getInstance( s"${basePath}vigilado-vertical.png" )
    signImage.scaleToFit( 80, 80 )
    signImage.setAlignment( Element.ALIGN_LEFT )
    cell_2.addElement( signImage )
    cell_2.addElement( lineSeparator_2 )
    cell_2.setPaddingLeft( 20f )
    cell_2.setPaddingRight( 40f )

    val cell_3 = new PdfPCell()
    val lineSeparator_3 = new LineSeparator()
    lineSeparator_3.setLineColor( BaseColor.GRAY )
    cell_3.setBorder( Rectangle.NO_BORDER )
    cell_3.addElement( lineSeparator_3 )
    cell_3.setPaddingLeft( 40f )
    cell_3.setPaddingRight( 40f )
    cell_3.setPaddingTop( 100f )

    val cell_4 = new PdfPCell()
    val paragraph_2 = new Paragraph( MessagesFormRetriever.getMessage( "form", "electronic_transfer_account", "legal_manager" ) )
    val representanteLegal = new Paragraph( representanteLegalName.toUpperCase + " " + representanteId )
    val empresa = new Paragraph( companyName.toUpperCase + " " + CompanyNit )
    representanteLegal.setFont( fontHeaderText )
    representanteLegal.setAlignment( Element.ALIGN_LEFT )
    empresa.setFont( fontHeaderText )
    empresa.setAlignment( Element.ALIGN_LEFT )
    paragraph_2.setFont( fontHeaderText )
    paragraph_2.setAlignment( Element.ALIGN_CENTER )
    cell_4.setBorder( Rectangle.NO_BORDER )
    cell_4.addElement( paragraph_2 )
    cell_4.addElement( representanteLegal )
    cell_4.addElement( empresa )
    cell_4.setPaddingLeft( 40f )
    cell_4.setPaddingRight( 40f )

    val cell_5 = new PdfPCell()
    val paragraph_5 = new Paragraph( MessagesFormRetriever.getMessage( "form", "electronic_transfer_account", "city" ) )
    paragraph_5.setFont( fontHeaderText )
    paragraph_5.setAlignment( Element.ALIGN_CENTER )
    cell_5.setBorder( Rectangle.NO_BORDER )
    cell_5.addElement( paragraph_5 )
    cell_5.setPaddingLeft( 40f )
    cell_5.setPaddingRight( 40f )

    val cell_6 = new PdfPCell()
    val paragraph_6 = new Paragraph( MessagesFormRetriever.getMessage( "form", "electronic_transfer_account", "date" ) )
    paragraph_6.setFont( fontHeaderText )
    paragraph_6.setAlignment( Element.ALIGN_CENTER )
    cell_6.setBorder( Rectangle.NO_BORDER )
    cell_6.addElement( paragraph_6 )
    cell_6.setPaddingLeft( 40f )
    cell_6.setPaddingRight( 40f )

    pdfPTable.addCell( cell_2 )
    pdfPTable.addCell( cell_1 )
    pdfPTable.addCell( cell_3 )
    pdfPTable.addCell( cell_4 )
    pdfPTable.addCell( cell_5 )
    pdfPTable.addCell( cell_6 )

    pdfPTable
  }

  def buildMovilityARLLetter() = {
    val pdfPTable: PdfPTable = new PdfPTable( 1 )
    pdfPTable.setWidthPercentage( 95 )

    pdfPTable.addCell( buildParagraphContent( s"\n\n\n\n\n${MessagesFormRetriever.getMessage( "form", "movility_arl", "receptor" )}", fontSecondParagraph ) )
    pdfPTable.addCell( buildParagraphContent( s"\n\n${MessagesFormRetriever.getMessage( "form", "movility_arl", "reference" )}", fontSecondParagraph ) )
    pdfPTable.addCell( buildParagraphContent( s"\n\n${MessagesFormRetriever.getMessage( "form", "movility_arl", "cheers" )}", fontSecondParagraph ) )
    pdfPTable.addCell( buildParagraphContent( s"\n${MessagesFormRetriever.getMessage( "form", "movility_arl", "paragraph_1" )}", fontSecondParagraph ) )
    pdfPTable.addCell( buildParagraphContent( s"\n${MessagesFormRetriever.getMessage( "form", "movility_arl", "paragraph_2" )}", fontSecondParagraph ) )
    pdfPTable.addCell( buildParagraphContent( s"\n${MessagesFormRetriever.getMessage( "form", "movility_arl", "paragraph_3" )}", fontSecondParagraph ) )
    pdfPTable.addCell( buildParagraphContent( s"\n${MessagesFormRetriever.getMessage( "form", "movility_arl", "paragraph_4" )}", fontSecondParagraph ) )

    pdfPTable
  }

  def buildMovilityLetter(): PdfPTable = {
    val pdfPTable: PdfPTable = new PdfPTable( 1 )
    pdfPTable.setWidthPercentage( 95 )

    pdfPTable.addCell( buildParagraphContent( s"\n\n\n\n\n${MessagesFormRetriever.getMessage( "form", "movility", "receptor" )}", fontSecondParagraph ) )
    pdfPTable.addCell( buildParagraphContent( s"\n\n${MessagesFormRetriever.getMessage( "form", "movility", "reference" )}", fontSecondParagraph ) )
    pdfPTable.addCell( buildParagraphContent( s"\n\n${MessagesFormRetriever.getMessage( "form", "movility", "cheers" )}", fontSecondParagraph ) )
    pdfPTable.addCell( buildParagraphContent( s"\n${MessagesFormRetriever.getMessage( "form", "movility", "paragraph_1" )}", fontSecondParagraph ) )
    pdfPTable.addCell( buildParagraphContent( s"\n${MessagesFormRetriever.getMessage( "form", "movility", "paragraph_2" )}", fontSecondParagraph ) )
    pdfPTable.addCell( buildParagraphContent( s"\n${MessagesFormRetriever.getMessage( "form", "movility", "paragraph_3" )}", fontSecondParagraph ) )
    pdfPTable.addCell( buildParagraphContent( s"\n${MessagesFormRetriever.getMessage( "form", "movility", "paragraph_4" )}", fontSecondParagraph ) )

    pdfPTable

  }

  def buildMovilityFooter( representanteLegalName: String, representanteId: String, companyName: String, CompanyNit: String ): PdfPTable = {
    val pdfPTable_0: PdfPTable = new PdfPTable( 1 )
    pdfPTable_0.setSpacingBefore( 120f )
    pdfPTable_0.setWidthPercentage( 95 )

    val lineSeparator_1 = new LineSeparator()
    lineSeparator_1.setLineColor( BaseColor.GRAY )
    val cell_1 = new PdfPCell()
    cell_1.setBorder( Rectangle.NO_BORDER )
    cell_1.addElement( lineSeparator_1 )
    cell_1.setPaddingRight( 200 )

    val cell_2 = new PdfPCell()
    val stringFooter = MessagesFormRetriever.getMessage( "form", "movility", "footer_1" )
    val paragraph_1 = new Paragraph( stringFooter )
    val representanteLegal = new Paragraph( representanteLegalName.toUpperCase + " " + representanteId )
    val empresa = new Paragraph( companyName.toUpperCase + " " + CompanyNit )
    representanteLegal.setFont( fontHeaderText )
    representanteLegal.setAlignment( Element.ALIGN_LEFT )
    empresa.setFont( fontHeaderText )
    empresa.setAlignment( Element.ALIGN_LEFT )
    paragraph_1.setFont( fontTitle )
    paragraph_1.setAlignment( Element.ALIGN_LEFT )
    cell_2.setBorder( Rectangle.NO_BORDER )
    cell_2.addElement( paragraph_1 )
    cell_2.addElement( representanteLegal )
    cell_2.addElement( empresa )
    cell_2.setPaddingRight( 40f )

    pdfPTable_0.addCell( cell_1 )
    pdfPTable_0.addCell( cell_2 )
    pdfPTable_0

  }

  def buildRightsLetter( legalName: String, nit: String ): PdfPTable = {
    val pdfPTable: PdfPTable = new PdfPTable( 1 )
    pdfPTable.setWidthPercentage( 95 )

    val date = new DateTime()
    val dateString = s"${Utils.getMonth( date.getMonthOfYear ).getOrElse( "" )} ${date.getDayOfMonth} de ${date.getYear}"
    pdfPTable.addCell( buildParagraphContent( s"\n\n\n$dateString\n$legalName\n$nit", fontSecondParagraph ) )
    pdfPTable.addCell( buildParagraphContent( s"\n\n\n${MessagesFormRetriever.getMessage( "form", "rights", "paragraph_1" )}", fontSecondParagraph ) )
    pdfPTable.addCell( buildParagraphContent( s"\n${MessagesFormRetriever.getMessage( "form", "rights", "paragraph_2" )}", fontSecondParagraph ) )
    pdfPTable.addCell( buildParagraphContent( s"\n${MessagesFormRetriever.getMessage( "form", "rights", "paragraph_3" )}", fontSecondParagraph ) )
    pdfPTable

  }

  def buildRightsFooter( representanteLegalName: String, representanteId: String, companyName: String, CompanyNit: String ): PdfPTable = {
    val pdfPTable_0: PdfPTable = new PdfPTable( 1 )
    pdfPTable_0.setSpacingBefore( 300f )
    pdfPTable_0.setWidthPercentage( 95 )

    val lineSeparator_1 = new LineSeparator()
    lineSeparator_1.setLineColor( BaseColor.GRAY )
    val cell_1 = new PdfPCell()
    cell_1.setBorder( Rectangle.NO_BORDER )
    cell_1.addElement( lineSeparator_1 )
    cell_1.setPaddingRight( 140 )

    val cell_2 = new PdfPCell()
    val paragraph_1 = new Paragraph( MessagesFormRetriever.getMessage( "form", "rights", "footer_1" ) )
    val representanteLegal = new Paragraph( representanteLegalName.toUpperCase + " " + representanteId )
    val empresa = new Paragraph( companyName.toUpperCase + " " + CompanyNit )
    representanteLegal.setFont( fontHeaderText )
    representanteLegal.setAlignment( Element.ALIGN_LEFT )
    empresa.setFont( fontHeaderText )
    empresa.setAlignment( Element.ALIGN_LEFT )
    paragraph_1.setFont( fontTitle )
    paragraph_1.setAlignment( Element.ALIGN_LEFT )
    cell_2.setBorder( Rectangle.NO_BORDER )
    cell_2.addElement( paragraph_1 )
    cell_2.addElement( representanteLegal )
    cell_2.addElement( empresa )
    cell_2.setPaddingRight( 40f )

    pdfPTable_0.addCell( cell_1 )
    pdfPTable_0.addCell( cell_2 )
    pdfPTable_0
  }

  def buildParagraphContent( content: String, font: Font ): PdfPCell = {
    val paragraph: Paragraph = new Paragraph( content )
    paragraph.setFont( font )
    paragraph.setAlignment( Element.ALIGN_JUSTIFIED )
    val cell: PdfPCell = new PdfPCell()
    cell.addElement( paragraph )
    cell.setBorder( Rectangle.NO_BORDER )
    cell
  }

  def buildGeneralConditionsContent(): PdfPTable = {
    val pdfPTable: PdfPTable = new PdfPTable( 1 )
    pdfPTable.setWidthPercentage( 95 )

    pdfPTable.addCell( buildParagraphContent( s"\n${MessagesFormRetriever.getMessage( "form", "general_conditions", "parrafo" )}", generalConditionsFont ) )

    pdfPTable
  }

  def buildLetterAuthorizationContent(): PdfPTable = {
    val pdfPTable: PdfPTable = new PdfPTable( 1 )
    pdfPTable.setWidthPercentage( 95 )

    pdfPTable.addCell( buildParagraphContent( s"\n${MessagesFormRetriever.getMessage( "form", "authorization", "paragraph_1" )}", fontFieldContent ) )
    pdfPTable.addCell( buildParagraphContent( s"\n${MessagesFormRetriever.getMessage( "form", "authorization", "paragraph_2" )}", fontFieldContent ) )
    pdfPTable.addCell( buildParagraphContent( s"\n${MessagesFormRetriever.getMessage( "form", "authorization", "paragraph_3" )}", fontFieldContent ) )
    pdfPTable.addCell( buildParagraphContent( s"\n${MessagesFormRetriever.getMessage( "form", "authorization", "paragraph_4" )}", fontFieldContent ) )
    pdfPTable.addCell( buildParagraphContent( s"\n${MessagesFormRetriever.getMessage( "form", "authorization", "paragraph_5" )}", fontFieldContent ) )
    pdfPTable.addCell( buildParagraphContent( s"\n${MessagesFormRetriever.getMessage( "form", "authorization", "paragraph_6" )}", fontFieldContent ) )
    pdfPTable.addCell( buildParagraphContent( s"\n${MessagesFormRetriever.getMessage( "form", "authorization", "paragraph_7" )}", fontFieldContent ) )

    pdfPTable
  }

  def buildAuthorizationFooter(): ( PdfPTable, PdfPTable ) = {
    val pdfPTable: PdfPTable = new PdfPTable( 2 )
    pdfPTable.setSpacingBefore( 20f )
    pdfPTable.setWidths( Array( 14.2f, 3.5f ) )
    pdfPTable.setWidthPercentage( 95 )

    val paragraph = new Paragraph( MessagesFormRetriever.getMessage( "form", "authorization", "footer_1" ) )
    paragraph.setFont( FontFactory.getFont( "Arial", 6, BaseColor.GRAY ) )
    val cell_1 = new PdfPCell()
    cell_1.setBorder( Rectangle.NO_BORDER )
    cell_1.addElement( paragraph )

    val paragraph_1 = new Paragraph( MessagesFormRetriever.getMessage( "form", "authorization", "footer_2" ) )
    paragraph_1.setFont( fontContextualHelp )
    paragraph_1.setAlignment( Element.ALIGN_CENTER )
    val cell_3 = new PdfPCell()
    cell_3.setBorder( Rectangle.NO_BORDER )
    cell_3.addElement( paragraph_1 )

    val image = Image.getInstance( s"${basePath}vigilado.png" )
    image.scaleAbsolute( 100, 100 )
    val cell_2 = new PdfPCell()
    cell_2.setBorder( Rectangle.NO_BORDER )
    cell_2.addElement( image )

    pdfPTable.addCell( cell_1 )
    pdfPTable.addCell( cell_2 )
    val pdfPTable_1: PdfPTable = new PdfPTable( 1 )
    pdfPTable_1.setSpacingBefore( 20f )
    pdfPTable_1.addCell( cell_3 )

    ( pdfPTable, pdfPTable_1 )
  }

  def buildAuthorizationSignFields( representanteLegalName: String, representanteId: String, companyName: String, CompanyNit: String ): PdfPTable = {
    val pdfPTable: PdfPTable = new PdfPTable( 2 )
    pdfPTable.setSpacingBefore( 100f )
    pdfPTable.setWidthPercentage( 95 )

    val lineSeparator_1 = new LineSeparator()
    lineSeparator_1.setLineColor( BaseColor.GRAY )
    val cell_1 = new PdfPCell()
    cell_1.setBorder( Rectangle.NO_BORDER )
    cell_1.addElement( lineSeparator_1 )
    cell_1.setPaddingLeft( 40f )
    cell_1.setPaddingRight( 40f )
    cell_1.setPaddingTop( 100f )

    val lineSeparator_2 = new LineSeparator()
    lineSeparator_2.setLineColor( BaseColor.GRAY )
    val cell_2 = new PdfPCell()
    cell_2.setBorder( Rectangle.NO_BORDER )
    val signImage = Image.getInstance( s"${basePath}firma-representante-legal-arlsura.png" )
    signImage.scalePercent( 100 )
    signImage.setAlignment( Element.ALIGN_CENTER )
    cell_2.addElement( signImage )
    cell_2.addElement( lineSeparator_2 )
    cell_2.setPaddingLeft( 40f )
    cell_2.setPaddingRight( 40f )

    val cell_3 = new PdfPCell()
    val paragraph_1 = new Paragraph( MessagesFormRetriever.getMessage( "form", "authorization", "sign_seal_1" ) )
    val representanteLegal = new Paragraph( representanteLegalName.toUpperCase + " " + representanteId )
    val empresa = new Paragraph( companyName.toUpperCase + " " + CompanyNit )
    representanteLegal.setFont( fontHeaderText )
    representanteLegal.setAlignment( Element.ALIGN_LEFT )
    empresa.setFont( fontHeaderText )
    empresa.setAlignment( Element.ALIGN_LEFT )
    paragraph_1.setFont( fontHeaderText )
    paragraph_1.setAlignment( Element.ALIGN_CENTER )
    cell_3.setBorder( Rectangle.NO_BORDER )
    cell_3.addElement( paragraph_1 )
    cell_3.addElement( representanteLegal )
    cell_3.addElement( empresa )
    cell_3.setPaddingLeft( 40f )
    cell_3.setPaddingRight( 40f )

    val cell_4 = new PdfPCell()
    val paragraph_2 = new Paragraph( MessagesFormRetriever.getMessage( "form", "authorization", "sign_seal_2" ) )
    paragraph_2.setFont( fontHeaderText )
    paragraph_2.setAlignment( Element.ALIGN_CENTER )
    cell_4.setBorder( Rectangle.NO_BORDER )
    cell_4.addElement( paragraph_2 )
    cell_4.setPaddingLeft( 40f )
    cell_4.setPaddingRight( 40f )

    pdfPTable.addCell( cell_1 )
    pdfPTable.addCell( cell_2 )
    pdfPTable.addCell( cell_3 )
    pdfPTable.addCell( cell_4 )

    pdfPTable
  }

  def buildAuthorizeLetterHeader() = {
    val pdfPTable: PdfPTable = new PdfPTable( 1 )
    pdfPTable.setSpacingAfter( 10f )
    pdfPTable.setSpacingBefore( 40f )
    pdfPTable.setWidthPercentage( 95 )
    val authorizeParagraph: Paragraph = new Paragraph( MessagesFormRetriever.getMessage( "form", "authorization", "authorize" ) )
    authorizeParagraph.setFont( fontTitle )
    val cell: PdfPCell = new PdfPCell()
    cell.setBorder( Rectangle.NO_BORDER )
    cell.addElement( authorizeParagraph )
    pdfPTable.addCell( cell )

    val sirsParagraph: Paragraph = new Paragraph( s"\n ${MessagesFormRetriever.getMessage( "form", "authorization", "sirs" )}" )
    sirsParagraph.setFont( fontFieldContent )
    val cell_1: PdfPCell = new PdfPCell()
    cell_1.addElement( sirsParagraph )
    cell_1.setBorder( Rectangle.NO_BORDER )
    pdfPTable.addCell( cell_1 )

    val toParagraph: Paragraph = new Paragraph( s"\n ${MessagesFormRetriever.getMessage( "form", "authorization", "to" )}" )
    toParagraph.setFont( fontFieldContent )
    val cell_2: PdfPCell = new PdfPCell()
    cell_2.addElement( toParagraph )
    cell_2.setBorder( Rectangle.NO_BORDER )
    pdfPTable.addCell( cell_2 )
    pdfPTable
  }

  def buildFormAuthHeader( f: => PdfPCell ): ( PdfPTable, LineSeparator ) = {
    val pdfTableHeader: PdfPTable = new PdfPTable( 1 )
    pdfTableHeader.setWidthPercentage( 100 )
    pdfTableHeader.addCell( f )
    val separator: LineSeparator = new LineSeparator
    separator.setLineColor( BaseColor.GRAY )

    ( pdfTableHeader, separator )
  }

  def buildFormHeader( f: => PdfPCell ): ( PdfPTable, LineSeparator ) = {
    val pdfTableImageHeader: PdfPTable = new PdfPTable( 2 )
    pdfTableImageHeader.setWidthPercentage( 100 )
    pdfTableImageHeader.setWidths( Array( 1, 2 ) )
    pdfTableImageHeader.addCell( createImageHeaderCell() )
    pdfTableImageHeader.addCell( f )

    val separator: LineSeparator = new LineSeparator
    separator.setLineColor( BaseColor.GRAY )

    ( pdfTableImageHeader, separator )

  }

  def buildContextualHelp( text: String ): PdfPTable = {
    val contextualHelp = new PdfPTable( 2 )
    contextualHelp.setSpacingBefore( 10 )
    contextualHelp.setWidthPercentage( 95 )
    contextualHelp.setWidths( Array( 1, 11 ) )

    contextualHelp.addCell( buildImageCell )
    contextualHelp.addCell( buildParagraphCell )

    def buildImageCell(): PdfPCell = {
      val contextImage = Image.getInstance( s"${basePath}/ico-informativo.png" )
      contextImage.scaleToFit( 30, 30 )
      val pdfCell = new PdfPCell( contextImage )
      pdfCell.setPaddingLeft( 10 )
      pdfCell.setPaddingTop( 5 )
      pdfCell.setPaddingBottom( 18 )
      pdfCell.setFixedHeight( 40f )
      pdfCell.setBorder( Rectangle.NO_BORDER )
      pdfCell.setBackgroundColor( new BaseColor( 242, 250, 224 ) )
      pdfCell
    }

    def buildParagraphCell(): PdfPCell = {
      val paragraph = new Paragraph()
      paragraph.setFont( fontContextualHelp )
      paragraph.add( text )
      paragraph.setAlignment( Element.ALIGN_LEFT )
      paragraph.setLeading( 12, 0 )
      val pdfCell = new PdfPCell
      pdfCell.addElement( paragraph )
      pdfCell.setBackgroundColor( new BaseColor( 242, 250, 224 ) )
      pdfCell.setBorder( Rectangle.NO_BORDER )
      pdfCell
    }

    contextualHelp
  }

  def createTextHeader(): PdfPCell = {
    val paragraph = new Paragraph()
    paragraph.setFont( FontFactory.getFont( "Arial", 10 ) )
    paragraph.add( MessagesFormRetriever.getMessage( "form", "header", "text_header_one" ) )
    paragraph.setAlignment( Element.ALIGN_RIGHT )
    paragraph.setLeading( 12, 0 )
    val paraTwo = new Paragraph()
    paraTwo.setFont( FontFactory.getFont( "Arial", 7 ) )
    paraTwo.setAlignment( Element.ALIGN_RIGHT )
    paraTwo.add( MessagesFormRetriever.getMessage( "form", "header", "text_header_two" ) )

    val pdfCell = new PdfPCell
    pdfCell.addElement( paragraph )
    pdfCell.addElement( paraTwo )
    pdfCell.setBorder( Rectangle.NO_BORDER )
    pdfCell
  }

  def createBankAccountHeader(): PdfPCell = {
    val paragraph = new Paragraph()
    paragraph.setFont( FontFactory.getFont( "Arial", 12 ) )
    paragraph.add( MessagesFormRetriever.getMessage( "form", "electronic_transfer_account", "title" ) )
    paragraph.setAlignment( Element.ALIGN_RIGHT )
    paragraph.setLeading( 12, 0 )

    val paragraph2 = new Paragraph()
    paragraph2.setFont( FontFactory.getFont( "Arial", 12 ) )
    paragraph2.add( MessagesFormRetriever.getMessage( "form", "electronic_transfer_account", "title_2" ) )
    paragraph2.setAlignment( Element.ALIGN_RIGHT )
    paragraph2.setLeading( 12, 0 )

    val pdfCell = new PdfPCell
    pdfCell.addElement( paragraph )
    pdfCell.addElement( paragraph2 )
    pdfCell.setBorder( Rectangle.NO_BORDER )
    pdfCell
  }

  def createLetterHeader(): PdfPCell = {
    val paragraph = new Paragraph()
    paragraph.setFont( FontFactory.getFont( "Arial", 10 ) )
    paragraph.add( MessagesFormRetriever.getMessage( "form", "authorization", "text_1" ) )
    paragraph.setAlignment( Element.ALIGN_RIGHT )
    paragraph.setLeading( 12, 0 )
    val paraTwo = new Paragraph()
    paraTwo.setFont( FontFactory.getFont( "Arial", 10 ) )
    paraTwo.setAlignment( Element.ALIGN_RIGHT )
    paraTwo.add( MessagesFormRetriever.getMessage( "form", "authorization", "text_2" ) )

    val paraThree = new Paragraph()
    paraThree.setFont( FontFactory.getFont( "Arial", 7 ) )
    paraThree.setAlignment( Element.ALIGN_RIGHT )
    paraThree.add( MessagesFormRetriever.getMessage( "form", "authorization", "text_3" ) )

    val pdfCell = new PdfPCell
    pdfCell.addElement( paragraph )
    pdfCell.addElement( paraTwo )
    pdfCell.addElement( paraThree )
    pdfCell.setBorder( Rectangle.NO_BORDER )
    pdfCell
  }

  def createImageHeaderCell(): PdfPCell = {
    val headerImage = Image.getInstance( s"$basePath/encabezado.png" )
    val pdfCell = new PdfPCell( headerImage, true )
    pdfCell.setPaddingLeft( 10 )
    pdfCell.setPaddingTop( 10 )
    pdfCell.setBorder( Rectangle.NO_BORDER )
    pdfCell
  }

  def createEmployeerData(
    name:             String,
    identification:   String,
    commercialName:   String,
    legalName:        String,
    docIdRep:         String,
    cotRate:          String,
    mainActivity:     String,
    legalCodeInForce: String,
    mainAddress:      String,
    city:             String,
    province:         String,
    phone:            String,
    riskCode:         String,
    mail:             String
  ): ( PdfPTable, PdfPTable, PdfPTable, PdfPTable, PdfPTable, PdfPTable, PdfPTable ) = {
    val pdfTable: PdfPTable = new PdfPTable( 2 )
    pdfTable.setWidthPercentage( 95 )
    pdfTable.addCell(
      addCellFormContent( name, MessagesFormRetriever.getMessage( "form", "employeer_data", "name" ), 130, 0 )
    )
    pdfTable.addCell(
      addCellExamFormContent( identification, MessagesFormRetriever.getMessage( "form", "employeer_data", "doc_id" ), 60, 2, 2 )
    )
    val pdfTable1: PdfPTable = new PdfPTable( 1 )
    pdfTable1.setWidthPercentage( 95 )
    pdfTable1.addCell(
      addCellFormContent( commercialName, MessagesFormRetriever.getMessage( "form", "employeer_data", "commercial_name" ) )
    )
    val pdfTable2: PdfPTable = new PdfPTable( 2 )
    pdfTable2.setWidthPercentage( 95 )
    pdfTable2.addCell(
      addCellFormContent( legalName, MessagesFormRetriever.getMessage( "form", "employeer_data", "legal_name" ), 130, 0 )
    )
    pdfTable2.addCell(
      addCellExamFormContent( docIdRep, MessagesFormRetriever.getMessage( "form", "employeer_data", "doc_id_rep" ), 60, 2, 2 )
    )
    val pdfTable3: PdfPTable = new PdfPTable( 1 )
    pdfTable3.setWidthPercentage( 95 )
    pdfTable3.addCell(
      addCellFormContent( mainActivity, MessagesFormRetriever.getMessage( "form", "employeer_data", "main_activity" ) )
    )

    val pdfTable4: PdfPTable = new PdfPTable( 3 )
    pdfTable4.setWidths( Array( 5, 5, 5 ) )
    pdfTable4.setWidthPercentage( 95 )
    pdfTable4.addCell(
      addCellFormContent( legalCodeInForce, MessagesFormRetriever.getMessage( "form", "employeer_data", "code_leg_inforce" ) )
    )
    pdfTable4.addCell(
      addCellFormContent( riskCode, MessagesFormRetriever.getMessage( "form", "employeer_data", "risk_code" ) )
    )
    pdfTable4.addCell(
      addCellFormContent( cotRate, MessagesFormRetriever.getMessage( "form", "employeer_data", "cot_rate" ) )
    )
    val pdfTable5: PdfPTable = new PdfPTable( 4 )
    pdfTable5.setWidths( Array( 10, 5, 5, 5 ) )
    pdfTable5.setWidthPercentage( 95 )
    pdfTable5.addCell(
      addCellFormContent( mainAddress, MessagesFormRetriever.getMessage( "form", "employeer_data", "main_address" ) )
    )
    pdfTable5.addCell(
      addCellFormContent( city, MessagesFormRetriever.getMessage( "form", "employeer_data", "city" ) )
    )
    pdfTable5.addCell(
      addCellFormContent( province, MessagesFormRetriever.getMessage( "form", "employeer_data", "province" ) )
    )
    pdfTable5.addCell(
      addCellFormContent( phone, MessagesFormRetriever.getMessage( "form", "employeer_data", "phone" ) )
    )

    val pdfTable6: PdfPTable = new PdfPTable( 1 )
    pdfTable6.setWidthPercentage( 95 )
    pdfTable6.addCell(
      addCellFormContent( mail, MessagesFormRetriever.getMessage( "form", "employeer_data", "mail" ) )
    )

    ( pdfTable, pdfTable1, pdfTable2, pdfTable3, pdfTable4, pdfTable5, pdfTable6 )

  }

  def createSubscriptionAccount() = {
    val pdfTable: PdfPTable = new PdfPTable( 2 )
    pdfTable.setWidthPercentage( 95 )
    pdfTable.addCell(
      addCellFormContent( "\n\n", "" )
    )
    pdfTable.addCell(
      addCellFormContent( "\n\n", "" )
    )

    val pdfTable_1: PdfPTable = new PdfPTable( 1 )
    pdfTable_1.setWidthPercentage( 95 )
    val cell = addCellFormContent( "\n", MessagesFormRetriever.getMessage( "form", "electronic_transfer_account", "person_type" ) )
    cell.setPaddingRight( 280f )
    pdfTable_1.addCell( cell )
    ( pdfTable, pdfTable_1 )

  }

  def createEmployeerDatabankAccount( nombre: String, identificacion: String, ciudad: String, departamento: String, tel: String, direccion: String, mail: String ) = {
    val pdfTable: PdfPTable = new PdfPTable( 2 )
    pdfTable.setWidthPercentage( 95 )
    pdfTable.addCell(
      addCellFormContent( nombre, MessagesFormRetriever.getMessage( "form", "electronic_transfer_account", "name" ) )
    )
    pdfTable.addCell(
      addCellFormContent( identificacion, MessagesFormRetriever.getMessage( "form", "electronic_transfer_account", "doc_type" ) )
    )
    val pdfTable1: PdfPTable = new PdfPTable( 4 )
    pdfTable1.setWidths( Array( 5, 5, 2, 2 ) )
    pdfTable1.setWidthPercentage( 95 )
    pdfTable1.addCell(
      addCellFormContent( ciudad, MessagesFormRetriever.getMessage( "form", "electronic_transfer_account", "mail_city" ) )
    )
    pdfTable1.addCell(
      addCellFormContent( departamento, MessagesFormRetriever.getMessage( "form", "electronic_transfer_account", "mail_province" ) )
    )
    pdfTable1.addCell(
      addCellFormContent( tel, MessagesFormRetriever.getMessage( "form", "electronic_transfer_account", "phone" ) )
    )
    pdfTable1.addCell(
      addCellFormContent( "\n", MessagesFormRetriever.getMessage( "form", "electronic_transfer_account", "fax" ) )
    )
    val pdfTable2: PdfPTable = new PdfPTable( 1 )
    pdfTable2.setWidthPercentage( 95 )
    pdfTable2.addCell(
      addCellFormContent( direccion, MessagesFormRetriever.getMessage( "form", "electronic_transfer_account", "address" ) )
    )

    val pdfTable3: PdfPTable = new PdfPTable( 1 )
    pdfTable3.setWidthPercentage( 95 )
    pdfTable3.addCell(
      addCellFormContent( mail, MessagesFormRetriever.getMessage( "form", "electronic_transfer_account", "email" ) )
    )

    val pdfTable4: PdfPTable = new PdfPTable( 4 )
    pdfTable4.setWidths( Array( 4, 2, 5, 2 ) )
    pdfTable4.setWidthPercentage( 95 )
    pdfTable4.addCell(
      addCellFormContent( "\n", MessagesFormRetriever.getMessage( "form", "electronic_transfer_account", "number_account" ) )
    )
    pdfTable4.addCell(
      addCellFormContent( "\n", MessagesFormRetriever.getMessage( "form", "electronic_transfer_account", "account_type" ) )
    )
    pdfTable4.addCell(
      addCellFormContent( "\n", MessagesFormRetriever.getMessage( "form", "electronic_transfer_account", "bank_entity" ) )
    )
    pdfTable4.addCell(
      addCellFormContent( "\n", MessagesFormRetriever.getMessage( "form", "electronic_transfer_account", "branch" ) )
    )

    ( pdfTable, pdfTable1, pdfTable2, pdfTable3, pdfTable4 )

  }

  def createTypeAffiliation( fromAnotherArl: String, otherArl: String, dateAnotherArl: String ): PdfPTable = {
    val pdfTable: PdfPTable = new PdfPTable( 3 )
    pdfTable.setWidthPercentage( 95 )
    pdfTable.setWidths( Array( 6, 8, 11 ) )
    pdfTable.addCell(
      addCellFormContent( fromAnotherArl, MessagesFormRetriever.getMessage( "form", "affiliation_type", "from_another_arl" ) )
    )
    pdfTable.addCell(
      addCellFormContent( otherArl, MessagesFormRetriever.getMessage( "form", "affiliation_type", "previous_arl" ) )
    )
    pdfTable.addCell(
      addCellFormContent( dateAnotherArl, MessagesFormRetriever.getMessage( "form", "affiliation_type", "date_letter_affiliation" ) )
    )
    pdfTable
  }

  def createWorkCenterTable( listWorkCenters: immutable.List[ ( String, String, String, String, String, String, String, String ) ] ) = {
    val headerValues = Array(
      MessagesFormRetriever.getMessage( "form", "work_centers", "header.name" ),
      MessagesFormRetriever.getMessage( "form", "work_centers", "header.direccion" ),
      MessagesFormRetriever.getMessage( "form", "work_centers", "header.ciudad" ),
      MessagesFormRetriever.getMessage( "form", "work_centers", "header.telefono" ),
      MessagesFormRetriever.getMessage( "form", "work_centers", "header.work_center" ),
      MessagesFormRetriever.getMessage( "form", "work_centers", "header.wc_activity" ),
      MessagesFormRetriever.getMessage( "form", "work_centers", "header.class" ),
      MessagesFormRetriever.getMessage( "form", "work_centers", "header.porcentage" )
    )
    val headerTable: PdfPTable = createHeaderTableInformation( 8, headerValues )
    val pdfTable: PdfPTable = new PdfPTable( 1 )
    headerTable.setWidths( Array( 1, 1, 1, 1, 1, 1, 1, 1 ) )
    pdfTable.setWidthPercentage( 95 )
    val lineSeparator: LineSeparator = new LineSeparator()
    lineSeparator.setLineWidth( 0.1f )
    lineSeparator.setOffset( -1.5f )
    lineSeparator.setLineColor( BaseColor.CYAN )

    val cell: PdfPCell = new PdfPCell
    cell.addElement( lineSeparator )
    cell.setBorder( Rectangle.NO_BORDER )
    pdfTable.addCell( cell )

    val dataTableWorkCenters: PdfPTable = new PdfPTable( 8 )
    dataTableWorkCenters.setWidthPercentage( 95 )
    dataTableWorkCenters.setWidths( Array( 1, 1, 1, 1, 1, 1, 1, 1 ) )
    for ( workCenter <- listWorkCenters ) {
      addValueToDataTable( workCenter._1, dataTableWorkCenters )
      addValueToDataTable( workCenter._2, dataTableWorkCenters )
      addValueToDataTable( workCenter._3, dataTableWorkCenters )
      addValueToDataTable( workCenter._4, dataTableWorkCenters )
      addValueToDataTable( workCenter._5, dataTableWorkCenters )
      addValueToDataTable( workCenter._6, dataTableWorkCenters )
      addValueToDataTable( workCenter._7, dataTableWorkCenters )
      addValueToDataTable( workCenter._8, dataTableWorkCenters )
    }

    ( headerTable, pdfTable, dataTableWorkCenters )

  }

  def createWorkersTable( listWorkers: immutable.List[ ( String, String, String, String, String ) ] ) = {
    val headerValues = Array(
      MessagesFormRetriever.getMessage( "form", "workers", "header.document" ),
      MessagesFormRetriever.getMessage( "form", "workers", "header.name" ),
      MessagesFormRetriever.getMessage( "form", "workers", "header.work_center" ),
      MessagesFormRetriever.getMessage( "form", "workers", "header.city" ),
      MessagesFormRetriever.getMessage( "form", "workers", "header.porcentage" )
    )
    val headerTable: PdfPTable = createHeaderTableInformation( 5, headerValues )
    val pdfTable: PdfPTable = new PdfPTable( 1 )
    headerTable.setWidths( Array( 1, 2, 2, 1, 1 ) )
    pdfTable.setWidthPercentage( 95 )
    val lineSeparator: LineSeparator = new LineSeparator()
    lineSeparator.setLineWidth( 0.1f )
    lineSeparator.setOffset( -1.5f )
    lineSeparator.setLineColor( BaseColor.CYAN )

    val cell: PdfPCell = new PdfPCell
    cell.addElement( lineSeparator )
    cell.setBorder( Rectangle.NO_BORDER )
    pdfTable.addCell( cell )

    val dataTableWorkCenters: PdfPTable = new PdfPTable( 5 )
    dataTableWorkCenters.setWidthPercentage( 95 )
    dataTableWorkCenters.setWidths( Array( 1, 2, 2, 1, 1 ) )
    for ( worker <- listWorkers ) {
      addValueToDataTable( worker._1, dataTableWorkCenters )
      addValueToDataTable( worker._2, dataTableWorkCenters )
      addValueToDataTable( worker._3, dataTableWorkCenters )
      addValueToDataTable( worker._4, dataTableWorkCenters )
      addValueToDataTable( worker._5, dataTableWorkCenters )
    }

    dataTableWorkCenters.setSpacingAfter( 80f )
    ( headerTable, pdfTable, dataTableWorkCenters )
  }

  def createFooterWorkCenters(): PdfPTable = {
    val tableFooter = new PdfPTable( 1 )
    tableFooter.setWidthPercentage( 95 )

    val cell = new PdfPCell()

    addElementFooterWorkCenter( "\n\n\n\n\n\n\n\n", cell, new Font( FontFamily.UNDEFINED, 5, Font.NORMAL, BaseColor.BLACK ) )
    addElementFooterWorkCenter( MessagesFormRetriever.getMessage( "form", "footerWorkCenter", "parrafoUno" ), cell, new Font( FontFamily.UNDEFINED, 5, Font.NORMAL, BaseColor.BLACK ) )
    addElementFooterWorkCenter( MessagesFormRetriever.getMessage( "form", "footerWorkCenter", "parrafoDos" ), cell, new Font( FontFamily.UNDEFINED, 5, Font.NORMAL, BaseColor.BLACK ) )
    addElementFooterWorkCenter( MessagesFormRetriever.getMessage( "form", "footerWorkCenter", "parrafoTres" ), cell, new Font( FontFamily.UNDEFINED, 5, Font.NORMAL, BaseColor.BLACK ) )
    addElementFooterWorkCenter( MessagesFormRetriever.getMessage( "form", "footerWorkCenter", "parrafoCuatro" ), cell, new Font( FontFamily.UNDEFINED, 5, Font.NORMAL, BaseColor.BLACK ) )

    tableFooter.addCell( cell )

    tableFooter

  }

  def createFooter(): PdfPTable = {
    val tableFooter = new PdfPTable( 1 )
    tableFooter.setWidthPercentage( 95 )

    val cell = new PdfPCell()

    addElementFooter( MessagesFormRetriever.getMessage( "form", "footer", "manager_responsability" ), cell, new Font( FontFamily.UNDEFINED, 8, Font.BOLD, BaseColor.BLACK ) )
    addElementFooter( MessagesFormRetriever.getMessage( "form", "footer", "description_text" ), cell, new Font( FontFamily.UNDEFINED, 8, Font.BOLD, BaseColor.GRAY ) )
    addElementFooter( MessagesFormRetriever.getMessage( "form", "footer", "website_info" ), cell, new Font( FontFamily.UNDEFINED, 8, Font.BOLD, BaseColor.BLACK ) )
    addElementFooter( MessagesFormRetriever.getMessage( "form", "footer", "warning" ), cell, new Font( FontFamily.UNDEFINED, 8, Font.NORMAL, BaseColor.BLACK ) )

    tableFooter.addCell( cell )

    tableFooter

  }

  def addElementFooter( content: String, cell: PdfPCell, font: Font ) = {
    val paragraph = new Paragraph( content )
    paragraph.setAlignment( Element.ALIGN_CENTER )
    cell.setBorder( Rectangle.NO_BORDER )
    paragraph.setFont( font )
    cell.addElement( paragraph )
  }

  def addElementFooterWorkCenter( content: String, cell: PdfPCell, font: Font ) = {
    val paragraph = new Paragraph( content )
    paragraph.setAlignment( Element.ALIGN_JUSTIFIED )
    cell.setBorder( Rectangle.NO_BORDER )
    paragraph.setFont( font )
    cell.addElement( paragraph )
  }

  def addValueToDataTable( content: String, table: PdfPTable ): Unit = {
    val cell: PdfPCell = new PdfPCell()
    cell.setBorder( Rectangle.NO_BORDER )
    val cellContent = new Paragraph( content )
    cellContent.setFont( fontContextualHelp )
    cell.addElement( cellContent )
    table.addCell( cell )
  }

  def createHeaderTableInformation( cols: Int, headerValues: Array[ String ] ): PdfPTable = {
    val tableHeaders: PdfPTable = new PdfPTable( cols )
    tableHeaders.setWidthPercentage( 95 )
    for ( i <- 0 to ( cols - 1 ) ) {
      val cell: PdfPCell = new PdfPCell()
      val cellContent: Paragraph = new Paragraph( headerValues( i ) )
      cellContent.setFont( fontHeaderText )
      cellContent.setAlignment( Element.ALIGN_LEFT )
      // cellContent.setAlignment( if ( i == 2 ) Element.ALIGN_CENTER else Element.ALIGN_LEFT )
      cell.addElement( cellContent )
      cell.setBorder( Rectangle.NO_BORDER )
      tableHeaders.addCell( cell )
    }
    tableHeaders
  }

  def addCellFormContent( content: String, title: String, customPerc: Float = 100, customAlignLine: Int = Element.ALIGN_BOTTOM, customAlignPara: Int = Element.ALIGN_UNDEFINED ): PdfPCell = {
    val cell: PdfPCell = new PdfPCell()
    val titleCell: Paragraph = getFieldTitle( title )
    titleCell.setAlignment( customAlignPara )
    val contentParagraph: Paragraph = new Paragraph( content )
    contentParagraph.setFont( fontFieldContent )
    contentParagraph.setAlignment( customAlignPara )
    val lineSeparator: LineSeparator = new LineSeparator()
    lineSeparator.setLineWidth( 1.3f )
    lineSeparator.setOffset( -1.5f )
    lineSeparator.setPercentage( customPerc )
    lineSeparator.setAlignment( customAlignLine )
    lineSeparator.setLineColor( BaseColor.GRAY )
    cell.setBorder( Rectangle.NO_BORDER )
    cell.addElement( titleCell )
    cell.addElement( contentParagraph )
    cell.addElement( lineSeparator )
    cell
  }
  def addCellExamFormContent( content: String, title: String, customPerc: Float = 100, customAlignLine: Int = Element.ALIGN_BOTTOM, customAlignPara: Int = Element.ALIGN_UNDEFINED ): PdfPCell = {
    val cell: PdfPCell = new PdfPCell()
    val titleCell: Paragraph = getFieldTitle( title )
    titleCell.setAlignment( customAlignPara )
    titleCell.setIndentationRight( 31 )
    val contentParagraph: Paragraph = new Paragraph( content )
    contentParagraph.setFont( fontFieldContent )
    contentParagraph.setAlignment( customAlignPara )
    contentParagraph.setIndentationRight( 86 )
    val lineSeparator: LineSeparator = new LineSeparator()
    lineSeparator.setLineWidth( 1.3f )
    lineSeparator.setOffset( -1.5f )
    lineSeparator.setPercentage( customPerc )
    lineSeparator.setAlignment( customAlignLine )
    lineSeparator.setLineColor( BaseColor.GRAY )
    cell.setBorder( Rectangle.NO_BORDER )
    cell.addElement( titleCell )
    cell.addElement( contentParagraph )
    cell.addElement( lineSeparator )
    cell
  }

  def getFieldTitle( title: String ): Paragraph = {
    val titleParagraph = new Paragraph( title )
    titleParagraph.setFont( fontFieldTitles )
    titleParagraph
  }

  def createFormSectionTittle( title: String ): PdfPTable = {
    val pdfTableTitle: PdfPTable = new PdfPTable( 1 )
    pdfTableTitle.setSpacingBefore( 8 )
    pdfTableTitle.setSpacingAfter( 5 )
    pdfTableTitle.setWidthPercentage( 95 )
    val lineSeparator: LineSeparator = new LineSeparator()
    lineSeparator.setLineColor( BaseColor.LIGHT_GRAY )
    lineSeparator.setLineWidth( 0.3f )
    lineSeparator.setOffset( -18 )
    val paragraph: Paragraph = new Paragraph()
    paragraph.add( lineSeparator )
    paragraph.setFont( fontTitle )
    paragraph.add( title )
    val pdfCell: PdfPCell = new PdfPCell( paragraph )
    pdfCell.setBorder( Rectangle.NO_BORDER )
    pdfTableTitle.addCell( pdfCell )
    pdfTableTitle

  }

}

object PDFFileGenerator {
  // TODO: when done, move to conf files
  val outputPath = MessagesFormRetriever.getMessage( "form", "paths", "output_path" )
  val outputFileName = MessagesFormRetriever.getMessage( "form", "file_name", "name" )
  val outputFileExtension = MessagesFormRetriever.getMessage( "form", "file_name", "extension" )
  val basePath = MessagesFormRetriever.getMessage( "form", "paths", "assets" )

  case class EmployerData(
    name:             String                                                                               = "",
    identification:   String                                                                               = "",
    commercialName:   String                                                                               = "",
    legalName:        String                                                                               = "",
    docIdRep:         String                                                                               = "",
    cotRate:          String                                                                               = "",
    mainActivity:     String                                                                               = "",
    legalCodeInForce: String                                                                               = "",
    mainAddress:      String                                                                               = "",
    city:             String                                                                               = "",
    province:         String                                                                               = "",
    phone:            String                                                                               = "",
    riskCode:         String                                                                               = "",
    fromAnotherArl:   String                                                                               = "",
    otherArl:         String                                                                               = "",
    dateAnotherArl:   String                                                                               = "",
    mail:             String                                                                               = "",
    listWorkCenters:  immutable.List[ ( String, String, String, String, String, String, String, String ) ],
    listWorkers:      immutable.List[ ( String, String, String, String, String ) ]
  )

  case class FooterData(
    docLegalId:  String = "",
    nit:         String = "",
    companyName: String = ""
  )
}
