package com.arlsura.afiliacion.proceso.pasos.resumen

import java.io.File

import com.arlsura.afiliacion.utils.messages.MessagesFormRetriever
import org.apache.commons.lang.exception.ExceptionUtils

/**
 * Created by John on 25/06/15.
 */
object PDFFileGeneratorLogHelper {

  val outputPath = MessagesFormRetriever.getMessage( "form", "paths", "output_path" )
  val outputFileName = MessagesFormRetriever.getMessage( "form", "file_name", "name" )
  val outputFileExtension = MessagesFormRetriever.getMessage( "form", "file_name", "extension" )
  val basePath = MessagesFormRetriever.getMessage( "form", "paths", "assets" )

  def logFileData: Unit = {
    logAllRequiredPaths()
    logOutputPath()
    logAssets()
  }

  private def logAllRequiredPaths(): Unit = {
    println( "------------------------------------------------------------------------------------------" )
    println( "PDF files parameters" )
    println( "------------------------------------------------------------------------------------------" )
    println( s"BasePath: $basePath" )
    println( s"OutputPath: $outputPath" )
    println( s"OutputFileName: $outputFileName" )
    println( s"OutputFileExtension: $outputFileExtension" )
    println( "------------------------------------------------------------------------------------------" )
  }

  private def logOutputPath(): Unit = {
    println( "------------------------------------------------------------------------------------------" )
    println( "OutputPath: " + outputPath )
    println( "------------------------------------------------------------------------------------------" )
    val outputDir = new File( outputPath )
    println( s"Exists? ${outputDir.exists}" )
    println( s"Can read? ${outputDir.canRead}" )
    println( s"Can write? ${outputDir.canWrite}" )
    println( "------------------------------------------------------------------------------------------" )
  }

  private def logAssets(): Unit = {
    println( "------------------------------------------------------------------------------------------" )
    println( "ASSETS:" + basePath )
    println( "------------------------------------------------------------------------------------------" )
    val assetsDir = new File( basePath )
    println( s"Exists? ${assetsDir.exists}" )
    println( s"Can read? ${assetsDir.canRead}" )
    println( s"Can write? ${assetsDir.canWrite}" )
    val files: Array[ File ] = assetsDir.listFiles()
    println( s"Files number: ${files.length}" )
    for ( file <- files ) {
      println( s"   - ${file.getName}" )
      println( s"         is it a file? ${file.isFile}" )
      println( s"         is it readable? ${file.canRead}" )
    }
    println( "------------------------------------------------------------------------------------------" )
  }

  def getFullErrorMessage( throwable: Throwable ): String = {
    val intro: String = "Ocurrio un error con la generacion del PDF. "
    val message: String = "Mensaje: " + ExceptionUtils.getMessage( throwable ) + ". "
    val cause: String = "Causa: " + ExceptionUtils.getCause( throwable ) + ". "
    val stackTrace: String = "Stacktrace: " + ExceptionUtils.getStackTrace( throwable )
    intro + message + cause + stackTrace
  }

}
