package com.arlsura.afiliacion.proceso.pasos.sucursales

import com.arlsura.afiliacion.persistence.daos.affiliation.wrappers.AffiliationBranchesDataWrapper
import com.google.inject.AbstractModule
import net.codingwell.scalaguice.ScalaModule

/**
 * Created by Jesús Martínez on 20/05/15.
 */
class BranchDataServiceModule extends AbstractModule with ScalaModule {
  override def configure(): Unit = {
    bind[ AffiliationBranchesDataWrapper ]
    bind[ BranchDataRepository ]
  }
}
