package com.arlsura.afiliacion.proceso.pasos.resumen

import scala.io.BufferedSource

/**
 * Created by John on 24/05/15.
 */
class PDFFileBytesReader {

  def readBytes( filepath: String ): Array[ Byte ] = {
    val time: Long = System.currentTimeMillis()
    val source: BufferedSource = scala.io.Source.fromFile( filepath )( scala.io.Codec.ISO8859 )
    val byteArray: Array[ Byte ] = source.map( _.toByte ).toArray
    source.close()
    byteArray
  }

}
