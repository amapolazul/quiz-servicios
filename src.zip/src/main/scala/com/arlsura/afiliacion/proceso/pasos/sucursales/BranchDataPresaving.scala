package com.arlsura.afiliacion.proceso.pasos.sucursales

import java.util.Date

import com.arlsura.afiliacion.bussiness.affiliation.{ BasicDataRepository, PreaffiliationManager }
import com.arlsura.afiliacion.persistence.daos.affiliation.wrappers.{ AffiliationBranchesDataWrapper, AffiliationBasicDataWrapper }
import com.arlsura.afiliacion.persistence.daos.wrappers.PreAffiliationWrapper
import com.arlsura.afiliacion.persistence.entities.PreAffiliation
import com.arlsura.afiliacion.persistence.entities.affiliation.basic_data.{ Address, AffiliationBasicData }
import com.arlsura.afiliacion.persistence.entities.affiliation.branch_data.AffiliationBranchesData
import com.arlsura.afiliacion.proceso.pasos.sucursales.BranchDataMarshaller.{ ContactName, PreSavingData }
import reactivemongo.core.commands.LastError
import scala.concurrent.Future
import scala.concurrent.ExecutionContext.Implicits.global
import scala.util.{ Failure, Success }

/**
 * Created by John on 29/04/15.
 */
class BranchDataPreSaving {

  private def defaultBranchCode = "1"
  private def defaultBranchName = "SEDE PRINCIPAL"

  val preaffiliationRepository: PreaffiliationManager = new PreaffiliationManager( new PreAffiliationWrapper )
  val affiliationBasicDataRepository: BasicDataRepository = new BasicDataRepository( new AffiliationBasicDataWrapper )
  val branchDataRepository: BranchDataRepository = new BranchDataRepository( new AffiliationBranchesDataWrapper )

  def save( data: PreSavingData ): Future[ Any ] = {
    val preaffiliationDataFuture: Future[ Option[ PreAffiliation ] ] = preaffiliationRepository.getPreAffiliationByDni( data.dni )
    val basicDataFuture: Future[ Option[ AffiliationBasicData ] ] = affiliationBasicDataRepository.getByDni( data.dni )

    val informationData: Future[ ( Option[ PreAffiliation ], Option[ AffiliationBasicData ] ) ] = for {
      preaffiliationDataOption <- preaffiliationDataFuture
      basicDataOption <- basicDataFuture
    } yield ( preaffiliationDataOption, basicDataOption )

    informationData flatMap {
      pair =>
        val preaffiliationDataOption = pair._1
        val basicDataOption = pair._2
        val defaultBranch: AffiliationBranchesData = buildDefaultBranch( data, preaffiliationDataOption, basicDataOption )
        branchDataRepository.findByDni( data.dni ) map {
          list =>
            if ( list.length == 0 ) {
              saveDefaultBranch( defaultBranch )
            }
        }
    }
  }

  /*
  def save( data: PreSavingData ): Unit = {
      val preaffiliationDataFuture: Future[ Option[ PreAffiliation ] ] = preaffiliationRepository.getPreAffiliationByDni( data.dni )
      val basicDataFuture: Future[ Option[ AffiliationBasicData ] ] = affiliationBasicDataRepository.getByDni( data.dni )

      for {
        preaffiliationDataOption <- preaffiliationDataFuture
        basicDataOption <- basicDataFuture
      } yield {
        val defaultBranch: AffiliationBranchesData = buildDefaultBranch( data, preaffiliationDataOption, basicDataOption )
        branchDataRepository.findByDni( data.dni ) onComplete {
          case Success( list ) =>
            if ( list.length == 0 ) {
              saveDefaultBranch( defaultBranch )
            }
          case Failure( throwable ) =>
            println( s"Ocurrio un error al consultar las sucursales para poder crear una por defecto (${defaultBranch.branchID}}). DNI: ${defaultBranch.dni}" )
            throwable.printStackTrace()
        }
      }
    }
  */

  private def saveDefaultBranch( defaultBranch: AffiliationBranchesData ): Future[ LastError ] = {
    branchDataRepository.create( defaultBranch )
  }

  private def buildDefaultBranch( data: PreSavingData, preaffiliationDataOption: Option[ PreAffiliation ], basicDataOption: Option[ AffiliationBasicData ] ): AffiliationBranchesData = {
    ( preaffiliationDataOption, basicDataOption ) match {
      case ( Some( preaffiliationData ), Some( basicData ) ) =>
        buildAffiliationBranchesData( data, preaffiliationData.contactInfo.email, getPhone( preaffiliationData ), getAddress( basicData ) )
      case ( None, Some( basicData ) ) =>
        buildAffiliationBranchesData( data, "", None, getAddress( basicData ) )
      case ( Some( preaffiliationData ), None ) =>
        buildAffiliationBranchesData( data, preaffiliationData.contactInfo.email, getPhone( preaffiliationData ), buildUglyEmptyAddress )
      case _ =>
        buildAffiliationBranchesData( data, "", None, buildUglyEmptyAddress )
    }
  }

  private def buildContactName( contactName: ContactName ): String = {
    val nameBuilder = new StringBuilder( contactName.name1 )
    contactName.name2 match {
      case Some( name2 ) => nameBuilder.append( " " + name2 )
      case _             => // No needed
    }
    nameBuilder.append( " " + contactName.lastName1 )
    contactName.lastName2 match {
      case Some( lastName2 ) => nameBuilder.append( " " + lastName2 )
      case _                 => // No needed
    }
    nameBuilder.toString()
  }

  private def getPhone( preaffiliationData: PreAffiliation ): Option[ String ] = {
    preaffiliationData.contactInfo.phone match {
      case Some( phoneNumber ) => preaffiliationData.contactInfo.phone
      case None                => preaffiliationData.cellphone
    }
  }

  private def getAddress( basicData: AffiliationBasicData ): Address = {
    basicData.mainAddress match {
      case Some( mainAddress ) => mainAddress
      case None                => buildUglyEmptyAddress
    }
  }

  private def generateBranchID: String = new Date().getTime().toString()

  private def buildAffiliationBranchesData( data: PreSavingData, email: String, phone: Option[ String ], address: Address ): AffiliationBranchesData = {
    AffiliationBranchesData(
      branchID = generateBranchID,
      dni = data.dni,
      branchCode = defaultBranchCode,
      branchName = defaultBranchName,
      branchAddressData = address,
      email = email,
      phone = phone,
      contact = Some( buildContactName( data.contact ) )
    )
  }

  private def buildUglyEmptyAddress: Address = {
    Address(
      provinceCode = "",
      municipalityCode = "",
      delegationCode = "",
      province = "",
      city = "",
      nomenclaturaVial = "",
      number1 = "0",
      letter1 = None,
      orientation1 = None,
      number2 = None,
      letter2 = None,
      number3 = None,
      orientation2 = None,
      details = None
    )
  }

}