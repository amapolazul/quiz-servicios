package com.arlsura.afiliacion.proceso.pasos.resumen

import com.arlsura.afiliacion.bussiness.HandlerSupport._
import com.arlsura.afiliacion.bussiness.affiliation.{ PreaffiliationManager, BasicDataRepository }
import com.arlsura.afiliacion.bussiness.affiliation.contacts.ContactDataRepository
import com.arlsura.afiliacion.bussiness.affiliation.employees.EmployeeDataRepository
import com.arlsura.afiliacion.bussiness.affiliation.workcenters.WorkCentersDataRepository
import com.arlsura.afiliacion.proceso.pasos.sucursales.BranchDataRepository
import com.google.inject.Inject

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

/**
 * Created by John on 24/05/15.
 */
class PDFFileGeneratorServiceHandler @Inject() (
    pdfFileGenerator:         PDFFileGenerator,
    pdfFileBytesReader:       PDFFileBytesReader,
    terminator:               PDFFileTerminator,
    basicDataRepository:      BasicDataRepository,
    contactServiceRepository: ContactDataRepository,
    branchOfficeRepository:   BranchDataRepository,
    workCenterRepository:     WorkCentersDataRepository,
    employeesRepository:      EmployeeDataRepository,
    preAffiliationRepository: PreaffiliationManager

) {

  def createPDF( dni: String ): Future[ ServiceFileHandlerResponse ] = {
    PDFFileGeneratorLogHelper.logFileData
    val dataManager: FormInformationManager = new FormInformationManager( basicDataRepository, contactServiceRepository, branchOfficeRepository, workCenterRepository, employeesRepository, preAffiliationRepository )
    dataManager.generateAffiliationForm( dni ) map {
      formInfo =>
        {
          println( "Se generará el PDF a partir de los datos consultados en la base de datos" )
          //                    println( "DNI: " + dni )
          val file: String = pdfFileGenerator.generatePDF( formInfo._1, formInfo._2, dni )
          val bytes: Array[ Byte ] = pdfFileBytesReader.readBytes( file )
          //          println( "bytes: " + bytes )
          Right( bytes )
        }
    } recover {
      case t: Throwable =>
        //        println( "Ocurrio un error en la generacion/creacion del PDF: " + t.getMessage )
        //        t.printStackTrace()
        Left( PDFFileGeneratorLogHelper.getFullErrorMessage( t ) )
    }
  }
}
