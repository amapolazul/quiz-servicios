package com.arlsura.afiliacion.proceso.pasos.sucursales

import com.arlsura.afiliacion.bussiness.HandlerSupport.ServiceHandlerResponse
import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.GeneralJsonResponseData
import com.arlsura.afiliacion.persistence.entities.affiliation.branch_data.AffiliationBranchesData
import com.arlsura.afiliacion.proceso.pasos.sucursales.BranchDataMarshaller._
import com.arlsura.afiliacion.security.TokenManager
import com.google.inject.Inject
import reactivemongo.bson.BSONObjectID
import scala.concurrent.{ ExecutionContext, Future }
import scala.concurrent.ExecutionContext.Implicits.global

/**
 * Created by John on 28/04/15.
 */
class BranchDataServiceHandler @Inject() ( private val repository: BranchDataRepository ) {

  def getBranchesData( dni: String )( implicit ec: ExecutionContext ): Future[ ServiceHandlerResponse ] = {
    repository.findByDni( dni ) map {
      list =>
        val branches: List[ BranchData ] = list map {
          branch: AffiliationBranchesData => mapGetRequest( branch )
        }
        Right( GeneralJsonResponseData( "Las sucursales fueron cargadas correctamente", Some( Branches( branches ) ), suraSessionManager = TokenManager.buildSessionToken( dni ) ) )
    } recover {
      case throwable: Throwable =>
        //        throwable.printStackTrace()
        Left( s"Ocurrio un error en la consulta de las sucursales del dni $dni. Error: ${throwable.getMessage}" )
    }
  }

  def saveBranchData( dni: String, data: BranchData ): Future[ ServiceHandlerResponse ] = {
    repository.get( dni, data.branchID ) flatMap {
      result =>
        val branch: AffiliationBranchesData = mapSaveRequest( dni, data )
        result match {
          case Some( b ) =>
            val branch: AffiliationBranchesData = mapUpdateRequest( dni, data, b._id )
            update( branch )
          case None =>
            val branch: AffiliationBranchesData = mapSaveRequest( dni, data )
            create( branch )
        }
    } recover {
      case throwable: Throwable =>
        manageCreationFailure( throwable, dni, data.branchID )
    }
  }

  private def create( branch: AffiliationBranchesData ): Future[ ServiceHandlerResponse ] = {
    repository.create( branch ) map {
      _ => manageCreationSuccess( branch.dni, branch.branchID )
    } recover {
      case throwable: Throwable => manageCreationFailure( throwable, branch.dni, branch.branchID )
    }
  }

  private def update( branch: AffiliationBranchesData ): Future[ ServiceHandlerResponse ] = {
    repository.update( branch.dni, branch.branchID, branch ) map {
      _ => manageCreationSuccess( branch.dni, branch.branchID )
    } recover {
      case throwable: Throwable => manageCreationFailure( throwable, branch.dni, branch.branchID )
    }
  }

  private def manageCreationFailure( throwable: Throwable, dni: String, branchID: String ): ServiceHandlerResponse = {
    //    throwable.printStackTrace()
    Left( s"Ocurrio un error al guardar la sucursal ${branchID} (dni $dni). Error: ${throwable.getMessage}" )
  }

  private def manageCreationSuccess( dni: String, branchID: String ): ServiceHandlerResponse = {
    Right( GeneralJsonResponseData( s"La sucursal $branchID fue guardada correctamente. (dni $dni)", suraSessionManager = TokenManager.buildSessionToken( dni ) ) )
  }

  private def mapSaveRequest( dni: String, branch: BranchData ): AffiliationBranchesData = {
    AffiliationBranchesData(
      branchID = branch.branchID,
      dni = dni,
      branchCode = branch.branchCode,
      branchName = branch.branchName,
      branchAddressData = branch.branchAddressData,
      email = branch.email,
      phone = branch.phone,
      contact = branch.contact
    )
  }

  private def mapUpdateRequest( dni: String, branch: BranchData, objectID: BSONObjectID ): AffiliationBranchesData = {
    AffiliationBranchesData(
      _id = objectID,
      branchID = branch.branchID,
      dni = dni,
      branchCode = branch.branchCode,
      branchName = branch.branchName,
      branchAddressData = branch.branchAddressData,
      email = branch.email,
      phone = branch.phone,
      contact = branch.contact
    )
  }

  private def mapGetRequest( branch: AffiliationBranchesData ): BranchData = {
    BranchData(
      branchID = branch.branchID,
      branchCode = branch.branchCode,
      branchName = branch.branchName,
      branchAddressData = branch.branchAddressData,
      email = branch.email,
      phone = branch.phone,
      contact = branch.contact
    )
  }

}
