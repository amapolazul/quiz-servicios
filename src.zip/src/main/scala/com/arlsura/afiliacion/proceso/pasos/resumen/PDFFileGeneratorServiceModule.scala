package com.arlsura.afiliacion.proceso.pasos.resumen

import com.arlsura.afiliacion.bussiness.affiliation.{ PreaffiliationManager, BasicDataRepository }
import com.arlsura.afiliacion.bussiness.affiliation.contacts.ContactDataRepository
import com.arlsura.afiliacion.bussiness.affiliation.employees.EmployeeDataRepository
import com.arlsura.afiliacion.bussiness.affiliation.workcenters.WorkCentersDataRepository
import com.arlsura.afiliacion.proceso.pasos.sucursales.BranchDataRepository
import com.google.inject.AbstractModule
import net.codingwell.scalaguice.ScalaModule

/**
 * Created by John on 24/05/15.
 */
class PDFFileGeneratorServiceModule extends AbstractModule with ScalaModule {

  override def configure(): Unit = {
    bind[ PDFFileGenerator ]
    bind[ PDFFileBytesReader ]
    bind[ PDFFileTerminator ]
    bind[ BasicDataRepository ]
    bind[ ContactDataRepository ]
    bind[ BranchDataRepository ]
    bind[ WorkCentersDataRepository ]
    bind[ EmployeeDataRepository ]
    bind[ PreaffiliationManager ]
  }

}
