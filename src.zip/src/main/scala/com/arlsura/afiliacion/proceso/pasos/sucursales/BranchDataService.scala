package com.arlsura.afiliacion.proceso.pasos.sucursales

import com.arlsura.afiliacion.authentication.CookieSessionAuthentication
import com.arlsura.afiliacion.bussiness.RequestContextSupport
import com.arlsura.afiliacion.proceso.pasos.sucursales.BranchDataMarshaller.BranchData
import com.arlsura.afiliacion.security.TokenManager
import com.arlsura.afiliacion.utils.resources.ResourcesNameRetriever
import com.google.inject.Guice
import spray.http.HttpCookie
import spray.routing.{ HttpService, RequestContext }
import BranchDataService._
import scala.concurrent.ExecutionContext
import net.codingwell.scalaguice.InjectorExtensions._

/**
 * Created by John on 28/04/15.
 */
trait BranchDataService extends HttpService with CookieSessionAuthentication with RequestContextSupport {
  private[ BranchDataService ] implicit val _: ExecutionContext = actorRefFactory.dispatcher
  private[ BranchDataService ] lazy val injector = Guice.createInjector( new BranchDataServiceModule() )

  val getBranchesRoute = {
    pathPrefix( affiliationsMainRoute / Segment ) {
      dni =>
        pathPrefix( dataRoute ) {
          pathPrefix( branchRoute ) {
            pathEndOrSingleSlash {
              get {
                authenticate( authenticateSession ) {
                  user =>
                    setCookie( HttpCookie( TokenManager.tokenName, content = TokenManager.buildSessionToken( ( user.dni ) ).get ) ) {
                      ( requestContext: RequestContext ) =>
                        lazy val handler = injector.instance[ BranchDataServiceHandler ]
                        completeRequest( handler.getBranchesData( dni ), requestContext )
                    }
                }
              }
            }
          }
        }
    }
  }

  val saveBranchRoute = {
    pathPrefix( affiliationsMainRoute / Segment ) {
      dni =>
        pathPrefix( dataRoute ) {
          pathPrefix( branchRoute / Segment ) {
            branchId =>
              pathEndOrSingleSlash {
                post {
                  entity( as[ BranchData ] ) {
                    data =>
                      authenticate( authenticateSession ) {
                        user =>
                          setCookie( HttpCookie( TokenManager.tokenName, content = TokenManager.buildSessionToken( ( user.dni ) ).get ) ) {
                            ( requestContext: RequestContext ) =>
                              lazy val handler = injector.instance[ BranchDataServiceHandler ]
                              completeRequest( handler.saveBranchData( dni, data ), requestContext )
                          }
                      }
                  }
                }
              }
          }
        }
    }
  }

  val branchDataRoutes = getBranchesRoute ~ saveBranchRoute

}

object BranchDataService {

  val affiliationsMainRoute = ResourcesNameRetriever.getResource( "affiliations", "MAIN_RESOURCE" )
  val dataRoute = ResourcesNameRetriever.getResource( "affiliations", "DATA" )
  val branchRoute = ResourcesNameRetriever.getResource( "affiliations", "BRANCH_DATA" )

}
