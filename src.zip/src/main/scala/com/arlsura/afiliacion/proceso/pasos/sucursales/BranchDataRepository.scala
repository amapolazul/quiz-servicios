package com.arlsura.afiliacion.proceso.pasos.sucursales

import com.arlsura.afiliacion.persistence.daos.affiliation.wrappers.AffiliationBranchesDataWrapper
import com.arlsura.afiliacion.persistence.entities.affiliation.basic_data.Address
import com.arlsura.afiliacion.persistence.entities.affiliation.branch_data.AffiliationBranchesData
import com.arlsura.afiliacion.utils.CipherFacility
import com.google.inject.Inject
import reactivemongo.bson.{ BSONString, BSONDocument }
import reactivemongo.core.commands.LastError
import scala.concurrent.{ ExecutionContext, Future }

/**
 * Created by John on 28/04/15.
 */
class BranchDataRepository @Inject() ( private val dao: AffiliationBranchesDataWrapper ) extends CipherFacility {

  private def encryptDocument( d: AffiliationBranchesData ): AffiliationBranchesData = {
    AffiliationBranchesData(
      _id = d._id,
      branchID = d.branchID,
      securityCode = d.securityCode,
      dni = encode( d.dni ),
      branchAddressData = Address.encrypt( d.branchAddressData ),
      email = encode( d.email ),
      branchCode = d.branchCode,
      branchName = d.branchName,
      phone = d.phone.map( encode ),
      contact = d.contact.map( encode )
    )
  }

  private def decryptDocument( d: AffiliationBranchesData ): AffiliationBranchesData = {
    AffiliationBranchesData(
      _id = d._id,
      branchID = d.branchID,
      securityCode = d.securityCode,
      dni = decode( d.dni ),
      branchAddressData = Address.decrypt( d.branchAddressData ),
      email = decode( d.email ),
      branchCode = d.branchCode,
      branchName = d.branchName,
      phone = d.phone.map( decode ),
      contact = d.contact.map( decode )
    )
  }

  def findByDni( dni: String )( implicit ec: ExecutionContext ): Future[ List[ AffiliationBranchesData ] ] =
    dao.findAll( BSONDocument( "dni" -> encode( dni ) ) ) map ( _.map( decryptDocument ) )

  def get( dni: String, branchID: String )( implicit ec: ExecutionContext ): Future[ Option[ AffiliationBranchesData ] ] =
    dao.findOne( BSONDocument( "dni" -> encode( dni ), "branchID" -> BSONString( branchID ) ) ) map ( _.map( decryptDocument ) )

  def update( dni: String, branchID: String, data: AffiliationBranchesData )( implicit ec: ExecutionContext ): Future[ LastError ] =
    dao.update( BSONDocument( "dni" -> encode( dni ), "branchID" -> BSONString( branchID ) ), encryptDocument( data ) )

  def create( data: AffiliationBranchesData )( implicit ec: ExecutionContext ): Future[ LastError ] = dao.insert( encryptDocument( data ) )

}
