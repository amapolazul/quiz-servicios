package com.arlsura.afiliacion.proceso.pasos.resumen

import com.arlsura.afiliacion.authentication.CookieSessionAuthentication
import com.arlsura.afiliacion.bussiness.HandlerSupport._
import com.arlsura.afiliacion.bussiness.RequestContextSupport
import com.arlsura.afiliacion.proceso.pasos.sucursales.BranchDataServiceHandler
import com.arlsura.afiliacion.security.TokenManager
import com.arlsura.afiliacion.utils.resources.ResourcesNameRetriever
import com.google.inject.Guice
import spray.http.HttpCookie
import spray.routing.{ RequestContext, HttpService }

import PDFFileGeneratorService._
import net.codingwell.scalaguice.InjectorExtensions._

import scala.concurrent.{ Future, ExecutionContext }

/**
 * Created by John on 24/05/15.
 */
trait PDFFileGeneratorService extends HttpService with CookieSessionAuthentication with RequestContextSupport {

  private lazy val injector = Guice.createInjector( new PDFFileGeneratorServiceModule() )

  private implicit val executionContext: ExecutionContext = actorRefFactory.dispatcher

  val getPDFBytesRoute = {
    pathPrefix( affiliationsMainRoute / Segment ) {
      dni =>
        pathPrefix( dataRoute ) {
          pathPrefix( summaryRoute ) {
            pathEndOrSingleSlash {
              get {
                authenticate( authenticateBothCookies() ) {
                  user =>
                    setCookie( HttpCookie( TokenManager.tokenName, content = TokenManager.buildSessionToken( ( user.dni ) ).get ) ) {
                      ( requestContext: RequestContext ) =>
                        if ( user.dni == dni ) {
                          lazy val handler: PDFFileGeneratorServiceHandler = injector.instance[ PDFFileGeneratorServiceHandler ]
                          val pdfFuture: Future[ ServiceFileHandlerResponse ] = handler.createPDF( dni )
                          completeRequestWithFileResult( pdfFuture, requestContext )
                        }
                        else {
                          completeWithRejection( requestContext )
                        }
                    }
                }
              }
            }
          }
        }
    }
  }

  val pdfRoutes = getPDFBytesRoute

}

object PDFFileGeneratorService {

  val affiliationsMainRoute = ResourcesNameRetriever.getResource( "affiliations", "MAIN_RESOURCE" )
  val dataRoute = ResourcesNameRetriever.getResource( "affiliations", "DATA" )
  val summaryRoute = ResourcesNameRetriever.getResource( "affiliations", "SUMMARY" )

}