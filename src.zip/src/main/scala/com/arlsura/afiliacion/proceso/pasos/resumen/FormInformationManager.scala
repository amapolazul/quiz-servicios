package com.arlsura.afiliacion.proceso.pasos.resumen

import com.arlsura.afiliacion.bussiness.affiliation.{ PreaffiliationManager, BasicDataRepository }
import com.arlsura.afiliacion.bussiness.affiliation.contacts.ContactDataRepository
import com.arlsura.afiliacion.bussiness.affiliation.employees.EmployeeDataRepository
import com.arlsura.afiliacion.bussiness.affiliation.workcenters.WorkCentersDataRepository
import com.arlsura.afiliacion.persistence.entities.PreAffiliation
import com.arlsura.afiliacion.persistence.entities.affiliation.basic_data.{ Address, AffiliationBasicData }
import com.arlsura.afiliacion.persistence.entities.affiliation.branch_data.AffiliationBranchesData
import com.arlsura.afiliacion.persistence.entities.affiliation.contacts_data.AffiliationContactsData
import com.arlsura.afiliacion.persistence.entities.affiliation.employee_data.{ EmployeeInformation, AffiliationEmployeesData }
import com.arlsura.afiliacion.persistence.entities.affiliation.work_center_data.{ WorkCenterInformation, AffiliationWorkCentersData }
import com.arlsura.afiliacion.persistence.entities.preaffiliation.FullEconomicActivity
import com.arlsura.afiliacion.proceso.pasos.resumen.PDFFileGenerator.{ EmployerData, FooterData }
import com.arlsura.afiliacion.proceso.pasos.sucursales.BranchDataRepository
import com.google.inject.Inject
import org.joda.time.DateTime

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

/**
 * Created by juanmartinez on 12/05/15.
 */
class FormInformationManager(
    basicDataRepository:      BasicDataRepository,
    contactServiceRepository: ContactDataRepository,
    branchOfficeRepository:   BranchDataRepository,
    workCenterRepository:     WorkCentersDataRepository,
    employeesRepository:      EmployeeDataRepository,
    preAffiliationRepository: PreaffiliationManager
) {

  /**
   * Obtiene toda la información del afiliado
   * @param dni
   * @return
   */
  private def getAffiliateFormInformation( dni: String ): Future[ ( Option[ AffiliationBasicData ], Option[ AffiliationContactsData ], List[ AffiliationBranchesData ], Option[ AffiliationWorkCentersData ], Option[ AffiliationEmployeesData ], Option[ PreAffiliation ] ) ] = {
    val affiliateBasicDataFuture: Future[ Option[ AffiliationBasicData ] ] = basicDataRepository.getByDni( dni )
    val contactsServiceDataFuture: Future[ Option[ AffiliationContactsData ] ] = contactServiceRepository.findByDni( dni )
    val branchOfficeDataFuture: Future[ List[ AffiliationBranchesData ] ] = branchOfficeRepository.findByDni( dni )
    val workCenterDataFuture: Future[ Option[ AffiliationWorkCentersData ] ] = workCenterRepository.findByDni( dni )
    val workersDataFuture: Future[ Option[ AffiliationEmployeesData ] ] = employeesRepository.findByDni( dni )
    val preaffiliationFuture: Future[ Option[ PreAffiliation ] ] = preAffiliationRepository.getPreAffiliationByDni( dni )

    for {
      affiliateData <- affiliateBasicDataFuture
      contactsServiceData <- contactsServiceDataFuture
      branchOfficeData <- branchOfficeDataFuture
      workCenterData <- workCenterDataFuture
      workersData <- workersDataFuture
      preAffiliation <- preaffiliationFuture
    } yield (
      affiliateData,
      contactsServiceData,
      branchOfficeData,
      workCenterData,
      workersData,
      preAffiliation
    )
  }

  def generateAffiliationForm( dni: String ): Future[ ( EmployerData, FooterData ) ] = {
    val affiliateInformationForm: Future[ ( Option[ AffiliationBasicData ], Option[ AffiliationContactsData ], List[ AffiliationBranchesData ], Option[ AffiliationWorkCentersData ], Option[ AffiliationEmployeesData ], Option[ PreAffiliation ] ) ] = getAffiliateFormInformation( dni )

    affiliateInformationForm map {
      affiliateInfoData =>
        {
          val getEmployerData: EmployerData = buildEmployerInformation( affiliateInfoData._1, affiliateInfoData._2, affiliateInfoData._4, affiliateInfoData._5, affiliateInfoData._6 )
          val buildFooterData: FooterData = buildFooter( affiliateInfoData._1, affiliateInfoData._2 )
          ( getEmployerData, buildFooterData )
        }
    }
  }

  private def buildEmployerInformation(
    basicData:       Option[ AffiliationBasicData ],
    contactsData:    Option[ AffiliationContactsData ],
    workCentersData: Option[ AffiliationWorkCentersData ],
    employeesData:   Option[ AffiliationEmployeesData ],
    preAffiliation:  Option[ PreAffiliation ]
  ): EmployerData = {

    ( basicData, contactsData, workCentersData, employeesData, preAffiliation ) match {
      case ( Some( data ), Some( contacts ), Some( workCenters ), Some( employees ), Some( preAff ) ) =>

        //nombre regular de la afiliacion
        val name1: String = data.contactInformation.name1
        val name2: Option[ String ] = data.contactInformation.name2
        val lastName1: String = data.contactInformation.lastname1
        val lastName2: Option[ String ] = data.contactInformation.lastname2

        //nombre representante legal
        val name1Legal: String = contacts.legalRepresentative.name1
        val name2Legal: Option[ String ] = contacts.legalRepresentative.name2
        val lastName1Legal: String = contacts.legalRepresentative.lastname1
        val lastName2Legal: Option[ String ] = contacts.legalRepresentative.lastname2

        EmployerData(
          name = data.contactInformation.name.getOrElse( buildFullName( name1, name2, lastName1, lastName2 ) ),
          identification = buildIdentificationType( data.contactInformation.identificationType, data.contactInformation.identification ),
          commercialName = data.commercialName.getOrElse( buildFullName( name1, name2, lastName1, lastName2 ) ),
          legalName = buildFullName( name1Legal, name2Legal, lastName1Legal, lastName2Legal ),
          docIdRep = buildIdentificationType( contacts.legalRepresentative.identificationType, contacts.legalRepresentative.identification ),
          cotRate = data.fullEconomicActivity.rate.get,
          mainActivity = data.fullEconomicActivity.description.get,
          legalCodeInForce = data.commercialActivity,
          mainAddress = buildMainAddress( data.mainAddress ),
          city = data.mainAddress map ( _.city ) getOrElse ( " " ),
          province = data.mainAddress map ( _.province ) getOrElse ( " " ),
          phone = preAff.cellphone.getOrElse( preAff.contactInfo.phone.getOrElse( " " ) ),
          fromAnotherArl = if ( preAff.prevarp.equals( "N000000002" ) ) "No" else "Si",
          otherArl = if ( preAff.prevarp.equals( "N000000002" ) ) " " else preAff.prevarp,
          dateAnotherArl = data.letterDeliveryDate.getOrElse( " " ).toString(),
          listWorkCenters = createWorkCenterList( workCenters ),
          listWorkers = createEmployeesList( employees, workCenters )
        )
      case ( _, _, _, _, _ ) =>
        EmployerData(
          listWorkCenters = List(),
          listWorkers = List()
        )
    }
  }

  private def buildFooter( basicData: Option[ AffiliationBasicData ], contactsData: Option[ AffiliationContactsData ] ): FooterData = {
    ( contactsData, basicData ) match {
      case ( Some( contacts ), Some( basic ) ) =>
        //nombre representante legal
        val name1Legal: String = contacts.legalRepresentative.name1
        val name2Legal: Option[ String ] = contacts.legalRepresentative.name2
        val lastName1Legal: String = contacts.legalRepresentative.lastname1
        val lastName2Legal: Option[ String ] = contacts.legalRepresentative.lastname2
        FooterData(
          companyName = basic.commercialName.getOrElse( buildFullName( name1Legal, name2Legal, lastName1Legal, lastName2Legal ) ),
          docLegalId = contacts.legalRepresentative.identification,
          nit = basic.dni
        )
      case ( _, _ ) =>
        FooterData()
    }
  }

  private def buildFullName( name1: String, name2: Option[ String ], lastName1: String, lastName2: Option[ String ] ) = {
    s"$name1 ${name2.getOrElse( "" )} $lastName1 ${lastName2.getOrElse( "" )}"
  }

  private def buildIdentificationType( idType: String, id: String ): String = s"$idType - $id"

  private def buildMainAddress( mainAddress: Option[ Address ] ): String = {
    mainAddress match {
      case Some( address ) =>
        s"${address.nomenclaturaVial} ${address.number1} ${address.letter1.getOrElse( "" )}" +
          s"${address.orientation1.getOrElse( "" )} ${address.number2.getOrElse( "" )} ${address.letter2.getOrElse( "" )}" +
          s"${address.number3.getOrElse( "" )} ${address.orientation2.getOrElse( "" )} ${address.details.getOrElse( "" )}"
      case None =>
        ""
    }
  }

  private def createWorkCenterList( workCenters: AffiliationWorkCentersData ): List[ ( String, String, String, String, String, String, String, String ) ] = {
    val workCentersInfo: List[ WorkCenterInformation ] = workCenters.workCenters
    for ( workCenter <- workCentersInfo )
      yield (
      workCenter.workcenterName,
      buildMainAddress( Some( workCenter.workcenterAddressData ) ),
      workCenter.workcenterAddressData.city,
      workCenter.phone.getOrElse( " " ),
      workCenter.workcenterCode,
      workCenter.commercialActivity.economicActivityId,
      workCenter.commercialActivity.cdClass.getOrElse( " " ),
      workCenter.commercialActivity.rate.getOrElse( " " )
    )
  }

  private def createEmployeesList( employees: AffiliationEmployeesData, workCenters: AffiliationWorkCentersData ): List[ ( String, String, String, String, String ) ] = {
    val employeesList: Option[ List[ EmployeeInformation ] ] = employees.employees
    employeesList match {
      case Some( employees ) =>
        for ( employee <- employees )
          yield (
          employee.contactInfo.identification,
          employee.contactInfo.name.getOrElse( s"${employee.contactInfo.name1} ${employee.contactInfo.name2.getOrElse( "" )} ${employee.contactInfo.lastname1} ${employee.contactInfo.lastname2.getOrElse( "" )}" ),
          employee.workcenter,
          employee.employeeAddressData.city,
          getWorkcenterByName( workCenters, employee.workcenter ).map {
            x => x.commercialActivity.rate.getOrElse( " " )
          } getOrElse ( " " )
        )
      case None =>
        List()
    }
  }

  private def getWorkcenterByName( workCenters: AffiliationWorkCentersData, name: String ): Option[ WorkCenterInformation ] = {
    val wc = workCenters.workCenters.find( _.workcenterName.equalsIgnoreCase( name ) )
    wc
  }

}
