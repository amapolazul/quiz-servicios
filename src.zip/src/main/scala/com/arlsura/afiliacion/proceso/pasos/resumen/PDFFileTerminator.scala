package com.arlsura.afiliacion.proceso.pasos.resumen

import java.io.File

/**
 * Created by John on 24/05/15.
 */
class PDFFileTerminator {

  def exterminate( fullpath: String ): Unit = {
    try {
      val file = new File( fullpath )
      val fileWasDeleted = file.delete()
    }
    catch {
      case t: Throwable =>
      //        t.printStackTrace()
    }
  }

}
