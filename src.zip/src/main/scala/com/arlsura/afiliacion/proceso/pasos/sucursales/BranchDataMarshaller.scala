package com.arlsura.afiliacion.proceso.pasos.sucursales

import com.arlsura.afiliacion.persistence.entities.affiliation.basic_data.Address
import org.json4s.{ DefaultFormats, Formats }
import spray.httpx.Json4sSupport

/**
 * Created by John on 28/04/15.
 */
object BranchDataMarshaller extends Json4sSupport {

  override implicit def json4sFormats: Formats = DefaultFormats

  case class BranchData(
    branchID:          String,
    branchCode:        String,
    branchName:        String,
    branchAddressData: Address,
    email:             String,
    phone:             Option[ String ],
    contact:           Option[ String ]
  )

  case class Branches( branches: List[ BranchData ] )

  case class PreSavingData(
    dni:     String,
    contact: ContactName
  )

  case class ContactName(
    name1:     String,
    name2:     Option[ String ],
    lastName1: String,
    lastName2: Option[ String ]
  )

}
