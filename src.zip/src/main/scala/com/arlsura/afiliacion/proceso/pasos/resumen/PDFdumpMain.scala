package com.arlsura.afiliacion.proceso.pasos.resumen

import com.arlsura.afiliacion.proceso.pasos.resumen.PDFFileGenerator.{ FooterData, EmployerData }

/**
 * Created by davidortiz on 26/08/15.
 */
object PDFdumpMain {

  val workcenters: List[ ( String, String, String, String, String, String, String, String ) ] = {
    List( ( "PRINCIPAL BOLIVAR", "calle 6 #2b-28", "Bogota", "6966308", "1", "1522901", "1", "0.522%" ) )
  }

  val workers: List[ ( String, String, String, String, String ) ] = {
    List( ( "1072662899", "maria paula cortes guerra", "PRINCIPAL BOLIVAR", "BOGOTA", "0.522%" ) )
  }
  val footer: FooterData = FooterData(
    companyName = "seven4n",
    docLegalId = "davindsito",
    nit = "AB11"
  )

  val empleado: EmployerData = EmployerData(
    name = "seven s.a.s",
    identification = "NIT - 1072662899",
    commercialName = "seven s.a.s",
    legalName = "Daniel Ortiz Velasco",
    docIdRep = "CC - 1072662899",
    cotRate = "0.55%",
    mainActivity = "SOFTWARE ACTIVITY",
    legalCodeInForce = "N0001",
    mainAddress = "Calle 6 # 2b-28",
    city = "CHIA",
    province = "CUNDINAMARCA",
    phone = "6966308",
    riskCode = "0.5",
    fromAnotherArl = "No",
    otherArl = " ",
    dateAnotherArl = " ",
    mail = "davidortiz@gmail.com",
    listWorkCenters = workcenters,
    listWorkers = workers
  )

  val generador = new PDFFileGenerator()
  generador.generatePDF( empleado, footer, "AB11" )

}
