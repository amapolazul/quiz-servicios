package com.arlsura.afiliacion.proceso.pasos.resumen

import com.arlsura.afiliacion.bussiness.affiliation.BasicDataRepository
import com.arlsura.afiliacion.bussiness.affiliation.contacts.ContactDataRepository
import com.arlsura.afiliacion.bussiness.affiliation.employees.EmployeeDataRepository
import com.arlsura.afiliacion.bussiness.affiliation.workcenters.WorkCentersDataRepository
import com.arlsura.afiliacion.proceso.pasos.sucursales.BranchDataRepository
import com.google.inject.AbstractModule
import net.codingwell.scalaguice.ScalaModule

/**
 * Created by juanmartinez on 25/05/15.
 */
class FormInformationModule extends AbstractModule with ScalaModule {

  override def configure(): Unit = {
    bind[ BasicDataRepository ]
    bind[ ContactDataRepository ]
    bind[ BranchDataRepository ]
    bind[ WorkCentersDataRepository ]
    bind[ EmployeeDataRepository ]
  }

}
