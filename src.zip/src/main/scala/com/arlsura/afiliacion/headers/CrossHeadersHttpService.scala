package com.arlsura.afiliacion.headers

import com.arlsura.afiliacion.utils.Utils
import spray.http.{ SomeOrigins, HttpOrigin, AllOrigins }
import spray.http.HttpHeaders.{ `Access-Control-Allow-Origin`, `Access-Control-Expose-Headers`, `Access-Control-Allow-Headers`, `Access-Control-Allow-Methods` }
import spray.http.HttpMethods._
import spray.routing.HttpService

/**
 * Created by juanmartinez on 9/10/14.
 */
trait CrossHeadersHttpService extends HttpService {

  import CrossHeadersHttpService._

  def crossHeadersList: List[ spray.http.HttpHeader ] = {
    List(
      `Access-Control-Allow-Methods`( OPTIONS, GET, POST, PUT, DELETE ),
      `Access-Control-Allow-Headers`( "Accept", "Authorization", "Content-Type", "X-Requested-With", "Authentication", "Set-Cookie", "Session-Tag" ),
      `Access-Control-Expose-Headers`( "Accept", "WWW-Authenticate" ),
      `Access-Control-Allow-Origin`( SomeOrigins( List( getAllowedOrigin ) ) )
    )
  }
}

object CrossHeadersHttpService {
  def getAllowedOrigin: String = Utils.getProperty( "origin.", "allowed_origin" ).asInstanceOf[ String ]
}
