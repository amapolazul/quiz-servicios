package com.arlsura.afiliacion.headers

import com.arlsura.afiliacion.utils.Utils
import spray.http._
import spray.http.HttpHeaders._
import spray.http.HttpMethods._
import CORSHeaders._

/**
 * Created by juanmartinez on 9/10/14.
 */
trait CORSHeaders {

  def crossHeadersList: List[ spray.http.HttpHeader ] = {
    List(
      `Access-Control-Allow-Methods`( OPTIONS, GET, POST, PUT, DELETE ),
      `Access-Control-Allow-Headers`( "Accept", "Authorization", "Content-Type", "X-Requested-With", "Authentication", "Set-Cookie", "Session-Tag" ),
      `Access-Control-Expose-Headers`( "Accept", "WWW-Authenticate", "Set-Cookie, Session-Tag" ),
      //`Access-Control-Allow-Origin`( SomeOrigins( List(getAllowedOrigin ) ) )
      `Access-Control-Allow-Origin`( AllOrigins )
    )
  }

  def getChallengeHeaders: List[ spray.http.HttpHeader ] = {
    List( `WWW-Authenticate`( HttpChallenge( scheme = "Access_token", realm = "Sura - ARL" ) ) )
  }

}

object CORSHeaders {
  def getAllowedOrigin: String = Utils.getProperty( "origin.", "allowed_origin" ).asInstanceOf[ String ]
}
