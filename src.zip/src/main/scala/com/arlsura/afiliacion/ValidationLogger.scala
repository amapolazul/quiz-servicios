package com.arlsura.afiliacion

/**
 * Created by John on 21/07/15.
 */
trait ValidationLogger {

  def logValidationsBlock( title: String, input: Option[ Any ] = None ): Unit = {
    separtor
    println( s"{$title.toUpperCase} VALIDATION: $input" )
    separtor
  }

  def logValidationFailed( valid: Boolean, description: String ): Unit = {
    if ( !valid ) {
      println( s"VALIDATION FAILED: $description" )
    }
  }

  def logValidationResult( valid: Boolean ): Unit = {
    println( s"VALIDATION RESULT: $valid" )
    separtor
  }

  private def separtor = println( "--------------------------------------------------------------------------------" )

}
