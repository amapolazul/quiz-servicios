//package com.arlsura.afiliacion
//
//import java.util.Calendar
//
//import co.com.sura.ventainformacion.service._
//import co.com.sura.ventainformacion.preafiliacion.service.consumer.PreafiliacionConsumerService
//
//object PruebaconRada {
//
//  def getPreDTO: PreAfiliacionDTO = {
//    val cs = new PreafiliacionConsumerService( "afilineaarl", "Lune5122", "1", "http://arlappslab.suramericana.com/VentaInformacionWS/services/PreafiliacionFacadeWSImpl" );
//    val dto = new PreAfiliacionDTO();
//    val ct = new ControlCentroTrabajoDTO(
//      "123",
//      null, // CODIGO CARGO NÓMINA QUEMADO
//      null, // CODIGO CARGO SALUD OCU QUEMADO
//      "1061",
//      "", // CODIGO SEDE VACÍO
//      "asd", //DNIBuilder.build( contactsData.rosterRepresentative.identificationType, contactsData.rosterRepresentative.identification ),
//      "asfsd", //DNIBuilder.build( contactsData.workSafetyRepresentative.identificationType, contactsData.workSafetyRepresentative.identification ),
//      "adsf",
//      "asdasd",
//      "", // NOMBRE SEDE VACÍO
//      "asda",
//      "sdfdsf",
//      1,
//      3,
//      "dsf",
//      "S",
//      "", // snCTReclasificar VACÍO
//      "N"
//    );
//
//    val cts = Array[ ControlCentroTrabajoDTO ]( ct )
//    dto.setCentrosTrabajo( cts );
//
//    val controlEmpresaAfiliacionDTO = new ControlEmpresaAfiliacionDTO(
//      "",
//      "",
//      "",
//      "2", // cdCargoGerente --> QUEMADO
//      638, // cdCargoRelaciones --> QUEMADO
//      "3", // cdCargoRepresentante --> QUEMADO
//      "D", // cdEstadoVenta --> QUEMADO
//      "",
//      "",
//      "12", // cdMotivoFueraNorma --> QUEMADO
//      "",
//      "",
//      "",
//      "234",
//      "sdf",
//      "",
//      "",
//      "",
//      "",
//      "",
//      "sdfsd",
//      "sdf",
//      "fsdfsdf",
//      Calendar.getInstance(),
//      Calendar.getInstance(),
//      "",
//      Calendar.getInstance(),
//      0.0,
//      0,
//      0,
//      "",
//      "S",
//      ""
//    );
//
//    dto.setControlEmpresaAfiliacionDTO( controlEmpresaAfiliacionDTO );
//
//    val empresaAfiliacionDTO = new EmpresaAfiliacionDTO(
//      "",
//      "234",
//      "55",
//      "",
//      "",
//      "",
//      "",
//      "",
//      "1061",
//      "",
//      "",
//      "",
//      "",
//      "",
//      new CentroTrabajoXmlDTO(
//        "526", // QUEMADO
//        "1", // QUEMADO
//        "5", // QUEMADO
//        "",
//        "fdfgdf",
//        "sdfsdf",
//        "sdfsdf",
//        "",
//        "sfsdf",
//        "asdf",
//        "",
//        "sdfs",
//        null,
//        null,
//        "",
//        "",
//        "",
//        "",
//        "",
//        "",
//        "",
//        "",
//        "",
//        "",
//        ""
//      ),
//      "",
//      null,
//      "dfg",
//      "dasfsd",
//      "",
//      "",
//      "dsfasdf",
//      false,
//      "",
//      Calendar.getInstance(),
//      Calendar.getInstance(),
//      Calendar.getInstance(),
//      "",
//      "",
//      "4",
//      1,
//      "asdfsdaf",
//      "",
//      "",
//      "",
//      "",
//      "S",
//      "",
//      "",
//      "",
//      "N",
//      0.0,
//      "",
//      "",
//      0
//    );
//
//    dto.setEmpresaAfiliacionDTO( empresaAfiliacionDTO );
//
//    val personaDTO = new PersonaDTO(
//      new DatosAdicionalesPersonaDTO(
//        false,
//        "",
//        "",
//        "",
//        "",
//        "",
//        "",
//        "",
//        "",
//        "",
//        "",
//        "",
//        "",
//        "",
//        null,
//        null,
//        null,
//        null,
//        "",
//        new PostalDTO(
//          "",
//          "1069",
//          "",
//          "",
//          null,
//          null,
//          0,
//          null,
//          null
//        ),
//        0,
//        "",
//        "",
//        "",
//        "",
//        0,
//        "",
//        false,
//        "",
//        "",
//        "",
//        ""
//      ),
//      "",
//      0,
//      "",
//      null,
//      null,
//      "",
//      "",
//      "",
//      "",
//      "sdfsdaf",
//      "asdasd",
//      "",
//      "",
//      "",
//      ""
//    );
//
//    val as = Array[ PersonaDTO ]( personaDTO, personaDTO, personaDTO, personaDTO, personaDTO )
//
//    dto.setPersonas( as );
//
//    val ta = new TrabajadorDTO(
//      "",
//      "",
//      "",
//      "",
//      "",
//      "",
//      "sdfsf",
//      "sdfsdf",
//      "adsfdf",
//      "dfasdf",
//      "sdfds",
//      "asdfsd",
//      null,
//      100L,
//      "dfsdf",
//      ""
//    );
//
//    val asds = Array[ TrabajadorDTO ]( ta );
//    dto.setTrabajadores( asds );
//
//    //    try {
//    //      System.out.println( "asdas " + cs.CrearPreafiliacion( dto ) );
//    //    }
//    //    catch {
//    //      case t =>
//    //        t.printStackTrace()
//    //    }
//
//    dto
//  }
//
//}