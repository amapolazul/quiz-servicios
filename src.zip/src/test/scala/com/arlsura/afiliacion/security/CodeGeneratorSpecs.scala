//package com.arlsura.afiliacion.security
//
//import org.scalatest.FlatSpec
//
//import scala.util.Random
//
///**
// * Created by Jesús Martínez on 21/11/14.
// */
//class CodeGeneratorSpecs extends FlatSpec {
//  private def getLength(valid: Boolean = true) = {
//    val random = new Random()
//    if (valid)
//      random.nextInt(28) + 4 //Así garantizamos que los casos borde se cumplen.
//    else random.nextInt(2) match {
//      case 0 => - random.nextInt() //Longitud negativa
//      case 1 => random.nextInt() + 33 //Longitud mayor a 32
//      case 2 => random.nextInt(3) //Longitud menor a 4
//    }
//  }
//  "A Code Generator" should "generate a numeric code by default" in {
//    assert(CodeGenerator.generate().right.get.forall(_.isDigit))
//    assert(CodeGenerator.generate(length = getLength()).right.get.forall(_.isDigit))
//  }
//
//  it should "generate a code of size 4 by default" in {
//    assert(CodeGenerator.generate().right.get.length == 4)
//    assert(CodeGenerator.generate(alphanumeric = true).right.get.length == 4)
//  }
//
//  it should "generate a code of the specified length" in {
//    val size = getLength()
//    assert(CodeGenerator.generate(length = size).right.get.length == size)
//    assert(CodeGenerator.generate(length = size, alphanumeric = true).right.get.length == size)
//  }
//
//  it should "generate a code alphanumeric if specified that way" in {
//    assert(CodeGenerator.generate(length = getLength(), alphanumeric = true).right.get.forall(_.isLetterOrDigit))
//    assert(CodeGenerator.generate(alphanumeric = true).right.get.forall(_.isLetterOrDigit))
//  }
//
//  it should "return an error when the size is below 4" in {
//    assert(CodeGenerator.generate(length = getLength(valid = false)).isLeft)
//    assert(CodeGenerator.generate(length = getLength(valid = false), alphanumeric = true).isLeft)
//  }
//}
