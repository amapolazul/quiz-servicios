//package com.arlsura.afiliacion.bussiness.sarlaft
//
//import org.scalatest.FlatSpec
//
///**
// * Created by root on 27/02/15.
// */
//class SarlaftManagerSpecs extends FlatSpec {
//  "A SarlatfManager" should "return a proper answer when asked for the risks related to any given client" in {
//    //val (moralRisk: Boolean, severeMoralRisk: Boolean) = SarlaftManager.consultRisk("C", "71775944")
//    //println("------------------------------------------------------------------")
//    //println(s"moralRisk result:  $moralRisk")
//    //println(s"moralRisk result:  $severeMoralRisk")
//    //assert(!moralRisk && !severeMoralRisk)
//  }
//}
