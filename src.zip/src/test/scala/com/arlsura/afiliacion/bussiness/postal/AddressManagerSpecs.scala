//package com.arlsura.afiliacion.bussiness.postal
//
//import com.arlsura.afiliacion.bussiness.address.AddressManager
//import org.scalatest.FlatSpec
//
///**
// * Created by Jesús Martínez on 17/12/14.
// */
//class AddressManagerSpecs extends FlatSpec {
//
//  "An AddressManager" should "return a non-empty list of countries' names" in {
//    assert(AddressManager.retrieveCountriesNames.nonEmpty)
//  }
//
//  it should "return a non-empty list of countries' information" in {
//    assert(AddressManager.retrieveCountriesInfo.nonEmpty)
//  }
//
//  it should "return a non-empty list of countries' codes" in {
//    assert(AddressManager.retrieveCountriesCodes.nonEmpty)
//  }
//
//  it should "return a non-empty list of Colombia's provinces" in {
//    val testResultList1 = AddressManager.retrieveProvincesInfoByCountryName()
//    val testResultList2 = AddressManager.retrieveProvincesInfoByCountryName("colombia")
//    val testResultList3 = AddressManager.retrieveProvincesInfoByCountryCode()
//    val testResultList4 = AddressManager.retrieveProvincesInfoByCountryCode(57)
//    val tests = testResultList1 :: testResultList2 :: testResultList3 :: testResultList4 :: Nil
//
//    //Todos las consultas deben traer resultados.
//    assert(tests.forall(_.nonEmpty))
//    //Todas las consultas traen el mismo resultado.
//    assert(tests.forall(t => tests.forall(_ == t)))
//  }
//
//  it should "return a non-empty list of any country's provinces" in {
//    val testResultList1 = AddressManager.retrieveProvincesInfoByCountryName("venezuela")
//    val testResultList2 = AddressManager.retrieveProvincesInfoByCountryCode(310)
//
//    assert(testResultList1.nonEmpty && testResultList2.nonEmpty)
//    assert(testResultList1 == testResultList2)
//  }
//
//  it should "return a valid list of municipalities for a given input set" in {
//    val municipalities = AddressManager.retrieveMunicipalities("05", "21")
//    assert(municipalities.length == 125)
//  }
//}
