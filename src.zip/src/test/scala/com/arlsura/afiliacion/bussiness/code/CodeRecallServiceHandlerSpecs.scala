//package com.arlsura.afiliacion.bussiness.code
//
//import com.arlsura.afiliacion.persistence.entities.preaffiliation.FullEconomicActivity
//import com.arlsura.afiliacion.utils.messages.MessagesRetriever
//import net.codingwell.scalaguice.InjectorExtensions._
//import com.arlsura.afiliacion.bussiness.code.recall.{ CodeRecallServiceHandler, CodeRecallRepository }
//import com.arlsura.afiliacion.persistence.daos.wrappers.{ PreAffiliationWrapper, SecurityCodeWrapper }
//import com.arlsura.afiliacion.persistence.entities.affiliation.contacts_data.ContactInformation
//import com.arlsura.afiliacion.persistence.entities.{ PreAffiliation, SecurityCode }
//import com.google.inject.{ Guice, AbstractModule }
//import net.codingwell.scalaguice.ScalaModule
//import org.scalatest.mock.MockitoSugar
//import org.scalatest.{ Matchers, FlatSpec }
//import reactivemongo.bson.{ BSONObjectID, BSONDocument }
//import scala.concurrent.ExecutionContext.Implicits.global
//import scala.concurrent.Future
//
///**
// * Created by Jesús Martínez on 3/06/15.
// */
//class CodeRecallServiceHandlerSpecs extends FlatSpec with Matchers {
//  private[ CodeRecallServiceHandlerSpecs ] object GlobalData {
//    val scd = SecurityCode(
//      _id = BSONObjectID.generate,
//      code = "1",
//      source = "A",
//      email = "jaxex706@gmail.com",
//      dni = "1234"
//    )
//
//    val pad = PreAffiliation(
//      _id = BSONObjectID.generate,
//      dni = "1234",
//      fullName = "ABC",
//      address = "K1#2-3",
//      cellphone = None,
//      econoact = "1",
//      workers = 1,
//      prevarp = "",
//      racea = "",
//      fileName = None,
//      file = None,
//      affiliationType = "B",
//      isNewCompany = None,
//      selectedProvinces = List.empty,
//      gender = None,
//      birthDate = None,
//      fullEconomicActivity = FullEconomicActivity( description = Some( "" ), economicActivityId = "", rate = Some( "" ) ),
//      contactInfo = ContactInformation( email = "test@test.tst", phone = Some( "8888888" ) )
//    )
//
//    val pad2 = PreAffiliation(
//      _id = BSONObjectID.generate,
//      dni = "4321",
//      fullName = "ABC",
//      address = "K1#2-3",
//      cellphone = None,
//      econoact = "1",
//      workers = 1,
//      prevarp = "",
//      racea = "",
//      fileName = None,
//      file = None,
//      affiliationType = "B",
//      isNewCompany = None,
//      selectedProvinces = List.empty,
//      gender = None,
//      birthDate = None,
//      fullEconomicActivity = FullEconomicActivity( description = Some( "" ), economicActivityId = "", rate = Some( "" ) ),
//      contactInfo = ContactInformation( email = "test@test.tst", phone = Some( "8888888" ) )
//    )
//
//    lazy val challengePassed = MessagesRetriever.getSuccessMessage( "code", "CHALLENGE_PASSED" )
//    lazy val challengeFailed = MessagesRetriever.getSuccessMessage( "code", "CHALLENGE_FAILED" )
//    lazy val codeNotFound = MessagesRetriever.getErrorMessage( "code", "NOT_FOUND" )
//    def errorOccurred( e: String ) = s"Ha ocurrido un error: $e"
//  }
//
//  private[ CodeRecallServiceHandlerSpecs ] class TestModule extends AbstractModule with ScalaModule with MockitoSugar {
//
//    import GlobalData._
//    import org.mockito.Mockito._
//
//    override def configure(): Unit = {
//      val repo = mock[ CodeRecallRepository ]
//
//      when {
//        repo.findCode( "1234" )
//      } thenReturn {
//        Future.successful( Some( scd ) )
//      }
//
//      when {
//        repo.findCode( "4321" )
//      } thenReturn {
//        Future.successful( None )
//      }
//
//      when {
//        repo.findByEmail( "1234", "test@test.tst" )
//      } thenReturn {
//        Future.successful( Some( pad ) )
//      }
//
//      when {
//        repo.findByPhone( "1234", "8888888" )
//      } thenReturn {
//        Future.successful( Some( pad ) )
//      }
//
//      when {
//        repo.findByEmail( "4321", "test@test.tst" )
//      } thenReturn {
//        Future.successful( Some( pad2 ) )
//      }
//
//      when {
//        repo.findByPhone( "4321", "8888888" )
//      } thenReturn {
//        Future.successful( Some( pad2 ) )
//      }
//
//      when {
//        repo.findByEmail( "1234", "nope@nope.not" )
//      } thenReturn {
//        Future.successful( None )
//      }
//
//      when {
//        repo.findByPhone( "1234", "1111111" )
//      } thenReturn {
//        Future.successful( None )
//      }
//
//      bind[ CodeRecallRepository ].toInstance( repo )
//    }
//  }
//
//  val injector = Guice.createInjector( new TestModule )
//  val handler = injector.instance[ CodeRecallServiceHandler ]
//
//  "A CodeRecallServiceHandler" should "validate an email challenge" in {
//    handler.recallCode( "1234", "email", "test@test.tst" ) onSuccess {
//      case Right( r ) =>
//        assert( r.data.get.asInstanceOf[ Map[ String, Boolean ] ]( "challengePassed" ) )
//        assert( r.suraSessionManager.forall( _.nonEmpty ) )
//        r.message should be( GlobalData.challengePassed )
//      case Left( _ ) => fail()
//    }
//
//    handler.recallCode( "1234", "email", "nope@nope.not" ) onSuccess {
//      case Right( r ) =>
//        assert( !r.data.get.asInstanceOf[ Map[ String, Boolean ] ]( "challengePassed" ) )
//        assert( r.suraSessionManager.forall( _.nonEmpty ) )
//        r.message should be( GlobalData.challengeFailed )
//      case Left( _ ) => fail()
//    }
//
//    handler.recallCode( "4321", "email", "test@test.tst" ) onSuccess {
//      case Right( _ )  => fail()
//      case Left( msg ) => msg should be( GlobalData.codeNotFound )
//    }
//  }
//
//  it should "validate an phone challenge" in {
//    handler.recallCode( "1234", "phone", "8888888" ) onSuccess {
//      case Right( r ) =>
//        assert( r.data.get.asInstanceOf[ Map[ String, Boolean ] ]( "challengePassed" ) )
//        assert( r.suraSessionManager.forall( _.nonEmpty ) )
//        r.message should be( GlobalData.challengePassed )
//      case Left( _ ) => fail()
//    }
//
//    handler.recallCode( "1234", "phone", "1111111" ) onSuccess {
//      case Right( r ) =>
//        assert( !r.data.get.asInstanceOf[ Map[ String, Boolean ] ]( "challengePassed" ) )
//        assert( r.suraSessionManager.forall( _.nonEmpty ) )
//        r.message should be( GlobalData.challengeFailed )
//      case Left( _ ) => fail()
//    }
//
//    handler.recallCode( "4321", "phone", "8888888" ) onSuccess {
//      case Right( _ )  => fail()
//      case Left( msg ) => msg should be( GlobalData.codeNotFound )
//    }
//  }
//
//}
