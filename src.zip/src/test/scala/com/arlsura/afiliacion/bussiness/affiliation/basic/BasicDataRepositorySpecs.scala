//package com.arlsura.afiliacion.bussiness.affiliation.basic
//
//import com.arlsura.afiliacion.bussiness.affiliation.BasicDataRepository
//import com.arlsura.afiliacion.persistence.daos.affiliation.wrappers.AffiliationBasicDataWrapper
//import com.arlsura.afiliacion.persistence.entities.affiliation.basic_data.AffiliationBasicData
//import com.arlsura.afiliacion.persistence.entities.affiliation.contacts_data.ContactInformation
//import com.arlsura.afiliacion.persistence.entities.preaffiliation.FullEconomicActivity
//import com.arlsura.afiliacion.utils.CipherFacility
//import com.google.inject.{ Guice, AbstractModule }
//import net.codingwell.scalaguice.ScalaModule
//import org.scalatest.mock.MockitoSugar
//import org.scalatest.{ Matchers, FlatSpec }
//import reactivemongo.bson.{ BSONDocument, BSONObjectID }
//import reactivemongo.core.commands.LastError
//import net.codingwell.scalaguice.InjectorExtensions._
//import scala.concurrent.Future
//import scala.concurrent.ExecutionContext.Implicits.global
//
///**
// * Created by Jesús Martínez on 25/05/15.
// */
//class BasicDataRepositorySpecs extends FlatSpec with Matchers {
//  private[ BasicDataRepositorySpecs ] object GlobalData extends CipherFacility {
//    val leOk = LastError( true, None, None, None, None, -1, false )
//    private val id = BSONObjectID.generate
//    val doc1 = AffiliationBasicData(
//      _id = id,
//      dni = "1234",
//      contactInformation = ContactInformation( identification = "473060" ),
//      contributorType = 0,
//      commercialActivity = "1111",
//      provincesSelected = List(),
//      personType = "N",
//      fullEconomicActivity = FullEconomicActivity(
//        description = Some( "test" ),
//        economicActivityId = "235",
//        rate = Some( "12.4" )
//      )
//    )
//    val doc2 = AffiliationBasicData(
//      _id = BSONObjectID.generate,
//      dni = "5678",
//      contactInformation = ContactInformation( identification = "584171" ),
//      contributorType = 5,
//      commercialActivity = "1112",
//      provincesSelected = List(),
//      personType = "N",
//      fullEconomicActivity = FullEconomicActivity(
//        description = Some( "test" ),
//        economicActivityId = "235",
//        rate = Some( "12.4" )
//      )
//    )
//    val doc1Modified = AffiliationBasicData(
//      _id = id,
//      dni = "1234",
//      contactInformation = ContactInformation( identification = "473060" ),
//      contributorType = 1,
//      commercialActivity = "2222",
//      provincesSelected = List(),
//      personType = "J",
//      fullEconomicActivity = null
//    )
//
//  }
//  private[ BasicDataRepositorySpecs ] class TestModule extends AbstractModule with ScalaModule with MockitoSugar with CipherFacility {
//    import org.mockito.Mockito._
//    import GlobalData._
//
//    override def configure(): Unit = {
//      val wrapper = mock[ AffiliationBasicDataWrapper ]
//
//      //Mock de llamada a findOne
//      when {
//        wrapper.findOne( BSONDocument( "dni" -> encode( "1234" ) ) )
//      } thenReturn {
//        Future.successful( Some( doc1 ) )
//      }
//
//      when {
//        wrapper.findOne( BSONDocument( "contactInformation.identification" -> encode( "473060" ) ) )
//      } thenReturn {
//        Future.successful( Some( doc1 ) )
//      }
//
//      when {
//        wrapper.findOne( BSONDocument( "dni" -> encode( "4321" ) ) )
//      } thenReturn {
//        Future.successful( None )
//      }
//
//      when {
//        wrapper.findOne( BSONDocument( "contactInformation.identification" -> encode( "123456" ) ) )
//      } thenReturn {
//        Future.successful( None )
//      }
//
//      //Mock de llamada a findAll
//      when {
//        wrapper.findAll()
//      } thenReturn {
//        Future.successful( List( doc1, doc2 ) )
//      }
//
//      //Mock de llamada a remove.
//      when {
//        wrapper.remove( BSONDocument( "dni" -> encode( "1234" ) ) )
//      } thenReturn {
//        Future.successful( leOk )
//      }
//
//      when {
//        wrapper.remove( BSONDocument( "contactInformation.identification" -> encode( "473060" ) ) )
//      } thenReturn {
//        Future.successful( leOk )
//      }
//
//      //Mock de llamada a update.
//      when {
//        wrapper.update( BSONDocument( "dni" -> encode( "1234" ) ), doc1Modified )
//      } thenReturn {
//        Future.successful( leOk )
//      }
//
//      //Mock de llamada a insert.
//      when {
//        wrapper.insert( doc2 )
//      } thenReturn {
//        Future.successful( leOk )
//      }
//
//      bind[ AffiliationBasicDataWrapper ].toInstance( wrapper )
//    }
//  }
//
//  import GlobalData._
//  val injector = Guice.createInjector( new TestModule() )
//  val repository = injector.instance[ BasicDataRepository ]
//
//  "A BasicDataRepository" should "find a document by dni" in {
//    repository.getByDni( "1234" ) onSuccess {
//      case Some( doc ) => doc should be( doc1 )
//      case None        => fail()
//    }
//
//    repository.getByDni( "4321" ) onSuccess {
//      case Some( _ ) => fail()
//      case None      => assert( true )
//    }
//  }
//
//  it should "find a document by identification" in {
//    repository.getByIdentification( "473060" ) onSuccess {
//      case Some( doc ) => doc should be( doc1 )
//      case None        => fail()
//    }
//
//    repository.getByIdentification( "123456" ) onSuccess {
//      case Some( _ ) => fail()
//      case None      => assert( true )
//    }
//  }
//
//  it should "insert a document" in {
//    repository.create( doc2 ) onSuccess {
//      case status => assert( status.ok )
//    }
//  }
//
//  it should "update a document found by dni" in {
//    repository.updateByDni( "1234", doc1Modified ) onSuccess {
//      case status => assert( status.ok )
//    }
//  }
//
//  it should "delete a document found by dni" in {
//    repository.deleteByDni( "1234" ) onSuccess {
//      case status => assume( status.ok )
//    }
//  }
//
//  it should "delete a document found by identification" in {
//    repository.deleteByIdentification( "473060" ) onSuccess {
//      case status => assert( status.ok )
//    }
//  }
//}