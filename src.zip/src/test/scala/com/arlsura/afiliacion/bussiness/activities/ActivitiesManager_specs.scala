//package com.arlsura.afiliacion.bussiness.activities
//
//import org.scalatest.{BeforeAndAfter, FlatSpec}
//import org.specs2.matcher.Matchers
//
//import scala.concurrent.ExecutionContext.Implicits.global
//
//
///**
// * Created by juanmartinez on 6/01/15.
// */
//class ActivitiesManager_specs extends FlatSpec with Matchers with BeforeAndAfter{
//
//  var activitiesManager : ActivitiesManager = _
//
//  before {
//    activitiesManager = new ActivitiesManager
//  }
//
//  "A list with all activities" should "be returned with no parameters are sent " in {
//    val activities = activitiesManager.getActivities()
//    activities map {
//      activities =>
//        assert(activities.length >= 600)
//    }
//  }
//
//  "A list with 10 activities" should "be returned sending the numRegistries parameter " in {
//    val activities = activitiesManager.getActivities(numRegistries = 10)
//    activities map {
//      activities =>
//        assert(activities.length == 10)
//    }
//  }
//
//  "A list with 1 activity" should "be returned sending the code parameter " in {
//    val activities = activitiesManager.getActivities(code = "5752201")
//    activities map {
//      activities =>
//        println(activities.length)
//        assert(activities.length == 1)
//    }
//  }
//
//}
