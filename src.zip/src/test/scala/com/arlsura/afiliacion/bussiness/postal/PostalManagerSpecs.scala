//package com.arlsura.afiliacion.bussiness.postal
//
//import org.scalatest.FlatSpec
//
///**
// * Created by Jesús Martínez on 15/12/14.
// */
//class PostalManagerSpecs extends FlatSpec {
//
//  "A PostalManager" should
//    "return a valid response when asked for the delegation code and branch office code, given a municipality" in {
//    val (delegationCode, branchCode) = PostalManager.consultMunicipality("4292")
//    assert(delegationCode == "21" && branchCode == "20")
//  }
//
//  it should "return a valid list of cities/municipality, given the proper data associated to a province" in {
//    val municipalities = PostalManager.getSettlements("05", "21")
//    assert(municipalities.length == 125)
//  }
//}
