//package com.arlsura.afiliacion.bussiness.code
//
//import com.arlsura.afiliacion.persistence.entities.SecurityCode
//import org.joda.time.DateTime
//import org.scalatest.{BeforeAndAfter, FlatSpec}
//import org.specs2.matcher.Matchers
//
///**
//* Created by juanmartinez on 15/12/14.
//*/
//class SecurityCodeManagerSpecs extends FlatSpec with Matchers with BeforeAndAfter{
//
//  var securityCodeManager: SecurityCodeManager = _
//  var securityCodeEntity: SecurityCode = _
//  var securityCodeEntityBefore: SecurityCode = _
//
//  before {
//    securityCodeManager = new SecurityCodeManager
//    securityCodeEntity = SecurityCodeManager.buildSecurityCodeEntity(
//      code = "1234",
//      dni = "N888888888",
//      email = "test@email.com",
//      source = CodeSourceIdentifiers.STANDARD,
//      expirationDate = SecurityCodeManager.generateExpirationDate
//    )
//    securityCodeEntityBefore = SecurityCodeManager.buildSecurityCodeEntity(
//      code = "1234",
//      dni = "N888888886",
//      email = "test@email.com",
//      source = CodeSourceIdentifiers.STANDARD,
//      expirationDate = SecurityCodeManager.generateExpirationDate.plusYears(-1)
//    )
//  }
//
//  "An expiration date" should "be two months later from today" in {
//    val today = DateTime.now().plusMonths(2)
//    val expirationDate = SecurityCodeManager.generateExpirationDate()
//
//    assert(today.year === expirationDate.year)
//    assert(today.monthOfYear === expirationDate.monthOfYear)
//    assert(today.dayOfMonth === expirationDate.dayOfMonth)
//  }
//
//  "An instance of SecurityCode" should "be returned" in {
//    assert(securityCodeEntity.isInstanceOf[SecurityCode])
//  }
//
//  "A security code with expiration date after now" should "be false" in {
//    val result = securityCodeManager.validateSecurityCode(securityCodeEntity)
//    assert(result === false)
//  }
//
//  "A security code with expiration date before now" should "be true" in {
//    val result = securityCodeManager.validateSecurityCode(securityCodeEntityBefore)
//    assert(result === true)
//  }
//}
