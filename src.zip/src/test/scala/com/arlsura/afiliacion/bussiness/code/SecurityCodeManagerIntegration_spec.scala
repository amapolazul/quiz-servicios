//package com.arlsura.afiliacion.bussiness.code
//
//import org.scalatest.{BeforeAndAfter, FlatSpec}
//import org.specs2.matcher.Matchers
//
//import scala.concurrent.ExecutionContext.Implicits.global
//import scala.util.{Failure, Success}
//
///**
//* Created by juanmartinez on 16/12/14.
//*/
//class SecurityCodeManagerIntegration_spec extends FlatSpec with Matchers with BeforeAndAfter {
//
//  var securityCodeManager: SecurityCodeManager = _
//
//  before {
//    securityCodeManager = new SecurityCodeManager
//  }
//
//  "A client without security code" should "return None as result" in {
//    securityCodeManager.existSecurityCode("N123456789") onComplete {
//      case Success(result) =>
//        assert(result.getOrElse(None) === None)
//      case Failure(e) => println("nothing")
//    }
//  }
//
//  "A security code" should "be saved in database" in {
//    val securityCode = SecurityCodeManager.buildSecurityCodeEntity(
//      code = "1234",
//      dni = "N888888888",
//      email = "test@email.com",
//      source = CodeSourceIdentifiers.STANDARD,
//      expirationDate = SecurityCodeManager.generateExpirationDate
//    )
//
//    securityCodeManager.saveSecurityCodeManager(securityCode) onComplete {
//      case Success(suc) =>
//        println("guardado -> " + suc)
//      case Failure(ex) =>
//        println("fallo")
//    }
//  }
//
//}
