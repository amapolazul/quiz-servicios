//package com.arlsura.afiliacion.bussiness.blacklist
//
//import com.arlsura.afiliacion.persistence.blacklist.{ Blacklist, BlacklistWrapper }
//import com.google.inject.{ Guice, AbstractModule }
//import net.codingwell.scalaguice.ScalaModule
//import org.joda.time.DateTime
//import org.scalatest.mock.MockitoSugar
//import org.scalatest.{ Matchers, FlatSpec }
//import reactivemongo.bson.BSONDocument
//import reactivemongo.core.commands.LastError
//import scala.concurrent.ExecutionContext.Implicits.global
//import scala.concurrent.{ ExecutionContext, Future }
//import net.codingwell.scalaguice.InjectorExtensions._
//import java.util.Date
//
///**
// * Created by Jesús Martínez on 9/06/15.
// */
//class BlacklistRepositorySpecs extends FlatSpec with Matchers {
//
//  private[ BlacklistRepositorySpecs ] object GlobalData {
//    val elem1 = Blacklist( dni = "1234", factor = .5, since = new DateTime() )
//    val leOk = LastError( ok = true, err = None, code = None, errMsg = None, originalDocument = None, updated = -1, updatedExisting = false )
//  }
//
//  private[ BlacklistRepositorySpecs ] class TestModule extends AbstractModule with ScalaModule with MockitoSugar {
//    import org.mockito.Mockito._
//    import org.mockito.Matchers._
//
//    override def configure(): Unit = {
//      val wrapper = mock[ BlacklistWrapper ]
//
//      when {
//        wrapper.findOne( BSONDocument( "dni" -> "1234" ), BSONDocument( "since" -> -1 ) )
//      } thenReturn {
//        Future.successful( Some( GlobalData.elem1 ) )
//      }
//
//      when {
//        wrapper.findOne( BSONDocument( "dni" -> "4321" ), BSONDocument( "since" -> -1 ) )
//      } thenReturn {
//        Future.successful( None )
//      }
//
//      when {
//        wrapper.insert( any[ Blacklist ] )( any[ ExecutionContext ] )
//      } thenReturn {
//        Future.successful( GlobalData.leOk )
//      }
//
//      bind[ BlacklistWrapper ].toInstance( wrapper )
//    }
//  }
//
//  val injector = Guice.createInjector( new TestModule() )
//  val repo = injector.instance[ BlacklistRepository ]
//
//  "A BlacklistRepository" should "insert a new entry properly" in {
//    repo.save( "4321", new Date().getTime, 1f ) onSuccess {
//      case status => assert( status.ok )
//    }
//  }
//
//  it should "return the most recent entry in the list for a given dni (if any)" in {
//    repo.findByDni( "1234" ) onSuccess {
//      case Some( rs ) =>
//        rs should be( GlobalData.elem1 )
//      case None => fail()
//    }
//
//    repo.findByDni( "4321" ) onSuccess {
//      case Some( _ ) => fail()
//      case None      => assert( true )
//    }
//  }
//
//}
