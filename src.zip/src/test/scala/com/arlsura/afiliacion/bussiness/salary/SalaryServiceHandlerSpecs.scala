//package com.arlsura.afiliacion.bussiness.salary
//
//import akka.actor.{ ActorSystem, Props }
//import com.arlsura.afiliacion.actors.cache.CacheRefresherActor
//import com.arlsura.afiliacion.actors.commons.VerboseActor
//import com.arlsura.afiliacion.persistence.cache.SalaryCache
//import org.scalatest.{ Matchers, FlatSpec }
//import scala.concurrent.ExecutionContext.Implicits.global
//
///**
// * Created by Jesús Martínez on 5/06/15.
// */
//class SalaryServiceHandlerSpecs extends FlatSpec with Matchers {
//  val system = ActorSystem( "TEST" )
//
//  "A SalaryServiceHandlerSpecs" should "retrieve the current minimum salary value" in {
//    val cache = system.actorOf( DummyActor.props )
//    val handler = new SalaryServiceHandler( cache )
//
//    handler.retrieveMinimumSalary() onSuccess {
//      case Right( r ) =>
//        r.data.get.asInstanceOf[ Map[ String, Double ] ]( "salary" ) should be( 650f )
//      case Left( _ ) => fail()
//    }
//  }
//
//}
//
////Actor que hará las veces de CacheActor.
//private class DummyActor extends VerboseActor {
//  override def receive = {
//    case CacheRefresherActor.GetSalaryValue =>
//      sender ! CacheRefresherActor.SalaryValueReturned( SalaryCache( 650f ) )
//      context.stop( self )
//  }
//}
//
////Companion object del actor ^
//private object DummyActor {
//  def props = Props( new DummyActor )
//}
