//package com.arlsura.afiliacion.bussiness.affiliation.work_centers
//
//import com.arlsura.afiliacion.bussiness.affiliation.workcenters.{ WorkCentersDataServiceHandler, WorkCentersDataRepository }
//import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.SaveWorkCentersData
//import com.arlsura.afiliacion.persistence.entities.affiliation.work_center_data.AffiliationWorkCentersData
//import com.arlsura.afiliacion.utils.messages.MessagesRetriever
//import com.google.inject.{ Guice, AbstractModule }
//import net.codingwell.scalaguice.ScalaModule
//import org.scalatest.mock.MockitoSugar
//import org.scalatest.{ Matchers, FlatSpec }
//import net.codingwell.scalaguice.InjectorExtensions._
//import reactivemongo.bson.BSONObjectID
//import reactivemongo.core.commands.LastError
//import scala.concurrent.ExecutionContext.Implicits.global
//import scala.concurrent.Future
//
///**
// * Created by Jesús Martínez on 22/05/15.
// */
//class WorkCentersDataServiceHandlerSpecs extends FlatSpec with Matchers {
//
//  private[ WorkCentersDataServiceHandlerSpecs ] class TestModule extends AbstractModule with ScalaModule with MockitoSugar {
//    import org.mockito.Mockito._
//    import GlobalData._
//    override def configure(): Unit = {
//      val repo = mock[ WorkCentersDataRepository ]
//
//      //Mock de llamada a findByDni
//      when {
//        repo.findByDni( "1234" )
//      } thenReturn {
//        Future.successful( Some( awcd ) )
//      }
//
//      when {
//        repo.findByDni( "4321" )
//      } thenReturn {
//        Future.successful( None )
//      }
//
//      //Mock de llamada a createOrUpdate
//      when {
//        repo.createOrUpdate( "1234", "ABC", List() )
//      } thenReturn {
//        Future.successful( leOK )
//      }
//
//      when {
//        repo.createOrUpdate( "4321", "ABC", List() )
//      } thenReturn {
//        Future.successful( leNotOK )
//      }
//
//      bind[ WorkCentersDataRepository ].toInstance( repo )
//    }
//  }
//
//  private[ WorkCentersDataServiceHandlerSpecs ] object GlobalData {
//    val id: BSONObjectID = BSONObjectID( "503792c1984587971b14530e" )
//    val leOK = LastError( ok = true, None, None, None, None, -1, false )
//    val leNotOK = LastError( ok = false, None, None, None, None, -1, false )
//    val awcd: AffiliationWorkCentersData = AffiliationWorkCentersData( id, "1234", "ABC", List() )
//
//    //mensajes de error y de exito para las respuestas
//    val retrieveWorkCentersSuccessMessage: String = MessagesRetriever.getSuccessMessage( "affiliation.work_centers", "RETRIEVE" )
//    val noWorkCentersSuccessMessage: String = MessagesRetriever.getSuccessMessage( "affiliation.work_centers", "NO_WORK_CENTERS" )
//    val saveWorkCentersSuccessMessage: String = MessagesRetriever.getSuccessMessage( "affiliation.work_centers", "SAVE" )
//    def errorOccurredMessage( error: String ): String = s"Ocurrión un error: $error"
//  }
//
//  val injector = Guice.createInjector( new TestModule() )
//  val handler = injector.instance[ WorkCentersDataServiceHandler ]
//
//  "An EmployeeDataServiceHandler" should "retrieve a document by dni" in {
//    handler.retrieveWorkCenters( "1234" ) onSuccess {
//      case Left( _ ) => fail()
//      case Right( response ) =>
//        response.message should be {
//          GlobalData.retrieveWorkCentersSuccessMessage
//        }
//
//        response.data should be {
//          Some( GlobalData.awcd )
//        }
//    }
//
//    handler.retrieveWorkCenters( "4321" ) onSuccess {
//      case Left( _ ) => fail()
//      case Right( response ) =>
//        response.message should be {
//          GlobalData.noWorkCentersSuccessMessage
//        }
//
//        response.data should be {
//          None
//        }
//    }
//  }
//
//  it should "save employees information successfully" in {
//    handler.saveWorkCenters( SaveWorkCentersData( "1234", "ABC", List() ) ) onSuccess {
//      case Left( _ ) => fail()
//      case Right( response ) =>
//        response.message should be {
//          GlobalData.saveWorkCentersSuccessMessage
//        }
//
//        response.data should be {
//          None
//        }
//    }
//  }
//
//  it should "when saving employees info, report a failure if a problem has happened in DB" in {
//    handler.saveWorkCenters( SaveWorkCentersData( "4321", "ABC", List() ) ) onSuccess {
//      case Right( _ ) => fail()
//      case Left( e ) =>
//        e should be {
//          GlobalData.errorOccurredMessage( "MongoDB-Error" )
//        }
//    }
//  }
//
//  it should "return a non-empty cookie with each successful request" in {
//    handler.saveWorkCenters( SaveWorkCentersData( "1234", "ABC", List() ) ) onSuccess {
//      case Left( _ ) => fail()
//      case Right( response ) =>
//        assert( response.suraSessionManager.forall( _.nonEmpty ) )
//    }
//
//    handler.retrieveWorkCenters( "1234" ) onSuccess {
//      case Left( _ ) => fail()
//      case Right( response ) =>
//        assert( response.suraSessionManager.forall( _.nonEmpty ) )
//    }
//  }
//}
//
