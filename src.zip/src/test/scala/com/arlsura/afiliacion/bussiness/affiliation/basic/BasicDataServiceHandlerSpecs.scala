//package com.arlsura.afiliacion.bussiness.affiliation.basic
//
//import java.util.Date
//
//import com.arlsura.afiliacion.bussiness.affiliation.BasicDataServiceHandler.AffiliationBasicDataResponse
//import com.arlsura.afiliacion.bussiness.affiliation.{ BasicDataServiceHandler, BasicDataRepository }
//import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller
//import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.{ SaveAffiliationBasicData, ContactInformationData, SaveContactInformation }
//import com.arlsura.afiliacion.persistence.daos.affiliation.wrappers.AffiliationContactsDataWrapper
//import com.arlsura.afiliacion.persistence.entities.affiliation.basic_data.{ BankInformation, AffiliationBasicData }
//import com.arlsura.afiliacion.persistence.entities.affiliation.contacts_data.{ ContactInformation, AffiliationContactsData }
//import com.arlsura.afiliacion.persistence.entities.preaffiliation.{ FullEconomicActivity, ProvinceSelected }
//import com.arlsura.afiliacion.utils.messages.MessagesRetriever
//import com.google.inject.{ Guice, AbstractModule }
//import net.codingwell.scalaguice.ScalaModule
//import org.joda.time.DateTime
//import org.scalatest.mock.MockitoSugar
//import org.scalatest.{ Matchers, FlatSpec }
//import reactivemongo.bson.{ BSONDocument, BSONObjectID }
//import reactivemongo.core.commands.LastError
//import net.codingwell.scalaguice.InjectorExtensions._
//import scala.concurrent.{ ExecutionContext, Future }
//import scala.concurrent.ExecutionContext.Implicits.global
//
///**
// * Created by Jesús Martínez on 25/05/15.
// */
//class BasicDataServiceHandlerSpecs extends FlatSpec with Matchers {
//
//  private[ BasicDataServiceHandlerSpecs ] object GlobalData {
//    private val id = BSONObjectID.generate
//    val leOk = LastError( true, None, None, None, None, -1, false )
//    val doc1 = AffiliationBasicData(
//      _id = id,
//      dni = "1234",
//      contactInformation = ContactInformation( identification = "473060" ),
//      contributorType = 0,
//      commercialActivity = "1111",
//      provincesSelected = List(),
//      personType = "N",
//      fullEconomicActivity = FullEconomicActivity(
//        description = Some( "test" ),
//        economicActivityId = "235",
//        rate = Some( "12.4" )
//      )
//    )
//    val doc2 = AffiliationBasicData(
//      _id = BSONObjectID.generate,
//      dni = "4321",
//      contactInformation = ContactInformation( identification = "584171" ),
//      contributorType = 5,
//      commercialActivity = "1112",
//      provincesSelected = List(),
//      personType = "N",
//      fullEconomicActivity = null
//    )
//    val doc1Modified = AffiliationBasicData(
//      _id = id,
//      dni = "1234",
//      contactInformation = ContactInformation( identification = "473060" ),
//      contributorType = 1,
//      commercialActivity = "2222",
//      provincesSelected = List(),
//      personType = "J",
//      fullEconomicActivity = null
//    )
//    val sabd1 = SaveAffiliationBasicData(
//      identification = doc1Modified.contactInformation.identification,
//      identificationType = doc1Modified.contactInformation.identificationType,
//      dni = doc1Modified.dni,
//      name = doc1Modified.contactInformation.name,
//      name1 = Some( doc1Modified.contactInformation.name1 ),
//      name2 = doc1Modified.contactInformation.name2,
//      lastname1 = Some( doc1Modified.contactInformation.lastname1 ),
//      lastname2 = doc1Modified.contactInformation.lastname2,
//      commercialName = doc1Modified.commercialName,
//      newCompany = doc1Modified.newCompany,
//      personType = doc1Modified.personType,
//      juridicalNature = doc1Modified.juridicalNature,
//      contributorType = doc1Modified.contributorType,
//      previousARL = doc1Modified.previousARL,
//      letterDeliveryDate = None,
//      coverageStartDate = None,
//      foundationDate = None,
//      fullEconomicActivity = doc1Modified.fullEconomicActivity,
//      mainAddress = doc1Modified.mainAddress,
//      mailAddress = doc1Modified.mailAddress,
//      bankInformation = doc1Modified.bankInformation,
//      provincesSelected = List()
//    )
//    val sabd2 = SaveAffiliationBasicData(
//      identification = doc2.contactInformation.identification,
//      identificationType = doc2.contactInformation.identificationType,
//      dni = doc2.dni,
//      name = doc2.contactInformation.name,
//      name1 = Some( doc2.contactInformation.name1 ),
//      name2 = doc2.contactInformation.name2,
//      lastname1 = Some( doc2.contactInformation.lastname1 ),
//      lastname2 = doc2.contactInformation.lastname2,
//      commercialName = doc2.commercialName,
//      newCompany = doc2.newCompany,
//      personType = doc2.personType,
//      juridicalNature = doc2.juridicalNature,
//      contributorType = doc2.contributorType,
//      previousARL = doc2.previousARL,
//      letterDeliveryDate = None,
//      coverageStartDate = None,
//      foundationDate = None,
//      fullEconomicActivity = doc2.fullEconomicActivity,
//      mainAddress = doc2.mainAddress,
//      mailAddress = doc2.mailAddress,
//      bankInformation = doc2.bankInformation,
//      provincesSelected = List()
//    )
//
//    def mapSaveRequest( data: SaveAffiliationBasicData, id: BSONObjectID ): AffiliationBasicData = {
//
//      val foundationDate = data.foundationDate match {
//        case Some( date ) => Some( new DateTime( date ) )
//        case None         => None
//      }
//      val letterDeliveryDate = data.letterDeliveryDate match {
//        case Some( date ) => Some( new DateTime( date ) )
//        case None         => None
//      }
//      val coverageStartDate = data.coverageStartDate match {
//        case Some( date ) => Some( new DateTime( date ) )
//        case None         => None
//      }
//
//      AffiliationBasicData(
//        _id = id,
//        contactInformation = ContactInformation(
//          identification = data.identification,
//          identificationType = data.identificationType,
//          name1 = data.name1.get,
//          name2 = data.name2,
//          lastname1 = data.lastname1.get,
//          lastname2 = data.lastname2,
//          email = ""
//        ),
//        dni = data.dni,
//        commercialName = data.commercialName,
//        commercialActivity = data.fullEconomicActivity.economicActivityId,
//        personType = data.personType,
//        contributorType = data.contributorType,
//        mainAddress = data.mainAddress,
//        mailAddress = data.mailAddress,
//        bankInformation = data.bankInformation,
//        foundationDate = foundationDate,
//        letterDeliveryDate = letterDeliveryDate,
//        coverageStartDate = coverageStartDate,
//        newCompany = data.newCompany,
//        juridicalNature = data.juridicalNature,
//        previousARL = data.previousARL,
//        provincesSelected = for ( province <- data.provincesSelected )
//          yield ProvinceSelected(
//          provinceName = province.provinceName,
//          provinceCode = province.provinceCode
//        ),
//        fullEconomicActivity = data.fullEconomicActivity
//      )
//    }
//
//    def mapResponse( basicData: AffiliationBasicData ): AffiliationBasicDataResponse = {
//      val letterDeliveryDate: Option[ Date ] = basicData.letterDeliveryDate match {
//        case Some( date ) => Some( date.toDate )
//        case None         => None
//      }
//      val coverageStartDate: Option[ Date ] = basicData.coverageStartDate match {
//        case Some( date ) => Some( date.toDate )
//        case None         => None
//      }
//      val foundationDate: Option[ Date ] = basicData.foundationDate match {
//        case Some( date ) => Some( date.toDate )
//        case None         => None
//      }
//      AffiliationBasicDataResponse(
//        identificationType = basicData.contactInformation.identificationType,
//        identification = basicData.contactInformation.identification,
//        dni = basicData.dni,
//        fullName = basicData.contactInformation.name match {
//        case Some( e ) =>
//          Some( e )
//        case None =>
//          buildFullName(
//            name1 = basicData.contactInformation.name1,
//            name2 = basicData.contactInformation.name2,
//            lastname1 = basicData.contactInformation.lastname1,
//            lastname2 = basicData.contactInformation.lastname2
//          )
//      },
//        name1 = Some( basicData.contactInformation.name1 ),
//        name2 = basicData.contactInformation.name2,
//        lastname1 = Some( basicData.contactInformation.lastname1 ),
//        lastname2 = basicData.contactInformation.lastname2,
//        commercialName = basicData.commercialName,
//        isNewCompany = basicData.newCompany,
//        personType = basicData.personType,
//        juridicalNature = basicData.juridicalNature,
//        previousARL = basicData.previousARL,
//        commercialActivity = basicData.fullEconomicActivity.economicActivityId,
//        letterDeliveryDate = letterDeliveryDate,
//        coverageStartDate = coverageStartDate,
//        foundationDate = foundationDate,
//        mainAddressData = basicData.mainAddress,
//        mailAddressData = basicData.mailAddress,
//        bankInfoData = basicData.bankInformation,
//        contributor = basicData.contributorType,
//        provincesSelected = basicData.provincesSelected
//      )
//    }
//
//    private def buildFullName( name1: String, name2: Option[ String ], lastname1: String, lastname2: Option[ String ] ) = {
//      Some( s"$name1 ${name2.getOrElse( "" )} $lastname1 ${lastname2.getOrElse( "" )}" )
//    }
//  }
//  private[ BasicDataServiceHandlerSpecs ] class TestModule extends AbstractModule with ScalaModule with MockitoSugar {
//    import org.mockito.Mockito._
//    import GlobalData._
//    override def configure(): Unit = {
//      val repo = mock[ BasicDataRepository ]
//
//      //Mock de llamada a getByDni.
//      when {
//        repo.getByDni( "1234" )
//      } thenReturn {
//        Future.successful( Some( doc1 ) )
//      }
//
//      when {
//        repo.getByDni( "4321" )
//      } thenReturn {
//        Future.successful( None )
//      }
//
//      //Mock de llamada a updateByDni.
//      when {
//        repo.updateByDni( "1234", doc1Modified )
//      } thenReturn {
//        Future.successful( leOk )
//      }
//
//      //Mock de llamda a create.
//      when {
//        import org.mockito.Matchers._
//        repo.create( any[ AffiliationBasicData ] )( any[ ExecutionContext ] )
//      } thenReturn {
//        Future.successful( leOk )
//      }
//
//      bind[ BasicDataRepository ].toInstance( repo )
//    }
//  }
//
//  import GlobalData._
//  val injector = Guice.createInjector( new TestModule() )
//  val handler = injector.instance[ BasicDataServiceHandler ]
//
//  "A BasicDataHandler" should "get the basic data associated to a dni correctly" in {
//    handler.getBasicData( "1234" ) onSuccess {
//      case Right( rs ) =>
//        rs.data should be( Some( mapResponse( doc1 ) ) )
//        assert( rs.suraSessionManager.forall( _.nonEmpty ) )
//        rs.message should be( "Los datos básicos asociados al dni 1234 fueron cargados correctamente" )
//      case Left( _ ) => fail()
//    }
//
//    handler.getBasicData( "4321" ) onSuccess {
//      case Right( rs ) =>
//        rs.data should be( None )
//        assert( rs.suraSessionManager.forall( _.nonEmpty ) )
//        rs.message should be( "No existen datos básicos asociados al dni 4321" )
//      case Left( _ ) => fail()
//    }
//  }
//
//  it should "save the basic data associated to a dni correctly" in {
//    handler.saveBasicData( "1234", sabd1 ) onSuccess {
//      case Right( rs ) =>
//        rs.message should be( "Los datos básicos asociados al dni 1234 fueron guardados correctamente" )
//        assert( rs.suraSessionManager.forall( _.nonEmpty ) )
//        rs.data should be( None )
//      case Left( _ ) => fail()
//    }
//
//    handler.saveBasicData( "4321", sabd2 ) onSuccess {
//      case Right( rs ) =>
//        rs.message should be( "Los datos básicos asociados al dni 4321 fueron guardados correctamente" )
//        assert( rs.suraSessionManager.forall( _.nonEmpty ) )
//        rs.data should be( None )
//      case Left( _ ) => fail()
//    }
//  }
//}
