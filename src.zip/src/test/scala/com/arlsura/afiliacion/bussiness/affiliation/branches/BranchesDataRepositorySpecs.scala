//package com.arlsura.afiliacion.bussiness.affiliation.branches
//
//import com.arlsura.afiliacion.persistence.daos.affiliation.wrappers.AffiliationBranchesDataWrapper
//import com.arlsura.afiliacion.persistence.entities.affiliation.basic_data.Address
//import com.arlsura.afiliacion.persistence.entities.affiliation.branch_data.AffiliationBranchesData
//import com.arlsura.afiliacion.proceso.pasos.sucursales.BranchDataRepository
//import com.google.inject.{ Guice, AbstractModule }
//import net.codingwell.scalaguice.ScalaModule
//import org.scalatest.mock.MockitoSugar
//import org.scalatest.{ Matchers, FlatSpec }
//import reactivemongo.bson.{ BSONDocument, BSONObjectID }
//import reactivemongo.core.commands.LastError
//import net.codingwell.scalaguice.InjectorExtensions._
//import scala.concurrent.Future
//import scala.concurrent.ExecutionContext.Implicits.global
//
///**
// * Created by Jesús Martínez on 22/05/15.
// */
//class BranchesDataRepositorySpecs extends FlatSpec with Matchers {
//
//  private[ BranchesDataRepositorySpecs ] object GlobalData {
//    val id: BSONObjectID = BSONObjectID.generate
//    val id2: BSONObjectID = BSONObjectID.generate
//    val leOK = LastError( ok = true, None, None, None, None, -1, false )
//    val abdd1 = AffiliationBranchesData(
//      _id = id,
//      branchID = "1",
//      securityCode = None,
//      dni = "1234",
//      branchCode = "A1",
//      branchName = "test branch",
//      branchAddressData = Address( "CUNDINAMARCA", "BOGOTA", "CALLE", "1", None, None, None, None, None, None, None ),
//      email = "test@test.tst",
//      phone = None,
//      contact = None
//    )
//    val abdd1Modified = AffiliationBranchesData(
//      _id = id,
//      dni = abdd1.dni,
//      branchID = abdd1.branchID,
//      securityCode = Some( "ABC" ),
//      branchAddressData = abdd1.branchAddressData,
//      branchName = abdd1.branchName,
//      branchCode = abdd1.branchCode,
//      email = abdd1.email,
//      phone = abdd1.phone
//    )
//    val abdd2 = AffiliationBranchesData(
//      _id = id2,
//      branchID = "2",
//      securityCode = None,
//      dni = "1234",
//      branchCode = "A2",
//      branchName = "example branch",
//      branchAddressData = Address( "CUNDINAMARCA", "BOGOTA", "CALLE", "1", None, None, None, None, None, None, None ),
//      email = "test@test.tst",
//      phone = None,
//      contact = None
//    )
//  }
//
//  private[ BranchesDataRepositorySpecs ] class TestModule extends AbstractModule with ScalaModule with MockitoSugar {
//    import org.mockito.Mockito._
//    import GlobalData._
//    override def configure(): Unit = {
//      val wrapper: AffiliationBranchesDataWrapper = mock[ AffiliationBranchesDataWrapper ]
//
//      //Mock de llamada a insert.
//      when {
//        wrapper.insert( abdd1 )
//      } thenReturn {
//        Future.successful( leOK )
//      }
//
//      //Mock de llamada a update.
//      when {
//        wrapper.update( BSONDocument( "dni" -> "1234", "branchID" -> "1" ), abdd1Modified )
//      } thenReturn {
//        Future.successful( leOK )
//      }
//
//      //Mocks de llamada a findAll
//      when {
//        wrapper.findAll( BSONDocument( "dni" -> "1234" ) )
//      } thenReturn {
//        Future.successful( List( abdd1, abdd2 ) )
//      }
//
//      when {
//        wrapper.findAll( BSONDocument( "dni" -> "4321" ) )
//      } thenReturn {
//        Future.successful( Nil )
//      }
//
//      //Mocks de llamadas a findOne
//      when {
//        wrapper.findOne( BSONDocument( "dni" -> "1234", "branchID" -> "1" ) )
//      } thenReturn {
//        Future.successful( Some( abdd1 ) )
//      }
//
//      when {
//        wrapper.findOne( BSONDocument( "dni" -> "1234", "branchID" -> "3" ) )
//      } thenReturn {
//        Future.successful( None )
//      }
//
//      bind[ AffiliationBranchesDataWrapper ].toInstance( wrapper )
//    }
//  }
//
//  val injector = Guice.createInjector( new TestModule() )
//  val repo: BranchDataRepository = injector.instance[ BranchDataRepository ]
//
//  "A BranchDataRepository" should "insert a new document" in {
//    repo.create( GlobalData.abdd1 ) onSuccess {
//      case status => assert( status.ok )
//    }
//  }
//
//  it should "update a document" in {
//    repo.update( "1234", "1", GlobalData.abdd1Modified ) onSuccess {
//      case status => assert( status.ok )
//    }
//  }
//
//  it should "find all the branches related to a dni number" in {
//    repo.findByDni( "1234" ) onSuccess {
//      case rs => rs should be( List( GlobalData.abdd1, GlobalData.abdd2 ) )
//    }
//
//    repo.findByDni( "4321" ) onSuccess {
//      case rs => assert( rs.isEmpty )
//    }
//  }
//
//  it should "find a branch by dni and branch id" in {
//    repo.get( "1234", "1" ) onSuccess {
//      case Some( b ) => b should be( GlobalData.abdd1 )
//      case None      => fail()
//    }
//
//    repo.get( "1234", "3" ) onSuccess {
//      case Some( _ ) => fail()
//      case None      => assert( true )
//    }
//  }
//}
