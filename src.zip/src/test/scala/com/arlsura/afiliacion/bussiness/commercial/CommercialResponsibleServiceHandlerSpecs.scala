//package com.arlsura.afiliacion.bussiness.commercial
//
//import com.arlsura.afiliacion.bussiness.commercial.responsible.CommercialResponsibleManager
//import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.{ CreateCommercialResponsibleRequest, UpdateCommercialResponsibleRequest, GetCommercialResponsibleRequest }
//import com.arlsura.afiliacion.persistence.entities.CommercialResponsible
//import com.arlsura.afiliacion.services.commercial.CommercialResponsibleServiceHandler
//import com.arlsura.afiliacion.utils.messages.MessagesRetriever
//import com.google.inject.{ Guice, AbstractModule }
//import net.codingwell.scalaguice.ScalaModule
//import org.scalatest.mock.MockitoSugar
//import org.scalatest.{ Matchers, FlatSpec }
//import reactivemongo.bson.{ BSONDocument, BSONObjectID }
//import reactivemongo.core.commands.LastError
//import scala.concurrent.ExecutionContext.Implicits.global
//import net.codingwell.scalaguice.InjectorExtensions._
//import scala.concurrent.Future
//
///**
// * Created by Jesús Martínez on 18/06/15.
// */
//class CommercialResponsibleServiceHandlerSpecs extends FlatSpec with Matchers {
//  private[ CommercialResponsibleServiceHandlerSpecs ] object GlobalData {
//    val ( id1, id2, id3 ) = ( BSONObjectID.generate, BSONObjectID.generate, BSONObjectID.generate )
//    val req1 = GetCommercialResponsibleRequest( city = Some( "Bogotá" ), email = Some( "test@test.tst" ) )
//    val req2 = GetCommercialResponsibleRequest( city = Some( "Bogotá" ), email = Some( "prueba@prueba.prb" ) )
//    val req3 = UpdateCommercialResponsibleRequest( id = id1.stringify, office = Some( 1 ) )
//    val req4 = CreateCommercialResponsibleRequest( 3, "Cogua", "N N A A", "mail@mail.com", "Mayor", "user3" )
//    val doc1 = CommercialResponsible( _id = id1, city = "Bogotá", fullName = "Name Name Lastname Lastname", email = "test@test.tst", charge = "Hero", networkUser = "user1", office = 1 )
//    val doc2 = CommercialResponsible( _id = id2, city = "Medellín", fullName = "Nombre Nombre Apellido Apellido", email = "prueba@prueba.prb", charge = "Manager", networkUser = "user2", office = 2 )
//    val leOK = LastError( true, None, None, None, None, -1, false )
//
//    def formattedResponse( response: CommercialResponsible ): Map[ String, Any ] =
//      Map(
//        "id" -> response._id.stringify,
//        "office" -> response.office,
//        "city" -> response.city,
//        "fullName" -> response.fullName,
//        "email" -> response.email,
//        "charge" -> response.charge,
//        "networkUser" -> response.networkUser
//      )
//
//    def commercialResponsibleCreateMessage: String = MessagesRetriever.getSuccessMessage( "commercial_responsible", "CREATE" )
//
//    def commercialResponsibleGetAllMessage: String = MessagesRetriever.getSuccessMessage( "commercial_responsible", "GET_ALL" )
//
//    def commercialResponsibleGetByMessage: String = MessagesRetriever.getSuccessMessage( "commercial_responsible", "GET_BY" )
//
//    def commercialResponsibleGetByIdMessage: String = MessagesRetriever.getSuccessMessage( "commercial_responsible", "GET_BY_ID" )
//
//    def commercialResponsibleUpdateMessage: String = MessagesRetriever.getSuccessMessage( "commercial_responsible", "UPDATE" )
//
//    def commercialResponsibleDeleteAllMessage: String = MessagesRetriever.getSuccessMessage( "commercial_responsible", "DELETE_ALL" )
//
//    def commercialResponsibleDeleteByIdMessage: String = MessagesRetriever.getSuccessMessage( "commercial_responsible", "DELETE_BY_ID" )
//  }
//
//  private[ CommercialResponsibleServiceHandlerSpecs ] class TestModule extends AbstractModule with ScalaModule with MockitoSugar {
//    import GlobalData._
//    import org.mockito.Mockito._
//
//    override def configure(): Unit = {
//      val manager = mock[ CommercialResponsibleManager ]
//
//      when {
//        manager.getAll()
//      } thenReturn {
//        Future.successful( List( doc1, doc2 ) )
//      }
//
//      when {
//        manager.create( req4 )
//      } thenReturn {
//        Future.successful( leOK )
//      }
//
//      when {
//        manager.getBy( req1 )
//      } thenReturn {
//        Future.successful( List( doc1 ) )
//      }
//
//      when {
//        manager.getById( id1.stringify )
//      } thenReturn {
//        Future.successful( Some( doc1 ) )
//      }
//
//      when {
//        manager.deleteAll()
//      } thenReturn {
//        Future.successful( leOK )
//      }
//
//      when {
//        manager.deleteById( id3.stringify )
//      } thenReturn {
//        Future.successful( leOK )
//      }
//
//      when {
//        manager.update( req3 )
//      } thenReturn {
//        Future.successful( leOK )
//      }
//
//      bind[ CommercialResponsibleManager ].toInstance( manager )
//    }
//  }
//
//  import GlobalData._
//  lazy val injector = Guice.createInjector( new TestModule() )
//  lazy val manager = injector.instance[ CommercialResponsibleServiceHandler ]
//
//  "A CommercialResponsibleServiceHandler" should "create a new document" in {
//    manager.create( req4 ) onSuccess {
//      case Right( r ) =>
//        r.data should be( None )
//        r.message should be( commercialResponsibleCreateMessage )
//      case Left( _ ) => fail()
//    }
//  }
//
//  it should "update an existing document" in {
//    manager.update( req3 ) onSuccess {
//      case Right( r ) =>
//        r.data should be( None )
//        r.message should be( commercialResponsibleUpdateMessage )
//      case Left( _ ) =>
//        fail()
//    }
//  }
//
//  it should "delete all the documents" in {
//    manager.deleteAll() onSuccess {
//      case Right( r ) =>
//        r.data should be( None )
//        r.message should be( commercialResponsibleDeleteAllMessage )
//      case Left( _ ) => fail()
//    }
//  }
//
//  it should "delete a document by its id" in {
//    manager.deleteById( id3.stringify ) onSuccess {
//      case Right( r ) =>
//        r.data should be( None )
//        r.message should be( commercialResponsibleDeleteByIdMessage )
//      case Left( _ ) => fail()
//    }
//  }
//
//  it should "retrieve all the documents" in {
//    manager.getAll() onSuccess {
//      case Right( r ) =>
//        r.data should be( Some( List( formattedResponse( doc1 ), formattedResponse( doc2 ) ) ) )
//        r.message should be( commercialResponsibleGetAllMessage )
//      case Left( _ ) => fail()
//    }
//  }
//
//  it should "get documents by certain search parameters" in {
//    manager.getBy( req1 ) onSuccess {
//      case Right( r ) =>
//        r.data should be( Some( List( formattedResponse( doc1 ) ) ) )
//        r.message should be( commercialResponsibleGetByMessage )
//      case Left( _ ) =>
//        fail()
//    }
//  }
//
//  it should "get a document by its id" in {
//    manager.getById( id1.stringify ) onSuccess {
//      case Right( r ) =>
//        r.data should be( Some( formattedResponse( doc1 ) ) )
//        r.message should be( commercialResponsibleGetByIdMessage )
//      case Left( _ ) => fail()
//    }
//  }
//
//}
