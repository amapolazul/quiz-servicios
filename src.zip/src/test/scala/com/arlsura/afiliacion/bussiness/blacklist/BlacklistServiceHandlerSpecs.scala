//package com.arlsura.afiliacion.bussiness.blacklist
//
//import java.util.Date
//
//import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.{ BlacklistEntryResponse, BlacklistEntry }
//import com.arlsura.afiliacion.persistence.blacklist.Blacklist
//import com.arlsura.afiliacion.utils.messages.MessagesRetriever
//import com.google.inject.{ Guice, AbstractModule }
//import net.codingwell.scalaguice.ScalaModule
//import org.joda.time.DateTime
//import org.scalatest.mock.MockitoSugar
//import org.scalatest.{ Matchers, FlatSpec }
//import net.codingwell.scalaguice.InjectorExtensions._
//import reactivemongo.core.commands.LastError
//import scala.concurrent.ExecutionContext.Implicits.global
//import scala.concurrent.Future
//
///**
// * Created by Jesús Martínez on 9/06/15.
// */
//class BlacklistServiceHandlerSpecs extends FlatSpec with Matchers {
//
//  private[ BlacklistServiceHandlerSpecs ] object GlobalData {
//    val date = new Date().getTime
//    val elem1 = Blacklist( dni = "1234", factor = .5, since = new DateTime() )
//    val entryResponse = BlacklistEntryResponse( elem1.dni, elem1.factor, elem1.since.toDate.getTime, elem1.calculateBlockEnd.toDate.getTime )
//    val entry = BlacklistEntry( "5678", 1f, date )
//    val leOk = LastError( ok = true, err = None, code = None, errMsg = None, originalDocument = None, updated = -1, updatedExisting = false )
//    val getEntrySuccessMessage: String = MessagesRetriever.getSuccessMessage( "blacklist", "GET" )
//    val noEntrySuccessMessage: String = MessagesRetriever.getSuccessMessage( "blacklist", "NO_ENTRY" )
//    val saveEntrySuccessMessage: String = MessagesRetriever.getSuccessMessage( "blacklist", "SAVE" )
//  }
//
//  private[ BlacklistServiceHandlerSpecs ] class TestModule extends AbstractModule with ScalaModule with MockitoSugar {
//    import org.mockito.Mockito._
//    override def configure(): Unit = {
//      val repo = mock[ BlacklistRepository ]
//
//      when {
//        repo.findByDni( "1234" )
//      } thenReturn {
//        Future.successful( Some( GlobalData.elem1 ) )
//      }
//
//      when {
//        repo.findByDni( "4321" )
//      } thenReturn {
//        Future.successful( None )
//      }
//
//      when {
//        repo.save( "5678", GlobalData.date, 1f )
//      } thenReturn {
//        Future.successful( GlobalData.leOk )
//      }
//
//      bind[ BlacklistRepository ].toInstance( repo )
//    }
//  }
//
//  val injector = Guice.createInjector( new TestModule() )
//  val handler = injector.instance[ BlacklistServiceHandler ]
//
//  "A BlacklistServiceHandler" should "save an entry in the list" in {
//    handler.save( GlobalData.entry ) onSuccess {
//      case Right( rs ) =>
//        assert( rs.suraSessionManager.forall( _.nonEmpty ) )
//        rs.message should be( GlobalData.saveEntrySuccessMessage )
//        rs.data should be( None )
//      case Left( _ ) => fail()
//    }
//  }
//
//  it should "retrieve the most recent entry related to a given dni" in {
//    handler.get( "1234" ) onSuccess {
//      case Right( rs ) =>
//        assert( rs.suraSessionManager.forall( _.nonEmpty ) )
//        rs.message should be( GlobalData.getEntrySuccessMessage )
//        rs.data.get.asInstanceOf[ BlacklistEntryResponse ] should be( GlobalData.entryResponse )
//      case Left( _ ) => fail()
//    }
//
//    handler.get( "4321" ) onSuccess {
//      case Right( rs ) =>
//        assert( rs.suraSessionManager.forall( _.nonEmpty ) )
//        rs.message should be( GlobalData.noEntrySuccessMessage )
//        rs.data should be( None )
//      case Left( _ ) => fail()
//    }
//  }
//
//}
