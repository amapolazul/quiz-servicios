//package com.arlsura.afiliacion.bussiness.affiliation.branches
//
//import com.arlsura.afiliacion.persistence.entities.affiliation.basic_data.Address
//import com.arlsura.afiliacion.persistence.entities.affiliation.branch_data.AffiliationBranchesData
//import com.arlsura.afiliacion.proceso.pasos.sucursales.BranchDataMarshaller.BranchData
//import com.arlsura.afiliacion.proceso.pasos.sucursales.{ BranchDataServiceHandler, BranchDataRepository }
//import com.google.inject.{ Guice, AbstractModule }
//import net.codingwell.scalaguice.ScalaModule
//import org.scalatest.mock.MockitoSugar
//import org.scalatest.{ Matchers, FlatSpec }
//import reactivemongo.bson.{ BSONDocument, BSONObjectID }
//import reactivemongo.core.commands.LastError
//import net.codingwell.scalaguice.InjectorExtensions._
//import scala.concurrent.{ ExecutionContext, Future }
//import scala.concurrent.ExecutionContext.Implicits.global
//
///**
// * Created by Jesús Martínez on 22/05/15.
// */
//class BranchesDataServiceHandlerSpecs extends FlatSpec with Matchers {
//
//  private[ BranchesDataServiceHandlerSpecs ] object GlobalData {
//    val id: BSONObjectID = BSONObjectID.generate
//    val id2: BSONObjectID = BSONObjectID.generate
//    val leOK = LastError( ok = true, None, None, None, None, -1, false )
//    val abdd1 = AffiliationBranchesData(
//      _id = id,
//      branchID = "1",
//      securityCode = None,
//      dni = "1234",
//      branchCode = "A1",
//      branchName = "test branch",
//      branchAddressData = Address( "CUNDINAMARCA", "BOGOTA", "CALLE", "1", None, None, None, None, None, None, None ),
//      email = "test@test.tst",
//      phone = None,
//      contact = None
//    )
//    val abdd1Modified = AffiliationBranchesData(
//      _id = id,
//      dni = abdd1.dni,
//      branchID = abdd1.branchID,
//      securityCode = Some( "ABC" ),
//      branchAddressData = abdd1.branchAddressData,
//      branchName = abdd1.branchName,
//      branchCode = abdd1.branchCode,
//      email = abdd1.email,
//      phone = abdd1.phone
//    )
//    val abdd2 = AffiliationBranchesData(
//      _id = id2,
//      branchID = "2",
//      securityCode = None,
//      dni = "1234",
//      branchCode = "A2",
//      branchName = "example branch",
//      branchAddressData = Address( "CUNDINAMARCA", "BOGOTA", "CALLE", "1", None, None, None, None, None, None, None ),
//      email = "test@test.tst",
//      phone = None,
//      contact = None
//    )
//  }
//  private[ BranchesDataServiceHandlerSpecs ] class TestModule extends AbstractModule with ScalaModule with MockitoSugar {
//    import org.mockito.Mockito._
//    import org.mockito.Matchers._
//    import GlobalData._
//    override def configure(): Unit = {
//      val repo = mock[ BranchDataRepository ]
//
//      when {
//        repo.findByDni( "1234" )
//      } thenReturn {
//        Future.successful( List( abdd1, abdd2 ) )
//      }
//
//      when {
//        repo.findByDni( "4321" )
//      } thenReturn {
//        Future.successful( Nil )
//      }
//
//      when {
//        repo.get( "1234", "1" )
//      } thenReturn {
//        Future.successful( None )
//      }
//
//      when {
//        repo.get( "1234", "3" )
//      } thenReturn {
//        Future.successful( None )
//      }
//
//      when {
//        //        repo.create(AffiliationBranchesData(
//        //          branchID = "1",
//        //          securityCode = None,
//        //          dni = "1234",
//        //          branchCode = "A1",
//        //          branchName = "test branch",
//        //          branchAddressData =  Address("CUNDINAMARCA", "BOGOTA", "CALLE", 1, None, None, None, None, None, None),
//        //          email = "test@test.tst",
//        //          phone = None,
//        //          contact = None
//        //        ))
//        //Esto se hace porque se crea en tiempo real el ID del registro.
//        repo.create( any[ AffiliationBranchesData ] )( any[ ExecutionContext ] )
//      } thenReturn {
//        Future.successful( leOK )
//      }
//
//      when {
//        repo.update( "1234", "1", abdd1Modified )
//      } thenReturn {
//        Future.successful( leOK )
//      }
//
//      bind[ BranchDataRepository ].toInstance( repo )
//    }
//  }
//
//  import GlobalData._
//  val injector = Guice.createInjector( new TestModule() )
//  val handler = injector.instance[ BranchDataServiceHandler ]
//
//  "A BranchesDataRepository" should "get branches data" in {
//    handler.getBranchesData( "1234" ) onSuccess {
//      case Right( rs ) =>
//        rs.data should be( Some( List( GlobalData.abdd1, GlobalData.abdd2 ) ) )
//        rs.message should be( "Las sucursales fueron cargadas correctamente" )
//      case Left( _ ) => fail()
//    }
//  }
//
//  it should "save branches data" in {
//    handler.saveBranchData( "1234", BranchData(
//      abdd1.branchID,
//      abdd1.branchCode,
//      abdd1.branchName,
//      abdd1.branchAddressData,
//      abdd1.email,
//      abdd1.phone,
//      abdd1.contact
//    ) ) onSuccess {
//      case Right( rs ) =>
//        rs.message should be( s"La sucursal 1 fue guardada correctamente. (dni 1234)" )
//        assert( rs.suraSessionManager.forall( _.nonEmpty ) )
//      case Left( _ ) => fail()
//    }
//
//    handler.saveBranchData( "1234", BranchData(
//      abdd1Modified.branchID,
//      abdd1Modified.branchCode,
//      abdd1Modified.branchName,
//      abdd1Modified.branchAddressData,
//      abdd1Modified.email,
//      abdd1Modified.phone,
//      abdd1Modified.contact
//    ) ) onSuccess {
//      case Right( rs ) =>
//        rs.message should be( s"La sucursal 1 fue guardada correctamente. (dni 1234)" )
//        assert( rs.suraSessionManager.forall( _.nonEmpty ) )
//      case Left( _ ) => fail()
//    }
//  }
//}
