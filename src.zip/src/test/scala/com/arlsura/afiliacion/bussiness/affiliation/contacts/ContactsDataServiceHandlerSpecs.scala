//package com.arlsura.afiliacion.bussiness.affiliation.contacts
//
//import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.{ ContactInformationData, SaveContactInformation }
//import com.arlsura.afiliacion.persistence.entities.affiliation.contacts_data.{ AffiliationContactsData, ContactInformation }
//import com.arlsura.afiliacion.utils.messages.MessagesRetriever
//import com.google.inject.{ AbstractModule, Guice }
//import net.codingwell.scalaguice.InjectorExtensions._
//import net.codingwell.scalaguice.ScalaModule
//import org.scalatest.mock.MockitoSugar
//import org.scalatest.{ FlatSpec, Matchers }
//import reactivemongo.bson.BSONObjectID
//import reactivemongo.core.commands.LastError
//
//import scala.concurrent.ExecutionContext.Implicits.global
//import scala.concurrent.{ ExecutionContext, Future }
//
///**
// * Created by Jesús Martínez on 22/05/15.
// */
//class ContactsDataServiceHandlerSpecs extends FlatSpec with Matchers {
//
//  private[ ContactsDataServiceHandlerSpecs ] object GlobalData {
//    val id = BSONObjectID.generate
//    val contact = AffiliationContactsData( _id = id, dni = "1234", legalRepresentative = new ContactInformation() )
//    val contactModified = AffiliationContactsData( _id = id, dni = "1234", legalRepresentative = new ContactInformation(), manager = ContactInformation( identification = "473060" ) )
//    val leOk = LastError( true, None, None, None, None, 1, false )
//
//    //mensajes de error y de exito para las respuestas
//    val getContactsInfoSuccessMessage: String = MessagesRetriever.getSuccessMessage( "affiliation.contacts", "GET_BY_ID" )
//    val createContactsInfoSuccessMessage: String = MessagesRetriever.getSuccessMessage( "affiliation.contacts", "CREATE" )
//    val updateContactsInfoSuccessMessage: String = MessagesRetriever.getSuccessMessage( "affiliation.contacts", "UPDATE" )
//    val emptyContactsInfoMessage: String = MessagesRetriever.getSuccessMessage( "affiliation.contacts", "EMPTY" )
//  }
//
//  private[ ContactsDataServiceHandlerSpecs ] class TestModule extends AbstractModule with ScalaModule with MockitoSugar {
//    import GlobalData._
//    import org.mockito.Matchers._
//    import org.mockito.Mockito._
//
//    override def configure(): Unit = {
//      val repo = mock[ ContactDataRepository ]
//
//      when {
//        repo.findByDni( "1234" )
//      } thenReturn {
//        Future.successful( Some( contact ) )
//      }
//
//      when {
//        repo.updateByDni( contactModified, "1234" )
//      } thenReturn {
//        Future.successful( leOk )
//      }
//
//      when {
//        repo.findByDni( "4321" )
//      } thenReturn {
//        Future.successful( None )
//      }
//
//      when {
//        repo.create( any[ AffiliationContactsData ] )( any[ ExecutionContext ] )
//      } thenReturn {
//        Future.successful( leOk )
//      }
//
//      bind[ ContactDataRepository ].toInstance( repo )
//    }
//  }
//
//  val injector = Guice.createInjector( new TestModule() )
//  val handler = injector.instance[ ContactsServiceHandler ]
//
//  import GlobalData._
//  "A ContactsDataServiceHandler" should "retrieve the contacts information properly" in {
//    handler.getContactsInfo( "1234" ) onSuccess {
//      case Right( rs ) =>
//        rs.data should be( Some( contact ) )
//        assert( rs.suraSessionManager.forall( _.nonEmpty ) )
//        rs.message should be( GlobalData.getContactsInfoSuccessMessage )
//      case Left( _ ) => fail()
//    }
//
//    handler.getContactsInfo( "4321" ) onSuccess {
//      case Right( rs ) =>
//        rs.data should be( None )
//        assert( rs.suraSessionManager.forall( _.nonEmpty ) )
//        rs.message should be( emptyContactsInfoMessage )
//    }
//  }
//
//  it should "save the contacts information properly" in {
//    val sci = SaveContactInformation(
//      dni = contactModified.dni,
//      securityCode = contactModified.securityCode,
//      legalRepresentative = ContactInformationData(
//        email = contact.legalRepresentative.email,
//        identification = contact.legalRepresentative.identification,
//        identificationType = contact.legalRepresentative.identificationType,
//        lastname1 = contact.legalRepresentative.lastname1,
//        lastname2 = contact.legalRepresentative.lastname2,
//        name1 = contact.legalRepresentative.name1,
//        name2 = contact.legalRepresentative.name2,
//        phone = contact.legalRepresentative.phone,
//        position = contact.legalRepresentative.position,
//        title = contact.legalRepresentative.title
//      ),
//      manager = ContactInformationData(
//        email = contact.manager.email,
//        identification = contact.manager.identification,
//        identificationType = contact.manager.identificationType,
//        lastname1 = contact.manager.lastname1,
//        lastname2 = contact.manager.lastname2,
//        name1 = contact.manager.name1,
//        name2 = contact.manager.name2,
//        phone = contact.manager.phone,
//        position = contact.manager.position,
//        title = contact.manager.title
//      ),
//      humanResourcesRepresentative = ContactInformationData(
//        email = contact.humanResourcesRepresentative.email,
//        identification = contact.humanResourcesRepresentative.identification,
//        identificationType = contact.humanResourcesRepresentative.identificationType,
//        lastname1 = contact.humanResourcesRepresentative.lastname1,
//        lastname2 = contact.humanResourcesRepresentative.lastname2,
//        name1 = contact.humanResourcesRepresentative.name1,
//        name2 = contact.humanResourcesRepresentative.name2,
//        phone = contact.humanResourcesRepresentative.phone,
//        position = contact.humanResourcesRepresentative.position,
//        title = contact.humanResourcesRepresentative.title
//      ), rosterRepresentative = ContactInformationData(
//        email = contact.rosterRepresentative.email,
//        identification = contact.rosterRepresentative.identification,
//        identificationType = contact.rosterRepresentative.identificationType,
//        lastname1 = contact.rosterRepresentative.lastname1,
//        lastname2 = contact.rosterRepresentative.lastname2,
//        name1 = contact.rosterRepresentative.name1,
//        name2 = contact.rosterRepresentative.name2,
//        phone = contact.rosterRepresentative.phone,
//        position = contact.rosterRepresentative.position,
//        title = contact.rosterRepresentative.title
//      ), insideTrainingRepresentative = ContactInformationData(
//        email = contact.insideTrainingRepresentative.email,
//        identification = contact.insideTrainingRepresentative.identification,
//        identificationType = contact.insideTrainingRepresentative.identificationType,
//        lastname1 = contact.insideTrainingRepresentative.lastname1,
//        lastname2 = contact.insideTrainingRepresentative.lastname2,
//        name1 = contact.insideTrainingRepresentative.name1,
//        name2 = contact.insideTrainingRepresentative.name2,
//        phone = contact.insideTrainingRepresentative.phone,
//        position = contact.insideTrainingRepresentative.position,
//        title = contact.insideTrainingRepresentative.title
//      ), workSafetyRepresentative = ContactInformationData(
//        email = contact.workSafetyRepresentative.email,
//        identification = contact.workSafetyRepresentative.identification,
//        identificationType = contact.workSafetyRepresentative.identificationType,
//        lastname1 = contact.workSafetyRepresentative.lastname1,
//        lastname2 = contact.workSafetyRepresentative.lastname2,
//        name1 = contact.workSafetyRepresentative.name1,
//        name2 = contact.workSafetyRepresentative.name2,
//        phone = contact.workSafetyRepresentative.phone,
//        position = contact.workSafetyRepresentative.position,
//        title = contact.workSafetyRepresentative.title
//      )
//    )
//    val sci2 =
//      SaveContactInformation(
//        dni = "4321",
//        securityCode = contactModified.securityCode,
//        legalRepresentative = ContactInformationData(
//          email = contact.legalRepresentative.email,
//          identification = contact.legalRepresentative.identification,
//          identificationType = contact.legalRepresentative.identificationType,
//          lastname1 = contact.legalRepresentative.lastname1,
//          lastname2 = contact.legalRepresentative.lastname2,
//          name1 = contact.legalRepresentative.name1,
//          name2 = contact.legalRepresentative.name2,
//          phone = contact.legalRepresentative.phone,
//          position = contact.legalRepresentative.position,
//          title = contact.legalRepresentative.title
//        ),
//        manager = ContactInformationData(
//          email = contact.manager.email,
//          identification = contact.manager.identification,
//          identificationType = contact.manager.identificationType,
//          lastname1 = contact.manager.lastname1,
//          lastname2 = contact.manager.lastname2,
//          name1 = contact.manager.name1,
//          name2 = contact.manager.name2,
//          phone = contact.manager.phone,
//          position = contact.manager.position,
//          title = contact.manager.title
//        ),
//        humanResourcesRepresentative = ContactInformationData(
//          email = contact.humanResourcesRepresentative.email,
//          identification = contact.humanResourcesRepresentative.identification,
//          identificationType = contact.humanResourcesRepresentative.identificationType,
//          lastname1 = contact.humanResourcesRepresentative.lastname1,
//          lastname2 = contact.humanResourcesRepresentative.lastname2,
//          name1 = contact.humanResourcesRepresentative.name1,
//          name2 = contact.humanResourcesRepresentative.name2,
//          phone = contact.humanResourcesRepresentative.phone,
//          position = contact.humanResourcesRepresentative.position,
//          title = contact.humanResourcesRepresentative.title
//        ), rosterRepresentative = ContactInformationData(
//          email = contact.rosterRepresentative.email,
//          identification = contact.rosterRepresentative.identification,
//          identificationType = contact.rosterRepresentative.identificationType,
//          lastname1 = contact.rosterRepresentative.lastname1,
//          lastname2 = contact.rosterRepresentative.lastname2,
//          name1 = contact.rosterRepresentative.name1,
//          name2 = contact.rosterRepresentative.name2,
//          phone = contact.rosterRepresentative.phone,
//          position = contact.rosterRepresentative.position,
//          title = contact.rosterRepresentative.title
//        ), insideTrainingRepresentative = ContactInformationData(
//          email = contact.insideTrainingRepresentative.email,
//          identification = contact.insideTrainingRepresentative.identification,
//          identificationType = contact.insideTrainingRepresentative.identificationType,
//          lastname1 = contact.insideTrainingRepresentative.lastname1,
//          lastname2 = contact.insideTrainingRepresentative.lastname2,
//          name1 = contact.insideTrainingRepresentative.name1,
//          name2 = contact.insideTrainingRepresentative.name2,
//          phone = contact.insideTrainingRepresentative.phone,
//          position = contact.insideTrainingRepresentative.position,
//          title = contact.insideTrainingRepresentative.title
//        ), workSafetyRepresentative = ContactInformationData(
//          email = contact.workSafetyRepresentative.email,
//          identification = contact.workSafetyRepresentative.identification,
//          identificationType = contact.workSafetyRepresentative.identificationType,
//          lastname1 = contact.workSafetyRepresentative.lastname1,
//          lastname2 = contact.workSafetyRepresentative.lastname2,
//          name1 = contact.workSafetyRepresentative.name1,
//          name2 = contact.workSafetyRepresentative.name2,
//          phone = contact.workSafetyRepresentative.phone,
//          position = contact.workSafetyRepresentative.position,
//          title = contact.workSafetyRepresentative.title
//        )
//      )
//    println( "Previo enviar... " )
//    //assert(3 === 2)
//    //    handler.createOrUpdateContactsInfo( sci, "1234" ) onSuccess {
//    //      case Right( rs ) =>
//    //
//    //        println("Mensaje: "+ rs.message)
//    //        rs.message should be( updateContactsInfoSuccessMessage )
//    //        assert( rs.suraSessionManager.forall( _.nonEmpty ) )
//    //        assert(3 === 2)
//    //      case Left( _ ) => fail()
//    //    }
//    //
//    //    handler.createOrUpdateContactsInfo( sci2, "4321" ) onSuccess {
//    //      case Right( rs ) =>
//    //        rs.message should be( createContactsInfoSuccessMessage )
//    //        assert( rs.suraSessionManager.forall( _.nonEmpty ) )
//    //    }
//  }
//}
