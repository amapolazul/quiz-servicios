//package com.arlsura.afiliacion.bussiness.affiliation.contacts
//
//import com.arlsura.afiliacion.persistence.daos.affiliation.wrappers.AffiliationContactsDataWrapper
//import com.arlsura.afiliacion.persistence.entities.affiliation.contacts_data.{ ContactInformation, AffiliationContactsData }
//import com.google.inject.{ Guice, AbstractModule }
//import net.codingwell.scalaguice.ScalaModule
//import org.scalatest.mock.MockitoSugar
//import org.scalatest.{ Matchers, FlatSpec }
//import reactivemongo.bson.{ BSONDocument, BSONObjectID }
//import reactivemongo.core.commands.LastError
//import net.codingwell.scalaguice.InjectorExtensions._
//import scala.concurrent.Future
//import scala.concurrent.ExecutionContext.Implicits.global
//
///**
// * Created by Jesús Martínez on 22/05/15.
// */
//
//class ContactsDataRepositorySpecs extends FlatSpec with Matchers {
//  private[ ContactsDataRepositorySpecs ] object GlobalData {
//    val id = BSONObjectID.generate
//    val contact = AffiliationContactsData( _id = id, dni = "1234", legalRepresentative = new ContactInformation() )
//    val contactModified = AffiliationContactsData( _id = id, dni = "1234", legalRepresentative = new ContactInformation(), manager = ContactInformation( identification = "473060" ) )
//    val leOk = LastError( true, None, None, None, None, 1, false )
//  }
//
//  private[ ContactsDataRepositorySpecs ] class TestModule extends AbstractModule with ScalaModule with MockitoSugar {
//    import org.mockito.Mockito._
//
//    override def configure(): Unit = {
//      val wrapper = mock[ AffiliationContactsDataWrapper ]
//
//      when {
//        wrapper.findOne( BSONDocument( "dni" -> "1234" ) )
//      } thenReturn {
//        Future.successful( Some( GlobalData.contact ) )
//      }
//
//      when {
//        wrapper.findOne( BSONDocument( "dni" -> "4321" ) )
//      } thenReturn {
//        Future.successful( None )
//      }
//
//      when {
//        wrapper.insert( GlobalData.contact )
//      } thenReturn {
//        Future.successful( GlobalData.leOk )
//      }
//
//      when {
//        wrapper.update( BSONDocument( "dni" -> "1234" ), GlobalData.contactModified )
//      } thenReturn {
//        Future.successful( GlobalData.leOk )
//      }
//
//      bind[ AffiliationContactsDataWrapper ].toInstance( wrapper )
//    }
//  }
//
//  val injector = Guice.createInjector( new TestModule() )
//  val repo = injector.instance[ ContactDataRepository ]
//
//  "A ContactsDataRepository" should "be able to find a document by dni" in {
//    repo.findByDni( "1234" ) onSuccess {
//      case Some( c ) => c should be( GlobalData.contact )
//      case None      => fail()
//    }
//
//    repo.findByDni( "4321" ) onSuccess {
//      case Some( _ ) => fail()
//      case None      => assert( true )
//    }
//  }
//
//  it should "update a document without troubles" in {
//    repo.updateByDni( GlobalData.contactModified, "1234" ) onSuccess {
//      case rs => assert( rs.ok )
//    }
//  }
//
//  it should "create a document without problems" in {
//    repo.create( GlobalData.contact ) onSuccess {
//      case rs => assert( rs.ok )
//    }
//  }
//}
