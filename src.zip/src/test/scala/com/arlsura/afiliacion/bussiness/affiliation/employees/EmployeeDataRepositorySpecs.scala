//package com.arlsura.afiliacion.bussiness.affiliation.employees
//
//import com.arlsura.afiliacion.persistence.daos.affiliation.wrappers.AffiliationEmployeesDataWrapper
//import com.arlsura.afiliacion.persistence.entities.affiliation.employee_data.AffiliationEmployeesData
//import com.google.inject.{ Guice, AbstractModule }
//import net.codingwell.scalaguice.ScalaModule
//import org.scalatest.mock.MockitoSugar
//import org.scalatest.{ FlatSpec, Matchers }
//import reactivemongo.bson.{ BSONDocument, BSONObjectID }
//import reactivemongo.core.commands.LastError
//import scala.concurrent.Future
//import net.codingwell.scalaguice.InjectorExtensions._
//import scala.concurrent.ExecutionContext.Implicits.global
//
//class EmployeeDataRepositorySpecs extends FlatSpec with Matchers {
//
//  private[ EmployeeDataRepositorySpecs ] class TestModule extends AbstractModule with ScalaModule with MockitoSugar {
//
//    import org.mockito.Mockito._
//
//    override def configure(): Unit = {
//      val wrapper: AffiliationEmployeesDataWrapper = mock[ AffiliationEmployeesDataWrapper ]
//
//      val le = LastError( ok = true, None, None, None, None, -1, false )
//
//      //Mock de la búsqueda de un documento existente.
//      when {
//        wrapper.findOne( BSONDocument( "dni" -> "1234" ) )
//      } thenReturn {
//        Future.successful( Some( GlobalData.aed ) )
//      }
//
//      //Mock de la búsqueda de un documento inexistente.
//      when {
//        wrapper.findOne( BSONDocument( "dni" -> "4321" ) )
//      } thenReturn {
//        Future.successful( None )
//      }
//
//      //Mock de la eliminación de un documento existente.
//      when {
//        wrapper.remove( BSONDocument( "dni" -> "1234" ) )
//      } thenReturn {
//        Future.successful( le )
//      }
//
//      //Mock de la actualización de un documento existente.
//      when {
//        wrapper.update( BSONDocument( "dni" -> "1234" ), AffiliationEmployeesData(
//          _id = GlobalData.d,
//          dni = "1234",
//          securityCode = "DEF",
//          employees = Some( List() )
//        ), upsert = true )
//      } thenReturn {
//        Future.successful( LastError( true, None, None, None, None, 1, true ) )
//      }
//
//      //Mock de la creación de un documento inexistente.
//      when {
//        wrapper.update(
//          BSONDocument( "dni" -> "4321" ),
//          AffiliationEmployeesData( dni = "4321", securityCode = "ABC", employees = Some( List() ) ), upsert = true
//        )
//      } thenReturn {
//        Future.successful( LastError( true, None, None, None, None, 1, false ) )
//      }
//
//      bind[ AffiliationEmployeesDataWrapper ].toInstance( wrapper )
//    }
//  }
//
//  private[ EmployeeDataRepositorySpecs ] object GlobalData {
//    val d: BSONObjectID = BSONObjectID( "503792c1984587971b14530e" )
//    val aed = AffiliationEmployeesData(
//      _id = d,
//      dni = "1234",
//      securityCode = "ABC",
//      employees = Some( List() )
//    )
//  }
//
//  val injector = Guice.createInjector( new TestModule() )
//
//  val repo: EmployeeDataRepository = injector.instance[ EmployeeDataRepository ]
//
//  "An employee data repository" should "be able to find a document by dni" in {
//    val dni: Future[ Option[ AffiliationEmployeesData ] ] = repo.findByDni( "1234" )
//    dni onSuccess {
//      case Some( aed ) =>
//        aed should be {
//          GlobalData.aed
//        }
//      case None => fail()
//    }
//  }
//
//  it should "return no results when a DNI doesn't match any document" in {
//    repo.findByDni( "4321" ) onSuccess {
//      case Some( _ ) => fail()
//      case None      => assert( true )
//    }
//  }
//
//  it should "remove a document by DNI" in {
//    val repo: EmployeeDataRepository = injector.instance[ EmployeeDataRepository ]
//
//    repo.removeByDni( "1234" ) onSuccess {
//      case status =>
//        assert( status.ok )
//    }
//  }
//
//  it should "update a document when already exists" in {
//    repo.createOrUpdate( "1234", "DEF", List() ) onSuccess {
//      case status =>
//        assert( status.ok )
//        assert( status.updatedExisting )
//    }
//  }
//
//  it should "create a document when it doesn't exist" in {
//    repo.createOrUpdate( "4321", "ABC", List() ) onSuccess {
//      case status =>
//        assert( status.ok )
//        assert( !status.updatedExisting )
//    }
//  }
//}