//package com.arlsura.afiliacion.bussiness.segmentation
//
//import com.arlsura.afiliacion.persistence.entities.SegmentationRules
//import org.scalatest.{BeforeAndAfter, FlatSpec}
//import org.specs2.matcher.Matchers
//
//import scala.concurrent.ExecutionContext.Implicits.global
//
///**
// * Created by juanmartinez on 22/12/14.
// */
//class SegmentationSpecs extends FlatSpec with Matchers with BeforeAndAfter{
//
//  var segManager : SegmentationManager = _
//
//  before {
//    segManager = new SegmentationManager
//  }
//
//  it should "return true when a long defined by 10 is lower than a long defined by 15" in {
//    val (l1:Long, l2: Long) = (10L, 15L)
//    val segRules = SegmentationRules(
//      num_workers = l2,
//      city = "test",
//      ciiu = "123",
//      operator = "lt"
//    )
//    assert (segManager.validateSegmentation(segRules, l1).toString.toBoolean)
//  }
//
//  it should "return true when a long defined by 15 is greater than a long defined by 10" in {
//    val (l1:Long, l2: Long) = (15L, 10L)
//    val segRules = SegmentationRules(
//      num_workers = l2,
//      city = "test",
//      ciiu = "123",
//      operator = "gt"
//    )
//    assert (segManager.validateSegmentation(segRules, l1).toString.toBoolean)
//  }
//
//  it should "return true when a long defined by 10 is equal than a long defined by 10" in {
//    val (l1:Long, l2: Long) = (10L, 10L)
//    val segRules = SegmentationRules(
//      num_workers = l2,
//      city = "test",
//      ciiu = "123",
//      operator = "eq"
//    )
//    assert (segManager.validateSegmentation(segRules, l1).toString.toBoolean)
//  }
//
//  it should "return true when a long defined by 15 is lower than or equal to a long defined by 15" in {
//    val (l1:Long, l2: Long) = (15L, 15L)
//    val segRules = SegmentationRules(
//      num_workers = l1,
//      city = "test",
//      ciiu = "123",
//      operator = "ltoe"
//    )
//    assert (segManager.validateSegmentation(segRules, l2).toString.toBoolean)
//  }
//
//  it should "return true when a long defined by 15 is greater than or equal to a long defined by 15" in {
//    val (l1:Long, l2: Long) = (15L, 15L)
//    val segRules = SegmentationRules(
//      num_workers = l1,
//      city = "test",
//      ciiu = "123",
//      operator = "gtoe"
//    )
//    assert (segManager.validateSegmentation(segRules, l2).toString.toBoolean)
//  }
//}
