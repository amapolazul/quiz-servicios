//package com.arlsura.afiliacion.bussiness.code
//
//import com.arlsura.afiliacion.persistence.entities.preaffiliation.FullEconomicActivity
//import net.codingwell.scalaguice.InjectorExtensions._
//import com.arlsura.afiliacion.bussiness.code.recall.CodeRecallRepository
//import com.arlsura.afiliacion.persistence.daos.wrappers.{ PreAffiliationWrapper, SecurityCodeWrapper }
//import com.arlsura.afiliacion.persistence.entities.affiliation.contacts_data.ContactInformation
//import com.arlsura.afiliacion.persistence.entities.{ PreAffiliation, SecurityCode }
//import com.google.inject.{ Guice, AbstractModule }
//import net.codingwell.scalaguice.ScalaModule
//import org.scalatest.mock.MockitoSugar
//import org.scalatest.{ Matchers, FlatSpec }
//import reactivemongo.bson.{ BSONObjectID, BSONDocument }
//import scala.concurrent.ExecutionContext.Implicits.global
//import scala.concurrent.Future
//
///**
// * Created by Jesús Martínez on 2/06/15.
// */
//class CodeRecallRepositorySpecs extends FlatSpec with Matchers {
//
//  private[ CodeRecallRepositorySpecs ] object GlobalData {
//    val scd = SecurityCode(
//      _id = BSONObjectID.generate,
//      code = "1",
//      source = "A",
//      email = "jaxex706@gmail.com",
//      dni = "1234"
//    )
//
//    val pad = PreAffiliation(
//      _id = BSONObjectID.generate,
//      dni = "1234",
//      fullName = "ABC",
//      address = "K1#2-3",
//      cellphone = None,
//      econoact = "1",
//      workers = 1,
//      prevarp = "",
//      racea = "",
//      fileName = None,
//      file = None,
//      affiliationType = "B",
//      isNewCompany = None,
//      selectedProvinces = List.empty,
//      gender = None,
//      birthDate = None,
//      fullEconomicActivity = FullEconomicActivity( description = Some( "" ), economicActivityId = "", rate = Some( "" ) ),
//      contactInfo = ContactInformation( email = "test@test.tst", phone = Some( "8888888" ) )
//    )
//  }
//
//  private[ CodeRecallRepositorySpecs ] class TestModule extends AbstractModule with ScalaModule with MockitoSugar {
//
//    import GlobalData._
//    import org.mockito.Mockito._
//
//    override def configure(): Unit = {
//      val scw: SecurityCodeWrapper = mock[ SecurityCodeWrapper ]
//      val paw: PreAffiliationWrapper = mock[ PreAffiliationWrapper ]
//
//      when {
//        scw.findOne( BSONDocument( "dni" -> "1234" ) )
//      } thenReturn {
//        Future.successful( Some( scd ) )
//      }
//
//      when {
//        scw.findOne( BSONDocument( "dni" -> "4321" ) )
//      } thenReturn {
//        Future.successful( None )
//      }
//
//      when {
//        paw.findOne( BSONDocument( "dni" -> "1234", "contactInfo.email" -> "test@test.tst" ) )
//      } thenReturn {
//        Future.successful( Some( pad ) )
//      }
//
//      when {
//        paw.findOne( BSONDocument( "dni" -> "1234", "contactInfo.phone" -> "8888888" ) )
//      } thenReturn {
//        Future.successful( Some( pad ) )
//      }
//
//      when {
//        paw.findOne( BSONDocument( "dni" -> "4321", "contactInfo.email" -> "test@test.tst" ) )
//      } thenReturn {
//        Future.successful( None )
//      }
//
//      when {
//        paw.findOne( BSONDocument( "dni" -> "4321", "contactInfo.phone" -> "8888888" ) )
//      } thenReturn {
//        Future.successful( None )
//      }
//
//      when {
//        paw.findOne( BSONDocument( "dni" -> "1234", "contactInfo.email" -> "nope@nope.not" ) )
//      } thenReturn {
//        Future.successful( None )
//      }
//
//      when {
//        paw.findOne( BSONDocument( "dni" -> "1234", "contactInfo.phone" -> "1111111" ) )
//      } thenReturn {
//        Future.successful( None )
//      }
//
//      bind[ SecurityCodeWrapper ].toInstance( scw )
//      bind[ PreAffiliationWrapper ].toInstance( paw )
//    }
//  }
//
//  val injector = Guice.createInjector( new TestModule() )
//  val repo: CodeRecallRepository = injector.instance[ CodeRecallRepository ]
//
//  "A CodeRecallRepository" should "find a code by dni" in {
//    repo.findCode( "1234" ) onSuccess {
//      case Some( code ) => code should be( GlobalData.scd )
//      case None         => fail()
//    }
//
//    repo.findCode( "4321" ) onSuccess {
//      case Some( _ ) => fail()
//      case None      => assert( true )
//    }
//  }
//
//  it should "find a preaffiliation by dni AND email" in {
//    repo.findByEmail( "1234", "test@test.tst" ) onSuccess {
//      case Some( p ) => p should be( GlobalData.pad )
//      case None      => fail()
//    }
//
//    repo.findByEmail( "4321", "test@test.tst" ) onSuccess {
//      case Some( _ ) => fail()
//      case None      => assert( true )
//    }
//
//    repo.findByEmail( "1234", "nope@nope.not" ) onSuccess {
//      case Some( _ ) => fail()
//      case None      => assert( true )
//    }
//  }
//
//  it should "find a preaffiliation by dni AND phone" in {
//    repo.findByPhone( "1234", "8888888" ) onSuccess {
//      case Some( p ) => p should be( GlobalData.pad )
//      case None      => fail()
//    }
//
//    repo.findByPhone( "4321", "8888888" ) onSuccess {
//      case Some( _ ) => fail()
//      case None      => assert( true )
//    }
//
//    repo.findByPhone( "1234", "1111111" ) onSuccess {
//      case Some( _ ) => fail()
//      case None      => assert( true )
//    }
//  }
//}
