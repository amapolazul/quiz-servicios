//package com.arlsura.afiliacion.bussiness.commercial
//
//import com.arlsura.afiliacion.bussiness.commercial.responsible.CommercialResponsibleManager
//import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.{ CreateCommercialResponsibleRequest, UpdateCommercialResponsibleRequest, GetCommercialResponsibleRequest }
//import com.arlsura.afiliacion.persistence.daos.wrappers.CommercialResponsibleWrapper
//import com.arlsura.afiliacion.persistence.entities.CommercialResponsible
//import com.google.inject.{ Guice, AbstractModule }
//import net.codingwell.scalaguice.ScalaModule
//import org.scalatest.mock.MockitoSugar
//import org.scalatest.{ Matchers, FlatSpec }
//import reactivemongo.bson.{ BSONDocument, BSONObjectID }
//import reactivemongo.core.commands.LastError
//import scala.concurrent.ExecutionContext.Implicits.global
//import scala.concurrent.{ ExecutionContext, Future }
//import net.codingwell.scalaguice.InjectorExtensions._
//
///**
// * Created by jesus on 18/06/15.
// */
//class CommercialResponsibleManagerSpecs extends FlatSpec with Matchers {
//  private[ CommercialResponsibleManagerSpecs ] object GlobalData {
//    val ( id1, id2, id3 ) = ( BSONObjectID.generate, BSONObjectID.generate, BSONObjectID.generate )
//    val req1 = GetCommercialResponsibleRequest( city = Some( "Bogotá" ), email = Some( "test@test.tst" ) )
//    val req2 = GetCommercialResponsibleRequest( city = Some( "Bogotá" ), email = Some( "prueba@prueba.prb" ) )
//    val req3 = UpdateCommercialResponsibleRequest( id = id1.stringify, office = Some( 1 ) )
//    val doc1 = CommercialResponsible( _id = id1, city = "Bogotá", fullName = "Name Name Lastname Lastname", email = "test@test.tst", charge = "Hero", networkUser = "user1", office = 1 )
//    val doc2 = CommercialResponsible( _id = id2, city = "Medellín", fullName = "Nombre Nombre Apellido Apellido", email = "prueba@prueba.prb", charge = "Manager", networkUser = "user2", office = 2 )
//    val leOK = LastError( true, None, None, None, None, -1, false )
//  }
//
//  private[ CommercialResponsibleManagerSpecs ] class TestModule extends AbstractModule with ScalaModule with MockitoSugar {
//    import GlobalData._
//    import org.mockito.Mockito._
//    import org.mockito.Matchers._
//
//    override def configure(): Unit = {
//      val wrapper = mock[ CommercialResponsibleWrapper ]
//
//      when {
//        wrapper.findAll()
//      } thenReturn {
//        Future.successful( List( doc1, doc2 ) )
//      }
//
//      when {
//        wrapper.findAll( BSONDocument( "city" -> "bogotá", "email" -> "test@test.tst" ) )
//      } thenReturn {
//        Future.successful( List( doc1 ) )
//      }
//
//      when {
//        wrapper.findAll( BSONDocument( "city" -> "bogotá", "email" -> "prueba@prueba.prb" ) )
//      } thenReturn {
//        Future.successful( Nil )
//      }
//
//      when {
//        wrapper.findOne( BSONDocument( "_id" -> id1 ) )
//      } thenReturn {
//        Future.successful( Some( doc1 ) )
//      }
//
//      when {
//        wrapper.findOne( BSONDocument( "_id" -> id3 ) )
//      } thenReturn {
//        Future.successful( None )
//      }
//
//      when {
//        wrapper.insert( any[ CommercialResponsible ] )( any[ ExecutionContext ] )
//      } thenReturn {
//        Future.successful( leOK )
//      }
//
//      when {
//        wrapper.removeAll()
//      } thenReturn {
//        Future.successful( leOK )
//      }
//
//      when {
//        wrapper.remove( BSONDocument( "_id" -> id1 ) )
//      } thenReturn {
//        Future.successful( leOK )
//      }
//
//      when {
//        wrapper.updateById( id1, BSONDocument( "$set" -> BSONDocument( "office" -> 1 ) ) )
//      } thenReturn {
//        Future.successful( leOK )
//      }
//
//      bind[ CommercialResponsibleWrapper ].toInstance( wrapper )
//    }
//  }
//
//  import GlobalData._
//  lazy val injector = Guice.createInjector( new TestModule() )
//  lazy val manager = injector.instance[ CommercialResponsibleManager ]
//
//  "A CommercialResponsibleManager" should "create a document correctly" in {
//    manager.create( CreateCommercialResponsibleRequest( 3, "", "", "", "", "" ) ) onSuccess {
//      case result => assert( result.ok )
//    }
//  }
//
//  it should "retrieve all the documents properly" in {
//    manager.getAll() onSuccess {
//      case result =>
//        result should be( List( doc1, doc2 ) )
//    }
//
//    manager.getBy( req1 ) onSuccess {
//      case result => result should be( List( doc1 ) )
//    }
//
//    manager.getBy( req2 ) onSuccess {
//      case result => result should be( Nil )
//    }
//
//    manager.getById( id1.stringify ) onSuccess {
//      case Some( res ) => res should be( doc1 )
//      case None        => fail()
//    }
//
//    manager.getById( id3.stringify ) onSuccess {
//      case Some( _ ) => fail()
//      case None      => assert( true )
//    }
//  }
//
//  it should "update a document by id" in {
//    manager.update( req3 ) onSuccess {
//      case result => assert( result.ok )
//    }
//  }
//
//  it should "delete all the documents" in {
//    manager.deleteAll() onSuccess {
//      case result => assert( result.ok )
//    }
//  }
//
//  it should "delete a document by id" in {
//    manager.deleteById( id1.stringify ) onSuccess {
//      case result => assert( result.ok )
//    }
//  }
//}
