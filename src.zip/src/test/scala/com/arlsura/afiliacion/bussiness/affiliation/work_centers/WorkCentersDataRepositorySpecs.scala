//package com.arlsura.afiliacion.bussiness.affiliation.work_centers
//
//import com.arlsura.afiliacion.bussiness.affiliation.workcenters.WorkCentersDataRepository
//import com.arlsura.afiliacion.persistence.daos.affiliation.wrappers.AffiliationWorkCentersDataWrapper
//import com.arlsura.afiliacion.persistence.entities.affiliation.work_center_data.AffiliationWorkCentersData
//import com.google.inject.AbstractModule
//import net.codingwell.scalaguice.ScalaModule
//import org.scalatest.mock.MockitoSugar
//import org.scalatest.{ Matchers, FlatSpec }
//import reactivemongo.bson.{ BSONObjectID, BSONDocument }
//import reactivemongo.core.commands.LastError
//import net.codingwell.scalaguice.InjectorExtensions._
//import scala.concurrent.ExecutionContext.Implicits.global
//import scala.concurrent.Future
//import com.google.inject.Guice
///**
// * Created by Jesús Martínez on 22/05/15.
// */
//class WorkCentersDataRepositorySpecs extends FlatSpec with Matchers {
//  private[ WorkCentersDataRepositorySpecs ] class TestModule extends AbstractModule with ScalaModule with MockitoSugar {
//    import org.mockito.Mockito._
//    import GlobalData._
//
//    override def configure(): Unit = {
//
//      val wrapper = mock[ AffiliationWorkCentersDataWrapper ]
//      //Mock de la búsqueda de un documento existente.
//      when {
//        wrapper.findOne( BSONDocument( "dni" -> "1234" ) )
//      } thenReturn {
//        Future.successful( Some( awcd ) )
//      }
//
//      //Mock de la búsqueda de un documento inexistente.
//      when {
//        wrapper.findOne( BSONDocument( "dni" -> "4321" ) )
//      } thenReturn {
//        Future.successful( None )
//      }
//
//      //Mock de la eliminación de un documento existente.
//      when {
//        wrapper.remove( BSONDocument( "dni" -> "1234" ) )
//      } thenReturn {
//        Future.successful( leOK )
//      }
//
//      //Mock de la actualización de un documento existente.
//      when {
//        wrapper.update( BSONDocument( "dni" -> "1234" ), AffiliationWorkCentersData(
//          _id = id,
//          dni = "1234",
//          securityCode = "DEF",
//          workCenters = List()
//        ), upsert = true )
//      } thenReturn {
//        Future.successful( leUpdated )
//      }
//
//      //Mock de la creación de un documento inexistente.
//      when {
//        wrapper.update(
//          BSONDocument( "dni" -> "4321" ),
//          AffiliationWorkCentersData( dni = "4321", securityCode = "ABC", workCenters = List() ), upsert = true
//        )
//      } thenReturn {
//        Future.successful( leCreated )
//      }
//
//      bind[ AffiliationWorkCentersDataWrapper ].toInstance( wrapper )
//    }
//  }
//
//  private[ WorkCentersDataRepositorySpecs ] object GlobalData {
//    val id: BSONObjectID = BSONObjectID.generate
//    val awcd: AffiliationWorkCentersData = AffiliationWorkCentersData( id, "1234", "ABC", List() )
//    val leOK: LastError = LastError( ok = true, None, None, None, None, -1, false )
//    val leUpdated: LastError = LastError( true, None, None, None, None, 1, true )
//    val leCreated: LastError = LastError( true, None, None, None, None, 1, false )
//  }
//
//  import GlobalData._
//  val injector = Guice.createInjector( new TestModule() )
//  val repo: WorkCentersDataRepository = injector.instance[ WorkCentersDataRepository ]
//
//  "An work centers data repository" should "be able to find a document by dni" in {
//    val dni: Future[ Option[ AffiliationWorkCentersData ] ] = repo.findByDni( "1234" )
//    dni onSuccess {
//      case Some( result ) =>
//        result should be( awcd )
//      case None => fail()
//    }
//  }
//
//  it should "return no results when a DNI doesn't match any document" in {
//    repo.findByDni( "4321" ) onSuccess {
//      case Some( _ ) => fail()
//      case None      => assert( true )
//    }
//  }
//
//  it should "remove a document by DNI" in {
//    repo.removeByDni( "1234" ) onSuccess {
//      case status =>
//        assert( status.ok )
//    }
//  }
//
//  it should "update a document when already exists" in {
//    repo.createOrUpdate( "1234", "DEF", List() ) onSuccess {
//      case status =>
//        assert( status.ok )
//        assert( status.updatedExisting )
//    }
//  }
//
//  it should "create a document when it doesn't exist" in {
//    repo.createOrUpdate( "4321", "ABC", List() ) onSuccess {
//      case status =>
//        assert( status.ok )
//        assert( !status.updatedExisting )
//    }
//  }
//}
//
