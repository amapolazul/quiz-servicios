//package com.arlsura.afiliacion.bussiness.affiliation.employees
//
//import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.SaveEmployeesData
//import com.arlsura.afiliacion.persistence.entities.affiliation.employee_data.AffiliationEmployeesData
//import com.arlsura.afiliacion.utils.messages.MessagesRetriever
//import com.google.inject.{ Guice, AbstractModule }
//import net.codingwell.scalaguice.ScalaModule
//import org.scalatest.mock.MockitoSugar
//import org.scalatest.{ Matchers, FlatSpec }
//import net.codingwell.scalaguice.InjectorExtensions._
//import reactivemongo.bson.BSONObjectID
//import reactivemongo.core.commands.LastError
//import scala.concurrent.ExecutionContext.Implicits.global
//import scala.concurrent.Future
//
///**
// * Created by Jesús Martínez on 21/05/15.
// */
//class EmployeeDataServiceHandlerSpecs extends FlatSpec with Matchers {
//  private[ EmployeeDataServiceHandlerSpecs ] class TestModule extends AbstractModule with ScalaModule with MockitoSugar {
//    import org.mockito.Mockito._
//
//    override def configure(): Unit = {
//      val repo = mock[ EmployeeDataRepository ]
//
//      //Mock de llamada a findByDni
//      when {
//        repo.findByDni( "1234" )
//      } thenReturn {
//        Future.successful( Some( GlobalData.aed ) )
//      }
//
//      when {
//        repo.findByDni( "4321" )
//      } thenReturn {
//        Future.successful( None )
//      }
//
//      //Mock de llamada a createOrUpdate
//      when {
//        repo.createOrUpdate( "1234", "ABC", List() )
//      } thenReturn {
//        Future.successful( GlobalData.leOK )
//      }
//
//      when {
//        repo.createOrUpdate( "4321", "ABC", List() )
//      } thenReturn {
//        Future.successful( GlobalData.leNotOK )
//      }
//
//      bind[ EmployeeDataRepository ].toInstance( repo )
//
//    }
//  }
//
//  private[ EmployeeDataServiceHandlerSpecs ] object GlobalData {
//    val id: BSONObjectID = BSONObjectID( "503792c1984587971b14530e" )
//    val leOK = LastError( ok = true, None, None, None, None, -1, false )
//    val leNotOK = LastError( ok = false, None, None, None, None, -1, false )
//
//    val aed = AffiliationEmployeesData(
//      _id = id,
//      dni = "1234",
//      securityCode = "ABC",
//      employees = Some( List() )
//    )
//
//    //mensajes de error y de exito para las respuestas
//    val retrieveEmployeesSuccessMessage: String = MessagesRetriever.getSuccessMessage( "affiliation.employees", "RETRIEVE" )
//    val noEmployeesSuccessMessage: String = MessagesRetriever.getSuccessMessage( "affiliation.employees", "NO_EMPLOYEES" )
//    val saveEmployeesSuccessMessage: String = MessagesRetriever.getSuccessMessage( "affiliation.employees", "SAVE" )
//    def errorOccurredMessage( error: String ): String = s"Ocurrión un error: $error"
//  }
//
//  val injector = Guice.createInjector( new TestModule() )
//  val handler = injector.instance[ EmployeeDataServiceHandler ]
//
//  "An EmployeeDataServiceHandler" should "retrieve a document by dni" in {
//    handler.retrieveEmployeesData( "1234" ) onSuccess {
//      case Left( _ ) => fail()
//      case Right( response ) =>
//        response.message should be {
//          GlobalData.retrieveEmployeesSuccessMessage
//        }
//
//        response.data should be {
//          Some( GlobalData.aed )
//        }
//    }
//
//    handler.retrieveEmployeesData( "4321" ) onSuccess {
//      case Left( _ ) => fail()
//      case Right( response ) =>
//        response.message should be {
//          GlobalData.noEmployeesSuccessMessage
//        }
//
//        response.data should be {
//          None
//        }
//    }
//  }
//
//  it should "save employees information successfully" in {
//    handler.saveEmployeesData( SaveEmployeesData( "1234", "ABC", List() ) ) onSuccess {
//      case Left( _ ) => fail()
//      case Right( response ) =>
//        response.message should be {
//          GlobalData.saveEmployeesSuccessMessage
//        }
//
//        response.data should be {
//          None
//        }
//    }
//  }
//
//  it should "when saving employees info, report a failure if a problem has happened in DB" in {
//    handler.saveEmployeesData( SaveEmployeesData( "4321", "ABC", List() ) ) onSuccess {
//      case Right( _ ) => fail()
//      case Left( e ) =>
//        e should be {
//          GlobalData.errorOccurredMessage( "MongoDB-Error" )
//        }
//    }
//  }
//
//  it should "return a non-empty cookie with each successful request" in {
//    handler.saveEmployeesData( SaveEmployeesData( "1234", "ABC", List() ) ) onSuccess {
//      case Left( _ ) => fail()
//      case Right( response ) =>
//        assert( response.suraSessionManager.forall( _.nonEmpty ) )
//    }
//
//    handler.retrieveEmployeesData( "1234" ) onSuccess {
//      case Left( _ ) => fail()
//      case Right( response ) =>
//        assert( response.suraSessionManager.forall( _.nonEmpty ) )
//    }
//  }
//}
