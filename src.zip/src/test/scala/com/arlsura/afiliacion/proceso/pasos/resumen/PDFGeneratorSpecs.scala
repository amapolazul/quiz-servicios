//package com.arlsura.afiliacion.proceso.pasos.resumen
//
//import com.arlsura.afiliacion.proceso.pasos.resumen.PDFFileGenerator.{ FooterData, EmployerData }
//import com.itextpdf.text.Font.FontFamily
//import com.itextpdf.text.pdf.draw.LineSeparator
//import com.itextpdf.text.{ BaseColor, FontFactory, Font }
//import com.itextpdf.text.pdf.{ PdfPCell, PdfPTable }
//import org.scalatest.FlatSpec
//
///**
// * Created by juanmartinez on 10/06/15.
// */
//class PDFGeneratorSpecs extends FlatSpec {
//
//  val baseColorTitle = new BaseColor( 110, 199, 45 )
//  val fontTitle = new Font( FontFamily.HELVETICA, 11, Font.BOLD, baseColorTitle )
//  val pdfGenerator: PDFFileGenerator = new PDFFileGenerator
//
//  //todo
//  //descomentar despues de verificar rutas
//  //  "A pdf file path " should " be created " in {
//  //    val pdfGenerator: PDFFileGenerator = new PDFFileGenerator
//  //    val pdfFile: String = pdfGenerator.generatePDF(EmployerData(listWorkCenters = List(), listWorkers = List()), FooterData(), "12343")
//  //    assert(pdfFile != null && !pdfFile.isEmpty)
//  //  }
//  /*
//  "A pdf table with the authorization field " should " be returned " in {
//    val table: PdfPTable = pdfGenerator.buildAuthorizationSignFields()
//    assert(table.isInstanceOf[PdfPTable])
//  }
//
//  "A pdf table with the authorization letter header " should " be returned " in {
//    val table: PdfPTable = pdfGenerator.buildAuthorizeLetterHeader()
//    assert(table.isInstanceOf[PdfPTable])
//  }
//
//  "A pdf table with the bank account footer " should " be returned " in {
//    val table: PdfPTable = pdfGenerator.buildBankAccountFooter()
//    assert(table.isInstanceOf[PdfPTable])
//  }
//
//  "A pdf table with the contextual help " should " be returned " in {
//    val table: PdfPTable = pdfGenerator.buildContextualHelp("contextual help text")
//    assert(table.isInstanceOf[PdfPTable])
//  }
//
//  "A pdf table with the letter authorization content " should " be returned " in {
//    val table: PdfPTable = pdfGenerator.buildLetterAuthorizationContent()
//    assert(table.isInstanceOf[PdfPTable])
//  }
//
//  "A pdf table with the ARL letter " should " be returned " in {
//    val table: PdfPTable = pdfGenerator.buildMovilityARLLetter()
//    assert(table.isInstanceOf[PdfPTable])
//  }
//
//  "A pdf table with the Movility footer " should " be returned " in {
//    val table: PdfPTable = pdfGenerator.buildMovilityFooter("1", "2", "3")
//    assert(table.isInstanceOf[PdfPTable])
//  }
//
//  "A pdf table with the paragraph bank account " should " be returned " in {
//    val table: PdfPTable = pdfGenerator.buildParagraphBankAccount()
//    assert(table.isInstanceOf[PdfPTable])
//  }
//
//  "A pdf cell with the authorization field " should " be returned " in {
//    val pdfPCell: PdfPCell = pdfGenerator.buildParagraphContent("content", fontTitle)
//    assert(pdfPCell.isInstanceOf[PdfPCell])
//  }
//
//  "A pdf table with rights footer " should " be returned " in {
//    val table: PdfPTable = pdfGenerator.buildRightsFooter()
//    assert(table.isInstanceOf[PdfPTable])
//  }
//
//  "A pdf cell with bank account header " should " be returned " in {
//    val cell: PdfPCell = pdfGenerator.createBankAccountHeader()
//    assert(cell.isInstanceOf[PdfPCell])
//  }
//
//  "A pdf table with the footer " should " be returned " in {
//    val table: PdfPTable = pdfGenerator.createFooter()
//    assert(table.isInstanceOf[PdfPTable])
//  }
//
//  "A pdf table with the form section title " should " be returned " in {
//    val table: PdfPTable = pdfGenerator.createFormSectionTittle("content")
//    assert(table.isInstanceOf[PdfPTable])
//  }
//
//  "A pdf table with header table information " should " be returned " in {
//    val table: PdfPTable = pdfGenerator.createHeaderTableInformation(1, Array("rtest"))
//    assert(table.isInstanceOf[PdfPTable])
//  }
//
//  "A pdf cell with image letters header " should " be returned " in {
//    val cell: PdfPCell = pdfGenerator.createImageHeaderCell()
//    assert(cell.isInstanceOf[PdfPCell])
//  }
//
//  "A pdf cell with header letter " should " be returned " in {
//    val cell: PdfPCell = pdfGenerator.createLetterHeader()
//    assert(cell.isInstanceOf[PdfPCell])
//  }
//
//  "A pdf tuple with suscription account tables" should " be returned " in {
//    val table: (PdfPTable, PdfPTable) = pdfGenerator.createSubscriptionAccount()
//
//    assert(table._1.isInstanceOf[PdfPTable])
//    assert(table._2.isInstanceOf[PdfPTable])
//  }
//
//  "A pdf tuple with form headers " should " be returned " in {
//    val table: (PdfPTable, LineSeparator) = pdfGenerator.buildFormHeader(pdfGenerator.createTextHeader())
//
//    assert(table._1.isInstanceOf[PdfPTable])
//    assert(table._2.isInstanceOf[LineSeparator])
//  }
//
//  "A pdf tuple with rights letter " should " be returned " in {
//    val table: (PdfPTable, PdfPTable, PdfPTable, PdfPTable, PdfPTable, PdfPTable) = pdfGenerator.createEmployeerData("asdf","asdf","asdf","asdf","sdf","asdf","asdf","sf","asdf","asdf","asdf","asdf")
//    assert(table._1.isInstanceOf[PdfPTable])
//    assert(table._2.isInstanceOf[PdfPTable])
//    assert(table._3.isInstanceOf[PdfPTable])
//    assert(table._4.isInstanceOf[PdfPTable])
//    assert(table._5.isInstanceOf[PdfPTable])
//    assert(table._6.isInstanceOf[PdfPTable])
//  }*/
//}
