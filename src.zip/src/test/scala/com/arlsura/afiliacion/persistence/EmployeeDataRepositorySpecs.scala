//package com.arlsura.afiliacion.persistence
//
//import com.arlsura.afiliacion.bussiness.affiliation.employees.EmployeeDataRepository
//import com.arlsura.afiliacion.persistence.daos.affiliation.wrappers.AffiliationEmployeesDataWrapper
//import com.arlsura.afiliacion.persistence.entities.affiliation.employee_data.AffiliationEmployeesData
//import org.scalatest.FlatSpec
//import org.scalatest.mock.MockitoSugar
//import org.mockito.Mockito._
//import org.mockito.Matchers._
//import reactivemongo.bson.{BSONObjectID, BSONDocument}
//import reactivemongo.core.commands.LastError
//import scala.concurrent.{Await, Future}
//import scala.concurrent.ExecutionContext.Implicits.global
//import scala.concurrent.duration._
//
///**
// * Created by Jesús Martínez on 4/05/15.
// */
//class EmployeeDataRepositorySpecs extends FlatSpec with MockitoSugar {
//  import Mocks._
//  val repo = new EmployeeDataRepository(wrapperMock)
//
//  "A EmployeeDataRepository" should "return a meaningful error when removing a document fails" in {
//    val le = Await.result(repo.removeByDni("0"), 5.seconds)
//    assert(!le.ok)
//    assert(le.errMsg.isDefined)
//    assert(le.err.isDefined)
//  }
//
//  it should "return a meaningful response when removing a document succeeds" in {
//    val le = Await.result(repo.removeByDni("1"), 5.seconds)
//    assert(le.ok)
//  }
//
//  it should "return zero results when the query doesn't find anything that matches" in {
//    val option = Await.result(repo.findByDni("0"), 5.seconds)
//    assert(option.isEmpty)
//  }
//
//  it should "return one result when the query matches something" in {
//    val option = Await.result(repo.findByDni("1"), 5.seconds)
//    assert(option.nonEmpty)
//    assert(option.forall(_.dni == "1"))
//  }
//
//  it should "update a document when it has been changed and already exists in db" in {
//    assert(dbOldState.length == 1)
//    println(dbOldState.head)
//    println(dbOldState.forall(d => d.dni == "1" && d.securityCode == "code" && d.employees.isEmpty))
//    assert(dbOldState.forall(d => d.dni == "1" && d.securityCode == "code" && d.employees.isEmpty))
//    val le = Await.result(repo.createOrUpdate("1", "code1", Nil), 5.seconds)
//    assert(le.ok)
//    assert(dbNewState.length == 1)
//    assert(dbNewState.forall(d => d.dni == "1" && d.securityCode == "code1" && d.employees.nonEmpty && d.employees.forall(_.isEmpty)))
//  }
//
//  it should "insert a document when it doesn't existis in db" in {
//    assert(dbUpsertOldState.length == 1)
//    assert(dbUpsertOldState.forall(d => d.dni == "1" && d.securityCode == "code1" && d.employees.nonEmpty && d.employees.forall(_.isEmpty)))
//    val le = Await.result(repo.createOrUpdate("2", "code2", Nil), 10.seconds)
//    assert(le.ok)
//    assert(dbUpsertNewState.length == 2)
//    println(dbUpsertNewState)
//    assert(dbUpsertNewState.exists(d => d.dni == "2" && d.securityCode == "code2" && d.employees.nonEmpty && d.employees.forall(_.isEmpty)))
//  }
//}
//
//private object Mocks extends MockitoSugar {
//  //El único parámetro que interesa es 'ok'
//  val successfulLastError = LastError(ok = true, None, None, None, None, -1, false)
//  //Los parámetros que importan son 'ok', 'err' y 'errMsg'
//  val failureLastError = LastError(ok = false, Some("org.example.WeirdNonExistentException"), Some(500), Some("Mock error"), None, -1, false)
//
//  val availableId = BSONObjectID.generate
//  val takenId = BSONObjectID.generate
//  val document = AffiliationEmployeesData(_id = takenId, dni = "1", securityCode = "code", employees = None)
//  val documentModified = AffiliationEmployeesData(_id = takenId, dni = "1", securityCode = "code1", employees = Some(Nil))
//  val newDocument = AffiliationEmployeesData(_id = availableId, dni = "2", securityCode = "code2", employees = Some(Nil))
//  var dbOldState = List(document)
//  var dbNewState = List.empty[AffiliationEmployeesData]
//  var dbUpsertOldState = List(documentModified)
//  var dbUpsertNewState = List.empty[AffiliationEmployeesData]
//
//  val wrapperMock = mock[AffiliationEmployeesDataWrapper]
//  when(wrapperMock.findOne(BSONDocument("dni" -> "2"))).thenReturn(Future(None))
//  when(wrapperMock.findOne(BSONDocument("dni" -> "0"))).thenReturn(Future(None))
//  when(wrapperMock.findOne(BSONDocument("dni" -> "1"))).thenReturn(Future(Some(document)))
//  when(wrapperMock.update(BSONDocument("dni" -> "1"), documentModified, upsert = true)).thenReturn {
//    Future {
//      dbNewState = List(documentModified)
//      successfulLastError
//    }
//  }
//  when(wrapperMock.update(any[BSONDocument], any[AffiliationEmployeesData], anyBoolean())).thenReturn {
//    Future {
//      dbUpsertNewState = newDocument :: dbUpsertOldState
//      successfulLastError
//    }
//  }
//  when(wrapperMock.remove(BSONDocument("dni" -> "0"))).thenReturn(Future(failureLastError))
//  when(wrapperMock.remove(BSONDocument("dni" -> "1"))).thenReturn(Future(successfulLastError))
//}
