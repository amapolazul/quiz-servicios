//package com.arlsura.afiliacion.preaffiliation
//
//import org.scalatest.FlatSpec
//
///**
// * Created by root on 5/02/15.
// */
//class PreaffiliationPrevalidationSpecs extends FlatSpec {
//
//  "PreaffiliationPrevalidation" should "return DNI is not affiliated, doesn't have key and doesn't have independants" in {
//    /*val state = PreaffiliationPrevalidation.check("C666666666")
//    assert(state.isAffiliated == false)
//    assert(state.hasKey == false)
//    assert(state.hasIndependants == false)*/
//  }
//
//  "PreaffiliationPrevalidation" should "return DNI is affiliated, but doesn't have key and doesn't have independants" in {
//    /*val state = PreaffiliationPrevalidation.check("N800053849")
//    assert(state.isAffiliated == true)
//    assert(state.hasKey == false)
//    assert(state.hasIndependants == false)*/
//  }
//
//}
