//package com.arlsura.afiliacion.actors.routers
//
//import akka.actor.Props
//import akka.routing.SmallestMailboxRouter
//import akka.testkit.TestActor
//import com.arlsura.afiliacion.actors.router.RouterFactory
//import com.arlsura.afiliacion.utils.Utils
//import org.scalatest.{FlatSpec, WordSpec}
//
///**
// * Created by Jesús Martínez on 5/02/15.
// */
//class RouterFactorySpecs extends FlatSpec with RouterFactory {
//  //Se define para poder ser herederos dignos de RouterFactory.
//  def router = Props[TestActor].withRouter(makeRouter()())
//
//  "A router factory" should "create the proper type of router" in {
//    var r = makeRouter()()
//    assert(r.getClass.toString.equalsIgnoreCase("class akka.routing.SmallestMailboxRouter"))
//    r = makeRouter(routerType = "ROUND-robin")()
//    assert(r.getClass.toString.equalsIgnoreCase("class akka.routing.RoundRobinRouter"))
//    r = makeRouter(routerType = "bRoAdCasT")()
//    assert(r.getClass.toString.equalsIgnoreCase("class akka.routing.BroadcastRouter"))
//  }
//
//  it should "throw a MatchError when an unexpected type of router is requested" in {
//    intercept[scala.MatchError] {
//      makeRouter("???")()
//    }
//  }
//
//  it should "retrieve the correct values from the configuration file" in {
//    assert(Utils.getProperty("pool.", "default-size").asInstanceOf[Int] == DEFAULT_POOL_SIZE)
//    assert(Utils.getProperty("pool.", "lower-bound").asInstanceOf[Int] == LOWER_BOUND_POOL_SIZE)
//    assert(Utils.getProperty("pool.", "upper-bound").asInstanceOf[Int] == UPPER_BOUND_POOL_SIZE)
//  }
//}

