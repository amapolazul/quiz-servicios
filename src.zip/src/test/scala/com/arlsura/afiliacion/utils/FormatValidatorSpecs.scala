//package com.arlsura.afiliacion.utils
//
//import org.scalatest.FlatSpec
//
///**
// * Created by Jesús Martínez on 6/07/15.
// */
//class FormatValidatorSpecs extends FlatSpec {
//  private val fv = FormatValidator
//   "A FormatValidator" should "return true when an input text is alphanumeric with or without whitespaces" in {
//     assert(fv.alphanumeric("This is a valid alphanumeric text and 7 is a lucky number"))
//     assert(fv.alphanumeric("ThereAreNoWhitespacesHereH0L4", allowWhitespaces = false))
//   }
//
//  it should "return false when an input text isn't alphanumeric" in {
//    assert(!fv.alphanumeric("This could be a valid input if there weren't a comma ---> , "))
//    assert(!fv.alphabetic("This would be a valid text if whitespaces were allowed", allowWhitespaces = false))
//    assert(!fv.alphabetic("ThisTextIsNotValidBecauseOfTheDot.", allowWhitespaces = false))
//  }
//
//  it should "return true when an input text is alphabetic with or without whitespaces" in {
//    assert(fv.alphabetic("This is a valid alphabetic text"))
//    assert(fv.alphabetic("ThisIsAValidTextBecauseWhitespacesAreDisabled", allowWhitespaces = false))
//  }
//
//  it should "return false when an input text isn't alphabetic" in {
//    assert(!fv.alphabetic("This could be a valid input if there weren't special chars like *?!%&/"))
//    assert(!fv.alphabetic("This would be a valid input if there weren't numb3rs"))
//    assert(!fv.alphabetic("ThisIsAFineTextWithNoSpacesBetweenWords Ooops", allowWhitespaces = false))
//    assert(!fv.alphabetic("ThisIsABadTextBecauseOfThis->.", allowWhitespaces = false))
//  }
//
//  it should "return true when an input text is numeric" in {
//    assert(fv.numeric("123456"))
//  }
//
//  it should "return false when an input text isn't numeric" in {
//    assert(!fv.numeric("12three456"))
//    assert(!fv.numeric("1,2,3,4,5,6"))
//    assert(!fv.numeric("1 2 3 4 5 6"))
//  }
//
//  it should "return true when a name is well constructed" in {
//    assert(fv.validName("John"))
//    assert(fv.validName("Jo"))
//    assert(fv.validName("Count of Montecristonssen von Derpinsson van Basten de Gea Nistelrooy Hooidoonkj"))
//  }
//
//  it should "return false when a name is malformed" in {
//    assert(!fv.validName("Je$u$"))
//    assert(!fv.validName("A"))
//    assert(!fv.validName("Count of Montecristonssen von Derpinsson van Basten de Gea Nistelrooy Hooidoonkjjjj"))
//  }
//
//  it should "return true when a phone is well constructed" in {
//    assert(fv.validPhone("8888888"))
//  }
//
//  it should "return false when a phone is malformed" in {
//    assert(!fv.validPhone("0123456"))
//    assert(!fv.validPhone("123456"))
//    assert(!fv.validPhone("12345678"))
//    assert(!fv.validPhone("12EAS6T"))
//  }
//
//  it should "return true when a cellphone is well constructed" in {
//    assert(fv.validCellphone("3203655304"))
//  }
//
//  it should "return false when a cellphone is malformed" in {
//    assert(!fv.validCellphone("320365"))
//    assert(!fv.validCellphone("583203655304"))
//    assert(!fv.validCellphone("E2OEGSS3OA"))
//  }
//
//  it should "return true when an email is well constructed" in {
//    assert(fv.validEmail("jesusmartinez@seven4n.com"))
//    assert(fv.validEmail("test@thisisaverylongdomain.com"))
//    assert(fv.validEmail("jesus.a.martinez.v@gmail.com"))
//    assert(fv.validEmail("jesus19_8@hotmail.com"))
//  }
//
//  it should "return false when an email is malformed" in {
//    assert(!fv.validEmail("jesusmartineatseven.com"))
//    assert(!fv.validEmail("jesus/martinez@seven4n.com"))
//    assert(!fv.validEmail("jesusmartinez@seven4ndotcom"))
//    assert(!fv.validEmail("<<<<<<<aaa@aaa.bbbb????"))
//  }
//
//  it should "return true when an IPv4 is valid" in {
//    assert(fv.validIPv4("165.2.85.255"))
//  }
//
//  it should "return false when an IPv4 is malformed" in {
//    assert(!fv.validIPv4("badIp"))
//    assert(!fv.validIPv4("300.2.3."))
//    assert(!fv.validIPv4("300.500.2.875"))
//  }
//}
