//package com.arlsura.afiliacion.utils
//
//import org.scalatest.FlatSpec
//import org.specs2._
//
///**
// * Created by john on 10/11/14.
// */
//class DNIBuilderSpecs extends FlatSpec {
//
//  var identification = "1010101010"
//
//  "Builder" should "build 'CEDULA DE CIUDADANIA' DNI" in {
//    val idType = "CC"
//    val idTypeEquivalent = "C"
//    assert(DNIBuilder.build(idType, identification).equals(idTypeEquivalent + identification))
//  }
//
//  it should "build 'NIT' DNI" in {
//    val idType = "NI"
//    val idTypeEquivalent = "N"
//    assert(DNIBuilder.build(idType, identification).equals(idTypeEquivalent + identification))
//  }
//
//  it should "build 'CEDULA EXTRANJERIA' DNI" in {
//    val idType = "CE"
//    val idTypeEquivalent = "E"
//    assert(DNIBuilder.build(idType, identification).equals(idTypeEquivalent + identification))
//  }
//
//  it should "build 'TARJETA IDENTIDAD' DNI" in {
//    val idType = "TI"
//    val idTypeEquivalent = "T"
//    assert(DNIBuilder.build(idType, identification).equals(idTypeEquivalent + identification))
//  }
//
//  it should "build 'REGISTRO CIVIL' DNI" in {
//    val idType = "RC"
//    val idTypeEquivalent = "I"
//    assert(DNIBuilder.build(idType, identification).equals(idTypeEquivalent + identification))
//  }
//
//  it should "build 'REGISTRO' DNI" in {
//    val idType = "M"
//    val idTypeEquivalent = "M"
//    assert(DNIBuilder.build(idType, identification).equals(idTypeEquivalent + identification))
//  }
//
//  it should "build 'PASAPORTE' DNI" in {
//    val idType = "PA"
//    val idTypeEquivalent = "P"
//    assert(DNIBuilder.build(idType, identification).equals(idTypeEquivalent + identification))
//  }
//
//  it should "build 'CARNE DIPLOMATICO' DNI" in {
//    val idType = "CD"
//    val idTypeEquivalent = "D"
//    assert(DNIBuilder.build(idType, identification).equals(idTypeEquivalent + identification))
//  }
//
//  it should "throw IllegalArgumentException when empty identification type" in {
//    val idType = ""
//    intercept[IllegalArgumentException] {
//      DNIBuilder.build(idType, identification)
//    }
//  }
//
//  it should "throw IllegalArgumentException when unknown identification type" in {
//    val idType = "XX"
//    intercept[IllegalArgumentException] {
//      DNIBuilder.build(idType, identification)
//    }
//  }
//
//  it should "throw IllegalArgumentException when empty identification" in {
//    val idType = "CC"
//    val identification = "   ";
//    intercept[IllegalArgumentException] {
//      DNIBuilder.build(idType, identification)
//    }
//  }
//
//}
