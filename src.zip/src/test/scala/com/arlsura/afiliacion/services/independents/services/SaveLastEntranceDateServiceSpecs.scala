//package com.arlsura.afiliacion.services.independientes.mongo.services
//
//import java.util.UUID
//
//import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.GeneralJsonResponseData
//import com.arlsura.afiliacion.services.independientes.mongo.LastEntranceDate
//import org.specs2.mutable.Specification
//import spray.http.StatusCodes._
//import spray.testkit.Specs2RouteTest
//
///**
//  * Created by john on 21/11/14.
//  */
//class SaveLastEntranceDateServiceSpecs extends Specification with Specs2RouteTest with SaveLastEntranceService {
//
//   def randomString = UUID.randomUUID().toString.replaceAll("-", "")
//
//   def actorRefFactory = system
//
//   val sampleURL = "http://localhost:8080/savelastentrance?dni=XXXXXXXXXXX"
//
//   val servicesTimeout : Long = 3000
//
//   "The service" should {
//
//     "return a MethodNotAllowed error for request distinct than GET" in {
//       Put(sampleURL) ~> sealRoute(saveLastEntrancePath) ~> check {
//         status === MethodNotAllowed
//       }
//       Post(sampleURL) ~> sealRoute(saveLastEntrancePath) ~> check {
//         status === MethodNotAllowed
//       }
//       Delete(sampleURL) ~> sealRoute(saveLastEntrancePath) ~> check {
//         status === MethodNotAllowed
//       }
//       Head(sampleURL) ~> sealRoute(saveLastEntrancePath) ~> check {
//         status === MethodNotAllowed
//       }
//       Options(sampleURL) ~> sealRoute(saveLastEntrancePath) ~> check {
//         status === MethodNotAllowed
//       }
//
//     }
//
//     "return a response to a valid request" in {
//
//       val dni = randomString
//       println(dni)
//
//       Get(s"http://localhost:8080/savelastentrance?dni=$dni") ~> sealRoute(saveLastEntrancePath) ~> check {
//         Thread.sleep(servicesTimeout)
//         status === OK
//         LastEntranceDate.query(dni) foreach {
//           case Some(selfEmployee) => assert(true)
//           case None => assert(false)
//
//         }
//       }
//
//     }
//
//   }
//
// }
