/*
package com.arlsura.afiliacion.services.code.services

import org.specs2.mutable.Specification
import spray.testkit.Specs2RouteTest
import spray.http.StatusCodes._

/**
 * Created by john on 24/11/14.
 */
class ClientMatchesCodeServiceSpecs extends Specification with Specs2RouteTest with ClientMatchesCodeService {

  def actorRefFactory = system

  val path = "clientmatchescode"

  val sampleURL = s"http://localhost:8080/$path?dni=XXXXXXXXXXX&code=XXXXXXXXXXXXXXXX"

  val servicesTimeout : Long = 3000

  "The service" should {

    "return a MethodNotAllowed error for request distinct than GET" in {

      Put(sampleURL) ~> sealRoute(clientMatchesCodeActorPath) ~> check {
        status === MethodNotAllowed
      }
      Post(sampleURL) ~> sealRoute(clientMatchesCodeActorPath) ~> check {
        status === MethodNotAllowed
      }
      Delete(sampleURL) ~> sealRoute(clientMatchesCodeActorPath) ~> check {
        status === MethodNotAllowed
      }
      Head(sampleURL) ~> sealRoute(clientMatchesCodeActorPath) ~> check {
        status === MethodNotAllowed
      }
      Options(sampleURL) ~> sealRoute(clientMatchesCodeActorPath) ~> check {
        status === MethodNotAllowed
      }

    }

    "return a response to a valid request" in {

      Get(s"http://localhost:8080/$path?dni=XXXXXXXXXXXXXXXXX&code=XXXXXXXXXXXXXX") ~> sealRoute(clientMatchesCodeActorPath) ~> check {
        Thread.sleep(servicesTimeout);
        status === OK
      }

      Get(s"http://localhost:8080/$path?dni=N123456789&code=XXXXXXXXXXXXXX") ~> sealRoute(clientMatchesCodeActorPath) ~> check {
        Thread.sleep(servicesTimeout);
        status === OK
      }

      Get(s"http://localhost:8080/$path?dni=N123456789&code=1234") ~> sealRoute(clientMatchesCodeActorPath) ~> check {
        Thread.sleep(servicesTimeout);
        status === OK
      }

    }

  }

}
*/ 