/*
package com.arlsura.afiliacion.services.code.services

import org.specs2.mutable.Specification
import spray.testkit.Specs2RouteTest
import spray.http.StatusCodes._

class ClientHasCodeFromCommercialOfficeServiceSpecs extends Specification with Specs2RouteTest with ClientHasCodeFromCommercialOfficeService {

  def actorRefFactory = system

  val path = "hascommercialcode"

  val sampleURL = s"http://localhost:8080/$path?dni=XXXXXXXXXXX"

  val servicesTimeout : Long = 3000

  "The service" should {

    "return a MethodNotAllowed error for request distinct than GET" in {

      Put(sampleURL) ~> sealRoute(clientHasCodeFromCommercialOfficePath) ~> check {
        status === MethodNotAllowed
      }
      Post(sampleURL) ~> sealRoute(clientHasCodeFromCommercialOfficePath) ~> check {
        status === MethodNotAllowed
      }
      Delete(sampleURL) ~> sealRoute(clientHasCodeFromCommercialOfficePath) ~> check {
        status === MethodNotAllowed
      }
      Head(sampleURL) ~> sealRoute(clientHasCodeFromCommercialOfficePath) ~> check {
        status === MethodNotAllowed
      }
      Options(sampleURL) ~> sealRoute(clientHasCodeFromCommercialOfficePath) ~> check {
        status === MethodNotAllowed
      }

    }

    "return a response to a valid request" in {

      Get(s"http://localhost:8080/$path?dni=XXXXXXXXXXXXXXXXX") ~> sealRoute(clientHasCodeFromCommercialOfficePath) ~> check {
        Thread.sleep(servicesTimeout);
        status === OK
      }

      Get(s"http://localhost:8080/$path?dni=N123456789") ~> sealRoute(clientHasCodeFromCommercialOfficePath) ~> check {
        Thread.sleep(servicesTimeout);
        status === OK
      }

    }

  }

}
*/ 