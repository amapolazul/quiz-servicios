//package com.arlsura.afiliacion.services.documento.selfemployee
//
//import org.scalatest.FlatSpec
//
///**
// * Created by john on 13/11/14.
// */
//class ClientWithSelfEmployeeSpecs extends FlatSpec {
//
//  "A client" should "have some self employees" in {
//    val hasSelfEmployees = ClientWithSelfEmployee.hasSelfEmployees("NI", "890903407")
//    assert(hasSelfEmployees)
//  }
//
//  it should "NOT have any self employees" in {
//    val hasSelfEmployees = ClientWithSelfEmployee.hasSelfEmployees("NI", "XXXXX")
//    assert(!hasSelfEmployees)
//  }
//
//}
