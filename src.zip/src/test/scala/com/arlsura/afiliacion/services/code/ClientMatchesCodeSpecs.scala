/*
package com.arlsura.afiliacion.services.code

import org.scalatest.FlatSpec
import scala.concurrent.ExecutionContext.Implicits.global

class ClientMatchesCodeSpecs extends FlatSpec {

  "Operation codeMatches" should "return that the code does not match the code of the DNI of the client" in {
    ClientMatchesCode.codeMatches("XXXXXXXXXXXXX", "XXXXXXXXXX") foreach {
      case Some(result) => assert(false)
      case None =>
    }
  }

  "Operation codeMatches" should "return that the code does not match the code of the DNI of the client when there is no code for that DNI" in {
    ClientMatchesCode.codeMatches("N123456789", "XXXXXXXXXX") foreach {
      case Some(result) => assert(false)
      case None =>
    }
  }

  "Operation codeMatches" should "return that the code matches the code of the DNI of the client" in {
    ClientMatchesCode.codeMatches("N123456789", "1234") foreach {
      case None => assert(false)
      case Some(_) =>
    }
  }

}
*/ 