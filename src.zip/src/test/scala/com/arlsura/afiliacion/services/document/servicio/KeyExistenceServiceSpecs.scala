//package com.arlsura.afiliacion.services.documento.servicio
//
//import com.arlsura.afiliacion.services.orchestrator.ARLSuraServiceRoute
//import org.specs2.mutable.Specification
//import spray.testkit.Specs2RouteTest
//import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller._
//import spray.http.StatusCodes._
//
///**
// * Created by Jesús Martínez on 14/11/14.
// */
//class KeyExistenceServiceSpecs extends Specification with Specs2RouteTest with ARLSuraServiceRoute {
//  def actorRefFactory = system
//  val route = "http://localhost:8080/sura/arl/rest/keyValidator"
//
//  "The service" should {
//    "return a MethodNotAllowed error for request distinct than GET" in {
//      Put(s"$route?document=x") ~> sealRoute(suraServiceRoutes) ~> check {
//        status === MethodNotAllowed
//      }
//
//      Post(s"$route?document=x") ~> sealRoute(suraServiceRoutes) ~> check {
//        status === MethodNotAllowed
//      }
//
//      Delete(s"$route?document=x") ~> sealRoute(suraServiceRoutes) ~> check {
//        status === MethodNotAllowed
//      }
//
//      Head(s"$route?document=x") ~> sealRoute(suraServiceRoutes) ~> check {
//        status === MethodNotAllowed
//      }
//    }
//
//    "leave GETs request to other resources past unhandled" in {
//      Get("http://localhost:8080/somePath") ~> suraServiceRoutes ~> check {
//        handled must beFalse
//      }
//    }
//
//    "return a response OK to a valid request" in {
//
////      Get(s"$route?document=x") ~> sealRoute(suraServiceRoutes) ~> check {
////        status === OK
////        responseAs[GeneralJsonResponseData] === GeneralJsonResponseData(1, "2", "hola")
////      }
//
////      Get(s"$route?document=N823456789&digit=5") ~> sealRoute(suraServiceRoutes) ~> check {
////        status === OK
////        responseAs[ValidationResponse] === ValidationResponse(true)
////      }
//    }
//  }
//}
