//package com.arlsura.afiliacion.services.documento.selfemployee
//
//import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.GeneralJsonResponseData
//import org.specs2.mutable.Specification
//import spray.testkit.Specs2RouteTest
//import spray.http.StatusCodes._
//
///**
// * Created by john on 13/11/14.
// */
//class ClientWithSelfEmployeeServiceSpecs extends Specification with Specs2RouteTest with ClientWithSelfEmployeeService {
//
//  def actorRefFactory = system
//
//  val sampleURL = "http://localhost:8080/selfemployee?idType=NI&identification=XXXXXXXXXX"
//  val servicesTimeout : Long = 3000
//
//  "The service" should {
//
//    "return a MethodNotAllowed error for request distinct than GET" in {
//      Put(sampleURL) ~> sealRoute(selfemployeePath) ~> check {
//        status === MethodNotAllowed
//      }
//      Post(sampleURL) ~> sealRoute(selfemployeePath) ~> check {
//        status === MethodNotAllowed
//      }
//      Delete(sampleURL) ~> sealRoute(selfemployeePath) ~> check {
//        status === MethodNotAllowed
//      }
//      Head(sampleURL) ~> sealRoute(selfemployeePath) ~> check {
//        status === MethodNotAllowed
//      }
//      Options(sampleURL) ~> sealRoute(selfemployeePath) ~> check {
//        status === MethodNotAllowed
//      }
//    }
//
//    "return a response OK to a valid request" in {
//
//      Get("http://localhost:8080/selfemployee?idType=CC&identification=99999999999999") ~> sealRoute(selfemployeePath) ~> check {
//        Thread.sleep(servicesTimeout);
//        status === OK
//        responseAs[GeneralJsonResponseData] === GeneralJsonResponseData(
//          status = 200,
//          message = "OK",
//          data = Some(Map {
//            "hasSelfEmployees" -> false
//          })
//        )
//      }
//
//      Get("http://localhost:8080/selfemployee?idType=NI&identification=890903407") ~> sealRoute(selfemployeePath) ~> check {
//        Thread.sleep(servicesTimeout);
//        status === OK
//        responseAs[GeneralJsonResponseData] === GeneralJsonResponseData(
//          status = 200,
//          message = "OK",
//          data = Some(Map {
//            "hasSelfEmployees" -> true
//          })
//        )
//      }
//
//    }
//
//  }
//
//}
