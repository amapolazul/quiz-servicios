/*package com.arlsura.afiliacion.services.independientes.mongo

import org.joda.time.DateTime
import org.scalatest.FlatSpec
import scala.concurrent.ExecutionContext.Implicits.global

/**
 * Pruebas de LastEntranceDate
 * Created by john on 21/11/14.
 */
class LastEntranceDateSpecs extends FlatSpec {

  "Query Method in DAO Facade LastEntranceDate" should "not return any last entrance date" in {
    LastEntranceDate.query("XXXXXXXXXXXXXX") foreach {
      case Some(selfEmployee) => assert(false)
      case None => assert(true)
    }
  }

  "Query Method in DAO Facade LastEntranceDate" should "return some last entrance date" in {
    LastEntranceDate.query("N890903407") foreach {
      case Some(selfEmployee) => assert(true)
      case None => assert(false)
    }
  }

  "Save Method in DAO Facade LastEntranceDate" should "save a last entrance date" in {
    val datetime = new DateTime()
    val dni = "someDNI"
    LastEntranceDate.save(dni, datetime)
    LastEntranceDate.query(dni) foreach {
      case Some(selfEmployee) => assert(true)
      case None => assert(false)
    }
  }

}*/
