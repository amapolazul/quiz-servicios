//package com.arlsura.afiliacion.services.captcha
//
//import com.arlsura.afiliacion.bussiness.HandlerSupport.ServiceHandlerResponse
//import com.arlsura.afiliacion.services.captcha.CaptchaJsonMarshaller.{ CaptchaServiceRequest, CaptchaServiceResponse }
//import com.google.inject.{ Injector, Guice, AbstractModule }
//import com.typesafe.scalalogging.LazyLogging
//import net.codingwell.scalaguice.ScalaModule
//import org.scalatest.mock.MockitoSugar
//import org.scalatest.{ BeforeAndAfter, FunSuite }
//import net.codingwell.scalaguice.InjectorExtensions._
//import scala.concurrent.Future
//import scala.concurrent.ExecutionContext.Implicits.global
//
///**
// * Prueba de CaptchaServiceHandler
// */
//class CaptchaServiceHandlerTest extends FunSuite with BeforeAndAfter with LazyLogging {
//
//  private[ CaptchaServiceHandlerTest ] val injector: Injector = Guice.createInjector( new CaptchaServiceHandlerTestModule() )
//
//  test( "sending empty input returns unsuccessful validation result" ) {
//    //    lazy val handler: CaptchaServiceHandler = injector.instance[ CaptchaServiceHandler ]
//    //    val futureResponse: Future[ ServiceHandlerResponse ] = handler.executeValidation( CaptchaServiceHandlerTestIO.emptyInput )
//    //    futureResponse map {
//    //      response =>
//    //        assert( response.isRight )
//    //        val responseData: CaptchaServiceResponse = response.right.get.data.asInstanceOf[ Option[ CaptchaServiceResponse ] ].get
//    //        assert( !responseData.success )
//    //    }
//  }
//
//  test( "sending nice input returns successful validation result" ) {
//    //    lazy val handler: CaptchaServiceHandler = injector.instance[ CaptchaServiceHandler ]
//    //    val futureResponse: Future[ ServiceHandlerResponse ] = handler.executeValidation( CaptchaServiceHandlerTestIO.niceInput )
//    //    futureResponse map {
//    //      response =>
//    //        assert( response.isRight )
//    //        val responseData: CaptchaServiceResponse = response.right.get.data.asInstanceOf[ Option[ CaptchaServiceResponse ] ].get
//    //        assert( responseData.success )
//    //    }
//  }
//
//}
//
///**
// * Modulo para la inyeccion con juice del mock de GoogleReCaptchaService
// */
//class CaptchaServiceHandlerTestModule extends AbstractModule with ScalaModule with MockitoSugar {
//
//  import org.mockito.Mockito._
//
//  private def setupEmptyCaptchaDataScenario( service: GoogleReCaptchaService ): Unit = {
//    val response: Future[ CaptchaServiceResponse ] = CaptchaServiceHandlerTestIO.createSimpleResponse( false )
//    when( service.validate( CaptchaServiceHandlerTestIO.emptyInput ) ).thenReturn( response )
//  }
//
//  private def setupOkCaptchaDataScenario( service: GoogleReCaptchaService ): Unit = {
//    val response: Future[ CaptchaServiceResponse ] = CaptchaServiceHandlerTestIO.createSimpleResponse( true )
//    when( service.validate( CaptchaServiceHandlerTestIO.niceInput ) ).thenReturn( response )
//  }
//
//  override def configure(): Unit = {
//    val reCaptchaServiceMock: GoogleReCaptchaService = mock[ GoogleReCaptchaService ]
//    setupEmptyCaptchaDataScenario( reCaptchaServiceMock )
//    setupOkCaptchaDataScenario( reCaptchaServiceMock )
//    bind[ GoogleReCaptchaService ] toInstance reCaptchaServiceMock
//  }
//
//}
//
//object CaptchaServiceHandlerTestIO {
//  val emptyString: String = ""
//  val emptyInput: CaptchaServiceRequest = createSimpleRequest( emptyString )
//  val niceString: String = "5fJvxA-MstGfEjqaev86YKNxiyN1LahZaQFZBLxbJslfZyIM5U90KNwFbpzSio-N"
//  val niceInput: CaptchaServiceRequest = createSimpleRequest( niceString )
//
//  def createSimpleRequest( captchaAnswer: String ): CaptchaServiceRequest = CaptchaServiceRequest( captchaResponse = captchaAnswer, "" )
//
//  def createSimpleResponse( success: Boolean ): Future[ CaptchaServiceResponse ] = Future.successful( CaptchaServiceResponse( success ) )
//}
