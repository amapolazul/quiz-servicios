//package com.arlsura.afiliacion.services.document.validation
//
//import org.scalatest.FlatSpec
//import scala.util.Random
//
///**
// * Created by root on 1/10/14.
// */
//class ValidatorSpecs extends FlatSpec {
//  private val validator = new Validator()
//  "A Validator" should "return false when the input doesn't matches an alien card id, a citizen card id, a passport or a NIT" in {
//    assert( ( ( 'a' to 'z' ).toSet - ( 'c', 'p', 'n' ) ) forall ( s => !validator.validate( s + "0" * 15 ) ) )
//  }
//
//  it should "return false when a NIT starts with with something different than 7, 8 or 9" in {
//    assert( ( 1 to 10 ).toSet - ( 7, 8, 9 ) forall ( d => !validator.validate( s"NI$d${"0" * 7}" ) ) )
//  }
//
//  it should "return false when an alien card starts with zero" in {
//    assert( !validator.validate( s"CE0${1 * 5}" ) )
//  }
//
//  it should "return false when a citizen card starts with zero" in {
//    assert( !validator.validate( s"CC0${1 * 5}" ) )
//  }
//
//  it should "calculate correctly the validation digit of a NIT" in {
//    assert( validator.validate( "NI800082019", Some( "2" ) ) )
//    assert( validator.validate( "NI890900197", Some( "3" ) ) )
//    assert( validator.validate( "NI890916911", Some( "6" ) ) )
//  }
//
//  it should "return false when an alien card id is empty" in {
//    assert( !validator.validate( "CE" ) )
//  }
//
//  it should "return false when a citizen card id is empty" in {
//    assert( !validator.validate( "CC" ) )
//  }
//
//  it should "return false when a passport is empty" in {
//    assert( !validator.validate( "PA" ) )
//  }
//
//  it should "return false when a NIT is empty" in {
//    assert( !validator.validate( "NI" ) )
//  }
//
//  it should "return false when an alien card id has non-numeric characters" in {
//    assert( !validator.validate( s"CEx${( for ( _ <- 1 to 6 ) yield Random.nextPrintableChar() ).mkString}" ) )
//  }
//
//  it should "return false when an citizen card id has non-numeric characters" in {
//    assert( !validator.validate( s"CCx${( for ( _ <- 1 to 9 ) yield Random.nextPrintableChar() ).mkString}" ) )
//  }
//
//  it should "return false when a passport has non accepted characters" in {
//    assert( !validator.validate( s"PA${for ( _ <- 1 to Random.nextInt( 16 ) ) yield Random.nextPrintableChar()}?" ) )
//  }
//
//  it should "return false when a NIT has non-numeric characters" in {
//    assert( !validator.validate( s"NIx${( for ( _ <- 1 to 8 ) yield Random.nextPrintableChar() ).mkString}" ) )
//  }
//
//  it should "return false when an alien card id has more than 7 characters" in {
//    assert( !validator.validate( s"CE${( for { _ <- 1 to 8 } yield Random.nextInt( 9 ) ).mkString}" ) )
//  }
//
//  it should "return false when a citizen card id has 9, less than 5 or more than 11 digits" in {
//    assert( !validator.validate( s"CC${( for { _ <- 1 until 5 } yield Random.nextInt( 9 ) ).mkString}" ) )
//    assert( !validator.validate( s"CC${( for { _ <- 1 to 12 } yield Random.nextInt( 9 ) ).mkString}" ) )
//    assert( !validator.validate( s"CC${( for { _ <- 1 to 9 } yield Random.nextInt( 9 ) ).mkString}" ) )
//  }
//
//  it should "return false when a passport has more than 17 characters" in {
//    assert( !validator.validate( s"PA${( for { _ <- 1 to 18 } yield Random.nextInt( 9 ) ).mkString}" ) )
//  }
//
//  it should "return false when a NIT has a number of digits distinct than 9" in {
//    assert( !validator.validate( s"NI${( for { _ <- 1 until 9 } yield Random.nextInt( 9 ) ).mkString}" ) )
//    assert( !validator.validate( s"NI${( for { _ <- 1 to 10 } yield Random.nextInt( 9 ) ).mkString}" ) )
//  }
//
//  it should "return false when a civil registry has a non allowed length" in {
//    assert( !validator.validate( s"RC${( for { _ <- 1 to 7 } yield Random.nextInt( 9 ) ).mkString}" ) )
//    assert( !validator.validate( s"RC${( for { _ <- 1 to 9 } yield Random.nextInt( 9 ) ).mkString}" ) )
//    assert( !validator.validate( s"RC${( for { _ <- 1 to 12 } yield Random.nextInt( 9 ) ).mkString}" ) )
//  }
//
//  it should "return false when a civil registry has non numeric characters" in {
//    assert( !validator.validate( s"RC${( for { _ <- 1 to 8 } yield Random.nextPrintableChar() ).mkString}" ) )
//    assert( !validator.validate( s"RC${( for { _ <- 1 to 10 } yield Random.nextPrintableChar() ).mkString}" ) )
//    assert( !validator.validate( s"RC${( for { _ <- 1 to 11 } yield Random.nextPrintableChar() ).mkString}" ) )
//  }
//
//  it should "return true when a civil registry is well formed" in {
//    assert( validator.validate( s"RC${( for { _ <- 1 to 8 } yield Random.nextInt( 9 ) ).mkString}" ) )
//    assert( validator.validate( s"RC${( for { _ <- 1 to 10 } yield Random.nextInt( 9 ) ).mkString}" ) )
//    assert( validator.validate( s"RC${( for { _ <- 1 to 11 } yield Random.nextInt( 9 ) ).mkString}" ) )
//  }
//
//  it should "return false when a diplomatic card has non numeric characters" in {
//    assert( !validator.validate( s"CD${( for { _ <- 1 to Random.nextInt( 19 ) + 1 } yield Random.nextPrintableChar() ).mkString}" ) )
//  }
//
//  it should "return false when a diplomatic card is empty" in {
//    assert( !validator.validate( "CD" ) )
//  }
//
//  it should "return false when a diplomatic card has more than 20 characters" in {
//    assert( !validator.validate( s"CD${( for { _ <- 1 to Random.nextInt( 21 ) + 21 } yield Random.nextInt( 9 ) ).mkString}" ) )
//  }
//
//  it should "return true when a diplomatic card is well formed" in {
//    assert( validator.validate( s"CD${( for { _ <- 1 to Random.nextInt( 19 ) + 1 } yield Random.nextInt( 9 ) ).mkString}" ) )
//  }
//
//  it should "return false when an identity card has an invalid length" in {
//    assert( !validator.validate( s"TI${Random.nextInt( 8 ) + 1}${( for { _ <- 1 to Random.nextInt( 8 ) } yield Random.nextInt( 9 ) ).mkString}" ) )
//    assert( !validator.validate( s"TI${Random.nextInt( 8 ) + 1}${( for { _ <- 1 to 11 } yield Random.nextInt( 9 ) ).mkString}" ) )
//  }
//
//  it should "return false when an identity card starts with zero" in {
//    assert( !validator.validate( s"TI0${( for { _ <- 1 to 9 } yield Random.nextInt( 9 ) ).mkString}" ) )
//    assert( !validator.validate( s"TI0${( for { _ <- 1 to 10 } yield Random.nextInt( 9 ) ).mkString}" ) )
//  }
//
//  it should "return false when an identity card has non numeric characters" in {
//    assert( !validator.validate( s"TI${Random.nextInt( 8 ) + 1}${( for { _ <- 1 to 9 } yield Random.nextPrintableChar() ).mkString}" ) )
//    assert( !validator.validate( s"TI${Random.nextInt( 8 ) + 1}${( for { _ <- 1 to 10 } yield Random.nextPrintableChar() ).mkString}" ) )
//  }
//
//  it should "return true when an identity card is well formed" in {
//    assert( validator.validate( s"TI${Random.nextInt( 8 ) + 1}${( for { _ <- 1 to 9 } yield Random.nextInt( 9 ) ).mkString}" ) )
//    assert( validator.validate( s"TI${Random.nextInt( 8 ) + 1}${( for { _ <- 1 to 10 } yield Random.nextInt( 9 ) ).mkString}" ) )
//  }
//
//  it should "return true when an alien card id is well formed" in {
//    assert( validator.
//      validate( s"CE${Random.nextInt( 8 ) + 1}${( for ( _ <- 0 until Random.nextInt( 6 ) ) yield Random.nextInt( 9 ) ).mkString}" ) )
//  }
//
//  it should "return true when a citizen card id is well formed" in {
//    def idOfSize( n: Int ) = s"CC${Random.nextInt( 8 ) + 1}${( for ( _ <- 1 to n - 1 ) yield Random.nextInt( 9 ) ).mkString}"
//    val testSizes = List( 6, 7, 8, 10 )
//
//    assert( testSizes.forall( s => validator.validate( idOfSize( s ) ) ) )
//  }
//
//  it should "return true when a NIT is well formed" in {
//    assert( validator.validate( s"NI8${( for ( _ <- 1 to 8 ) yield Random.nextInt( 9 ) ).mkString}" ) )
//    assert( validator.validate( s"NI9${( for ( _ <- 1 to 8 ) yield Random.nextInt( 9 ) ).mkString}" ) )
//    assert( validator.validate( s"NI7${( for ( _ <- 1 to 8 ) yield Random.nextInt( 9 ) ).mkString}" ) )
//  }
//
//  it should "return true when a passport is well formed" in {
//    assert( validator.validate( s"PA${
//      ( for ( _ <- 0 until 16 ) yield {
//        val char = Random.nextPrintableChar()
//        if ( !char.isLetterOrDigit ) '0'
//        else char
//      } ).mkString
//    }" ) )
//  }
//}
