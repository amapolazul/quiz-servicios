//package com.arlsura.afiliacion.services.independientes.mongo.services
//
//import org.specs2.mutable.Specification
//import spray.testkit.Specs2RouteTest
//import com.arlsura.afiliacion.json.marshallers.ARLJsonMarshaller.GeneralJsonResponseData
//import spray.http.StatusCodes._
//
///**
// * Created by john on 21/11/14.
// */
//class LastEntranceDateServiceSpecs extends Specification with Specs2RouteTest with LastEntranceDateService {
//
//  def actorRefFactory = system
//
//  val sampleURL = "http://localhost:8080/lastentrance?dni=XXXXXXXXXXX"
//
//  val servicesTimeout : Long = 3000
//
//  "The service" should {
//
//    "return a MethodNotAllowed error for request distinct than GET" in {
//      Put(sampleURL) ~> sealRoute(lastEntrancePath) ~> check {
//        status === MethodNotAllowed
//      }
//      Post(sampleURL) ~> sealRoute(lastEntrancePath) ~> check {
//        status === MethodNotAllowed
//      }
//      Delete(sampleURL) ~> sealRoute(lastEntrancePath) ~> check {
//        status === MethodNotAllowed
//      }
//      Head(sampleURL) ~> sealRoute(lastEntrancePath) ~> check {
//        status === MethodNotAllowed
//      }
//      Options(sampleURL) ~> sealRoute(lastEntrancePath) ~> check {
//        status === MethodNotAllowed
//      }
//
//    }
//
//    "return a response to a valid request" in {
//
//      Get("http://localhost:8080/lastentrance?dni=XXXXXXXXXXXXXXXXX") ~> sealRoute(lastEntrancePath) ~> check {
//        Thread.sleep(servicesTimeout);
//        status === OK
//        responseAs[GeneralJsonResponseData] === GeneralJsonResponseData(
//          status = 200,
//          message = "OK",
//          data = Some(Map("firstEntrance" -> true))
//        )
//      }
//
//      Get("http://localhost:8080/lastentrance?dni=N890903407") ~> sealRoute(lastEntrancePath) ~> check {
//        Thread.sleep(servicesTimeout);
//        status === OK
//      }
//
//    }
//
//  }
//
//}
