/*
package com.arlsura.afiliacion.services.code

import org.scalatest.FlatSpec
import scala.concurrent.ExecutionContext.Implicits.global

class ClientHasCodeFromCommercialOfficeSpecs extends FlatSpec {

  "Operation hasCommercialCode" should "return that there is no code generated in commercial area" in {
    ClientHasCodeFromCommercialOffice.hasCommercialCode("XXXXXXXXXXXXXX") foreach {
      case Some(result) => assert(false)
      case None =>
    }
  }

  "Operation hasCommercialCode" should "return that there is a code generated in commercial area" in {
    ClientHasCodeFromCommercialOffice.hasCommercialCode("N123456789") foreach {
      case None => assert(false)
      case Some(_) =>
    }
  }

}
*/ 